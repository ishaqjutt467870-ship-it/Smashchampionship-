import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

export interface LiveNewsArticle {
  id: string;
  title: string;
  summary: string;
  source: string;
  publishedAt: string;
  url: string;
  category: string;
}

function decodeXmlEntities(input: string): string {
  return input
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/<[^>]+>/g, '')
    .trim();
}

async function fetchRealBadmintonRss(category: string): Promise<LiveNewsArticle[]> {
  const queryMap: Record<string, string> = {
    bwf: 'BWF World Tour badminton results',
    rankings: 'BWF world badminton rankings Viktor Axelsen An Se Young',
    tournaments: 'badminton Open championship finals tournament',
    all: 'badminton BWF World Tour championship',
  };
  const q = encodeURIComponent(queryMap[category] || queryMap.all);
  const rssUrl = `https://news.google.com/rss/search?q=${q}&hl=en-US&gl=US&ceid=US:en`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(rssUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'SmashChampionship/3.0',
      },
    });
    if (!res.ok) {
      throw new Error(`RSS feed responded with HTTP ${res.status}`);
    }
    const xml = await res.text();
    const itemMatches = xml.match(/<item>[\s\S]*?<\/item>/g) || [];
    return itemMatches.slice(0, 12).map((itemXml, index) => {
      const titleMatch = itemXml.match(/<title>([\s\S]*?)<\/title>/);
      const linkMatch = itemXml.match(/<link>([\s\S]*?)<\/link>/);
      const dateMatch = itemXml.match(/<pubDate>([\s\S]*?)<\/pubDate>/);
      const sourceMatch = itemXml.match(/<source[^>]*>([\s\S]*?)<\/source>/);
      const descMatch = itemXml.match(/<description>([\s\S]*?)<\/description>/);

      const rawTitle = decodeXmlEntities(titleMatch?.[1] || 'Badminton Update');
      const sourceName = decodeXmlEntities(sourceMatch?.[1] || 'World Badminton Wire');
      const cleanTitle = rawTitle.replace(new RegExp(`\\s*-\\s*${sourceName}$`, 'i'), '').trim();
      const summaryText = decodeXmlEntities(descMatch?.[1] || '').slice(0, 220);

      return {
        id: `rss-${index}-${Date.now()}`,
        title: cleanTitle || rawTitle,
        summary: summaryText || `Latest coverage via ${sourceName}.`,
        source: sourceName,
        publishedAt: dateMatch?.[1] ? new Date(dateMatch[1]).toLocaleDateString() : 'Recent',
        url: (linkMatch?.[1] || 'https://bwfworldtour.bwfbadminton.com/').trim(),
        category: category === 'all' ? 'BWF & Global' : category.toUpperCase(),
      };
    });
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchBadmintonNewsWithGemini(category: string): Promise<{
  articles: LiveNewsArticle[];
  groundingSources: Array<{ title: string; url: string }>;
  provider: string;
} | null> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const topicPrompt: Record<string, string> = {
    bwf: 'latest BWF World Tour badminton tournament results, champions, and match highlights',
    rankings: 'latest BWF World Badminton Rankings movement for singles and doubles stars',
    tournaments: 'upcoming and recent Super 1000, Super 750, Thomas & Uber Cup, or World Championships badminton news',
    all: 'latest real-world international badminton news, BWF World Tour results, rankings, and upcoming events',
  };

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `Find 6 real, current news stories about: ${
      topicPrompt[category] || topicPrompt.all
    }. Summarize each concisely using verified search results only.`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            summary: { type: Type.STRING },
            source: { type: Type.STRING },
            publishedAt: { type: Type.STRING },
            category: { type: Type.STRING },
            url: { type: Type.STRING },
          },
          required: ['title', 'summary', 'source'],
        },
      },
    },
  });

  const groundingChunks =
    response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const groundingSources = groundingChunks
    .map((chunk) => ({
      title: chunk.web?.title || 'Verified Source',
      url: chunk.web?.uri || '',
    }))
    .filter((s) => Boolean(s.url));

  const parsed = JSON.parse((response.text ?? '[]').trim()) as Array<
    Partial<LiveNewsArticle>
  >;

  if (!Array.isArray(parsed) || parsed.length === 0) return null;

  const articles: LiveNewsArticle[] = parsed.map((item, idx) => ({
    id: `gemini-news-${idx}-${Date.now()}`,
    title: item.title || 'Badminton Update',
    summary: item.summary || '',
    source: item.source || groundingSources[idx]?.title || 'Live Search',
    publishedAt: item.publishedAt || 'Latest',
    url:
      item.url && item.url.startsWith('http')
        ? item.url
        : groundingSources[idx]?.url ||
          groundingSources[0]?.url ||
          'https://bwfbadminton.com/news/',
    category: item.category || (category === 'all' ? 'World Tour' : category.toUpperCase()),
  }));

  return {
    articles,
    groundingSources,
    provider: 'google-search-grounding',
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      service: 'smash-championship',
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/news/badminton', async (req, res) => {
    const category = String(req.query.category || 'all').toLowerCase();
    try {
      const geminiNews = await fetchBadmintonNewsWithGemini(category).catch(() => null);
      if (geminiNews && geminiNews.articles.length > 0) {
        return res.json({
          ok: true,
          fetchedAt: new Date().toISOString(),
          ...geminiNews,
        });
      }

      const rssArticles = await fetchRealBadmintonRss(category);
      return res.json({
        ok: true,
        fetchedAt: new Date().toISOString(),
        provider: 'live-rss-feed',
        groundingSources: [],
        articles: rssArticles,
      });
    } catch (error) {
      return res.status(503).json({
        ok: false,
        error:
          error instanceof Error
            ? error.message
            : 'Unable to fetch live badminton news. Check internet connectivity.',
      });
    }
  });

  if (!IS_PROD) {
    process.env.DISABLE_HMR = 'true';
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
      },
      appType: 'spa',
    });

    app.get('/@vite/client', async (_req, res, next) => {
      try {
        const result = await vite.transformRequest('/@vite/client');
        if (!result) return next();
        const patched = result.code
          .replace('await wsTransport.connect(handlers);', 'return;')
          .replace(
            'ws.send(JSON.stringify(data));',
            'if (ws && ws.readyState === 1) ws.send(JSON.stringify(data));'
          );
        res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
        return res.send(patched);
      } catch (err) {
        return next(err);
      }
    });

    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Smash Championship server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
