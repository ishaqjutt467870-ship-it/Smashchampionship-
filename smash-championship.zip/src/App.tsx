import { useState, useEffect, useMemo } from 'react';
import { Header, AppTab } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { TournamentsView } from './components/TournamentsView';
import { PlayerSetup } from './components/PlayerSetup';
import { LeagueMatches } from './components/LeagueMatches';
import { StandingsTable } from './components/StandingsTable';
import { KnockoutStage } from './components/KnockoutStage';
import { CourtManager } from './components/CourtManager';
import { HeadToHeadMatrix } from './components/HeadToHeadMatrix';
import { ChampionPodium } from './components/ChampionPodium';
import { MobileBottomNav } from './components/MobileBottomNav';
import { AndroidProjectModal } from './components/AndroidProjectModal';
import { TournamentShareModal } from './components/TournamentShareModal';
import { PlayerProfileModal } from './components/PlayerProfileModal';
import { LiveCourtScorer } from './components/LiveCourtScorer';
import { DynamicBadmintonBackdrop } from './components/DynamicBadmintonBackdrop';
import { SplashScreen } from './components/SplashScreen';
import { PDFReportModal } from './components/PDFReportModal';
import { SettingsModal } from './components/SettingsModal';
import { PinLockModal } from './components/PinLockModal';
import { ConfirmModal } from './components/ConfirmModal';
import { ThemeWallpaperModal } from './components/ThemeWallpaperModal';
import { AuthSignUpModal } from './components/AuthSignUpModal';
import { QuickMatchModal } from './components/QuickMatchModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { RankingsView } from './components/RankingsView';
import { QRCodeModal } from './components/QRCodeModal';
import { AboutModal } from './components/AboutModal';
import { NewsView } from './components/NewsView';
import { VenueMapView } from './components/VenueMapView';
import { FinanceView } from './components/FinanceView';
import { MediaStudioView } from './components/MediaStudioView';
import { AdminCenterView } from './components/AdminCenterView';
import { OnboardingModal } from './components/OnboardingModal';
import { KnockoutLaunchPayload } from './components/KnockoutStage';
import {
  TournamentState,
  TournamentStore,
  MatchScore,
  MatchFormat,
  TournamentFormatType,
  CompetitionCategory,
  CustomTournamentRules,
  AppLanguage,
  PlayerBio,
  UserAccount,
  WallpaperSettings,
  QuickMatchRecord,
  TournamentAnnouncement,
  MatchScheduleInfo,
  TournamentMatch,
  MatchMetaInfo,
  DoubleElimBracketState,
  ConsolationBracketState,
  DoublesTeam,
  RankingConfig,
  CourtRecord,
  CourtMatchHistoryEntry,
  UserRoleMode,
  VenueLocation,
  FinancialRecord,
  AdminAccount,
  AccessibilitySettings,
} from './types';
import {
  loadTournamentStore,
  saveTournamentStore,
  createDefaultTournamentState,
  generateTournamentId,
  generateFixtures,
  generateNextSwissRoundFixtures,
  autoScheduleMatches,
  calculateStandings,
  DEFAULT_LOGO_URL,
  DEFAULT_RANKING_CONFIG,
  DEFAULT_COURTS,
  formatScore,
  clampPointsPerSet,
  getSuggestedInterval,
  getSuggestedDeuceCap,
} from './utils/tournament';
import { getThemeById, applyThemeToDocument } from './utils/themes';
import { fireConfetti } from './utils/confetti';
import { evaluatePlayerSeeds, buildSmartSeededRoster } from './utils/seeding';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [store, setStore] = useState<TournamentStore>(() => loadTournamentStore());
  const [activeTab, setActiveTab] = useState<AppTab>(() => {
    if (typeof window === 'undefined') return 'dashboard';
    const tabParam = new URLSearchParams(window.location.search).get('tab') as AppTab | null;
    const allowed: AppTab[] = [
      'dashboard',
      'tournaments',
      'history',
      'roster',
      'matches',
      'table',
      'knockout',
      'courts',
      'h2h',
      'rankings',
      'news',
      'venue',
      'finance',
      'studio',
      'admin',
      'live',
    ];
    return tabParam && allowed.includes(tabParam) ? tabParam : 'dashboard';
  });
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [isTutorialOpen, setIsTutorialOpen] = useState<boolean>(
    () => !loadTournamentStore().onboardingDone
  );
  const [lastDarkThemeId, setLastDarkThemeId] = useState<string>(() => {
    const initial = getThemeById(loadTournamentStore().selectedThemeId);
    return initial.mode === 'dark' ? initial.id : 'black-gold-elite';
  });
  const [lastLightThemeId, setLastLightThemeId] = useState<string>(() => {
    const initial = getThemeById(loadTournamentStore().selectedThemeId);
    return initial.mode === 'light' ? initial.id : 'crisp-light';
  });

  const [isLocked, setIsLocked] = useState<boolean>(() => Boolean(store.appPin));
  const [isPinSetupOpen, setIsPinSetupOpen] = useState(false);

  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isPDFModalOpen, setIsPDFModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isThemeStudioOpen, setIsThemeStudioOpen] = useState(false);
  const [themeStudioSection, setThemeStudioSection] = useState<'themes' | 'wallpapers'>('themes');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isQuickMatchOpen, setIsQuickMatchOpen] = useState(false);
  const [isGlobalSearchOpen, setIsGlobalSearchOpen] = useState(false);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);
  const [selectedPlayerId, setSelectedPlayerId] = useState<number | null>(null);
  const [liveMatchId, setLiveMatchId] = useState<string>('');
  const [liveCourtNumber, setLiveCourtNumber] = useState<number>(1);
  const [knockoutLiveMatch, setKnockoutLiveMatch] = useState<KnockoutLaunchPayload | null>(null);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  // Listen for Google Maps quota exhaustion events
  useEffect(() => {
    const onQuotaExceeded = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  // Keyboard shortcut Ctrl+K / Cmd+K for Global Search
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsGlobalSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const activeTheme = useMemo(
    () => getThemeById(store.selectedThemeId),
    [store.selectedThemeId]
  );
  const isDark = activeTheme.mode === 'dark';

  const state: TournamentState = useMemo(() => {
    return (
      store.tournaments.find((t) => t.id === store.activeTournamentId) ||
      store.tournaments[0] ||
      createDefaultTournamentState()
    );
  }, [store.tournaments, store.activeTournamentId]);

  const updateActiveTournament = (
    updater: (prev: TournamentState) => TournamentState
  ) => {
    setStore((prevStore) => ({
      ...prevStore,
      tournaments: prevStore.tournaments.map((t) =>
        t.id === prevStore.activeTournamentId ? updater(t) : t
      ),
    }));
  };

  // Sync active theme palette & dark/light class with DOM
  useEffect(() => {
    applyThemeToDocument(activeTheme);
    localStorage.setItem('smash-theme', activeTheme.mode);
  }, [activeTheme]);

  // Persist multi-tournament store (and legacy 'hbt-state' mirror inside saveTournamentStore)
  useEffect(() => {
    saveTournamentStore(store);
  }, [store]);

  // Toggle global CSS animations flag & Accessibility settings
  useEffect(() => {
    const root = document.documentElement;
    const acc = store.accessibility || { fontScale: 'md', highContrast: false, lowPerfMode: false };
    root.classList.toggle('no-animations', store.animationsEnabled === false || acc.lowPerfMode);
    root.classList.toggle('low-perf-mode', Boolean(acc.lowPerfMode));
    root.classList.toggle('high-contrast', Boolean(acc.highContrast));
    root.classList.remove('font-scale-sm', 'font-scale-md', 'font-scale-lg');
    root.classList.add(`font-scale-${acc.fontScale || 'md'}`);
  }, [store.animationsEnabled, store.accessibility]);

  // Write local auto-backup snapshot whenever enabled
  useEffect(() => {
    if (store.autoBackupEnabled) {
      try {
        localStorage.setItem('smash-auto-backup-snapshot', JSON.stringify(store));
      } catch {
        // ignore quota errors
      }
    }
  }, [store]);

  const handleToggleDark = (nextDark: boolean) => {
    const targetThemeId = nextDark ? lastDarkThemeId : lastLightThemeId;
    setStore((prev) => ({ ...prev, selectedThemeId: targetThemeId }));
  };

  const handleSelectTheme = (themeId: string) => {
    const chosen = getThemeById(themeId);
    if (chosen.mode === 'dark') {
      setLastDarkThemeId(chosen.id);
    } else {
      setLastLightThemeId(chosen.id);
    }
    setStore((prev) => ({ ...prev, selectedThemeId: chosen.id }));
  };

  const handleUpdateWallpaper = (wallpaper: WallpaperSettings) => {
    setStore((prev) => ({ ...prev, wallpaper }));
  };

  const handleSaveUserAccount = (userAccount: UserAccount | null) => {
    setStore((prev) => ({ ...prev, userAccount }));
  };

  const handleSaveQuickMatch = (record: QuickMatchRecord) => {
    setStore((prev) => ({
      ...prev,
      quickMatches: [record, ...(prev.quickMatches || [])].slice(0, 50),
    }));
  };

  const handleDeleteQuickMatch = (id: string) => {
    setStore((prev) => ({
      ...prev,
      quickMatches: (prev.quickMatches || []).filter((q) => q.id !== id),
    }));
  };

  const handleToggleQuickMatchMvp = (id: string) => {
    setStore((prev) => ({
      ...prev,
      quickMatches: (prev.quickMatches || []).map((q) =>
        q.id === id ? { ...q, mvpWinner: !q.mvpWinner } : q
      ),
    }));
  };

  const openThemeStudio = (section: 'themes' | 'wallpapers' = 'themes') => {
    setThemeStudioSection(section);
    setIsThemeStudioOpen(true);
  };

  const activeFormat = state.tournamentFormat || 'round_robin';

  // Generated fixtures respecting round-robin / group-stage / elimination / manual edits
  const baseFixtures = useMemo(() => {
    return generateFixtures(state.players.length, activeFormat, state.manualFixtures);
  }, [state.players.length, activeFormat, state.manualFixtures]);

  const fixtures = useMemo(() => {
    if (!knockoutLiveMatch) return baseFixtures;
    const koMatch: TournamentMatch = {
      id: `ko:${knockoutLiveMatch.knockoutKey}`,
      playerAIndex: knockoutLiveMatch.playerAIndex,
      playerBIndex: knockoutLiveMatch.playerBIndex,
      roundNumber: baseFixtures.length + 1,
    };
    return [koMatch, ...baseFixtures];
  }, [baseFixtures, knockoutLiveMatch]);

  // Live standings with photos, bios & group assignment
  const standings = useMemo(() => {
    return calculateStandings(
      state.players,
      state.results,
      state.scores,
      state.playerPhotos,
      state.playerBios,
      activeFormat,
      state.manualFixtures
    );
  }, [
    state.players,
    state.results,
    state.scores,
    state.playerPhotos,
    state.playerBios,
    activeFormat,
    state.manualFixtures,
  ]);

  const playableFixtures = useMemo(
    () => fixtures.filter((f) => !f.isBye && f.playerBIndex >= 0),
    [fixtures]
  );
  const completedMatchesCount = playableFixtures.filter(
    (m) => state.results[m.id] !== undefined
  ).length;
  const totalMatchesCount = playableFixtures.length;
  const allLeagueMatchesDone =
    totalMatchesCount > 0 && completedMatchesCount === totalMatchesCount;
  const upcomingMatches = useMemo(
    () => playableFixtures.filter((m) => state.results[m.id] === undefined),
    [playableFixtures, state.results]
  );

  const selectedPlayerStats = useMemo(() => {
    if (selectedPlayerId === null) return null;
    return standings.find((s) => s.id === selectedPlayerId) || null;
  }, [selectedPlayerId, standings]);

  // Multi-Tournament Store Handlers
  const handleSelectTournament = (
    id: string,
    navigateTo: 'dashboard' | 'matches' | 'knockout' = 'dashboard'
  ) => {
    setStore((prev) => ({
      ...prev,
      activeTournamentId: id,
      recentTournamentIds: [id, ...(prev.recentTournamentIds || []).filter((x) => x !== id)].slice(0, 6),
    }));
    setLiveMatchId('');
    setActiveTab(navigateTo);
  };

  const handleCreateTournament = (payload: {
    tournamentTitle: string;
    venue: string;
    createdDate: string;
    category: CompetitionCategory;
    tournamentFormat: TournamentFormatType;
    matchFormat: MatchFormat;
    pointsPerSet: number;
    description: string;
  }) => {
    const newId = generateTournamentId();
    const pts = clampPointsPerSet(payload.pointsPerSet);
    const created = createDefaultTournamentState({
      id: newId,
      tournamentTitle: payload.tournamentTitle,
      venue: payload.venue,
      createdDate: payload.createdDate,
      category: payload.category,
      tournamentFormat: payload.tournamentFormat,
      matchFormat: payload.matchFormat,
      description: payload.description,
      customRules: {
        pointsPerSet: pts,
        intervalAt: getSuggestedInterval(pts),
        maxDeuceCap: getSuggestedDeuceCap(pts),
        refereeName: 'Hassan',
      },
      players:
        payload.category === 'singles'
          ? ['Player 1', 'Player 2', 'Player 3', 'Player 4', 'Player 5', 'Player 6']
          : ['Team Falcons', 'Team Vipers', 'Team Titans', 'Team Phoenix', 'Team Raptors', 'Team Cyclones'],
      customLogoUrl: state.customLogoUrl || DEFAULT_LOGO_URL,
    });
    setStore((prev) => ({
      ...prev,
      activeTournamentId: newId,
      tournaments: [created, ...prev.tournaments],
    }));
    setLiveMatchId('');
    setActiveTab('roster');
  };

  const handleUpdateTournamentMeta = (
    id: string,
    payload: {
      tournamentTitle: string;
      venue: string;
      createdDate: string;
      category: CompetitionCategory;
      tournamentFormat: TournamentFormatType;
      matchFormat: MatchFormat;
      pointsPerSet: number;
      description: string;
    }
  ) => {
    const pts = clampPointsPerSet(payload.pointsPerSet);
    setStore((prev) => ({
      ...prev,
      tournaments: prev.tournaments.map((t) =>
        t.id === id
          ? {
              ...t,
              tournamentTitle: payload.tournamentTitle,
              venue: payload.venue,
              createdDate: payload.createdDate,
              category: payload.category,
              tournamentFormat: payload.tournamentFormat,
              matchFormat: payload.matchFormat,
              description: payload.description,
              customRules: {
                refereeName: t.customRules?.refereeName ?? 'Hassan',
                pointsPerSet: pts,
                intervalAt: getSuggestedInterval(pts),
                maxDeuceCap: getSuggestedDeuceCap(pts),
              },
            }
          : t
      ),
    }));
  };

  const handleDuplicateTournament = (id: string) => {
    const source = store.tournaments.find((t) => t.id === id);
    if (!source) return;
    const dupId = generateTournamentId();
    const duplicate: TournamentState = {
      ...source,
      id: dupId,
      tournamentTitle: `${source.tournamentTitle} (Copy)`,
      archived: false,
      results: {},
      scores: {},
      matchMeta: {},
      matchMvps: {},
      doubleElim: {},
      consolationBracket: {},
      semis: {},
      semiScores: {},
      quarters: {},
      quarterScores: {},
      thirdPlaceWinner: null,
      thirdPlaceScore: undefined,
      finalWinner: null,
      finalScore: undefined,
      started: false,
      createdDate: new Date().toISOString(),
    };
    setStore((prev) => ({
      ...prev,
      activeTournamentId: dupId,
      tournaments: [duplicate, ...prev.tournaments],
    }));
  };

  const handleDeleteTournament = (id: string) => {
    setStore((prev) => {
      if (prev.tournaments.length <= 1) return prev;
      const remaining = prev.tournaments.filter((t) => t.id !== id);
      const nextActiveId =
        prev.activeTournamentId === id
          ? (remaining[0].id as string)
          : prev.activeTournamentId;
      return {
        ...prev,
        activeTournamentId: nextActiveId,
        tournaments: remaining,
      };
    });
  };

  const handleReopenTournament = (id: string) => {
    setStore((prev) => ({
      ...prev,
      activeTournamentId: id,
      tournaments: prev.tournaments.map((t) =>
        t.id === id ? { ...t, finalWinner: null } : t
      ),
    }));
    setActiveTab('knockout');
  };

  // Language & PIN Handlers
  const handleSetLanguage = (language: AppLanguage) => {
    setStore((prev) => ({ ...prev, language }));
  };

  const handleSavePin = (newPin: string | null) => {
    setStore((prev) => ({ ...prev, appPin: newPin }));
    if (!newPin) setIsLocked(false);
  };

  const handlePinButtonClick = () => {
    if (store.appPin) {
      setIsLocked(true);
    } else {
      setIsPinSetupOpen(true);
    }
  };

  // Active Tournament Mutation Handlers
  const handleStartTournament = () => {
    updateActiveTournament((prev) => ({ ...prev, started: true }));
    setActiveTab('matches');
  };

  const handleSetPlayers = (newPlayers: string[]) => {
    updateActiveTournament((prev) => {
      const countChanged = prev.players.length !== newPlayers.length;
      return {
        ...prev,
        players: newPlayers,
        ...(countChanged
          ? {
              results: {},
              scores: {},
              matchMeta: {},
              matchMvps: {},
              manualFixtures: undefined,
              doubleElim: {},
              semis: {},
              semiScores: {},
              quarters: {},
              finalWinner: null,
              thirdPlaceWinner: null,
            }
          : {}),
      };
    });
  };

  const handleApplySmartSeeding = () => {
    updateActiveTournament((prev) => {
      const evaluations = evaluatePlayerSeeds(prev.players, standings, store.tournaments);
      const seeded = buildSmartSeededRoster(
        prev.players,
        prev.tournamentFormat || 'round_robin',
        evaluations,
        prev.playerPhotos,
        prev.playerBios
      );
      return {
        ...prev,
        players: seeded.players,
        playerPhotos: seeded.playerPhotos,
        playerBios: seeded.playerBios,
        results: {},
        scores: {},
        matchMvps: {},
        semis: {},
        semiScores: {},
        quarters: {},
        quarterScores: {},
        finalWinner: null,
        finalScore: undefined,
        thirdPlaceWinner: null,
        thirdPlaceScore: undefined,
      };
    });
  };

  const handleSwapPlayers = (indexA: number, indexB: number) => {
    updateActiveTournament((prev) => {
      if (
        indexA < 0 ||
        indexB < 0 ||
        indexA >= prev.players.length ||
        indexB >= prev.players.length
      ) {
        return prev;
      }
      const nextPlayers = [...prev.players];
      [nextPlayers[indexA], nextPlayers[indexB]] = [nextPlayers[indexB], nextPlayers[indexA]];

      const nextPhotos = { ...(prev.playerPhotos || {}) };
      const photoA = nextPhotos[indexA];
      const photoB = nextPhotos[indexB];
      if (photoB) nextPhotos[indexA] = photoB;
      else delete nextPhotos[indexA];
      if (photoA) nextPhotos[indexB] = photoA;
      else delete nextPhotos[indexB];

      const nextBios = { ...(prev.playerBios || {}) };
      const bioA = nextBios[indexA];
      const bioB = nextBios[indexB];
      if (bioB) nextBios[indexA] = bioB;
      else delete nextBios[indexA];
      if (bioA) nextBios[indexB] = bioA;
      else delete nextBios[indexB];

      return {
        ...prev,
        players: nextPlayers,
        playerPhotos: nextPhotos,
        playerBios: nextBios,
        results: {},
        scores: {},
        matchMvps: {},
        semis: {},
        semiScores: {},
        quarters: {},
        quarterScores: {},
        finalWinner: null,
        finalScore: undefined,
        thirdPlaceWinner: null,
        thirdPlaceScore: undefined,
      };
    });
  };

  const handleSetMatchFormat = (format: MatchFormat) => {
    updateActiveTournament((prev) => ({
      ...prev,
      matchFormat: format,
      matchFormats: {},
    }));
  };

  const handleSetMatchItemFormat = (matchId: string, format: MatchFormat) => {
    updateActiveTournament((prev) => ({
      ...prev,
      matchFormats: {
        ...(prev.matchFormats || {}),
        [matchId]: format,
      },
    }));
  };

  const handleSetTournamentFormat = (tournamentFormat: TournamentFormatType) => {
    updateActiveTournament((prev) => ({
      ...prev,
      tournamentFormat,
      manualFixtures: undefined,
      doubleElim: {},
      results: {},
      scores: {},
      matchMeta: {},
      matchMvps: {},
      semis: {},
      semiScores: {},
      quarters: {},
      finalWinner: null,
      thirdPlaceWinner: null,
    }));
  };

  const handleSetCategory = (category: CompetitionCategory) => {
    updateActiveTournament((prev) => ({ ...prev, category }));
  };

  const handleUpdateCustomRules = (customRules: CustomTournamentRules) => {
    updateActiveTournament((prev) => ({ ...prev, customRules }));
  };

  const handleSetMatchMvp = (
    matchId: string,
    playerIndex: number | null,
    tournamentId?: string
  ) => {
    setStore((prevStore) => ({
      ...prevStore,
      tournaments: prevStore.tournaments.map((t) => {
        if (t.id !== (tournamentId || prevStore.activeTournamentId)) return t;
        const nextMvps = { ...(t.matchMvps || {}) };
        if (playerIndex === null) {
          delete nextMvps[matchId];
        } else {
          nextMvps[matchId] = playerIndex;
        }
        return {
          ...t,
          matchMvps: nextMvps,
        };
      }),
    }));
  };

  const handleSetMatchResult = (
    matchId: string,
    winnerIndex: number,
    score?: MatchScore,
    mvpPlayerIndex?: number,
    meta?: MatchMetaInfo
  ) => {
    updateActiveTournament((prev) => {
      const nextMvps = { ...(prev.matchMvps || {}) };
      if (mvpPlayerIndex !== undefined) {
        nextMvps[matchId] = mvpPlayerIndex;
      } else {
        delete nextMvps[matchId];
      }
      return {
        ...prev,
        results: {
          ...prev.results,
          [matchId]: winnerIndex,
        },
        scores: {
          ...(prev.scores || {}),
          ...(score ? { [matchId]: score } : {}),
        },
        matchMeta: meta
          ? {
              ...(prev.matchMeta || {}),
              [matchId]: meta,
            }
          : prev.matchMeta,
        matchMvps: nextMvps,
        semis: {},
        semiScores: {},
        quarters: {},
        finalWinner: null,
        thirdPlaceWinner: null,
      };
    });
  };

  const handleUndoMatchResult = (matchId: string) => {
    updateActiveTournament((prev) => {
      const nextResults = { ...prev.results };
      delete nextResults[matchId];
      const nextScores = { ...(prev.scores || {}) };
      delete nextScores[matchId];
      const nextMeta = { ...(prev.matchMeta || {}) };
      delete nextMeta[matchId];
      const nextMvps = { ...(prev.matchMvps || {}) };
      delete nextMvps[matchId];
      return {
        ...prev,
        results: nextResults,
        scores: nextScores,
        matchMeta: nextMeta,
        matchMvps: nextMvps,
        semis: {},
        semiScores: {},
        quarters: {},
        finalWinner: null,
        thirdPlaceWinner: null,
      };
    });
  };

  const handleSimulateAllRemaining = () => {
    updateActiveTournament((prev) => {
      const nextResults = { ...prev.results };
      const nextScores = { ...(prev.scores || {}) };
      const format = prev.matchFormat || 'bo3';
      const targetPts = prev.customRules?.pointsPerSet ?? 21;
      const randLow = () => Math.max(5, targetPts - Math.floor(Math.random() * 6) - 2);

      fixtures.forEach((match) => {
        if (!match.isBye && match.playerBIndex >= 0 && nextResults[match.id] === undefined) {
          const isPlayerAWinner = Math.random() > 0.5;
          const winnerIndex = isPlayerAWinner ? match.playerAIndex : match.playerBIndex;
          nextResults[match.id] = winnerIndex;

          const itemFormat = prev.matchFormats?.[match.id] || format;
          const s1a = isPlayerAWinner ? targetPts : randLow();
          const s1b = isPlayerAWinner ? randLow() : targetPts;
          const s2a = isPlayerAWinner ? targetPts : randLow();
          const s2b = isPlayerAWinner ? randLow() : targetPts;

          if (itemFormat === 'bo1') {
            nextScores[match.id] = { s1a, s1b };
          } else if (itemFormat === 'bo5') {
            const s3a = isPlayerAWinner ? targetPts : randLow();
            const s3b = isPlayerAWinner ? randLow() : targetPts;
            nextScores[match.id] = { s1a, s1b, s2a, s2b, s3a, s3b };
          } else {
            nextScores[match.id] = { s1a, s1b, s2a, s2b };
          }
        }
      });

      return {
        ...prev,
        results: nextResults,
        scores: nextScores,
      };
    });
  };

  const handleSetQuarterWinner = (
    quarterIndex: number,
    winnerIndex: number,
    score?: MatchScore
  ) => {
    updateActiveTournament((prev) => ({
      ...prev,
      quarters: {
        ...(prev.quarters || {}),
        [quarterIndex]: winnerIndex,
      },
      quarterScores: {
        ...(prev.quarterScores || {}),
        ...(score ? { [quarterIndex]: score } : {}),
      },
      semis: {},
      semiScores: {},
      finalWinner: null,
      finalScore: undefined,
      thirdPlaceWinner: null,
      thirdPlaceScore: undefined,
    }));
  };

  const handleUndoQuarter = (quarterIndex: number) => {
    updateActiveTournament((prev) => {
      const nextQuarters = { ...(prev.quarters || {}) };
      delete nextQuarters[quarterIndex];
      const nextQuarterScores = { ...(prev.quarterScores || {}) };
      delete nextQuarterScores[quarterIndex];
      const nextMvps = { ...(prev.matchMvps || {}) };
      delete nextMvps[`ko:qf-${quarterIndex}`];
      delete nextMvps['ko:sf-0'];
      delete nextMvps['ko:sf-1'];
      delete nextMvps['ko:final'];
      delete nextMvps['ko:third'];
      return {
        ...prev,
        quarters: nextQuarters,
        quarterScores: nextQuarterScores,
        matchMvps: nextMvps,
        semis: {},
        semiScores: {},
        finalWinner: null,
        finalScore: undefined,
        thirdPlaceWinner: null,
        thirdPlaceScore: undefined,
      };
    });
  };

  const handleSetSemiWinner = (
    semiIndex: number,
    winnerIndex: number,
    score?: MatchScore
  ) => {
    updateActiveTournament((prev) => ({
      ...prev,
      semis: {
        ...prev.semis,
        [semiIndex]: winnerIndex,
      },
      semiScores: {
        ...(prev.semiScores || {}),
        ...(score ? { [semiIndex]: score } : {}),
      },
      finalWinner: null,
      finalScore: undefined,
      thirdPlaceWinner: null,
      thirdPlaceScore: undefined,
    }));
  };

  const handleUndoSemi = (semiIndex: number) => {
    updateActiveTournament((prev) => {
      const nextSemis = { ...prev.semis };
      delete nextSemis[semiIndex];
      const nextSemiScores = { ...(prev.semiScores || {}) };
      delete nextSemiScores[semiIndex];
      const nextMvps = { ...(prev.matchMvps || {}) };
      delete nextMvps[`ko:sf-${semiIndex}`];
      delete nextMvps['ko:final'];
      delete nextMvps['ko:third'];
      return {
        ...prev,
        semis: nextSemis,
        semiScores: nextSemiScores,
        matchMvps: nextMvps,
        finalWinner: null,
        finalScore: undefined,
        thirdPlaceWinner: null,
        thirdPlaceScore: undefined,
      };
    });
  };

  const handleSetFinalWinner = (winnerIndex: number, score?: MatchScore) => {
    updateActiveTournament((prev) => ({
      ...prev,
      finalWinner: winnerIndex,
      ...(score ? { finalScore: score } : {}),
    }));
    if (store.animationsEnabled !== false) {
      fireConfetti();
    }
  };

  const handleUndoFinal = () => {
    updateActiveTournament((prev) => {
      const nextMvps = { ...(prev.matchMvps || {}) };
      delete nextMvps['ko:final'];
      return {
        ...prev,
        matchMvps: nextMvps,
        finalWinner: null,
        finalScore: undefined,
      };
    });
  };

  const handleSetThirdPlaceWinner = (winnerIndex: number, score?: MatchScore) => {
    updateActiveTournament((prev) => ({
      ...prev,
      thirdPlaceWinner: winnerIndex,
      ...(score ? { thirdPlaceScore: score } : {}),
    }));
  };

  const handleUndoThirdPlace = () => {
    updateActiveTournament((prev) => {
      const nextMvps = { ...(prev.matchMvps || {}) };
      delete nextMvps['ko:third'];
      return {
        ...prev,
        matchMvps: nextMvps,
        thirdPlaceWinner: null,
        thirdPlaceScore: undefined,
      };
    });
  };

  const handleUpdateAnnouncements = (announcements: TournamentAnnouncement[]) => {
    updateActiveTournament((prev) => ({ ...prev, announcements }));
  };

  const handleUpdateReferees = (referees: string[]) => {
    updateActiveTournament((prev) => ({ ...prev, referees }));
  };

  const handleUpdateMatchSchedule = (matchId: string, info: MatchScheduleInfo) => {
    updateActiveTournament((prev) => ({
      ...prev,
      matchSchedules: {
        ...(prev.matchSchedules || {}),
        [matchId]: info,
      },
    }));
  };

  const handleImportFullStore = (importedStore: TournamentStore) => {
    if (!Array.isArray(importedStore.tournaments) || importedStore.tournaments.length === 0) return;
    const normalizedTournaments = importedStore.tournaments.map((t) =>
      createDefaultTournamentState(t)
    );
    const activeId = normalizedTournaments.some((t) => t.id === importedStore.activeTournamentId)
      ? importedStore.activeTournamentId
      : (normalizedTournaments[0].id as string);
    setStore({
      activeTournamentId: activeId,
      tournaments: normalizedTournaments,
      language: importedStore.language === 'ur' ? 'ur' : 'en',
      appPin: importedStore.appPin ?? null,
      biometricCredentialId: importedStore.biometricCredentialId ?? null,
      hapticsEnabled: importedStore.hapticsEnabled ?? true,
      animationsEnabled: importedStore.animationsEnabled ?? true,
      notificationsEnabled: importedStore.notificationsEnabled ?? true,
      autoBackupEnabled: importedStore.autoBackupEnabled ?? true,
      lastBackupAt: importedStore.lastBackupAt,
      userRoleMode: importedStore.userRoleMode === 'referee' ? 'referee' : 'admin',
      selectedThemeId: importedStore.selectedThemeId || 'black-gold-elite',
      wallpaper: importedStore.wallpaper || { id: 'none', opacity: 45, blur: 2, scrim: true },
      userAccount: importedStore.userAccount ?? null,
      quickMatches: Array.isArray(importedStore.quickMatches) ? importedStore.quickMatches : [],
      doublesTeams: Array.isArray(importedStore.doublesTeams) ? importedStore.doublesTeams : [],
      rankingConfig: importedStore.rankingConfig || DEFAULT_RANKING_CONFIG,
      courts:
        Array.isArray(importedStore.courts) && importedStore.courts.length > 0
          ? importedStore.courts
          : DEFAULT_COURTS,
      courtHistory: Array.isArray(importedStore.courtHistory) ? importedStore.courtHistory : [],
      spectatorMode: Boolean(importedStore.spectatorMode),
      favouriteTournamentIds: Array.isArray(importedStore.favouriteTournamentIds)
        ? importedStore.favouriteTournamentIds
        : [],
      recentTournamentIds: Array.isArray(importedStore.recentTournamentIds)
        ? importedStore.recentTournamentIds
        : [],
      financialRecords: Array.isArray(importedStore.financialRecords)
        ? importedStore.financialRecords
        : [],
      adminAccounts: Array.isArray(importedStore.adminAccounts)
        ? importedStore.adminAccounts
        : [],
      activeAdminName: importedStore.activeAdminName || 'Hassan (Organizer)',
      auditLogs: Array.isArray(importedStore.auditLogs) ? importedStore.auditLogs : [],
      accessibility: importedStore.accessibility || {
        fontScale: 'md',
        highContrast: false,
        lowPerfMode: false,
      },
      onboardingDone: importedStore.onboardingDone ?? true,
    });
  };

  // Elite Upgrade Handlers: Role Mode, Biometrics, Animations, Backups, Doubles, Fixtures, Courts, QR
  const handleToggleRoleMode = () => {
    setStore((prev) => ({
      ...prev,
      userRoleMode: prev.userRoleMode === 'referee' ? 'admin' : 'referee',
    }));
  };

  const handleChangeUserRoleMode = (mode: UserRoleMode) => {
    setStore((prev) => ({ ...prev, userRoleMode: mode }));
  };

  const handleToggleAnimations = () => {
    setStore((prev) => ({
      ...prev,
      animationsEnabled: !(prev.animationsEnabled ?? true),
    }));
  };

  const handleToggleAutoBackup = () => {
    setStore((prev) => {
      const nextEnabled = !(prev.autoBackupEnabled ?? true);
      return {
        ...prev,
        autoBackupEnabled: nextEnabled,
        lastBackupAt: nextEnabled ? new Date().toISOString() : prev.lastBackupAt,
      };
    });
  };

  const handleUpdateBiometric = (credentialId: string | null) => {
    setStore((prev) => ({ ...prev, biometricCredentialId: credentialId }));
  };

  const handleAddDoublesTeam = (team: DoublesTeam) => {
    setStore((prev) => ({
      ...prev,
      doublesTeams: [team, ...(prev.doublesTeams || [])],
    }));
  };

  const handleRemoveDoublesTeam = (teamId: string) => {
    setStore((prev) => ({
      ...prev,
      doublesTeams: (prev.doublesTeams || []).filter((t) => t.id !== teamId),
    }));
  };

  const handleUpdateManualFixtures = (manualFixtures: TournamentMatch[]) => {
    updateActiveTournament((prev) => ({
      ...prev,
      manualFixtures,
    }));
  };

  const handleUpdateDoubleElim = (doubleElim: DoubleElimBracketState) => {
    const prevGrand = state.doubleElim?.grandFinalWinner ?? null;
    updateActiveTournament((prev) => ({
      ...prev,
      doubleElim,
      ...(doubleElim.grandFinalWinner !== undefined
        ? {
            finalWinner: doubleElim.grandFinalWinner ?? null,
            finalScore: doubleElim.grandFinalScore ?? prev.finalScore,
          }
        : {}),
    }));
    if (
      doubleElim.grandFinalWinner !== undefined &&
      doubleElim.grandFinalWinner !== null &&
      doubleElim.grandFinalWinner !== prevGrand &&
      store.animationsEnabled !== false
    ) {
      fireConfetti();
    }
  };

  const handleUpdateCourts = (courts: CourtRecord[]) => {
    setStore((prev) => ({ ...prev, courts }));
  };

  const handleUpdateRankingConfig = (rankingConfig: RankingConfig) => {
    setStore((prev) => ({ ...prev, rankingConfig }));
  };

  const handleRegisterPlayerFromQR = (name: string, bio?: PlayerBio) => {
    updateActiveTournament((prev) => {
      const clean = name.trim();
      if (!clean) return prev;
      const existingIdx = prev.players.findIndex(
        (p) => p.trim().toLowerCase() === clean.toLowerCase()
      );
      if (existingIdx >= 0) {
        if (!bio) return prev;
        return {
          ...prev,
          playerBios: {
            ...(prev.playerBios || {}),
            [existingIdx]: { ...(prev.playerBios?.[existingIdx] || {}), ...bio },
          },
        };
      }
      const newIdx = prev.players.length;
      return {
        ...prev,
        players: [...prev.players, clean],
        playerBios: bio ? { ...(prev.playerBios || {}), [newIdx]: bio } : prev.playerBios,
      };
    });
  };

  const handleImportTournamentFromQR = (payload: Partial<TournamentState>) => {
    const newId = generateTournamentId();
    const normalized = createDefaultTournamentState({
      ...payload,
      id: newId,
    });
    setStore((prev) => ({
      ...prev,
      activeTournamentId: newId,
      tournaments: [normalized, ...prev.tournaments],
    }));
    setActiveTab('tournaments');
  };

  // Mega Expansion Handlers: Audit, Spectator, Accessibility, Venue, Swiss, Auto-Schedule, Consolation, Finance, Admin
  const appendAuditLog = (action: string, target: string) => {
    setStore((prev) => ({
      ...prev,
      auditLogs: [
        {
          id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          timestamp: new Date().toISOString(),
          actor: prev.activeAdminName || prev.userAccount?.name || 'Hassan (Organizer)',
          action,
          target,
        },
        ...(prev.auditLogs || []),
      ].slice(0, 120),
    }));
  };

  const handleToggleFavouriteTournament = (id: string) => {
    setStore((prev) => {
      const current = prev.favouriteTournamentIds || [];
      const exists = current.includes(id);
      return {
        ...prev,
        favouriteTournamentIds: exists ? current.filter((x) => x !== id) : [id, ...current],
      };
    });
  };

  const handleToggleArchiveTournament = (id: string) => {
    setStore((prev) => ({
      ...prev,
      tournaments: prev.tournaments.map((t) =>
        t.id === id ? { ...t, archived: !t.archived } : t
      ),
    }));
    appendAuditLog('Toggle Archive', `Tournament ${id}`);
  };

  const handleSaveVenueLocation = (venueLocation: VenueLocation | undefined) => {
    updateActiveTournament((prev) => ({
      ...prev,
      venueLocation,
      venue: venueLocation ? venueLocation.name : prev.venue,
    }));
    appendAuditLog(
      venueLocation ? 'Save Venue GPS Pin' : 'Clear Venue Pin',
      venueLocation?.name || state.tournamentTitle
    );
  };

  const handleGenerateNextSwissRound = () => {
    const nextFixtures = generateNextSwissRoundFixtures(
      state.players,
      baseFixtures,
      state.results,
      standings
    );
    updateActiveTournament((prev) => ({
      ...prev,
      manualFixtures: nextFixtures,
    }));
    appendAuditLog('Generate Swiss Round', state.tournamentTitle);
  };

  const handleAutoSchedulePending = () => {
    const plan = autoScheduleMatches(
      baseFixtures,
      state.results,
      store.courts || DEFAULT_COURTS,
      state.referees || ['Hassan'],
      state.players,
      state.matchSchedules || {}
    );
    updateActiveTournament((prev) => ({
      ...prev,
      matchSchedules: plan.schedules,
    }));
    appendAuditLog('Auto-Schedule Pending', `${plan.assignedCount} matches scheduled`);
  };

  const handleApplyAutoSchedule = (
    schedules: Record<string, MatchScheduleInfo>,
    assignedCount: number
  ) => {
    updateActiveTournament((prev) => ({
      ...prev,
      matchSchedules: schedules,
    }));
    appendAuditLog('Bulk Auto-Schedule', `${assignedCount} fixtures assigned`);
  };

  const handleUpdateMatchMeta = (
    matchId: string,
    updater: (prev: MatchMetaInfo) => MatchMetaInfo
  ) => {
    updateActiveTournament((prev) => ({
      ...prev,
      matchMeta: {
        ...(prev.matchMeta || {}),
        [matchId]: updater(prev.matchMeta?.[matchId] || {}),
      },
    }));
  };

  const handleUpdateConsolation = (consolationBracket: ConsolationBracketState) => {
    updateActiveTournament((prev) => ({
      ...prev,
      consolationBracket,
    }));
  };

  const handleAddFinancialRecord = (record: FinancialRecord) => {
    setStore((prev) => ({
      ...prev,
      financialRecords: [record, ...(prev.financialRecords || [])],
    }));
    appendAuditLog('Add Finance Entry', `${record.title} (${record.amount})`);
  };

  const handleToggleFinancialPaid = (id: string) => {
    setStore((prev) => ({
      ...prev,
      financialRecords: (prev.financialRecords || []).map((r) =>
        r.id === id ? { ...r, status: r.status === 'paid' ? 'pending' : 'paid' } : r
      ),
    }));
  };

  const handleDeleteFinancialRecord = (id: string) => {
    setStore((prev) => ({
      ...prev,
      financialRecords: (prev.financialRecords || []).filter((r) => r.id !== id),
    }));
    appendAuditLog('Delete Finance Entry', id);
  };

  const handleAddAdminAccount = (name: string, role: AdminAccount['role']) => {
    const clean = name.trim();
    if (!clean) return;
    const acc: AdminAccount = {
      id: `adm-${Date.now()}`,
      name: clean,
      role,
      createdAt: new Date().toISOString(),
    };
    setStore((prev) => ({
      ...prev,
      adminAccounts: [...(prev.adminAccounts || []), acc],
    }));
    appendAuditLog('Add Staff Account', `${clean} (${role})`);
  };

  const handleSwitchActiveAdmin = (name: string) => {
    setStore((prev) => ({
      ...prev,
      activeAdminName: name,
    }));
    appendAuditLog('Switch Active Operator', name);
  };

  const handleDeleteAdminAccount = (id: string) => {
    setStore((prev) => ({
      ...prev,
      adminAccounts: (prev.adminAccounts || []).filter((a) => a.id !== id),
    }));
  };

  const handleBulkImportPlayers = (names: string[]) => {
    const cleanNames = names.map((n) => n.trim()).filter(Boolean);
    if (cleanNames.length === 0) return;
    handleSetPlayers(cleanNames);
    appendAuditLog('Bulk Import Players', `${cleanNames.length} players imported`);
  };

  const handleDeduplicatePlayers = () => {
    const seen = new Set<string>();
    const deduped: string[] = [];
    state.players.forEach((p) => {
      const key = p.trim().toLowerCase();
      if (key && !seen.has(key)) {
        seen.add(key);
        deduped.push(p.trim());
      }
    });
    if (deduped.length !== state.players.length) {
      handleSetPlayers(deduped);
      appendAuditLog(
        'Deduplicate Roster',
        `Removed ${state.players.length - deduped.length} duplicates`
      );
    }
  };

  const handleClearAuditLogs = () => {
    setStore((prev) => ({ ...prev, auditLogs: [] }));
  };

  const handleToggleSpectatorMode = () => {
    setStore((prev) => {
      const next = !prev.spectatorMode;
      if (next && (activeTab === 'finance' || activeTab === 'admin')) {
        setActiveTab('dashboard');
      }
      return { ...prev, spectatorMode: next };
    });
  };

  const handleUpdateAccessibility = (accessibility: AccessibilitySettings) => {
    setStore((prev) => ({ ...prev, accessibility }));
  };

  const handleCloseTutorial = () => {
    setIsTutorialOpen(false);
    setStore((prev) => ({ ...prev, onboardingDone: true }));
  };

  const handleResetTournament = () => {
    setIsResetConfirmOpen(true);
  };

  const executeResetTournament = () => {
    updateActiveTournament((prev) => ({
      ...prev,
      results: {},
      scores: {},
      matchMvps: {},
      semis: {},
      semiScores: {},
      quarters: {},
      finalWinner: null,
      thirdPlaceWinner: null,
    }));
    setIsResetConfirmOpen(false);
  };

  const handleResetAll = () => {
    updateActiveTournament((prev) =>
      createDefaultTournamentState({
        id: prev.id,
      })
    );
    setActiveTab('roster');
  };

  const handleUpdateLogo = (logoUrl: string) => {
    updateActiveTournament((prev) => ({
      ...prev,
      customLogoUrl: logoUrl,
    }));
  };

  const handleUpdatePhoto = (playerId: number, dataUrl: string) => {
    updateActiveTournament((prev) => ({
      ...prev,
      playerPhotos: {
        ...(prev.playerPhotos || {}),
        [playerId]: dataUrl,
      },
    }));
  };

  const handleRemovePhoto = (playerId: number) => {
    updateActiveTournament((prev) => {
      const nextPhotos = { ...(prev.playerPhotos || {}) };
      delete nextPhotos[playerId];
      return {
        ...prev,
        playerPhotos: nextPhotos,
      };
    });
  };

  const handleUpdateBio = (playerId: number, bio: PlayerBio) => {
    updateActiveTournament((prev) => ({
      ...prev,
      playerBios: {
        ...(prev.playerBios || {}),
        [playerId]: bio,
      },
    }));
  };

  const handleImportState = (imported: TournamentState) => {
    const newId = imported.id || generateTournamentId();
    const normalized = createDefaultTournamentState({
      ...imported,
      id: newId,
    });
    setStore((prev) => ({
      ...prev,
      activeTournamentId: newId,
      tournaments: [normalized, ...prev.tournaments.filter((t) => t.id !== newId)],
    }));
  };

  const runnerUp = useMemo(() => {
    if (state.finalWinner === null) return null;
    const sf1Winner = state.semis[0];
    const sf2Winner = state.semis[1];
    if (sf1Winner !== undefined && sf2Winner !== undefined) {
      return state.finalWinner === sf1Winner ? sf2Winner : sf1Winner;
    }
    const wf = state.doubleElim?.winnersFinalWinner;
    const lf = state.doubleElim?.losersFinalWinner;
    if (wf !== undefined && wf !== null && lf !== undefined && lf !== null) {
      return state.finalWinner === wf ? lf : wf;
    }
    return null;
  }, [state.finalWinner, state.semis, state.doubleElim]);

  return (
    <div
      className="min-h-screen bg-transparent text-[#172033] dark:text-white flex flex-col font-sans transition-colors pb-28 md:pb-12 relative overflow-x-hidden w-full max-w-full"
      style={{ color: activeTheme.textPrimary }}
    >
      <DynamicBadmintonBackdrop theme={activeTheme} wallpaper={store.wallpaper} />

      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {showSplash && (
        <SplashScreen
          onFinish={() => setShowSplash(false)}
          isDark={isDark}
          customLogoUrl={state.customLogoUrl}
        />
      )}

      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        tournamentStarted={state.started}
        isDark={isDark}
        setIsDark={handleToggleDark}
        language={store.language}
        setLanguage={handleSetLanguage}
        hasPin={Boolean(store.appPin)}
        onPinAction={handlePinButtonClick}
        userRoleMode={store.userRoleMode || 'admin'}
        onToggleRoleMode={handleToggleRoleMode}
        spectatorMode={Boolean(store.spectatorMode)}
        onToggleSpectatorMode={handleToggleSpectatorMode}
        upcomingMatches={upcomingMatches}
        players={state.players}
        onLaunchLiveFromReminder={(matchId) => {
          setLiveMatchId(matchId);
          setActiveTab('live');
        }}
        onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        onOpenPDFModal={() => setIsPDFModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        onOpenThemeStudio={() => openThemeStudio('themes')}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenQuickMatch={() => setIsQuickMatchOpen(true)}
        onOpenGlobalSearch={() => setIsGlobalSearchOpen(true)}
        onOpenQRModal={() => setIsQRModalOpen(true)}
        onOpenAboutModal={() => setIsAboutModalOpen(true)}
        userAccount={store.userAccount}
        completedMatchesCount={completedMatchesCount}
        totalMatchesCount={totalMatchesCount}
        customLogoUrl={state.customLogoUrl}
      />

      {store.spectatorMode && (
        <div className="bg-emerald-500/15 border-b border-emerald-500/35 px-4 py-1.5 text-center text-[11px] font-bold text-emerald-400 flex items-center justify-center gap-3 z-20">
          <span>Public Spectator Mode Active — Read-only scoreboard, standings &amp; venue view</span>
          <button
            type="button"
            onClick={handleToggleSpectatorMode}
            className="underline font-black text-[#FFD700] cursor-pointer"
          >
            Exit Spectator
          </button>
        </div>
      )}

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 z-10">
        {state.finalWinner !== null &&
          activeTab !== 'dashboard' &&
          activeTab !== 'tournaments' &&
          activeTab !== 'history' &&
          activeTab !== 'rankings' && (
            <div className="mb-6">
              <ChampionPodium
                players={state.players}
                finalWinner={state.finalWinner}
                runnerUp={runnerUp}
                thirdPlace={state.thirdPlaceWinner ?? null}
                standings={standings}
                onResetTournament={handleResetTournament}
                onOpenShareModal={() => setIsShareModalOpen(true)}
              />
            </div>
          )}

        {activeTab === 'dashboard' && (
          <Dashboard
            state={state}
            tournamentsCount={store.tournaments.length}
            standings={standings}
            fixtures={baseFixtures}
            totalMatchesCount={totalMatchesCount}
            completedMatchesCount={completedMatchesCount}
            courts={store.courts || DEFAULT_COURTS}
            courtHistory={store.courtHistory || []}
            language={store.language}
            isDark={isDark}
            userAccount={store.userAccount}
            activeThemeName={activeTheme.name}
            spectatorMode={Boolean(store.spectatorMode)}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onLaunchLiveMatch={(matchId) => {
              setKnockoutLiveMatch(null);
              setLiveMatchId(matchId);
              setActiveTab('live');
            }}
            onStartTournament={handleStartTournament}
            onOpenCertificateModal={() => setIsPDFModalOpen(true)}
            onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
            onOpenThemeStudio={openThemeStudio}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onOpenQuickMatch={() => setIsQuickMatchOpen(true)}
            onOpenQRModal={() => setIsQRModalOpen(true)}
            onUpdateAnnouncements={handleUpdateAnnouncements}
          />
        )}

        {(activeTab === 'tournaments' || activeTab === 'history') && (
          <TournamentsView
            mode={activeTab === 'history' ? 'history' : 'tournaments'}
            tournaments={store.tournaments}
            activeTournamentId={store.activeTournamentId}
            userRoleMode={store.userRoleMode || 'admin'}
            spectatorMode={Boolean(store.spectatorMode)}
            favouriteIds={store.favouriteTournamentIds || []}
            recentIds={store.recentTournamentIds || []}
            onToggleFavourite={handleToggleFavouriteTournament}
            onToggleArchive={handleToggleArchiveTournament}
            onSelectTournament={handleSelectTournament}
            onCreateTournament={handleCreateTournament}
            onUpdateTournamentMeta={handleUpdateTournamentMeta}
            onDuplicateTournament={handleDuplicateTournament}
            onDeleteTournament={handleDeleteTournament}
            onReopenTournament={handleReopenTournament}
            onToggleMatchMvp={(tournamentId, matchId, playerIndex) =>
              handleSetMatchMvp(matchId, playerIndex, tournamentId)
            }
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'roster' && (
          <PlayerSetup
            players={state.players}
            setPlayers={handleSetPlayers}
            playerPhotos={state.playerPhotos}
            standings={standings}
            allTournaments={store.tournaments}
            doublesTeams={store.doublesTeams || []}
            onAddDoublesTeam={handleAddDoublesTeam}
            onRemoveDoublesTeam={handleRemoveDoublesTeam}
            onUpdateBio={handleUpdateBio}
            onApplySmartSeeding={handleApplySmartSeeding}
            onSwapPlayers={handleSwapPlayers}
            matchFormat={state.matchFormat || 'bo3'}
            setMatchFormat={handleSetMatchFormat}
            tournamentFormat={activeFormat}
            setTournamentFormat={handleSetTournamentFormat}
            category={state.category || 'singles'}
            setCategory={handleSetCategory}
            customRules={state.customRules}
            onUpdateCustomRules={handleUpdateCustomRules}
            tournamentStarted={state.started}
            onStartTournament={handleStartTournament}
            onResetTournament={handleResetTournament}
            onOpenPlayerProfile={(id) => setSelectedPlayerId(id)}
          />
        )}

        {activeTab === 'matches' && (
          <LeagueMatches
            players={state.players}
            fixtures={baseFixtures}
            manualFixtures={state.manualFixtures}
            onUpdateManualFixtures={handleUpdateManualFixtures}
            tournamentFormat={activeFormat}
            onGenerateNextSwissRound={handleGenerateNextSwissRound}
            onAutoSchedulePending={handleAutoSchedulePending}
            onUpdateMatchMeta={handleUpdateMatchMeta}
            results={state.results}
            scores={state.scores || {}}
            matchMeta={state.matchMeta || {}}
            tournamentTitle={state.tournamentTitle}
            matchFormat={state.matchFormat || 'bo3'}
            setMatchFormat={handleSetMatchFormat}
            matchFormats={state.matchFormats || {}}
            onSetMatchItemFormat={handleSetMatchItemFormat}
            matchSchedules={state.matchSchedules || {}}
            onUpdateMatchSchedule={handleUpdateMatchSchedule}
            referees={state.referees}
            customRules={state.customRules}
            onUpdateCustomRules={handleUpdateCustomRules}
            playerPhotos={state.playerPhotos}
            onSetResult={handleSetMatchResult}
            onUndoResult={handleUndoMatchResult}
            matchMvps={state.matchMvps || {}}
            onToggleMatchMvp={(matchId, playerIndex) => handleSetMatchMvp(matchId, playerIndex)}
            onSimulateAll={handleSimulateAllRemaining}
            onOpenPlayerProfile={(id) => setSelectedPlayerId(id)}
            onLaunchLiveScorer={(matchId) => {
              setKnockoutLiveMatch(null);
              setLiveMatchId(matchId);
              setActiveTab('live');
            }}
          />
        )}

        {activeTab === 'table' && (
          <StandingsTable
            standings={standings}
            tournamentState={state}
            fixtures={baseFixtures}
            tournamentFormat={activeFormat}
            onNavigateToKnockout={() => setActiveTab('knockout')}
            allMatchesDone={allLeagueMatchesDone}
            onOpenPlayerProfile={(id) => setSelectedPlayerId(id)}
          />
        )}

        {activeTab === 'courts' && (
          <CourtManager
            players={state.players}
            fixtures={baseFixtures}
            results={state.results}
            scores={state.scores || {}}
            playerPhotos={state.playerPhotos}
            referees={state.referees}
            onUpdateReferees={handleUpdateReferees}
            courts={store.courts || DEFAULT_COURTS}
            onUpdateCourts={handleUpdateCourts}
            courtHistory={store.courtHistory || []}
            onLaunchLiveScorer={(matchId, courtNum) => {
              setKnockoutLiveMatch(null);
              setLiveMatchId(matchId);
              setLiveCourtNumber(courtNum);
              setActiveTab('live');
            }}
          />
        )}

        {activeTab === 'live' && (
          <LiveCourtScorer
            players={state.players}
            fixtures={fixtures}
            playerPhotos={state.playerPhotos}
            matchFormat={state.matchFormat || 'bo3'}
            matchFormats={state.matchFormats || {}}
            onSetMatchItemFormat={handleSetMatchItemFormat}
            tournamentTitle={
              knockoutLiveMatch
                ? `${state.tournamentTitle} · ${knockoutLiveMatch.label}`
                : state.tournamentTitle
            }
            competitionCategory={state.category || 'singles'}
            customRules={state.customRules}
            onUpdateCustomRules={handleUpdateCustomRules}
            courts={store.courts || DEFAULT_COURTS}
            userRoleMode={store.userRoleMode || 'admin'}
            defaultDurationMinutes={state.defaultMatchDurationMinutes || 30}
            animationsEnabled={store.animationsEnabled ?? true}
            onOpenQuickMatch={() => setIsQuickMatchOpen(true)}
            initialMatchId={liveMatchId}
            initialCourtNumber={liveCourtNumber}
            onSaveMatchResult={(
              matchId,
              winnerIndex,
              score,
              mvpPlayerIndex,
              meta,
              courtNumber
            ) => {
              const targetMatch = fixtures.find((m) => m.id === matchId);
              const courtNum = courtNumber || liveCourtNumber || 1;
              const courtObj = (store.courts || DEFAULT_COURTS).find((c) => c.id === courtNum);
              const courtName = courtObj?.name || `Court ${courtNum}`;

              if (targetMatch && targetMatch.playerBIndex >= 0) {
                const entry: CourtMatchHistoryEntry = {
                  id: `ch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                  courtId: courtNum,
                  courtName,
                  matchId,
                  playerA: state.players[targetMatch.playerAIndex] || 'Player A',
                  playerB: state.players[targetMatch.playerBIndex] || 'Player B',
                  winner: state.players[winnerIndex] || 'Winner',
                  score: formatScore(score),
                  completedAt: new Date().toISOString(),
                };
                setStore((prev) => ({
                  ...prev,
                  courtHistory: [entry, ...(prev.courtHistory || [])].slice(0, 100),
                  courts: (prev.courts || DEFAULT_COURTS).map((c) =>
                    c.assignedMatchId === matchId
                      ? { ...c, assignedMatchId: null, status: 'available' }
                      : c
                  ),
                }));
              }

              if (matchId.startsWith('ko:')) {
                const key = matchId.slice(3);
                if (key.startsWith('qf-')) {
                  handleSetQuarterWinner(Number(key.slice(3)), winnerIndex, score);
                } else if (key.startsWith('sf-')) {
                  handleSetSemiWinner(Number(key.slice(3)), winnerIndex, score);
                } else if (key === 'final') {
                  handleSetFinalWinner(winnerIndex, score);
                } else if (key === 'third') {
                  handleSetThirdPlaceWinner(winnerIndex, score);
                }
                if (mvpPlayerIndex !== undefined) {
                  handleSetMatchMvp(matchId, mvpPlayerIndex);
                }
                setKnockoutLiveMatch(null);
                setActiveTab('knockout');
              } else {
                handleSetMatchResult(matchId, winnerIndex, score, mvpPlayerIndex, meta);
                setActiveTab('matches');
              }
            }}
          />
        )}

        {activeTab === 'knockout' && (
          <KnockoutStage
            players={state.players}
            standings={standings}
            allLeagueMatchesDone={allLeagueMatchesDone}
            semis={state.semis}
            semiScores={state.semiScores}
            quarters={state.quarters || {}}
            quarterScores={state.quarterScores}
            finalWinner={state.finalWinner}
            finalScore={state.finalScore}
            thirdPlaceWinner={state.thirdPlaceWinner ?? null}
            thirdPlaceScore={state.thirdPlaceScore}
            targetPoints={state.customRules?.pointsPerSet ?? 21}
            matchFormat={state.matchFormat || 'bo3'}
            matchFormats={state.matchFormats || {}}
            tournamentFormat={activeFormat}
            doubleElim={state.doubleElim}
            onUpdateDoubleElim={handleUpdateDoubleElim}
            consolationBracket={state.consolationBracket}
            onUpdateConsolation={handleUpdateConsolation}
            onSetMatchItemFormat={handleSetMatchItemFormat}
            onSetQuarterWinner={handleSetQuarterWinner}
            onUndoQuarter={handleUndoQuarter}
            onSetSemiWinner={handleSetSemiWinner}
            onUndoSemi={handleUndoSemi}
            onSetFinalWinner={handleSetFinalWinner}
            onUndoFinal={handleUndoFinal}
            onSetThirdPlaceWinner={handleSetThirdPlaceWinner}
            onUndoThirdPlace={handleUndoThirdPlace}
            matchMvps={state.matchMvps || {}}
            onToggleMatchMvp={(matchId, playerIndex) => handleSetMatchMvp(matchId, playerIndex)}
            onLaunchKnockoutLive={(payload) => {
              setKnockoutLiveMatch(payload);
              setLiveMatchId(`ko:${payload.knockoutKey}`);
              setActiveTab('live');
            }}
            onNavigateToMatches={() => setActiveTab('matches')}
            onOpenPlayerProfile={(id) => setSelectedPlayerId(id)}
          />
        )}

        {activeTab === 'h2h' && (
          <HeadToHeadMatrix
            players={state.players}
            fixtures={fixtures}
            results={state.results}
            scores={state.scores || {}}
            playerPhotos={state.playerPhotos}
            onOpenPlayerProfile={(id) => setSelectedPlayerId(id)}
          />
        )}

        {activeTab === 'rankings' && (
          <RankingsView
            tournaments={store.tournaments}
            rankingConfig={store.rankingConfig || DEFAULT_RANKING_CONFIG}
            onUpdateRankingConfig={handleUpdateRankingConfig}
            userRoleMode={store.userRoleMode || 'admin'}
          />
        )}

        {activeTab === 'news' && <NewsView />}

        {activeTab === 'venue' && (
          <VenueMapView
            tournamentTitle={state.tournamentTitle}
            venueName={state.venue || 'Main Sports Hall'}
            savedLocation={state.venueLocation}
            onSaveVenueLocation={handleSaveVenueLocation}
            spectatorMode={Boolean(store.spectatorMode)}
          />
        )}

        {activeTab === 'finance' && (
          <FinanceView
            records={store.financialRecords || []}
            tournaments={store.tournaments}
            activeTournamentId={store.activeTournamentId}
            onAddRecord={handleAddFinancialRecord}
            onTogglePaid={handleToggleFinancialPaid}
            onDeleteRecord={handleDeleteFinancialRecord}
            spectatorMode={Boolean(store.spectatorMode)}
          />
        )}

        {activeTab === 'studio' && (
          <MediaStudioView
            state={state}
            standings={standings}
            fixtures={baseFixtures}
            onOpenPDFModal={() => setIsPDFModalOpen(true)}
          />
        )}

        {activeTab === 'admin' && (
          <AdminCenterView
            store={store}
            activeTournament={state}
            fixtures={baseFixtures}
            courts={store.courts || DEFAULT_COURTS}
            onAddAdminAccount={handleAddAdminAccount}
            onSwitchActiveAdmin={handleSwitchActiveAdmin}
            onDeleteAdminAccount={handleDeleteAdminAccount}
            onApplyAutoSchedule={handleApplyAutoSchedule}
            onBulkImportPlayers={handleBulkImportPlayers}
            onDeduplicatePlayers={handleDeduplicatePlayers}
            onClearAuditLogs={handleClearAuditLogs}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-12 theme-card border-x-0 border-b-0 rounded-none py-6 px-4 z-10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#64748B] dark:text-[#A0A0A0]">
          <div className="flex items-center gap-2">
            <span className="text-base">🏸</span>
            <span className="font-black text-[#172033] dark:text-white">Smash Championship</span>
            <span aria-hidden="true">·</span>
            <span>Hassan Badminton Tournament Manager</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2">
            <span className="font-extrabold text-[#172B4D] dark:text-[#FFD700] text-sm theme-accent-text">
              Developed By Hassan
            </span>
            <span className="hidden sm:inline" aria-hidden="true">·</span>
            <span className="text-[11px] text-[#64748B] dark:text-[#D4AF37] font-semibold">
              Black + Gold Elite Edition
            </span>
          </div>
        </div>
      </footer>

      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        tournamentStarted={state.started}
        completedMatchesCount={completedMatchesCount}
        totalMatchesCount={totalMatchesCount}
        hasChampion={state.finalWinner !== null}
        language={store.language}
        userAccount={store.userAccount}
        userRoleMode={store.userRoleMode || 'admin'}
        onToggleRoleMode={handleToggleRoleMode}
        spectatorMode={Boolean(store.spectatorMode)}
        onToggleSpectatorMode={handleToggleSpectatorMode}
        isDark={isDark}
        onToggleDark={() => handleToggleDark(!isDark)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenPDFModal={() => setIsPDFModalOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        onOpenThemeStudio={() => openThemeStudio('themes')}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        onOpenQRModal={() => setIsQRModalOpen(true)}
        onOpenAboutModal={() => setIsAboutModalOpen(true)}
        onOpenTutorial={() => setIsTutorialOpen(true)}
      />

      <PlayerProfileModal
        player={selectedPlayerStats}
        isOpen={selectedPlayerId !== null}
        onClose={() => setSelectedPlayerId(null)}
        fixtures={fixtures}
        results={state.results}
        scores={state.scores || {}}
        matchMvps={state.matchMvps || {}}
        allPlayers={state.players}
        allTournaments={store.tournaments}
        rankingConfig={store.rankingConfig || DEFAULT_RANKING_CONFIG}
        tournamentCategory={state.category || 'singles'}
        rankPosition={
          selectedPlayerId !== null
            ? standings.findIndex((s) => s.id === selectedPlayerId) + 1
            : undefined
        }
        onUpdatePhoto={handleUpdatePhoto}
        onRemovePhoto={handleRemovePhoto}
        onUpdateBio={handleUpdateBio}
      />

      <AndroidProjectModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      <TournamentShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        tournamentState={state}
        fullStore={store}
        standings={standings}
        fixtures={baseFixtures}
        onImportState={handleImportState}
        onImportFullStore={handleImportFullStore}
        onResetAll={handleResetAll}
      />

      <PDFReportModal
        isOpen={isPDFModalOpen}
        onClose={() => setIsPDFModalOpen(false)}
        tournamentState={state}
        standings={standings}
        fixtures={baseFixtures}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        isDark={isDark}
        setIsDark={handleToggleDark}
        matchFormat={state.matchFormat || 'bo3'}
        setMatchFormat={handleSetMatchFormat}
        customRules={state.customRules}
        onUpdateCustomRules={handleUpdateCustomRules}
        language={store.language}
        setLanguage={handleSetLanguage}
        hasPin={Boolean(store.appPin)}
        onOpenPinSetup={() => setIsPinSetupOpen(true)}
        animationsEnabled={store.animationsEnabled ?? true}
        onToggleAnimations={handleToggleAnimations}
        autoBackupEnabled={store.autoBackupEnabled ?? true}
        onToggleAutoBackup={handleToggleAutoBackup}
        lastBackupAt={store.lastBackupAt}
        userRoleMode={store.userRoleMode || 'admin'}
        onChangeUserRoleMode={handleChangeUserRoleMode}
        spectatorMode={Boolean(store.spectatorMode)}
        onToggleSpectatorMode={handleToggleSpectatorMode}
        accessibility={
          store.accessibility || { fontScale: 'md', highContrast: false, lowPerfMode: false }
        }
        onUpdateAccessibility={handleUpdateAccessibility}
        onOpenTutorial={() => setIsTutorialOpen(true)}
        biometricCredentialId={store.biometricCredentialId}
        onUpdateBiometric={handleUpdateBiometric}
        onOpenQRModal={() => setIsQRModalOpen(true)}
        onOpenAboutModal={() => setIsAboutModalOpen(true)}
        onResetTournament={handleResetTournament}
        onResetAll={handleResetAll}
        onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
        customLogoUrl={state.customLogoUrl}
        onUpdateLogo={handleUpdateLogo}
        activeThemeName={activeTheme.name}
        onOpenThemeStudio={openThemeStudio}
        userAccount={store.userAccount}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      <OnboardingModal isOpen={isTutorialOpen} onClose={handleCloseTutorial} />

      <QRCodeModal
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
        tournamentState={state}
        onRegisterPlayer={handleRegisterPlayerFromQR}
        onImportTournamentFromQR={handleImportTournamentFromQR}
      />

      <AboutModal
        isOpen={isAboutModalOpen}
        onClose={() => setIsAboutModalOpen(false)}
        onOpenAndroidModal={() => {
          setIsAboutModalOpen(false);
          setIsAndroidModalOpen(true);
        }}
      />

      <ThemeWallpaperModal
        isOpen={isThemeStudioOpen}
        onClose={() => setIsThemeStudioOpen(false)}
        selectedThemeId={activeTheme.id}
        onSelectTheme={handleSelectTheme}
        wallpaper={
          store.wallpaper || {
            id: 'none',
            opacity: 45,
            blur: 2,
            scrim: true,
          }
        }
        onUpdateWallpaper={handleUpdateWallpaper}
        initialSection={themeStudioSection}
      />

      <AuthSignUpModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        userAccount={store.userAccount ?? null}
        onSaveAccount={handleSaveUserAccount}
      />

      <QuickMatchModal
        isOpen={isQuickMatchOpen}
        onClose={() => setIsQuickMatchOpen(false)}
        rosterPlayers={state.players}
        defaultMatchFormat={state.matchFormat || 'bo3'}
        defaultPointsPerSet={state.customRules?.pointsPerSet ?? 21}
        quickMatches={store.quickMatches || []}
        onSaveQuickMatch={handleSaveQuickMatch}
        onDeleteQuickMatch={handleDeleteQuickMatch}
        onToggleQuickMatchMvp={handleToggleQuickMatchMvp}
      />

      <GlobalSearchModal
        isOpen={isGlobalSearchOpen}
        onClose={() => setIsGlobalSearchOpen(false)}
        tournaments={store.tournaments}
        activeTournament={state}
        fixtures={baseFixtures}
        quickMatches={store.quickMatches || []}
        onSelectTournament={handleSelectTournament}
        onOpenPlayerProfile={(id) => setSelectedPlayerId(id)}
        onLaunchLiveMatch={(matchId) => {
          setKnockoutLiveMatch(null);
          setLiveMatchId(matchId);
          setActiveTab('live');
        }}
        onSelectTheme={handleSelectTheme}
        onNavigateTab={(tab) => setActiveTab(tab)}
        onOpenQuickMatch={() => setIsQuickMatchOpen(true)}
      />

      <PinLockModal
        mode="unlock"
        isOpen={isLocked && Boolean(store.appPin)}
        expectedPin={store.appPin}
        biometricCredentialId={store.biometricCredentialId}
        onUnlock={() => setIsLocked(false)}
        onBiometricUnlock={() => setIsLocked(false)}
      />

      <PinLockModal
        mode="setup"
        isOpen={isPinSetupOpen}
        expectedPin={store.appPin}
        onSavePin={handleSavePin}
        onClose={() => setIsPinSetupOpen(false)}
      />

      <ConfirmModal
        isOpen={isResetConfirmOpen}
        title="Reset Match Scores?"
        message="This will clear all completed match results and scores for this tournament. Registered players and rosters will be preserved."
        confirmText="Reset Scores"
        cancelText="Keep Scores"
        type="warning"
        onConfirm={executeResetTournament}
        onCancel={() => setIsResetConfirmOpen(false)}
      />

      <OfflineIndicator />
    </div>
  );
}
