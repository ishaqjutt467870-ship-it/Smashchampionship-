export type MatchFormat = 'bo1' | 'bo2' | 'bo3' | 'bo5';
export type TournamentFormatType =
  | 'round_robin'
  | 'double_round_robin'
  | 'swiss'
  | 'league'
  | 'knockout'
  | 'group_stage'
  | 'single_elimination'
  | 'double_elimination'
  | 'team_championship'
  | 'custom';
export type CompetitionCategory = 'singles' | 'doubles' | 'mixed_doubles';
export type AppLanguage = 'en' | 'ur';
export type MatchResultType = 'normal' | 'retired' | 'walkover' | 'bye';
export type UserRoleMode = 'admin' | 'referee';

export interface CustomTournamentRules {
  pointsPerSet: number; // Adjustable 11 to 21
  maxDeuceCap: number;
  intervalAt: number;
  refereeName?: string;
}

export interface VenueLocation {
  name: string;
  address: string;
  placeId?: string;
  lat: number;
  lng: number;
  googleMapsUri?: string;
  savedAt?: string;
}

export interface UserAccount {
  id: string;
  name: string;
  method: 'email' | 'mobile';
  email?: string;
  mobile?: string;
  role: 'Organizer' | 'Referee' | 'Player';
  verified: boolean;
  verifiedAt: string;
}

export interface WallpaperSettings {
  id: string;
  customUrl?: string;
  opacity: number;
  blur: number;
  scrim: boolean;
}

export interface MatchScore {
  s1a?: number;
  s1b?: number;
  s2a?: number;
  s2b?: number;
  s3a?: number;
  s3b?: number;
  s4a?: number;
  s4b?: number;
  s5a?: number;
  s5b?: number;
}

export interface MatchIncident {
  id: string;
  time: string;
  type:
    | 'warning'
    | 'yellow_card'
    | 'red_card'
    | 'service_fault'
    | 'let'
    | 'medical_timeout'
    | 'incident';
  playerSide: 'A' | 'B' | 'General';
  note: string;
}

export interface ScoreAuditEntry {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  previousValue?: string;
  nextValue?: string;
}

export interface RallyStatPoint {
  set: number;
  winner: 'A' | 'B';
  server?: 'A' | 'B';
  shot: string;
  rallySec: number;
  scoreA: number;
  scoreB: number;
}

export interface MatchMetaInfo {
  resultType?: MatchResultType;
  status?: 'scheduled' | 'in_progress' | 'postponed' | 'completed';
  postponedReason?: string;
  rescheduledTo?: string;
  retiredPlayerIndex?: number;
  walkoverWinnerIndex?: number;
  note?: string;
  completedAt?: string;
  courtNumber?: number;
  durationSeconds?: number;
  intervalCount?: number;
  endsSwitchedCount?: number;
  verifiedBy?: string;
  verifiedAt?: string;
  incidents?: MatchIncident[];
  auditTrail?: ScoreAuditEntry[];
  rallyHistory?: RallyStatPoint[];
}

export interface PlayerBio {
  playStyle?: string;
  hand?: 'Right' | 'Left';
  racket?: string;
  notes?: string;
  playerCode?: string;
  age?: number;
  contact?: string;
  preferredCategory?: CompetitionCategory;
  club?: string;
  availability?: 'Available' | 'On Court' | 'Resting' | 'Injured';
  favourite?: boolean;
  achievements?: string[];
  badges?: string[];
}

export interface PlayerStats {
  id: number;
  name: string;
  photo?: string;
  avatarColor: string;
  played: number;
  won: number;
  lost: number;
  points: number;
  setsWon: number;
  setsLost: number;
  pointsFor: number;
  pointsAgainst: number;
  form: ('W' | 'L')[];
  group?: 'A' | 'B';
  bio?: PlayerBio;
}

export interface DoublesTeam {
  id: string;
  name: string;
  player1: string;
  player2: string;
  category: 'doubles' | 'mixed_doubles';
  createdAt: string;
}

export interface RankingConfig {
  winPoints: number;
  lossPoints: number;
  setWinBonus: number;
  championshipBonus: number;
  runnerUpBonus: number;
  mvpBonus: number;
}

export interface CourtRecord {
  id: number;
  name: string;
  assignedMatchId: string | null;
  referee?: string;
  status: 'available' | 'warmup' | 'in_progress' | 'maintenance';
}

export interface CourtMatchHistoryEntry {
  id: string;
  courtId: number;
  courtName: string;
  matchId: string;
  playerA: string;
  playerB: string;
  winner: string;
  score: string;
  completedAt: string;
}

export interface TournamentMatch {
  id: string; // e.g. "0-1" or "manual-..."
  playerAIndex: number;
  playerBIndex: number; // -1 represents a BYE slot
  roundNumber?: number;
  group?: 'A' | 'B';
  leg?: 1 | 2;
  swissRound?: number;
  score?: MatchScore;
  courtNumber?: number;
  bracketSide?: 'winners' | 'losers' | 'grand_final' | 'consolation' | 'manual';
  isBye?: boolean;
}

export interface DoubleElimBracketState {
  winnersSemis?: Record<number, number>;
  winnersSemiScores?: Record<number, MatchScore>;
  winnersFinalWinner?: number | null;
  winnersFinalScore?: MatchScore;
  losersR1?: Record<number, number>;
  losersR1Scores?: Record<number, MatchScore>;
  losersFinalWinner?: number | null;
  losersFinalScore?: MatchScore;
  grandFinalWinner?: number | null;
  grandFinalScore?: MatchScore;
}

export interface ConsolationBracketState {
  semis?: Record<number, number>;
  semiScores?: Record<number, MatchScore>;
  winner?: number | null;
  score?: MatchScore;
}

export interface ShuttleEquipment {
  type: 'feather' | 'nylon';
  brand: string;
  speed: 76 | 77 | 78;
  shuttlesUsed: number;
}

export interface LivePointHistory {
  player: 'A' | 'B';
  scoreA: number;
  scoreB: number;
  server: 'A' | 'B';
  timestamp: number;
}

export interface LiveMatchState {
  matchId: string;
  playerAIndex: number;
  playerBIndex: number;
  currentSet: number;
  setScores: Array<{ a: number; b: number }>;
  currentPointsA: number;
  currentPointsB: number;
  server: 'A' | 'B';
  servingSide: 'right' | 'left';
  sideAOnLeft: boolean;
  history: LivePointHistory[];
  courtNumber: number;
  equipment: ShuttleEquipment;
  status: 'warmup' | 'in_progress' | 'interval' | 'set_break' | 'finished';
  intervalRemainingSeconds?: number;
}

export interface TournamentAnnouncement {
  id: string;
  text: string;
  createdAt: string;
  pinned?: boolean;
  author?: string;
}

export interface MatchScheduleInfo {
  time?: string;
  courtNumber?: number;
  referee?: string;
}

export interface FinancialRecord {
  id: string;
  tournamentId: string;
  type: 'registration_fee' | 'sponsor' | 'expense' | 'prize';
  title: string;
  partyName: string;
  amount: number;
  currency?: string;
  status: 'paid' | 'pending';
  date: string;
  receiptNo: string;
  notes?: string;
}

export interface AdminAccount {
  id: string;
  name: string;
  role: 'organizer' | 'admin' | 'referee';
  createdAt: string;
}

export interface AdminAuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
}

export interface AccessibilitySettings {
  fontScale: 'sm' | 'md' | 'lg';
  highContrast: boolean;
  lowPerfMode: boolean;
}

export interface TournamentState {
  id?: string;
  players: string[];
  playerPhotos?: Record<number, string>;
  playerBios?: Record<number, PlayerBio>;
  matchFormat: MatchFormat;
  matchFormats?: Record<string, MatchFormat>;
  tournamentFormat?: TournamentFormatType;
  category?: CompetitionCategory;
  venue?: string;
  venueLocation?: VenueLocation;
  description?: string;
  customRules?: CustomTournamentRules;
  defaultMatchDurationMinutes?: number;
  archived?: boolean;
  manualSeedOrder?: boolean;
  results: Record<string, number>;
  scores?: Record<string, MatchScore>;
  matchMeta?: Record<string, MatchMetaInfo>;
  matchMvps?: Record<string, number>;
  manualFixtures?: TournamentMatch[];
  doubleElim?: DoubleElimBracketState;
  consolationBracket?: ConsolationBracketState;
  semis: Record<number, number>;
  semiScores?: Record<number, MatchScore>;
  quarters?: Record<number, number>;
  quarterScores?: Record<number, MatchScore>;
  thirdPlaceWinner?: number | null;
  thirdPlaceScore?: MatchScore;
  finalWinner: number | null;
  finalScore?: MatchScore;
  started: boolean;
  tournamentTitle: string;
  customLogoUrl?: string;
  createdDate: string;
  shuttleEquipment?: ShuttleEquipment;
  announcements?: TournamentAnnouncement[];
  referees?: string[];
  matchSchedules?: Record<string, MatchScheduleInfo>;
}

export interface QuickMatchRecord {
  id: string;
  title: string;
  category: 'singles' | 'doubles';
  playerAName: string;
  playerBName: string;
  matchFormat: MatchFormat;
  pointsPerSet: number;
  setScores: Array<{ a: number; b: number }>;
  winner: 'A' | 'B';
  mvpWinner?: boolean;
  durationSeconds: number;
  playedAt: string;
}

export interface TournamentStore {
  activeTournamentId: string;
  tournaments: TournamentState[];
  language: AppLanguage;
  appPin?: string | null;
  biometricCredentialId?: string | null;
  hapticsEnabled?: boolean;
  animationsEnabled?: boolean;
  notificationsEnabled?: boolean;
  autoBackupEnabled?: boolean;
  lastBackupAt?: string;
  userRoleMode?: UserRoleMode;
  spectatorMode?: boolean;
  selectedThemeId?: string;
  wallpaper?: WallpaperSettings;
  userAccount?: UserAccount | null;
  quickMatches?: QuickMatchRecord[];
  doublesTeams?: DoublesTeam[];
  rankingConfig?: RankingConfig;
  courts?: CourtRecord[];
  courtHistory?: CourtMatchHistoryEntry[];
  favouriteTournamentIds?: string[];
  recentTournamentIds?: string[];
  financialRecords?: FinancialRecord[];
  adminAccounts?: AdminAccount[];
  activeAdminName?: string;
  auditLogs?: AdminAuditLog[];
  accessibility?: AccessibilitySettings;
  onboardingDone?: boolean;
}
