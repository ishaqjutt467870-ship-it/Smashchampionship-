/**
 * Optional Browser Biometric (WebAuthn Platform Authenticator) helpers.
 * Safely degrades on restricted frames or non-supporting devices without throwing uncaught errors.
 */

export function isBiometricSupported(): boolean {
  try {
    return (
      typeof window !== 'undefined' &&
      window.isSecureContext &&
      'PublicKeyCredential' in window &&
      typeof navigator !== 'undefined' &&
      Boolean(navigator.credentials?.create)
    );
  } catch {
    return false;
  }
}

function bufferToBase64Url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlToUint8Array(base64Url: string): Uint8Array {
  const padding = '='.repeat((4 - (base64Url.length % 4)) % 4);
  const base64 = (base64Url + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export async function enrollBiometricCredential(
  label: string = 'Tournament Admin'
): Promise<{ ok: boolean; credentialId?: string; message: string }> {
  if (!isBiometricSupported()) {
    return {
      ok: false,
      message: 'Biometric passkeys require HTTPS / supported device hardware.',
    };
  }

  try {
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const userId = crypto.getRandomValues(new Uint8Array(16));
    const credential = (await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: 'Smash Championship' },
        user: {
          id: userId,
          name: label,
          displayName: label,
        },
        pubKeyCredParams: [
          { type: 'public-key', alg: -7 },
          { type: 'public-key', alg: -257 },
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'preferred',
        },
        timeout: 45000,
      },
    })) as PublicKeyCredential | null;

    if (!credential) {
      return { ok: false, message: 'Biometric enrollment was cancelled.' };
    }
    return {
      ok: true,
      credentialId: bufferToBase64Url(credential.rawId),
      message: 'Biometric unlock enrolled on this device.',
    };
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : 'Unable to register biometric authenticator.';
    return { ok: false, message: msg };
  }
}

export async function verifyBiometricCredential(
  credentialId: string
): Promise<{ ok: boolean; message: string }> {
  if (!isBiometricSupported() || !credentialId) {
    return { ok: false, message: 'Biometric authenticator unavailable here.' };
  }
  try {
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const rawId = base64UrlToUint8Array(credentialId);
    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge,
        allowCredentials: [
          {
            type: 'public-key',
            id: rawId.buffer as ArrayBuffer,
          },
        ],
        userVerification: 'preferred',
        timeout: 45000,
      },
    });
    if (!assertion) {
      return { ok: false, message: 'Biometric check failed.' };
    }
    return { ok: true, message: 'Biometric identity verified.' };
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : 'Biometric verification cancelled or blocked.';
    return { ok: false, message: msg };
  }
}
