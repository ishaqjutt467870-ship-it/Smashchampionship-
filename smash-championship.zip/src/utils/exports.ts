import JSZip from 'jszip';
import { FinancialRecord, MatchScore, PlayerStats, TournamentMatch, TournamentState, TournamentStore } from '../types';
import { calculateStandings, formatScore, generateFixtures } from './tournament';
import { generateTournamentAutoReport } from './reports';

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function escapeCSV(val: string | number | undefined): string {
  const str = String(val ?? '');
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function getTournamentSlug(state: TournamentState): string {
  return (state.tournamentTitle || 'smash-championship')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'smash-championship';
}

function extractSetArray(score?: MatchScore): Array<{ set: number; scoreA: number; scoreB: number }> {
  if (!score) return [];
  const pairs: Array<[number | undefined, number | undefined]> = [
    [score.s1a, score.s1b],
    [score.s2a, score.s2b],
    [score.s3a, score.s3b],
    [score.s4a, score.s4b],
    [score.s5a, score.s5b],
  ];
  const sets: Array<{ set: number; scoreA: number; scoreB: number }> = [];
  pairs.forEach(([a, b], idx) => {
    if (a !== undefined && b !== undefined) {
      sets.push({ set: idx + 1, scoreA: a, scoreB: b });
    }
  });
  return sets;
}

export interface ExportMatchHistoryEntry {
  matchId: string;
  stage: string;
  matchNumber: number | string;
  group: string;
  playerA: string;
  playerB: string;
  status: 'Completed' | 'Scheduled';
  winner: string | null;
  loser: string | null;
  matchMvp: string | null;
  format: string;
  scoreSummary: string;
  sets: Array<{ set: number; scoreA: number; scoreB: number }>;
  courtNumber: number | null;
  referee: string | null;
  scheduledTime: string | null;
}

export function buildAllMatchHistoryEntries(
  state: TournamentState,
  standings: PlayerStats[],
  fixtures: TournamentMatch[]
): ExportMatchHistoryEntry[] {
  const fmt = state.tournamentFormat || 'round_robin';
  const defaultMatchFmt = state.matchFormat || 'bo3';
  const mvps = state.matchMvps || {};
  const schedules = state.matchSchedules || {};
  const entries: ExportMatchHistoryEntry[] = [];

  fixtures.forEach((m, idx) => {
    const isBye = m.isBye || m.playerBIndex < 0;
    const playerA = state.players[m.playerAIndex] || `Player ${m.playerAIndex + 1}`;
    const playerB = isBye ? 'BYE' : state.players[m.playerBIndex] || `Player ${m.playerBIndex + 1}`;
    const winnerIdx = state.results?.[m.id];
    const isCompleted = winnerIdx !== undefined;
    const loserIdx =
      isCompleted && !isBye
        ? winnerIdx === m.playerAIndex
          ? m.playerBIndex
          : m.playerAIndex
        : undefined;
    const mvpIdx = mvps[m.id];
    const score = state.scores?.[m.id];
    const sched = schedules[m.id];

    entries.push({
      matchId: m.id,
      stage: m.group ? `Group ${m.group}` : fmt === 'knockout' ? 'Opening Round' : 'League Stage',
      matchNumber: m.roundNumber || idx + 1,
      group: m.group || '-',
      playerA,
      playerB,
      status: isCompleted || isBye ? 'Completed' : 'Scheduled',
      winner: isBye ? playerA : isCompleted ? state.players[winnerIdx] || null : null,
      loser: loserIdx !== undefined ? state.players[loserIdx] || null : null,
      matchMvp: mvpIdx !== undefined ? state.players[mvpIdx] || null : null,
      format: (state.matchFormats?.[m.id] || defaultMatchFmt).toUpperCase(),
      scoreSummary: formatScore(score),
      sets: extractSetArray(score),
      courtNumber: sched?.courtNumber ?? m.courtNumber ?? null,
      referee: sched?.referee ?? state.customRules?.refereeName ?? null,
      scheduledTime: sched?.time ?? null,
    });
  });

  // Include completed knockout playoff matches
  const groupA = standings.filter((p) => p.group === 'A');
  const groupB = standings.filter((p) => p.group === 'B');
  const useGroupSeeding = fmt === 'group_stage' && groupA.length >= 2 && groupB.length >= 2;
  const quarters = state.quarters || {};
  const allQuartersComplete =
    standings.length >= 8 &&
    quarters[0] !== undefined &&
    quarters[1] !== undefined &&
    quarters[2] !== undefined &&
    quarters[3] !== undefined;

  if (standings.length >= 8) {
    const qfPairs: Array<[number, number]> = [
      [standings[0].id, standings[7].id],
      [standings[3].id, standings[4].id],
      [standings[1].id, standings[6].id],
      [standings[2].id, standings[5].id],
    ];
    qfPairs.forEach(([aId, bId], qIdx) => {
      const w = quarters[qIdx];
      if (w === undefined) return;
      const mId = `ko:qf-${qIdx}`;
      const score = state.quarterScores?.[qIdx];
      const lId = w === aId ? bId : aId;
      const mvpIdx = mvps[mId];
      entries.push({
        matchId: mId,
        stage: 'Quarter-Final',
        matchNumber: `QF${qIdx + 1}`,
        group: 'Playoffs',
        playerA: state.players[aId] || `Player ${aId + 1}`,
        playerB: state.players[bId] || `Player ${bId + 1}`,
        status: 'Completed',
        winner: state.players[w] || null,
        loser: state.players[lId] || null,
        matchMvp: mvpIdx !== undefined ? state.players[mvpIdx] || null : null,
        format: (state.matchFormats?.[`qf-${qIdx}`] || defaultMatchFmt).toUpperCase(),
        scoreSummary: formatScore(score),
        sets: extractSetArray(score),
        courtNumber: null,
        referee: state.customRules?.refereeName ?? null,
        scheduledTime: null,
      });
    });
  }

  if (standings.length >= 4) {
    const sf1A = allQuartersComplete ? quarters[0] : useGroupSeeding ? groupA[0].id : standings[0].id;
    const sf1B = allQuartersComplete ? quarters[1] : useGroupSeeding ? groupB[1].id : standings[3].id;
    const sf2A = allQuartersComplete ? quarters[2] : useGroupSeeding ? groupB[0].id : standings[1].id;
    const sf2B = allQuartersComplete ? quarters[3] : useGroupSeeding ? groupA[1].id : standings[2].id;

    [
      { idx: 0, a: sf1A, b: sf1B, num: 'SF1' },
      { idx: 1, a: sf2A, b: sf2B, num: 'SF2' },
    ].forEach((sf) => {
      const w = state.semis?.[sf.idx];
      if (w === undefined) return;
      const mId = `ko:sf-${sf.idx}`;
      const score = state.semiScores?.[sf.idx];
      const lId = w === sf.a ? sf.b : sf.a;
      const mvpIdx = mvps[mId];
      entries.push({
        matchId: mId,
        stage: 'Semi-Final',
        matchNumber: sf.num,
        group: 'Playoffs',
        playerA: state.players[sf.a] || `Player ${sf.a + 1}`,
        playerB: state.players[sf.b] || `Player ${sf.b + 1}`,
        status: 'Completed',
        winner: state.players[w] || null,
        loser: state.players[lId] || null,
        matchMvp: mvpIdx !== undefined ? state.players[mvpIdx] || null : null,
        format: (state.matchFormats?.[`sf-${sf.idx}`] || defaultMatchFmt).toUpperCase(),
        scoreSummary: formatScore(score),
        sets: extractSetArray(score),
        courtNumber: null,
        referee: state.customRules?.refereeName ?? null,
        scheduledTime: null,
      });
    });

    const sf1W = state.semis?.[0];
    const sf2W = state.semis?.[1];
    if (sf1W !== undefined && sf2W !== undefined) {
      if (state.finalWinner !== null && state.finalWinner !== undefined) {
        const lId = state.finalWinner === sf1W ? sf2W : sf1W;
        const mvpIdx = mvps['ko:final'];
        entries.push({
          matchId: 'ko:final',
          stage: 'Grand Final',
          matchNumber: 'FINAL',
          group: 'Playoffs',
          playerA: state.players[sf1W] || `Player ${sf1W + 1}`,
          playerB: state.players[sf2W] || `Player ${sf2W + 1}`,
          status: 'Completed',
          winner: state.players[state.finalWinner] || null,
          loser: state.players[lId] || null,
          matchMvp: mvpIdx !== undefined ? state.players[mvpIdx] || null : null,
          format: (state.matchFormats?.['final'] || defaultMatchFmt).toUpperCase(),
          scoreSummary: formatScore(state.finalScore),
          sets: extractSetArray(state.finalScore),
          courtNumber: null,
          referee: state.customRules?.refereeName ?? null,
          scheduledTime: null,
        });
      }

      const sf1L = sf1W === sf1A ? sf1B : sf1A;
      const sf2L = sf2W === sf2A ? sf2B : sf2A;
      if (state.thirdPlaceWinner !== null && state.thirdPlaceWinner !== undefined) {
        const lId = state.thirdPlaceWinner === sf1L ? sf2L : sf1L;
        const mvpIdx = mvps['ko:third'];
        entries.push({
          matchId: 'ko:third',
          stage: '3rd Place Playoff',
          matchNumber: '3RD',
          group: 'Playoffs',
          playerA: state.players[sf1L] || `Player ${sf1L + 1}`,
          playerB: state.players[sf2L] || `Player ${sf2L + 1}`,
          status: 'Completed',
          winner: state.players[state.thirdPlaceWinner] || null,
          loser: state.players[lId] || null,
          matchMvp: mvpIdx !== undefined ? state.players[mvpIdx] || null : null,
          format: (state.matchFormats?.['third'] || defaultMatchFmt).toUpperCase(),
          scoreSummary: formatScore(state.thirdPlaceScore),
          sets: extractSetArray(state.thirdPlaceScore),
          courtNumber: null,
          referee: state.customRules?.refereeName ?? null,
          scheduledTime: null,
        });
      }
    }
  }

  return entries;
}

export function buildStandingsCSVRows(state: TournamentState, standings: PlayerStats[]) {
  const headers = [
    'Rank',
    'Player ID',
    'Player Name',
    'Group',
    'Matches Played',
    'Won',
    'Lost',
    'Win %',
    'Sets Won',
    'Sets Lost',
    'Points Scored',
    'Points Conceded',
    'Point Diff',
    'League Points',
    'Match MVPs',
  ];

  const mvpValues = Object.values(state.matchMvps || {});
  const rows = standings.map((p, idx) => {
    const winPct = p.played > 0 ? Math.round((p.won / p.played) * 100) : 0;
    const diff = p.pointsFor - p.pointsAgainst;
    const mvpCount = mvpValues.filter((pid) => pid === p.id).length;
    return [
      idx + 1,
      p.bio?.playerCode || `#SC-${String(p.id + 1).padStart(2, '0')}`,
      p.name,
      p.group || '-',
      p.played,
      p.won,
      p.lost,
      `${winPct}%`,
      p.setsWon,
      p.setsLost,
      p.pointsFor,
      p.pointsAgainst,
      diff > 0 ? `+${diff}` : diff,
      p.points,
      mvpCount,
    ]
      .map(escapeCSV)
      .join(',');
  });

  return { headers, rows };
}

export function buildStandingsCSVContent(state: TournamentState, standings: PlayerStats[]): string {
  const { headers, rows } = buildStandingsCSVRows(state, standings);
  return '\uFEFF' + [headers.join(','), ...rows].join('\n');
}

export function downloadStandingsCSV(state: TournamentState, standings: PlayerStats[]) {
  const csvContent = buildStandingsCSVContent(state, standings);
  triggerDownload(
    new Blob([csvContent], { type: 'text/csv;charset=utf-8;' }),
    `${getTournamentSlug(state)}-standings.csv`
  );
}

export function buildMatchesCSVContent(
  state: TournamentState,
  fixtures: TournamentMatch[],
  standings?: PlayerStats[]
): string {
  const resolvedStandings =
    standings ||
    calculateStandings(
      state.players,
      state.results || {},
      state.scores || {},
      state.playerPhotos,
      state.playerBios,
      state.tournamentFormat || 'round_robin'
    );
  const entries = buildAllMatchHistoryEntries(state, resolvedStandings, fixtures);

  const headers = [
    'Stage',
    'Match #',
    'Group',
    'Player A',
    'Player B',
    'Status',
    'Winner',
    'Match MVP',
    'Format',
    'Set Scores',
    'Court',
    'Referee',
  ];

  const rows = entries.map((m) =>
    [
      m.stage,
      m.matchNumber,
      m.group,
      m.playerA,
      m.playerB,
      m.status,
      m.winner || 'Pending',
      m.matchMvp || '-',
      m.format,
      m.scoreSummary || '-',
      m.courtNumber ?? '-',
      m.referee || '-',
    ]
      .map(escapeCSV)
      .join(',')
  );

  return '\uFEFF' + [headers.join(','), ...rows].join('\n');
}

export function downloadMatchesCSV(
  state: TournamentState,
  fixtures: TournamentMatch[],
  standings?: PlayerStats[]
) {
  const csvContent = buildMatchesCSVContent(state, fixtures, standings);
  triggerDownload(
    new Blob([csvContent], { type: 'text/csv;charset=utf-8;' }),
    `${getTournamentSlug(state)}-match-history.csv`
  );
}

export function buildTournamentAnalyticsCSVContent(
  state: TournamentState,
  standings: PlayerStats[],
  fixtures?: TournamentMatch[]
): string {
  const resolvedFixtures =
    fixtures || generateFixtures(state.players.length, state.tournamentFormat || 'round_robin');
  const { headers: sHeaders, rows: sRows } = buildStandingsCSVRows(state, standings);
  const entries = buildAllMatchHistoryEntries(state, standings, resolvedFixtures);

  const mHeaders = [
    'Stage',
    'Match #',
    'Group',
    'Player A',
    'Player B',
    'Status',
    'Winner',
    'Match MVP',
    'Format',
    'Set Scores',
    'Court',
    'Referee',
  ];
  const mRows = entries.map((m) =>
    [
      m.stage,
      m.matchNumber,
      m.group,
      m.playerA,
      m.playerB,
      m.status,
      m.winner || 'Pending',
      m.matchMvp || '-',
      m.format,
      m.scoreSummary || '-',
      m.courtNumber ?? '-',
      m.referee || '-',
    ]
      .map(escapeCSV)
      .join(',')
  );

  const metaLines = [
    ['Tournament', state.tournamentTitle || 'Smash Championship'].map(escapeCSV).join(','),
    ['Venue', state.venue || 'Center Arena Court'].map(escapeCSV).join(','),
    ['Category', state.category || 'singles'].map(escapeCSV).join(','),
    ['Format', state.tournamentFormat || 'round_robin'].map(escapeCSV).join(','),
    ['Points Per Set', state.customRules?.pointsPerSet ?? 21].map(escapeCSV).join(','),
    ['Exported At', new Date().toISOString()].map(escapeCSV).join(','),
    '',
    'SECTION: TOURNAMENT STANDINGS',
    sHeaders.join(','),
    ...sRows,
    '',
    'SECTION: MATCH HISTORY',
    mHeaders.join(','),
    ...mRows,
  ];

  return '\uFEFF' + metaLines.join('\n');
}

export function downloadTournamentAnalyticsCSV(
  state: TournamentState,
  standings: PlayerStats[],
  fixtures?: TournamentMatch[]
) {
  const csvContent = buildTournamentAnalyticsCSVContent(state, standings, fixtures);
  triggerDownload(
    new Blob([csvContent], { type: 'text/csv;charset=utf-8;' }),
    `${getTournamentSlug(state)}-standings-and-history.csv`
  );
}

export function buildTournamentAnalyticsPayload(
  state: TournamentState,
  standings: PlayerStats[],
  fixtures?: TournamentMatch[]
) {
  const resolvedFixtures =
    fixtures || generateFixtures(state.players.length, state.tournamentFormat || 'round_robin');
  const matchHistory = buildAllMatchHistoryEntries(state, standings, resolvedFixtures);
  const mvpValues = Object.values(state.matchMvps || {});

  const sf1 = state.semis?.[0];
  const sf2 = state.semis?.[1];
  const runnerUpIdx =
    state.finalWinner !== null && sf1 !== undefined && sf2 !== undefined
      ? state.finalWinner === sf1
        ? sf2
        : sf1
      : null;

  const completedCount = matchHistory.filter((m) => m.status === 'Completed').length;
  const totalPointsPlayed = matchHistory.reduce(
    (sum, m) => sum + m.sets.reduce((sSum, s) => sSum + s.scoreA + s.scoreB, 0),
    0
  );

  return {
    exportedAt: new Date().toISOString(),
    tournament: {
      id: state.id || null,
      title: state.tournamentTitle || 'Smash Championship',
      venue: state.venue || 'Center Arena Court',
      category: state.category || 'singles',
      tournamentFormat: state.tournamentFormat || 'round_robin',
      matchFormat: state.matchFormat || 'bo3',
      pointsPerSet: state.customRules?.pointsPerSet ?? 21,
      referee: state.customRules?.refereeName || 'Hassan',
      createdDate: state.createdDate,
      champion: state.finalWinner !== null ? state.players[state.finalWinner] || null : null,
      runnerUp: runnerUpIdx !== null ? state.players[runnerUpIdx] || null : null,
      thirdPlace:
        state.thirdPlaceWinner !== null && state.thirdPlaceWinner !== undefined
          ? state.players[state.thirdPlaceWinner] || null
          : null,
    },
    summary: {
      totalPlayers: state.players.length,
      totalMatches: matchHistory.length,
      completedMatches: completedCount,
      pendingMatches: matchHistory.length - completedCount,
      completionPercentage:
        matchHistory.length > 0 ? Math.round((completedCount / matchHistory.length) * 100) : 0,
      totalRallyPointsRecorded: totalPointsPlayed,
    },
    standings: standings.map((p, idx) => {
      const winPct = p.played > 0 ? Math.round((p.won / p.played) * 100) : 0;
      const pointDiff = p.pointsFor - p.pointsAgainst;
      const setDiff = p.setsWon - p.setsLost;
      const matchMvpsAwarded = mvpValues.filter((pid) => pid === p.id).length;
      return {
        rank: idx + 1,
        playerCode: p.bio?.playerCode || `#SC-${String(p.id + 1).padStart(2, '0')}`,
        playerName: p.name,
        group: p.group || null,
        played: p.played,
        won: p.won,
        lost: p.lost,
        winPercentage: winPct,
        setsWon: p.setsWon,
        setsLost: p.setsLost,
        setDifference: setDiff,
        pointsFor: p.pointsFor,
        pointsAgainst: p.pointsAgainst,
        pointDifference: pointDiff,
        leaguePoints: p.points,
        matchMvpsAwarded,
        recentForm: p.form,
      };
    }),
    matchHistory,
  };
}

export function downloadTournamentAnalyticsJSON(
  state: TournamentState,
  standings: PlayerStats[],
  fixtures?: TournamentMatch[]
) {
  const payload = buildTournamentAnalyticsPayload(state, standings, fixtures);
  triggerDownload(
    new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8;' }),
    `${getTournamentSlug(state)}-analytics.json`
  );
}

export async function downloadTournamentZip(
  state: TournamentState,
  standings: PlayerStats[],
  fixtures?: TournamentMatch[],
  fullStore?: TournamentStore
) {
  const slug = getTournamentSlug(state);
  const resolvedFixtures =
    fixtures || generateFixtures(state.players.length, state.tournamentFormat || 'round_robin');

  const zip = new JSZip();
  const folder = zip.folder(slug) || zip;

  const analyticsPayload = buildTournamentAnalyticsPayload(state, standings, resolvedFixtures);
  const standingsCsv = buildStandingsCSVContent(state, standings);
  const matchesCsv = buildMatchesCSVContent(state, resolvedFixtures, standings);
  const combinedCsv = buildTournamentAnalyticsCSVContent(state, standings, resolvedFixtures);
  const autoReport = generateTournamentAutoReport(state, standings, resolvedFixtures);

  folder.file(`${slug}-analytics.json`, JSON.stringify(analyticsPayload, null, 2));
  folder.file(`${slug}-standings.csv`, standingsCsv);
  folder.file(`${slug}-match-history.csv`, matchesCsv);
  folder.file(`${slug}-standings-and-history.csv`, combinedCsv);
  folder.file(`${slug}-official-report.md`, autoReport.markdownText);
  folder.file(`${slug}-state-backup.json`, JSON.stringify(state, null, 2));

  if (fullStore) {
    folder.file('hassan-badminton-full-backup.json', JSON.stringify(fullStore, null, 2));
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  triggerDownload(blob, `${slug}-export-bundle.zip`);
}

export interface ScoreboardImageOptions {
  tournamentTitle: string;
  courtNumber: number;
  currentSet: number;
  playerA: string;
  playerB: string;
  pointsA: number;
  pointsB: number;
  setsWonA: number;
  setsWonB: number;
  completedSets: Array<{ a: number; b: number }>;
  server: 'A' | 'B';
}

export function downloadScoreboardImage(opts: ScoreboardImageOptions) {
  const canvas = document.createElement('canvas');
  canvas.width = 1200;
  canvas.height = 675;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Deep Black background (#080808)
  ctx.fillStyle = '#080808';
  ctx.fillRect(0, 0, 1200, 675);

  // Gold Championship Top Accent Bar
  const grad = ctx.createLinearGradient(0, 0, 1200, 0);
  grad.addColorStop(0, '#D4AF37');
  grad.addColorStop(0.5, '#FFD700');
  grad.addColorStop(1, '#D4AF37');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1200, 8);

  // Header strip
  ctx.fillStyle = '#141414';
  ctx.fillRect(48, 36, 1104, 86);
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.45)';
  ctx.lineWidth = 2;
  ctx.strokeRect(48, 36, 1104, 86);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 30px Outfit, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(opts.tournamentTitle.toUpperCase(), 76, 82);

  ctx.fillStyle = '#A0A0A0';
  ctx.font = '600 16px sans-serif';
  ctx.fillText('Developed By Hassan · Hassan developers', 76, 108);

  // Court badge
  ctx.fillStyle = '#FFD700';
  ctx.font = '800 22px monospace';
  ctx.textAlign = 'right';
  ctx.fillText(`COURT ${opts.courtNumber} · SET ${opts.currentSet}`, 1122, 86);

  // Player Card Renderer
  const drawPlayerCard = (
    x: number,
    name: string,
    points: number,
    setsWon: number,
    isServing: boolean,
    label: string
  ) => {
    ctx.fillStyle = '#141414';
    ctx.fillRect(x, 154, 520, 380);
    ctx.strokeStyle = isServing ? '#FFD700' : 'rgba(212, 175, 55, 0.25)';
    ctx.lineWidth = isServing ? 4 : 2;
    ctx.strokeRect(x, 154, 520, 380);

    if (isServing) {
      ctx.fillStyle = '#D4AF37';
      ctx.fillRect(x + 28, 182, 130, 34);
      ctx.fillStyle = '#080808';
      ctx.font = '900 16px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('SERVING', x + 93, 205);
    } else {
      ctx.fillStyle = '#A0A0A0';
      ctx.font = '700 16px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(label, x + 28, 204);
    }

    ctx.fillStyle = '#A0A0A0';
    ctx.font = '700 18px monospace';
    ctx.textAlign = 'right';
    ctx.fillText(`GAMES: ${setsWon}`, x + 492, 205);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '800 38px sans-serif';
    ctx.textAlign = 'center';
    const displayName = name.length > 18 ? name.slice(0, 17) + '…' : name;
    ctx.fillText(displayName, x + 260, 285);

    ctx.fillStyle = isServing ? '#FFD700' : '#FFFFFF';
    ctx.font = '900 160px monospace';
    ctx.fillText(String(points), x + 260, 465);
  };

  drawPlayerCard(48, opts.playerA, opts.pointsA, opts.setsWonA, opts.server === 'A', 'SIDE A');
  drawPlayerCard(632, opts.playerB, opts.pointsB, opts.setsWonB, opts.server === 'B', 'SIDE B');

  // VS Gold Seal
  ctx.fillStyle = '#D4AF37';
  ctx.beginPath();
  ctx.arc(600, 344, 30, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#080808';
  ctx.font = '900 20px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('VS', 600, 351);

  // Bottom bar
  ctx.fillStyle = '#141414';
  ctx.fillRect(48, 562, 1104, 72);
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.35)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(48, 562, 1104, 72);

  const setSummary =
    opts.completedSets.length > 0
      ? opts.completedSets.map((s, i) => `Game ${i + 1}: ${s.a}-${s.b}`).join('   |   ')
      : 'Live Match Scoreboard Snapshot';

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '700 20px monospace';
  ctx.textAlign = 'left';
  ctx.fillText(setSummary, 76, 606);

  ctx.fillStyle = '#D4AF37';
  ctx.font = '700 16px sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('SMASH CHAMPIONSHIP · OFFICIAL SCOREBOARD', 1122, 605);

  canvas.toBlob((blob) => {
    if (blob) {
      triggerDownload(blob, `smash-scoreboard-court-${opts.courtNumber}.png`);
    }
  }, 'image/png');
}

function drawGoldFrame(ctx: CanvasRenderingContext2D, width: number, height: number) {
  ctx.fillStyle = '#080808';
  ctx.fillRect(0, 0, width, height);

  // Radial gold ambient glow
  const glow = ctx.createRadialGradient(width / 2, height * 0.28, 40, width / 2, height * 0.35, width * 0.55);
  glow.addColorStop(0, 'rgba(212, 175, 55, 0.18)');
  glow.addColorStop(1, 'rgba(8, 8, 8, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, width, height);

  // Outer gold border
  const grad = ctx.createLinearGradient(0, 0, width, height);
  grad.addColorStop(0, '#D4AF37');
  grad.addColorStop(0.5, '#FFD700');
  grad.addColorStop(1, '#D4AF37');
  ctx.strokeStyle = grad;
  ctx.lineWidth = 6;
  ctx.strokeRect(20, 20, width - 40, height - 40);

  ctx.strokeStyle = 'rgba(212, 175, 55, 0.35)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(34, 34, width - 68, height - 68);
}

export function downloadMatchResultPoster(opts: {
  tournamentTitle: string;
  stageLabel: string;
  playerA: string;
  playerB: string;
  winnerName: string;
  scoreSummary: string;
  isMvp?: boolean;
  venue?: string;
}) {
  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 1080;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  drawGoldFrame(ctx, 1080, 1080);

  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 22px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('OFFICIAL MATCH RESULT', 540, 110);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 42px Outfit, sans-serif';
  ctx.fillText(opts.tournamentTitle.toUpperCase().slice(0, 28), 540, 170);

  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 22px sans-serif';
  ctx.fillText(`${opts.stageLabel} · ${opts.venue || 'Center Arena Court'}`, 540, 215);

  // Winner Banner Card
  ctx.fillStyle = '#141414';
  ctx.fillRect(90, 270, 900, 420);
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 3;
  ctx.strokeRect(90, 270, 900, 420);

  ctx.fillStyle = '#FFD700';
  ctx.font = '800 24px monospace';
  ctx.fillText('MATCH WINNER', 540, 340);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 58px Outfit, sans-serif';
  ctx.fillText(opts.winnerName.slice(0, 22), 540, 425);

  if (opts.isMvp) {
    ctx.fillStyle = '#D4AF37';
    ctx.fillRect(390, 455, 300, 44);
    ctx.fillStyle = '#080808';
    ctx.font = '900 20px sans-serif';
    ctx.fillText('★ MATCH MVP AWARDED ★', 540, 484);
  }

  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 28px sans-serif';
  ctx.fillText(`${opts.playerA}  vs  ${opts.playerB}`, 540, 565);

  ctx.fillStyle = '#FFD700';
  ctx.font = '900 44px monospace';
  ctx.fillText(opts.scoreSummary || 'VICTORY', 540, 640);

  // Footer
  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 22px sans-serif';
  ctx.fillText('HASSAN BADMINTON TOURNAMENT MANAGER', 540, 950);
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '600 18px sans-serif';
  ctx.fillText('Developed By Hassan · Smash Championship Edition', 540, 990);

  canvas.toBlob((blob) => {
    if (blob) {
      triggerDownload(blob, `match-result-${opts.winnerName.toLowerCase().replace(/\s+/g, '-')}.png`);
    }
  }, 'image/png');
}

export function downloadTournamentWinnerPoster(opts: {
  tournamentTitle: string;
  championName: string;
  runnerUpName?: string;
  thirdPlaceName?: string;
  venue?: string;
  date?: string;
  totalMatches?: number;
}) {
  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 1350;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  drawGoldFrame(ctx, 1080, 1350);

  ctx.fillStyle = '#FFD700';
  ctx.font = '800 24px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('CHAMPIONSHIP CROWN', 540, 130);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 48px Outfit, sans-serif';
  ctx.fillText(opts.tournamentTitle.toUpperCase().slice(0, 26), 540, 200);

  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 22px sans-serif';
  ctx.fillText(`${opts.venue || 'Center Arena Court'} · ${opts.date || new Date().toLocaleDateString()}`, 540, 245);

  // Trophy Circle
  ctx.fillStyle = '#141414';
  ctx.beginPath();
  ctx.arc(540, 420, 110, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 4;
  ctx.stroke();

  ctx.fillStyle = '#FFD700';
  ctx.font = '900 84px sans-serif';
  ctx.fillText('🏆', 540, 448);

  // Champion Card
  ctx.fillStyle = '#141414';
  ctx.fillRect(90, 580, 900, 250);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 3;
  ctx.strokeRect(90, 580, 900, 250);

  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 24px monospace';
  ctx.fillText('GRAND TOURNAMENT CHAMPION', 540, 645);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 64px Outfit, sans-serif';
  ctx.fillText(opts.championName.slice(0, 20), 540, 740);

  ctx.fillStyle = '#22C55E';
  ctx.font = '800 22px monospace';
  ctx.fillText(`${opts.totalMatches || 0} OFFICIAL MATCHES COMPLETED`, 540, 795);

  // Podium Info
  ctx.fillStyle = '#141414';
  ctx.fillRect(90, 875, 430, 160);
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.35)';
  ctx.lineWidth = 2;
  ctx.strokeRect(90, 875, 430, 160);
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 18px monospace';
  ctx.fillText('2ND PLACE · RUNNER-UP', 305, 930);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 30px sans-serif';
  ctx.fillText((opts.runnerUpName || 'TBD').slice(0, 18), 305, 985);

  ctx.fillStyle = '#141414';
  ctx.fillRect(560, 875, 430, 160);
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.35)';
  ctx.strokeRect(560, 875, 430, 160);
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 18px monospace';
  ctx.fillText('3RD PLACE · BRONZE', 775, 930);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 30px sans-serif';
  ctx.fillText((opts.thirdPlaceName || 'TBD').slice(0, 18), 775, 985);

  // Footer
  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 24px sans-serif';
  ctx.fillText('SMASH CHAMPIONSHIP · OFFICIAL EDITION', 540, 1190);
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '600 18px sans-serif';
  ctx.fillText('Developed By Hassan · Hassan developers', 540, 1230);

  canvas.toBlob((blob) => {
    if (blob) {
      triggerDownload(blob, `champion-poster-${opts.championName.toLowerCase().replace(/\s+/g, '-')}.png`);
    }
  }, 'image/png');
}

export function downloadPlayerAchievementCard(opts: {
  playerName: string;
  playerCode: string;
  rank: number;
  ratingPoints: number;
  wins: number;
  losses: number;
  winRate: number;
  titles: number;
  mvpCount: number;
  category?: string;
}) {
  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 675;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  drawGoldFrame(ctx, 1080, 675);

  ctx.textAlign = 'left';
  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 20px monospace';
  ctx.fillText(`PLAYER ACHIEVEMENT CARD · ${opts.playerCode}`, 76, 95);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 54px Outfit, sans-serif';
  ctx.fillText(opts.playerName.slice(0, 22), 76, 170);

  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 20px sans-serif';
  ctx.fillText(`Category: ${(opts.category || 'Singles').toUpperCase()}  |  Global Rank: #${opts.rank}`, 76, 212);

  // Stats Row
  const metrics = [
    { label: 'RANK PTS', value: String(opts.ratingPoints), color: '#FFD700' },
    { label: 'RECORD', value: `${opts.wins}W-${opts.losses}L`, color: '#FFFFFF' },
    { label: 'WIN RATE', value: `${opts.winRate}%`, color: '#22C55E' },
    { label: 'TITLES', value: String(opts.titles), color: '#FFD700' },
    { label: 'MATCH MVP', value: String(opts.mvpCount), color: '#D4AF37' },
  ];

  metrics.forEach((m, i) => {
    const x = 76 + i * 188;
    ctx.fillStyle = '#141414';
    ctx.fillRect(x, 270, 172, 190);
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.35)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, 270, 172, 190);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#A0A0A0';
    ctx.font = '700 15px monospace';
    ctx.fillText(m.label, x + 86, 320);

    ctx.fillStyle = m.color;
    ctx.font = '900 40px monospace';
    ctx.fillText(m.value, x + 86, 395);
  });

  ctx.textAlign = 'center';
  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 20px sans-serif';
  ctx.fillText('HASSAN BADMINTON TOURNAMENT MANAGER · SMASH CHAMPIONSHIP', 540, 560);
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '600 16px sans-serif';
  ctx.fillText('Verified Player Career Statistics · Developed By Hassan', 540, 595);

  canvas.toBlob((blob) => {
    if (blob) {
      triggerDownload(blob, `player-card-${opts.playerName.toLowerCase().replace(/\s+/g, '-')}.png`);
    }
  }, 'image/png');
}

export function downloadSocialGraphic(opts: {
  tournamentTitle: string;
  headline: string;
  subline: string;
  highlightValue: string;
  clubName?: string;
  sponsorText?: string;
  aspect?: 'square' | 'story';
}) {
  const isStory = opts.aspect === 'story';
  const width = 1080;
  const height = isStory ? 1920 : 1080;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  drawGoldFrame(ctx, width, height);

  const cy = height / 2;
  ctx.textAlign = 'center';

  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 22px monospace';
  ctx.fillText((opts.clubName || 'SMASH CHAMPIONSHIP SERIES').toUpperCase().slice(0, 34), 540, isStory ? 220 : 125);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 48px Outfit, sans-serif';
  ctx.fillText(opts.tournamentTitle.toUpperCase().slice(0, 26), 540, isStory ? 310 : 195);

  // Center Gold Card
  ctx.fillStyle = '#141414';
  ctx.fillRect(88, cy - 220, 904, 420);
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 3;
  ctx.strokeRect(88, cy - 220, 904, 420);

  ctx.fillStyle = '#FFD700';
  ctx.font = '800 24px monospace';
  ctx.fillText(opts.headline.toUpperCase().slice(0, 32), 540, cy - 135);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 66px Outfit, sans-serif';
  ctx.fillText(opts.highlightValue.slice(0, 20), 540, cy - 20);

  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 26px sans-serif';
  ctx.fillText(opts.subline.slice(0, 44), 540, cy + 75);

  if (opts.sponsorText) {
    ctx.fillStyle = '#D4AF37';
    ctx.font = '700 20px monospace';
    ctx.fillText(`POWERED BY ${opts.sponsorText.toUpperCase().slice(0, 32)}`, 540, height - (isStory ? 240 : 140));
  }

  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 18px sans-serif';
  ctx.fillText('HASSAN BADMINTON TOURNAMENT MANAGER', 540, height - (isStory ? 180 : 90));

  canvas.toBlob((blob) => {
    if (blob) {
      triggerDownload(blob, `smash-${opts.aspect || 'square'}-graphic.png`);
    }
  }, 'image/png');
}

export function downloadAnnouncementPoster(opts: {
  tournamentTitle: string;
  date: string;
  venue: string;
  category: string;
  formatLabel: string;
  clubName?: string;
  sponsorText?: string;
  entryInfo?: string;
}) {
  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 1350;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  drawGoldFrame(ctx, 1080, 1350);
  ctx.textAlign = 'center';

  ctx.fillStyle = '#FFD700';
  ctx.font = '900 26px monospace';
  ctx.fillText('OFFICIAL TOURNAMENT ANNOUNCEMENT', 540, 140);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 54px Outfit, sans-serif';
  ctx.fillText(opts.tournamentTitle.toUpperCase().slice(0, 24), 540, 230);

  ctx.fillStyle = '#D4AF37';
  ctx.font = '800 24px sans-serif';
  ctx.fillText((opts.clubName || 'Hassan Badminton Arena').slice(0, 36), 540, 285);

  ctx.fillStyle = '#141414';
  ctx.fillRect(90, 360, 900, 560);
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.5)';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(90, 360, 900, 560);

  const lines = [
    { k: 'DATE', v: opts.date },
    { k: 'VENUE', v: opts.venue },
    { k: 'CATEGORY', v: opts.category.toUpperCase() },
    { k: 'FORMAT', v: opts.formatLabel },
    { k: 'NOTES', v: opts.entryInfo || 'Registration Open · BWF Scoring Rules' },
  ];

  lines.forEach((item, idx) => {
    const y = 450 + idx * 96;
    ctx.textAlign = 'left';
    ctx.fillStyle = '#D4AF37';
    ctx.font = '800 18px monospace';
    ctx.fillText(item.k, 140, y);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '800 28px sans-serif';
    ctx.fillText(String(item.v).slice(0, 36), 140, y + 36);
  });

  ctx.textAlign = 'center';
  if (opts.sponsorText) {
    ctx.fillStyle = '#FFD700';
    ctx.font = '800 22px monospace';
    ctx.fillText(`OFFICIAL SPONSOR: ${opts.sponsorText.toUpperCase().slice(0, 34)}`, 540, 1060);
  }
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 20px sans-serif';
  ctx.fillText('Developed By Hassan · Smash Championship', 540, 1210);

  canvas.toBlob((blob) => {
    if (blob) {
      triggerDownload(blob, `announcement-${opts.tournamentTitle.toLowerCase().replace(/\s+/g, '-')}.png`);
    }
  }, 'image/png');
}

export function downloadFinancialReportCSV(
  records: FinancialRecord[],
  tournamentTitle = 'All Tournaments'
) {
  const headers = [
    'Receipt No',
    'Date',
    'Type',
    'Title',
    'Party / Player',
    'Currency',
    'Amount',
    'Status',
    'Notes',
  ];
  const rows = records.map((r) =>
    [
      r.receiptNo,
      r.date,
      r.type,
      r.title,
      r.partyName,
      r.currency || 'PKR',
      r.amount,
      r.status,
      r.notes || '',
    ]
      .map(escapeCSV)
      .join(',')
  );
  const content = '\uFEFF' + [headers.join(','), ...rows].join('\n');
  const slug = tournamentTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'finance';
  triggerDownload(
    new Blob([content], { type: 'text/csv;charset=utf-8;' }),
    `${slug}-financial-report.csv`
  );
}

export function downloadFinancialReceiptPNG(
  record: FinancialRecord,
  tournamentTitle: string
) {
  const canvas = document.createElement('canvas');
  canvas.width = 900;
  canvas.height = 600;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  drawGoldFrame(ctx, 900, 600);
  ctx.textAlign = 'left';

  ctx.fillStyle = '#FFD700';
  ctx.font = '900 22px monospace';
  ctx.fillText(`OFFICIAL RECEIPT · ${record.receiptNo}`, 72, 95);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '900 34px Outfit, sans-serif';
  ctx.fillText(tournamentTitle.slice(0, 32), 72, 148);

  ctx.fillStyle = '#141414';
  ctx.fillRect(72, 185, 756, 260);
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.45)';
  ctx.lineWidth = 2;
  ctx.strokeRect(72, 185, 756, 260);

  const curr = record.currency || 'PKR';
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '700 18px sans-serif';
  ctx.fillText(`Description: ${record.title}`, 104, 240);
  ctx.fillText(`Party / Member: ${record.partyName}`, 104, 282);
  ctx.fillText(`Date: ${record.date}  |  Category: ${record.type.replace('_', ' ').toUpperCase()}`, 104, 324);

  ctx.fillStyle = record.status === 'paid' ? '#22C55E' : '#F59E0B';
  ctx.font = '900 22px monospace';
  ctx.fillText(`STATUS: ${record.status.toUpperCase()}`, 104, 385);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#FFD700';
  ctx.font = '900 44px monospace';
  ctx.fillText(`${curr} ${record.amount.toLocaleString()}`, 795, 388);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '600 16px sans-serif';
  ctx.fillText('Hassan Badminton Tournament Manager · Official Finance Ledger', 450, 520);

  canvas.toBlob((blob) => {
    if (blob) {
      triggerDownload(blob, `receipt-${record.receiptNo}.png`);
    }
  }, 'image/png');
}

export function downloadPlayerBulkCSV(state: TournamentState) {
  const headers = ['Player Name', 'Player ID', 'Club', 'Category', 'Availability', 'Hand', 'Play Style'];
  const rows = state.players.map((name, idx) => {
    const bio = state.playerBios?.[idx];
    return [
      name,
      bio?.playerCode || `#SC-${String(idx + 1).padStart(2, '0')}`,
      bio?.club || '',
      bio?.preferredCategory || state.category || 'singles',
      bio?.availability || 'Available',
      bio?.hand || 'Right',
      bio?.playStyle || '',
    ]
      .map(escapeCSV)
      .join(',');
  });
  const content = '\uFEFF' + [headers.join(','), ...rows].join('\n');
  triggerDownload(
    new Blob([content], { type: 'text/csv;charset=utf-8;' }),
    `${getTournamentSlug(state)}-players-roster.csv`
  );
}


