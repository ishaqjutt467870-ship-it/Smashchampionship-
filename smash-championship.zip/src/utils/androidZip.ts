import JSZip from 'jszip';

export interface AndroidProjectOptions {
  appName: string;
  packageId: string;
  targetUrl: string;
  versionName: string;
  versionCode: number;
  sha256Fingerprint?: string;
}

export const DEFAULT_ANDROID_OPTIONS: AndroidProjectOptions = {
  appName: 'Hassan Badminton Manager',
  packageId: 'com.hassan.badminton',
  targetUrl: 'https://ais-pre-43ahuu47t6bwvzfmti46pp-798435965289.asia-northeast1.run.app',
  versionName: '2.1.0',
  versionCode: 3,
  sha256Fingerprint: '',
};

export function buildAssetLinksJson(packageId: string, sha256?: string): string {
  const cleanSha = (sha256 || '').trim() ||
    '00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00';
  return JSON.stringify(
    [
      {
        relation: ['delegate_permission/common.handle_all_urls'],
        target: {
          namespace: 'android_app',
          package_name: packageId.trim() || 'com.hassan.badminton',
          sha256_cert_fingerprints: [cleanSha],
        },
      },
    ],
    null,
    2
  );
}

export async function generateCustomAndroidProjectZip(
  options: AndroidProjectOptions
): Promise<Blob> {
  const pkg = options.packageId.trim() || 'com.hassan.badminton';
  const pkgPath = pkg.split('.').join('/');
  const appName = (options.appName || 'Hassan Badminton Manager').replace(/"/g, '\\"');
  const targetUrl = options.targetUrl.trim() || DEFAULT_ANDROID_OPTIONS.targetUrl;
  const hostName = (() => {
    try {
      return new URL(targetUrl).hostname;
    } catch {
      return 'ais-pre-43ahuu47t6bwvzfmti46pp-798435965289.asia-northeast1.run.app';
    }
  })();

  const zip = new JSZip();
  const root = zip.folder('smash_project')!;

  root.file(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "SmashChampionship"
include(":app")
`
  );

  root.file(
    'build.gradle.kts',
    `plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
`
  );

  root.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`
  );

  root
    .folder('gradle')!
    .folder('wrapper')!
    .file(
      'gradle-wrapper.properties',
      `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
    );

  root.file(
    'gradlew',
    `#!/usr/bin/env sh
exec gradle "$@"
`,
    { unixPermissions: '755' }
  );

  root.file(
    'gradlew.bat',
    `@rem Gradle startup script for Windows
gradle %*
`
  );

  root.file(
    'PWABUILDER_GUIDE.md',
    `# PWABuilder & Play Store APK Packaging Guide

1. Visit https://www.pwabuilder.com/
2. Enter your HTTPS app URL:
   ${targetUrl}
3. Click "Package For Stores" -> Android -> Generate Package
4. Upload the generated assetlinks.json to /.well-known/assetlinks.json if using Trusted Web Activity (TWA).

Package ID: ${pkg}
App Name: ${options.appName}
Version: ${options.versionName} (${options.versionCode})
`
  );

  root.file(
    'README.md',
    `# ${options.appName} — Android Studio APK Project

Package: \`${pkg}\`
Version: \`${options.versionName}\`
Target URL: \`${targetUrl}\`

## Native Capabilities Included
- Black (#080808) & Gold (#D4AF37) Material 3 WebView shell
- Hardware-accelerated WebView + DOM storage + offline caching
- Keep-Screen-On (FLAG_KEEP_SCREEN_ON) for live court refereeing
- Geolocation permission flow for Google Maps Venue Locator
- File upload picker (avatars, custom logos, JSON/CSV backups)
- Native Downloads bridge for JSON/CSV backups, Player Certificates, and Scorecards
- External intent routing for Google Maps directions, tel:, and mailto:

## Build Debug / Release APK
1. Extract \`smash_project/\` and open it in Android Studio (File > Open).
2. Let Gradle sync automatically.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the APK inside \`app/build/outputs/apk/debug/\`.
`
  );

  const app = root.folder('app')!;
  app.file(
    'build.gradle.kts',
    `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${pkg}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${pkg}"
        minSdk = 24
        targetSdk = 34
        versionCode = ${options.versionCode}
        versionName = "${options.versionName}"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.webkit:webkit:1.10.0")
}
`
  );

  app.file(
    'proguard-rules.pro',
    `-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
`
  );

  const main = app.folder('src')!.folder('main')!;
  main.file(
    'AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <queries>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="geo" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
    </queries>

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.SmashChampionship"
        android:networkSecurityConfig="@xml/network_security_config"
        android:usesCleartextTraffic="false">

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:exported="true"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="${hostName}" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`
  );

  const res = main.folder('res')!;
  const values = res.folder('values')!;
  values.file(
    'strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${appName}</string>
</resources>
`
  );
  values.file(
    'colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="smash_black">#080808</color>
    <color name="smash_surface">#141414</color>
    <color name="smash_gold">#D4AF37</color>
    <color name="smash_gold_bright">#FFD700</color>
</resources>
`
  );
  values.file(
    'styles.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.SmashChampionship" parent="Theme.Material3.Dark.NoActionBar">
        <item name="android:windowBackground">@color/smash_black</item>
        <item name="android:statusBarColor">@color/smash_black</item>
        <item name="android:navigationBarColor">@color/smash_black</item>
        <item name="colorPrimary">@color/smash_gold</item>
        <item name="colorAccent">@color/smash_gold_bright</item>
    </style>
</resources>
`
  );

  const xml = res.folder('xml')!;
  xml.file(
    'file_paths.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<paths>
    <external-path name="downloads" path="Download/" />
    <cache-path name="cache" path="/" />
</paths>
`
  );
  xml.file(
    'network_security_config.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
</network-security-config>
`
  );

  // Include real launcher icons fetched from PWA assets
  try {
    const [icon192Resp, icon512Resp] = await Promise.all([
      fetch('/pwa-192x192.png'),
      fetch('/pwa-512x512.png'),
    ]);
    if (icon192Resp.ok && icon512Resp.ok) {
      const buf192 = await icon192Resp.arrayBuffer();
      const buf512 = await icon512Resp.arrayBuffer();
      for (const dir of ['mipmap-hdpi', 'mipmap-xhdpi']) {
        const folder = res.folder(dir)!;
        folder.file('ic_launcher.png', buf192);
        folder.file('ic_launcher_round.png', buf192);
      }
      for (const dir of ['mipmap-xxhdpi', 'mipmap-xxxhdpi']) {
        const folder = res.folder(dir)!;
        folder.file('ic_launcher.png', buf512);
        folder.file('ic_launcher_round.png', buf512);
      }
    }
  } catch {
    // fallback silently if offline during generation
  }

  let javaFolder = main.folder('java')!;
  for (const part of pkgPath.split('/')) {
    javaFolder = javaFolder.folder(part)!;
  }

  javaFolder.file(
    'MainActivity.kt',
    `package ${pkg}

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingGeoOrigin: String? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        fileUploadCallback?.onReceiveValue(if (uris.isNotEmpty()) uris.toTypedArray() else null)
        fileUploadCallback = null
    }

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        pendingGeoCallback?.invoke(pendingGeoOrigin, granted, false)
        pendingGeoCallback = null
        pendingGeoOrigin = null
    }

    inner class DownloadBridge {
        @JavascriptInterface
        fun saveBase64File(base64Data: String, fileName: String, mimeType: String) {
            try {
                val clean = base64Data.substringAfter(",")
                val bytes = Base64.decode(clean, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    FileOutputStream(File(dir, fileName)).use { it.write(bytes) }
                }
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Saved to Downloads: $fileName", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Export failed: \${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#080808"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.setGeolocationEnabled(true)
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true

            addJavascriptInterface(DownloadBridge(), "SmashAndroidBridge")

            setDownloadListener { url, _, _, mimeType, _ ->
                if (url.startsWith("data:")) {
                    DownloadBridge().saveBase64File(url, "smash-export.json", mimeType ?: "application/octet-stream")
                } else if (url.startsWith("blob:")) {
                    evaluateJavascript(
                        """
                        (function() {
                          fetch("$url").then(r => r.blob()).then(b => {
                            const reader = new FileReader();
                            reader.onloadend = () => window.SmashAndroidBridge.saveBase64File(reader.result, "smash-export", b.type || "application/octet-stream");
                            reader.readAsDataURL(b);
                          });
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return false
                    val url = uri.toString()
                    if (url.startsWith("geo:") ||
                        url.contains("maps.google.com") ||
                        url.contains("google.com/maps") ||
                        url.startsWith("mailto:") ||
                        url.startsWith("tel:")
                    ) {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                        return true
                    }
                    return false
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        view?.settings?.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = filePathCallback
                    fileChooserLauncher.launch("*/*")
                    return true
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    val hasFine = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                    if (hasFine) {
                        callback?.invoke(origin, true, false)
                    } else {
                        pendingGeoCallback = callback
                        pendingGeoOrigin = origin
                        locationPermissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    }
                }
            }
        }

        setContentView(webView)
        val launchUrl = intent?.data?.toString() ?: "${targetUrl}"
        webView.loadUrl(launchUrl)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }
}
`
  );

  root.file('assetlinks.json', buildAssetLinksJson(pkg, options.sha256Fingerprint));

  return zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
}
