import {
  MatchMetaInfo,
  MatchScore,
  PlayerStats,
  TournamentMatch,
  TournamentState,
} from '../types';
import { calculateTournamentAwards, formatScore, getTournamentFormatLabel } from './tournament';

export interface SmartMatchInsights {
  completedCount: number;
  totalPointsPlayed: number;
  avgPointsPerMatch: number;
  straightSetWins: number;
  straightSetRate: number;
  deciderMatches: number;
  upsetCount: number;
  hasRallyTelemetry: boolean;
  totalRalliesLogged: number;
  avgRallyDurationSec: number;
  serviceWinRatePct: number;
  totalServiceFaults: number;
  totalLets: number;
  totalMedicalTimeouts: number;
  momentumSwings: number;
  closestMatch: {
    label: string;
    scoreText: string;
    margin: number;
  } | null;
  highestScoringMatch: {
    label: string;
    scoreText: string;
    totalPoints: number;
  } | null;
  comebackMatch: {
    label: string;
    scoreText: string;
  } | null;
  progressionData: Array<{
    matchLabel: string;
    matchTitle: string;
    winnerPts: number;
    loserPts: number;
    totalPts: number;
    cumulativeAvg: number;
  }>;
}

function extractMatchPointTotals(score?: MatchScore) {
  if (!score) {
    return {
      ptsA: 0,
      ptsB: 0,
      setsA: 0,
      setsB: 0,
      setsPlayed: 0,
      setMargins: [] as number[],
    };
  }
  const sets = [
    [score.s1a, score.s1b],
    [score.s2a, score.s2b],
    [score.s3a, score.s3b],
    [score.s4a, score.s4b],
    [score.s5a, score.s5b],
  ].filter(([a, b]) => a !== undefined && b !== undefined) as Array<[number, number]>;

  let ptsA = 0;
  let ptsB = 0;
  let setsA = 0;
  let setsB = 0;
  const setMargins: number[] = [];

  sets.forEach(([a, b]) => {
    ptsA += a;
    ptsB += b;
    if (a > b) setsA++;
    else if (b > a) setsB++;
    setMargins.push(Math.abs(a - b));
  });

  return { ptsA, ptsB, setsA, setsB, setsPlayed: sets.length, setMargins };
}

export function computeSmartMatchAnalytics(
  players: string[],
  fixtures: TournamentMatch[],
  results: Record<string, number>,
  scores: Record<string, MatchScore>,
  standings: PlayerStats[],
  matchMeta?: Record<string, MatchMetaInfo>
): SmartMatchInsights {
  const rankMap = new Map<number, number>();
  standings.forEach((s, idx) => rankMap.set(s.id, idx + 1));

  const completedFixtures = fixtures.filter((m) => results[m.id] !== undefined);

  let totalPointsPlayed = 0;
  let scoredMatchCount = 0;
  let straightSetWins = 0;
  let deciderMatches = 0;
  let upsetCount = 0;

  let totalRalliesLogged = 0;
  let totalRallySec = 0;
  let serviceTrackedRallies = 0;
  let serviceWins = 0;
  let totalServiceFaults = 0;
  let totalLets = 0;
  let totalMedicalTimeouts = 0;
  let momentumSwings = 0;

  let closestMatch: SmartMatchInsights['closestMatch'] = null;
  let highestScoringMatch: SmartMatchInsights['highestScoringMatch'] = null;
  let comebackMatch: SmartMatchInsights['comebackMatch'] = null;
  const progressionData: SmartMatchInsights['progressionData'] = [];

  let cumulativeTotalPts = 0;

  completedFixtures.forEach((match, idx) => {
    const winnerIdx = results[match.id];
    const loserIdx = winnerIdx === match.playerAIndex ? match.playerBIndex : match.playerAIndex;
    const pA = players[match.playerAIndex] || 'Player A';
    const pB = players[match.playerBIndex] || 'Player B';
    const winnerName = players[winnerIdx] || 'Winner';
    const loserName = players[loserIdx] || 'Opponent';

    const winnerRank = rankMap.get(winnerIdx) ?? 99;
    const loserRank = rankMap.get(loserIdx) ?? 99;
    if (winnerRank > loserRank) {
      upsetCount++;
    }

    const meta = matchMeta?.[match.id];
    if (meta?.rallyHistory && meta.rallyHistory.length > 0) {
      let prevLeader: 'A' | 'B' | 'T' = 'T';
      meta.rallyHistory.forEach((r) => {
        totalRalliesLogged += 1;
        totalRallySec += Math.max(0, r.rallySec || 0);
        if (r.server === 'A' || r.server === 'B') {
          serviceTrackedRallies += 1;
          if (r.server === r.winner) serviceWins += 1;
        }
        const leader: 'A' | 'B' | 'T' =
          r.scoreA > r.scoreB ? 'A' : r.scoreB > r.scoreA ? 'B' : 'T';
        if (leader !== 'T' && prevLeader !== 'T' && leader !== prevLeader) {
          momentumSwings += 1;
        }
        if (leader !== 'T') prevLeader = leader;
      });
    }
    if (meta?.incidents && meta.incidents.length > 0) {
      meta.incidents.forEach((inc) => {
        if (inc.type === 'service_fault') totalServiceFaults += 1;
        else if (inc.type === 'let') totalLets += 1;
        else if (inc.type === 'medical_timeout') totalMedicalTimeouts += 1;
      });
    }

    const sc = scores[match.id];
    const parsed = extractMatchPointTotals(sc);
    const matchTotalPts = parsed.ptsA + parsed.ptsB;
    const scoreText = formatScore(sc) || 'Recorded Win';

    if (parsed.setsPlayed > 0) {
      scoredMatchCount++;
      totalPointsPlayed += matchTotalPts;
      cumulativeTotalPts += matchTotalPts;

      const winnerIsA = winnerIdx === match.playerAIndex;
      const winnerPts = winnerIsA ? parsed.ptsA : parsed.ptsB;
      const loserPts = winnerIsA ? parsed.ptsB : parsed.ptsA;

      if (parsed.setsA === 0 || parsed.setsB === 0) {
        straightSetWins++;
      } else {
        deciderMatches++;
      }

      // Check comeback (lost Set 1, won match)
      if (sc?.s1a !== undefined && sc?.s1b !== undefined && parsed.setsPlayed >= 2) {
        const lostSet1 = winnerIsA ? sc.s1a < sc.s1b : sc.s1b < sc.s1a;
        if (lostSet1 && !comebackMatch) {
          comebackMatch = {
            label: `${winnerName} def. ${loserName}`,
            scoreText,
          };
        }
      }

      const margin = Math.abs(parsed.ptsA - parsed.ptsB);
      if (!closestMatch || margin < closestMatch.margin) {
        closestMatch = {
          label: `${pA} vs ${pB}`,
          scoreText,
          margin,
        };
      }

      if (!highestScoringMatch || matchTotalPts > highestScoringMatch.totalPoints) {
        highestScoringMatch = {
          label: `${pA} vs ${pB}`,
          scoreText,
          totalPoints: matchTotalPts,
        };
      }

      progressionData.push({
        matchLabel: `M${idx + 1}`,
        matchTitle: `${winnerName} def. ${loserName}`,
        winnerPts,
        loserPts,
        totalPts: matchTotalPts,
        cumulativeAvg: Math.round(cumulativeTotalPts / scoredMatchCount),
      });
    } else {
      // Unscored match: only increment point totals when actual set scores exist
      progressionData.push({
        matchLabel: `M${idx + 1}`,
        matchTitle: `${winnerName} def. ${loserName}`,
        winnerPts: 0,
        loserPts: 0,
        totalPts: 0,
        cumulativeAvg: scoredMatchCount > 0 ? Math.round(cumulativeTotalPts / scoredMatchCount) : 0,
      });
    }
  });

  return {
    completedCount: completedFixtures.length,
    totalPointsPlayed,
    avgPointsPerMatch:
      scoredMatchCount > 0 ? Math.round(totalPointsPlayed / scoredMatchCount) : 0,
    straightSetWins,
    straightSetRate:
      completedFixtures.length > 0
        ? Math.round((straightSetWins / completedFixtures.length) * 100)
        : 0,
    deciderMatches,
    upsetCount,
    hasRallyTelemetry: totalRalliesLogged > 0,
    totalRalliesLogged,
    avgRallyDurationSec:
      totalRalliesLogged > 0 ? Number((totalRallySec / totalRalliesLogged).toFixed(1)) : 0,
    serviceWinRatePct:
      serviceTrackedRallies > 0 ? Math.round((serviceWins / serviceTrackedRallies) * 100) : 0,
    totalServiceFaults,
    totalLets,
    totalMedicalTimeouts,
    momentumSwings,
    closestMatch,
    highestScoringMatch,
    comebackMatch,
    progressionData,
  };
}

export interface AutoGeneratedReport {
  headline: string;
  executiveSummary: string[];
  standingsHighlights: string[];
  matchBreakdown: string[];
  markdownText: string;
}

export function generateTournamentAutoReport(
  state: TournamentState,
  standings: PlayerStats[],
  fixtures: TournamentMatch[]
): AutoGeneratedReport {
  const insights = computeSmartMatchAnalytics(
    state.players,
    fixtures,
    state.results,
    state.scores || {},
    standings,
    state.matchMeta
  );
  const awards = calculateTournamentAwards(standings);
  const completedCount = insights.completedCount;
  const totalFixtures = fixtures.length;
  const completionPct =
    totalFixtures > 0 ? Math.round((completedCount / totalFixtures) * 100) : 0;

  const champName =
    state.finalWinner !== null
      ? state.players[state.finalWinner]
      : standings[0]?.name || 'TBD';

  const runnerUpName =
    state.semis && state.finalWinner !== null
      ? state.players[
          state.semis[0] === state.finalWinner ? state.semis[1] : state.semis[0]
        ] || standings[1]?.name || 'TBD'
      : standings[1]?.name || 'TBD';

  const headline = `${state.tournamentTitle || 'Smash Championship'} — Official Executive Report`;

  const executiveSummary: string[] = [
    `Format & Rules: ${getTournamentFormatLabel(state.tournamentFormat)} (${(
      state.matchFormat || 'bo3'
    ).toUpperCase()}, ${state.customRules?.pointsPerSet ?? 21} pts/set) hosted at ${
      state.venue || 'Center Arena Court'
    }.`,
    `Progress: ${completedCount} of ${totalFixtures} fixtures completed (${completionPct}%), with ${insights.totalPointsPlayed} total rally points contested (avg ${insights.avgPointsPerMatch} pts/match).`,
    state.finalWinner !== null
      ? `Championship Result: ${champName} captured the title defeating ${runnerUpName} in the Grand Final.`
      : `Current Standings Leader: ${champName} leads the table with ${
          standings[0]?.points || 0
        } points (${standings[0]?.won || 0}W - ${standings[0]?.lost || 0}L).`,
  ];

  const standingsHighlights: string[] = [];
  if (awards.mvp) {
    standingsHighlights.push(
      `Tournament MVP: ${awards.mvp.name} (${awards.mvp.points} pts, ${awards.mvp.won}W-${awards.mvp.lost}L)`
    );
  }
  if (awards.topScorer) {
    standingsHighlights.push(
      `Top Rally Scorer: ${awards.topScorer.name} with ${awards.topScorer.pointsFor} rally points scored`
    );
  }
  if (insights.closestMatch) {
    standingsHighlights.push(
      `Closest Match Thriller: ${insights.closestMatch.label} (${insights.closestMatch.scoreText})`
    );
  }
  if (insights.highestScoringMatch) {
    standingsHighlights.push(
      `Highest Scoring Clash: ${insights.highestScoringMatch.label} (${insights.highestScoringMatch.totalPoints} total points)`
    );
  }
  if (insights.comebackMatch) {
    standingsHighlights.push(
      `Comeback Victory: ${insights.comebackMatch.label} (${insights.comebackMatch.scoreText})`
    );
  }
  standingsHighlights.push(
    `Match Tempo: ${insights.straightSetRate}% straight-set finishes (${insights.straightSetWins} straight-set / ${insights.deciderMatches} deciders)`
  );

  const matchBreakdown = fixtures
    .filter((m) => state.results[m.id] !== undefined)
    .map((m, idx) => {
      const wIdx = state.results[m.id];
      const lIdx = wIdx === m.playerAIndex ? m.playerBIndex : m.playerAIndex;
      const sc = formatScore(state.scores?.[m.id]);
      const isMvp = state.matchMvps?.[m.id] === wIdx;
      return `Match #${m.roundNumber || idx + 1}: ${state.players[wIdx]} def. ${
        state.players[lIdx]
      }${sc ? ` (${sc})` : ''}${isMvp ? ` — Match MVP: ${state.players[wIdx]}` : ''}`;
    });

  const markdownLines = [
    `# ${headline}`,
    `Generated: ${new Date().toLocaleString()} | Chief Referee: ${
      state.customRules?.refereeName || 'Hassan'
    }`,
    '',
    '## Executive Summary',
    ...executiveSummary.map((line) => `- ${line}`),
    '',
    '## Key Analytics & Awards',
    ...standingsHighlights.map((line) => `- ${line}`),
    '',
    '## Standings Table',
    '| Rank | Player | MP | W | L | Sets | Pts Diff | Points |',
    '|---|---|---|---|---|---|---|---|',
    ...standings.map(
      (p, i) =>
        `| #${i + 1} | ${p.name} | ${p.played} | ${p.won} | ${p.lost} | ${p.setsWon}-${p.setsLost} | ${
          p.pointsFor - p.pointsAgainst >= 0 ? '+' : ''
        }${p.pointsFor - p.pointsAgainst} | ${p.points} |`
    ),
    '',
    '## Completed Match Ledger',
    ...(matchBreakdown.length > 0
      ? matchBreakdown.map((line) => `- ${line}`)
      : ['- No completed fixtures logged yet.']),
    '',
    '---',
    'Smash Championship · Developed By Hassan (Hassan developers)',
  ];

  return {
    headline,
    executiveSummary,
    standingsHighlights,
    matchBreakdown,
    markdownText: markdownLines.join('\n'),
  };
}
