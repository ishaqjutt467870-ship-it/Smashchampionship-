import {
  PlayerBio,
  PlayerStats,
  TournamentFormatType,
  TournamentState,
} from '../types';
import { calculateStandings } from './tournament';

export interface PlayerSeedEvaluation {
  index: number;
  name: string;
  rating: number;
  careerWins: number;
  careerMatches: number;
  titlesWon: number;
  pointDiff: number;
  seedRank: number;
  assignedGroup: 'A' | 'B';
}

/**
 * Evaluates each player's smart seeding power rating from:
 * 1. Current tournament standings (if matches have already been played)
 * 2. Historical performance across all saved tournaments in the store
 * 3. Tie-breaking by point differential and sets ratio
 */
export function evaluatePlayerSeeds(
  players: string[],
  currentStandings: PlayerStats[],
  allTournaments: TournamentState[] = []
): PlayerSeedEvaluation[] {
  const historicalMap = new Map<
    string,
    { wins: number; matches: number; titles: number; pointDiff: number }
  >();

  allTournaments.forEach((tourney) => {
    const tStandings = calculateStandings(
      tourney.players,
      tourney.results || {},
      tourney.scores,
      tourney.playerPhotos,
      tourney.playerBios,
      tourney.tournamentFormat || 'round_robin'
    );
    const champName =
      tourney.finalWinner !== null ? tourney.players[tourney.finalWinner]?.toLowerCase() : null;

    tStandings.forEach((st) => {
      const key = st.name.trim().toLowerCase();
      if (!key) return;
      const prev = historicalMap.get(key) || {
        wins: 0,
        matches: 0,
        titles: 0,
        pointDiff: 0,
      };
      historicalMap.set(key, {
        wins: prev.wins + st.won,
        matches: prev.matches + st.played,
        titles: prev.titles + (champName === key ? 1 : 0),
        pointDiff: prev.pointDiff + (st.pointsFor - st.pointsAgainst),
      });
    });
  });

  const evaluations = players.map((name, index) => {
    const current = currentStandings.find((s) => s.id === index);
    const hist = historicalMap.get(name.trim().toLowerCase()) || {
      wins: 0,
      matches: 0,
      titles: 0,
      pointDiff: 0,
    };

    const totalMatches = hist.matches > 0 ? hist.matches : current?.played || 0;
    const totalWins = hist.matches > 0 ? hist.wins : current?.won || 0;
    const totalDiff =
      hist.matches > 0
        ? hist.pointDiff
        : (current?.pointsFor || 0) - (current?.pointsAgainst || 0);

    const winRate = totalMatches > 0 ? totalWins / totalMatches : 0.5;
    // Composite power rating (deterministic, 1000 baseline)
    const rating = Math.round(
      1000 +
        winRate * 300 +
        totalWins * 25 +
        hist.titles * 120 +
        Math.max(-150, Math.min(250, totalDiff * 2))
    );

    return {
      index,
      name,
      rating,
      careerWins: totalWins,
      careerMatches: totalMatches,
      titlesWon: hist.titles,
      pointDiff: totalDiff,
      seedRank: index + 1,
      assignedGroup: (index % 2 === 0 ? 'A' : 'B') as 'A' | 'B',
    };
  });

  const sorted = [...evaluations].sort((a, b) => {
    if (b.rating !== a.rating) return b.rating - a.rating;
    if (b.careerWins !== a.careerWins) return b.careerWins - a.careerWins;
    if (b.pointDiff !== a.pointDiff) return b.pointDiff - a.pointDiff;
    return a.index - b.index;
  });

  sorted.forEach((ev, rankIdx) => {
    ev.seedRank = rankIdx + 1;
    // Snake distribution for balanced groups: 1->A, 2->B, 3->B, 4->A, 5->A, 6->B...
    const snakePair = Math.floor(rankIdx / 2) % 2;
    const posInPair = rankIdx % 2;
    ev.assignedGroup =
      snakePair === 0 ? (posInPair === 0 ? 'A' : 'B') : posInPair === 0 ? 'B' : 'A';
  });

  return sorted;
}

/**
 * Reorders players, photos, and bios using BWF-style smart seeding:
 * - For Group Stage: arranges players so index % 2 === 0 (Group A) and index % 2 === 1 (Group B)
 *   reflect balanced snake seeding (#1 in A, #2 in B, #3 in B, #4 in A...).
 * - For Knockout / Round-Robin: alternates top seeds across opposite halves of the draw
 *   so #1 and #2 stay on opposite sides until the Grand Final.
 */
export function buildSmartSeededRoster(
  players: string[],
  tournamentFormat: TournamentFormatType,
  evaluations: PlayerSeedEvaluation[],
  playerPhotos?: Record<number, string>,
  playerBios?: Record<number, PlayerBio>
): {
  players: string[];
  playerPhotos: Record<number, string>;
  playerBios: Record<number, PlayerBio>;
} {
  const n = evaluations.length;
  const orderedIndices: number[] = new Array(n).fill(0);

  if (tournamentFormat === 'group_stage') {
    const groupA = evaluations.filter((e) => e.assignedGroup === 'A');
    const groupB = evaluations.filter((e) => e.assignedGroup === 'B');
    const finalOrder: number[] = [];
    const maxLen = Math.max(groupA.length, groupB.length);
    for (let i = 0; i < maxLen; i++) {
      if (groupA[i]) finalOrder.push(groupA[i].index);
      if (groupB[i]) finalOrder.push(groupB[i].index);
    }
    finalOrder.forEach((oldIdx, newIdx) => {
      orderedIndices[newIdx] = oldIdx;
    });
  } else {
    // Opposite-half bracket placement: Seed #1 at top (0), Seed #2 at bottom (n-1), #3 at 1, #4 at n-2...
    let left = 0;
    let right = n - 1;
    evaluations.forEach((ev, rankIdx) => {
      if (rankIdx % 2 === 0) {
        orderedIndices[left++] = ev.index;
      } else {
        orderedIndices[right--] = ev.index;
      }
    });
  }

  const nextPlayers: string[] = [];
  const nextPhotos: Record<number, string> = {};
  const nextBios: Record<number, PlayerBio> = {};

  orderedIndices.forEach((oldIdx, newIdx) => {
    nextPlayers.push(players[oldIdx]);
    if (playerPhotos?.[oldIdx]) nextPhotos[newIdx] = playerPhotos[oldIdx];
    if (playerBios?.[oldIdx]) nextBios[newIdx] = playerBios[oldIdx];
  });

  return {
    players: nextPlayers,
    playerPhotos: nextPhotos,
    playerBios: nextBios,
  };
}
