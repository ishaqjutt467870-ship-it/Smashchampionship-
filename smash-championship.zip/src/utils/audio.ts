/**
 * Zero-dependency Web Audio synthesizer & haptic feedback utility for badminton sound effects
 */

let audioCtx: AudioContext | null = null;
let isMuted: boolean = (() => {
  try {
    return localStorage.getItem('smash-audio-muted') === 'true';
  } catch {
    return false;
  }
})();

let hapticsEnabled: boolean = (() => {
  try {
    const val = localStorage.getItem('smash-haptics-enabled');
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
})();

export function toggleAudioMute(muted?: boolean): boolean {
  if (muted !== undefined) {
    isMuted = muted;
  } else {
    isMuted = !isMuted;
  }
  try {
    localStorage.setItem('smash-audio-muted', isMuted ? 'true' : 'false');
  } catch {
    // ignore
  }
  return isMuted;
}

export function getAudioMuted(): boolean {
  return isMuted;
}

export const isAudioMuted = getAudioMuted;

export function getHapticsEnabled(): boolean {
  return hapticsEnabled;
}

export function toggleHaptics(enabled?: boolean): boolean {
  if (enabled !== undefined) {
    hapticsEnabled = enabled;
  } else {
    hapticsEnabled = !hapticsEnabled;
  }
  try {
    localStorage.setItem('smash-haptics-enabled', hapticsEnabled ? 'true' : 'false');
  } catch {
    // ignore
  }
  return hapticsEnabled;
}

export function triggerHaptic(pattern: number | number[] = 18) {
  if (!hapticsEnabled) return;
  try {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {
    // ignore unsupported browsers
  }
}

function getContext(): AudioContext | null {
  if (isMuted) return null;
  try {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  } catch {
    return null;
  }
}

export function playShuttleHitSound() {
  triggerHaptic(18);
  const ctx = getContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'triangle';
  osc.frequency.setValueAtTime(440, now);
  osc.frequency.exponentialRampToValueAtTime(110, now + 0.08);

  gain.gain.setValueAtTime(0.35, now);
  gain.gain.exponentialRampToValueAtTime(0.01, now + 0.08);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.09);
}

export function playPointChime() {
  const ctx = getContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(587.33, now);
  osc.frequency.setValueAtTime(880, now + 0.08);

  gain.gain.setValueAtTime(0.2, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.25);
}

export function playAlertTone() {
  triggerHaptic([35, 40, 50]);
  const ctx = getContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  [0, 0.12].forEach((delay, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(idx === 0 ? 523.25 : 659.25, now + delay);

    gain.gain.setValueAtTime(0.2, now + delay);
    gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.15);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now + delay);
    osc.stop(now + delay + 0.16);
  });
}

export function playIntervalBuzzer() {
  triggerHaptic([60, 40, 60]);
  const ctx = getContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'square';
  osc.frequency.setValueAtTime(800, now);
  osc.frequency.setValueAtTime(1000, now + 0.15);

  gain.gain.setValueAtTime(0.15, now);
  gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(now);
  osc.stop(now + 0.36);
}

let voiceUmpireEnabled: boolean = (() => {
  try {
    return localStorage.getItem('smash-voice-umpire') === 'true';
  } catch {
    return false;
  }
})();

export function getVoiceUmpireEnabled(): boolean {
  return voiceUmpireEnabled;
}

export function toggleVoiceUmpire(enabled?: boolean): boolean {
  if (enabled !== undefined) {
    voiceUmpireEnabled = enabled;
  } else {
    voiceUmpireEnabled = !voiceUmpireEnabled;
  }
  try {
    localStorage.setItem('smash-voice-umpire', voiceUmpireEnabled ? 'true' : 'false');
  } catch {
    // ignore
  }
  if (!voiceUmpireEnabled && typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
  return voiceUmpireEnabled;
}

export function speakUmpireCall(text: string, force: boolean = false) {
  if ((!voiceUmpireEnabled && !force) || isMuted) return;
  try {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.04;
    utterance.pitch = 1.0;
    utterance.volume = 0.9;
    window.speechSynthesis.speak(utterance);
  } catch {
    // Ignore speech synthesis errors on restricted browsers
  }
}

export function playMatchPointSound() {
  triggerHaptic([35, 30, 55]);
  const ctx = getContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  [659.25, 880].forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, now + idx * 0.1);
    gain.gain.setValueAtTime(0.22, now + idx * 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.16);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + idx * 0.1);
    osc.stop(now + idx * 0.1 + 0.18);
  });
}

export function playGameWonSound() {
  triggerHaptic([45, 35, 65]);
  const ctx = getContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  [523.25, 659.25, 783.99].forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + idx * 0.09);
    gain.gain.setValueAtTime(0.22, now + idx * 0.09);
    gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.09 + 0.22);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + idx * 0.09);
    osc.stop(now + idx * 0.09 + 0.24);
  });
}

export function playMatchWonFanfare() {
  triggerHaptic([60, 40, 60, 40, 120]);
  const ctx = getContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, now + idx * 0.11);
    gain.gain.setValueAtTime(0.26, now + idx * 0.11);
    gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.11 + 0.34);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + idx * 0.11);
    osc.stop(now + idx * 0.11 + 0.36);
  });
}
