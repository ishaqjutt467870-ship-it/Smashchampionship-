import stadiumNightImg from '../assets/images/wallpaper_stadium_night_1794516601292.jpg';
import shuttlecockMacroImg from '../assets/images/wallpaper_shuttlecock_macro_1794516601522.jpg';
import cyberCourtImg from '../assets/images/wallpaper_cyber_court_1794516602058.jpg';
import goldArenaImg from '../assets/images/wallpaper_gold_arena_1794516602243.jpg';

export interface WallpaperOption {
  id: string;
  name: string;
  subtitle: string;
  type: 'none' | 'image' | 'gradient';
  imageUrl?: string;
  cssBackground?: string;
  recommendedMode: 'dark' | 'light' | 'any';
}

export const BUILTIN_WALLPAPERS: WallpaperOption[] = [
  {
    id: 'none',
    name: 'Dynamic Theme Arena',
    subtitle: 'Adaptive theme stadium lights',
    type: 'none',
    recommendedMode: 'any',
  },
  {
    id: 'stadium-night',
    name: 'Championship Arena Night',
    subtitle: 'HD Indoor Stadium Lights',
    type: 'image',
    imageUrl: stadiumNightImg,
    recommendedMode: 'dark',
  },
  {
    id: 'shuttlecock-macro',
    name: 'Feather Shuttle Macro',
    subtitle: 'Electric Lime Rim Studio',
    type: 'image',
    imageUrl: shuttlecockMacroImg,
    recommendedMode: 'dark',
  },
  {
    id: 'cyber-court',
    name: 'Neon Cyber Court',
    subtitle: 'Glowing Geometry Overhead',
    type: 'image',
    imageUrl: cyberCourtImg,
    recommendedMode: 'dark',
  },
  {
    id: 'gold-arena',
    name: 'Grand Finals Gold Hall',
    subtitle: 'Luxury Champagne Stadium',
    type: 'image',
    imageUrl: goldArenaImg,
    recommendedMode: 'dark',
  },
  {
    id: 'lime-horizon',
    name: 'Electric Lime Aurora',
    subtitle: 'Radiant Navy & Volt Mesh',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 18% 15%, rgba(183,243,74,0.38), transparent 45%), radial-gradient(circle at 82% 28%, rgba(56,189,248,0.34), transparent 48%), linear-gradient(135deg, #07111F 0%, #0E1F38 52%, #07131D 100%)',
    recommendedMode: 'dark',
  },
  {
    id: 'emerald-pavilion',
    name: 'All-England Emerald Mesh',
    subtitle: 'Deep Grass & Gold Glow',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 75% 18%, rgba(52,211,153,0.36), transparent 45%), radial-gradient(circle at 20% 80%, rgba(251,191,36,0.22), transparent 46%), linear-gradient(145deg, #03130F 0%, #0A251D 55%, #04100D 100%)',
    recommendedMode: 'dark',
  },
  {
    id: 'crimson-smash',
    name: 'Istora Crimson Flare',
    subtitle: 'High-Energy Final Spotlights',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 22% 20%, rgba(244,63,94,0.36), transparent 45%), radial-gradient(circle at 80% 78%, rgba(245,158,11,0.28), transparent 46%), linear-gradient(135deg, #16070B 0%, #270F17 55%, #0E0714 100%)',
    recommendedMode: 'dark',
  },
  {
    id: 'royal-amethyst',
    name: 'Royal Violet Nebula',
    subtitle: 'Champagne & Indigo Lights',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 25% 22%, rgba(168,85,247,0.38), transparent 48%), radial-gradient(circle at 78% 72%, rgba(34,211,238,0.3), transparent 45%), linear-gradient(135deg, #0D061A 0%, #1B1035 55%, #080E1E 100%)',
    recommendedMode: 'dark',
  },
  {
    id: 'ocean-cobalt',
    name: 'Olympic Cobalt Wave',
    subtitle: 'Deep Blue Stadium Mist',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 80% 20%, rgba(59,130,246,0.42), transparent 48%), radial-gradient(circle at 18% 78%, rgba(45,212,191,0.28), transparent 45%), linear-gradient(155deg, #040B1A 0%, #0A1B3D 55%, #05111F 100%)',
    recommendedMode: 'dark',
  },
  {
    id: 'sunset-ember',
    name: 'Solar Sunset Horizon',
    subtitle: 'Amber & Warm Coral Blend',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 25% 18%, rgba(251,146,60,0.42), transparent 48%), radial-gradient(circle at 82% 75%, rgba(244,63,94,0.3), transparent 46%), linear-gradient(135deg, #160A04 0%, #2B150A 55%, #120810 100%)',
    recommendedMode: 'dark',
  },
  {
    id: 'nordic-frost',
    name: 'Nordic Sky Frost',
    subtitle: 'Clean Daylight Mist',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 15% 15%, rgba(56,189,248,0.24), transparent 45%), radial-gradient(circle at 85% 80%, rgba(139,203,53,0.22), transparent 48%), linear-gradient(135deg, #F0F9FF 0%, #E0F2FE 50%, #F4F7FB 100%)',
    recommendedMode: 'light',
  },
  {
    id: 'pearl-meadow',
    name: 'Wimbledon Pearl Light',
    subtitle: 'Soft Mint & Ivory Glow',
    type: 'gradient',
    cssBackground:
      'radial-gradient(circle at 80% 15%, rgba(16,185,129,0.22), transparent 46%), radial-gradient(circle at 18% 82%, rgba(139,203,53,0.2), transparent 45%), linear-gradient(135deg, #ECFDF5 0%, #F4FBF6 55%, #FFFFFF 100%)',
    recommendedMode: 'light',
  },
  {
    id: 'carbon-blueprint',
    name: 'Architectural Carbon Grid',
    subtitle: 'Stealth Matte Court Lines',
    type: 'gradient',
    cssBackground:
      'linear-gradient(rgba(183,243,74,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(56,189,248,0.06) 1px, transparent 1px), linear-gradient(145deg, #07090D 0%, #11151E 100%)',
    recommendedMode: 'dark',
  },
];

export function getWallpaperById(id?: string): WallpaperOption {
  return BUILTIN_WALLPAPERS.find((w) => w.id === id) || BUILTIN_WALLPAPERS[0];
}
