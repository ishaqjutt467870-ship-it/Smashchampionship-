import {
  TournamentMatch,
  PlayerStats,
  TournamentState,
  TournamentStore,
  MatchScore,
  MatchFormat,
  TournamentFormatType,
  PlayerBio,
  RankingConfig,
  CompetitionCategory,
  CourtRecord,
  MatchScheduleInfo,
} from '../types';

export const STORAGE_KEY = 'hbt-state';
export const STORE_KEY = 'smash-store-v2';
export const DEFAULT_LOGO_URL = '/logo.png';
export const LEGACY_GOLD_LOGO_URL =
  '/assets/aistudio/dba4c5bb83eecdac85935cdaea59d1d86df353d2bbc12422e6c39f761f44c8c7_87d89dc8.png';

export const DEFAULT_RANKING_CONFIG: RankingConfig = {
  winPoints: 100,
  lossPoints: 20,
  setWinBonus: 15,
  championshipBonus: 300,
  runnerUpBonus: 150,
  mvpBonus: 50,
};

export const DEFAULT_COURTS: CourtRecord[] = [
  { id: 1, name: 'Court 1 (Center Arena)', assignedMatchId: null, status: 'available' },
  { id: 2, name: 'Court 2 (East)', assignedMatchId: null, status: 'available' },
  { id: 3, name: 'Court 3 (West)', assignedMatchId: null, status: 'available' },
  { id: 4, name: 'Court 4 (Warmup)', assignedMatchId: null, status: 'available' },
];

export const PLAYER_COLORS = [
  '#D4AF37', // championship gold
  '#FFD700', // bright gold
  '#16A34A', // emerald
  '#0EA5E9', // sky
  '#F59E0B', // amber
  '#DC2626', // red
  '#9333EA', // purple
  '#0D9488', // teal
  '#EA580C', // orange
  '#4F46E5', // indigo
  '#DB2777', // pink
  '#0284C7', // cyan
];

export const PLAY_STYLES = [
  'Jump Smash Attacker',
  'All-Round Tactician',
  'Net Play Specialist',
  'Defensive Retriever',
  'Fast-Paced Speedster',
  'Deceptive Drop-Shotter',
];

export const PRESET_ROSTERS = [
  {
    name: 'Badminton Legends',
    players: [
      'Viktor Axelsen',
      'Lee Chong Wei',
      'Lin Dan',
      'Kento Momota',
      'Anthony Ginting',
      'Shi Yuqi',
    ],
  },
  {
    name: 'Club All-Stars',
    players: ['Hassan', 'Hamza', 'Ali', 'Usman', 'Tariq', 'Bilal'],
  },
  {
    name: 'Top 4 Quick Cup',
    players: ['Alex', 'Brian', 'Charlie', 'David'],
  },
  {
    name: 'Doubles Teams',
    players: [
      'Team Falcons',
      'Team Vipers',
      'Team Titans',
      'Team Phoenix',
      'Team Raptors',
      'Team Cyclones',
    ],
  },
];

export function clampPointsPerSet(value: number): number {
  if (!Number.isFinite(value)) return 21;
  return Math.min(21, Math.max(11, Math.round(value)));
}

export function getSuggestedInterval(pointsPerSet: number): number {
  const pts = clampPointsPerSet(pointsPerSet);
  return Math.ceil(pts / 2);
}

export function getSuggestedDeuceCap(pointsPerSet: number): number {
  const pts = clampPointsPerSet(pointsPerSet);
  if (pts <= 11) return 15;
  if (pts <= 15) return 21;
  return Math.min(30, pts + 9);
}

export function getPlayerColor(index: number): string {
  const safeIdx = Math.abs(index);
  return PLAYER_COLORS[safeIdx % PLAYER_COLORS.length];
}

export function getPlayerCode(index: number): string {
  return `#SC-${String(index + 1).padStart(2, '0')}`;
}

export function getInitials(name: string): string {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
}

export function getSetsRequiredToWin(format: MatchFormat): number {
  switch (format) {
    case 'bo1':
      return 1;
    case 'bo2':
      return 2;
    case 'bo5':
      return 3;
    case 'bo3':
    default:
      return 2;
  }
}

export function getMaxSets(format: MatchFormat): number {
  switch (format) {
    case 'bo1':
      return 1;
    case 'bo2':
      return 2;
    case 'bo5':
      return 5;
    case 'bo3':
    default:
      return 3;
  }
}

export function getFormatLabel(format: MatchFormat): string {
  switch (format) {
    case 'bo1':
      return 'Best of 1 Set (1 set)';
    case 'bo2':
      return 'Best of 2 Sets (2 sets, pts tie-break)';
    case 'bo5':
      return 'Best of 5 Sets (First to 3)';
    case 'bo3':
    default:
      return 'Best of 3 Sets (First to 2)';
  }
}

export function getTournamentFormatLabel(fmt?: TournamentFormatType): string {
  switch (fmt) {
    case 'group_stage':
      return 'Group Stage (A & B)';
    case 'single_elimination':
      return 'Single Elimination';
    case 'double_elimination':
      return 'Double Elimination (WB + LB)';
    case 'double_round_robin':
      return 'Double Round-Robin (2 Legs)';
    case 'swiss':
      return 'Swiss System';
    case 'league':
      return 'Pro League Format';
    case 'team_championship':
      return 'Team Championship';
    case 'custom':
      return 'Custom Format';
    case 'knockout':
      return 'Knockout Elimination';
    case 'round_robin':
    default:
      return 'Round-Robin League';
  }
}

export function generateFixtures(
  playerCount: number,
  tournamentFormat: TournamentFormatType = 'round_robin',
  manualFixtures?: TournamentMatch[]
): TournamentMatch[] {
  if (manualFixtures && manualFixtures.length > 0) {
    return manualFixtures;
  }

  const matches: TournamentMatch[] = [];
  if (playerCount < 2) return matches;

  if (tournamentFormat === 'group_stage') {
    const groupA: number[] = [];
    const groupB: number[] = [];
    for (let i = 0; i < playerCount; i++) {
      if (i % 2 === 0) groupA.push(i);
      else groupB.push(i);
    }

    let matchCount = 1;
    for (let i = 0; i < groupA.length; i++) {
      for (let j = i + 1; j < groupA.length; j++) {
        matches.push({
          id: `${groupA[i]}-${groupA[j]}`,
          playerAIndex: groupA[i],
          playerBIndex: groupA[j],
          roundNumber: matchCount++,
          group: 'A',
        });
      }
    }
    for (let i = 0; i < groupB.length; i++) {
      for (let j = i + 1; j < groupB.length; j++) {
        matches.push({
          id: `${groupB[i]}-${groupB[j]}`,
          playerAIndex: groupB[i],
          playerBIndex: groupB[j],
          roundNumber: matchCount++,
          group: 'B',
        });
      }
    }
    return matches;
  }

  if (
    tournamentFormat === 'knockout' ||
    tournamentFormat === 'single_elimination' ||
    tournamentFormat === 'double_elimination'
  ) {
    const bracketSize = Math.pow(2, Math.ceil(Math.log2(playerCount)));
    const pairCount = bracketSize / 2;
    for (let i = 0; i < pairCount; i++) {
      const a = i;
      const rawB = bracketSize - 1 - i;
      const isBye = rawB >= playerCount;
      const b = isBye ? -1 : rawB;
      matches.push({
        id: isBye ? `${a}-bye` : `${a}-${b}`,
        playerAIndex: a,
        playerBIndex: b,
        roundNumber: i + 1,
        bracketSide: tournamentFormat === 'double_elimination' ? 'winners' : undefined,
        isBye,
      });
    }
    return matches;
  }

  if (tournamentFormat === 'double_round_robin') {
    let matchCount = 1;
    for (let i = 0; i < playerCount; i++) {
      for (let j = i + 1; j < playerCount; j++) {
        matches.push({
          id: `${i}-${j}`,
          playerAIndex: i,
          playerBIndex: j,
          roundNumber: matchCount++,
          leg: 1,
        });
      }
    }
    for (let i = 0; i < playerCount; i++) {
      for (let j = i + 1; j < playerCount; j++) {
        matches.push({
          id: `${j}-${i}-leg2`,
          playerAIndex: j,
          playerBIndex: i,
          roundNumber: matchCount++,
          leg: 2,
        });
      }
    }
    return matches;
  }

  if (tournamentFormat === 'swiss') {
    // Initial Round 1 Swiss pairings (1 vs 2, 3 vs 4, ...) with safe BYE for odd count
    let matchNum = 1;
    for (let i = 0; i < playerCount; i += 2) {
      const hasOpponent = i + 1 < playerCount;
      matches.push({
        id: hasOpponent ? `sw-r1-${i}-${i + 1}` : `sw-r1-${i}-bye`,
        playerAIndex: i,
        playerBIndex: hasOpponent ? i + 1 : -1,
        roundNumber: matchNum++,
        swissRound: 1,
        isBye: !hasOpponent,
      });
    }
    return matches;
  }

  // round_robin, league, team_championship, custom default
  let matchCount = 1;
  for (let i = 0; i < playerCount; i++) {
    for (let j = i + 1; j < playerCount; j++) {
      matches.push({
        id: `${i}-${j}`,
        playerAIndex: i,
        playerBIndex: j,
        roundNumber: matchCount++,
      });
    }
  }

  return matches;
}

export function generateNextSwissRoundFixtures(
  players: string[],
  currentFixtures: TournamentMatch[],
  results: Record<string, number>,
  standings: PlayerStats[]
): TournamentMatch[] {
  const maxRound = currentFixtures.reduce((acc, f) => Math.max(acc, f.swissRound || 1), 1);
  const nextRound = maxRound + 1;
  const playedPairs = new Set<string>();
  currentFixtures.forEach((f) => {
    if (!f.isBye && f.playerBIndex >= 0) {
      const k1 = `${Math.min(f.playerAIndex, f.playerBIndex)}-${Math.max(f.playerAIndex, f.playerBIndex)}`;
      playedPairs.add(k1);
    }
  });

  const orderedIds = standings.map((s) => s.id);
  const used = new Set<number>();
  const additions: TournamentMatch[] = [];
  let matchOrder = currentFixtures.length + 1;

  for (let i = 0; i < orderedIds.length; i++) {
    const a = orderedIds[i];
    if (used.has(a)) continue;

    let chosenB: number | null = null;
    for (let j = i + 1; j < orderedIds.length; j++) {
      const b = orderedIds[j];
      if (used.has(b)) continue;
      const pairKey = `${Math.min(a, b)}-${Math.max(a, b)}`;
      if (!playedPairs.has(pairKey)) {
        chosenB = b;
        break;
      }
    }
    // Fallback if all non-used opponents already played
    if (chosenB === null) {
      for (let j = i + 1; j < orderedIds.length; j++) {
        const b = orderedIds[j];
        if (!used.has(b)) {
          chosenB = b;
          break;
        }
      }
    }

    used.add(a);
    if (chosenB !== null) {
      used.add(chosenB);
      additions.push({
        id: `sw-r${nextRound}-${a}-${chosenB}`,
        playerAIndex: a,
        playerBIndex: chosenB,
        roundNumber: matchOrder++,
        swissRound: nextRound,
      });
    } else if (players[a]) {
      additions.push({
        id: `sw-r${nextRound}-${a}-bye`,
        playerAIndex: a,
        playerBIndex: -1,
        roundNumber: matchOrder++,
        swissRound: nextRound,
        isBye: true,
      });
    }
  }

  // Keep unfinished check clean
  void results;
  return [...currentFixtures, ...additions];
}

export function calculateStandings(
  players: string[],
  results: Record<string, number>,
  scores?: Record<string, MatchScore>,
  playerPhotos?: Record<number, string>,
  playerBios?: Record<number, PlayerBio>,
  tournamentFormat: TournamentFormatType = 'round_robin',
  manualFixtures?: TournamentMatch[]
): PlayerStats[] {
  const fixtures = generateFixtures(players.length, tournamentFormat, manualFixtures);

  const stats: PlayerStats[] = players.map((name, i) => ({
    id: i,
    name,
    photo: playerPhotos?.[i],
    avatarColor: getPlayerColor(i),
    played: 0,
    won: 0,
    lost: 0,
    points: 0,
    setsWon: 0,
    setsLost: 0,
    pointsFor: 0,
    pointsAgainst: 0,
    form: [],
    group: tournamentFormat === 'group_stage' ? (i % 2 === 0 ? 'A' : 'B') : undefined,
    bio: {
      playStyle: playerBios?.[i]?.playStyle || PLAY_STYLES[i % PLAY_STYLES.length],
      hand: playerBios?.[i]?.hand || (i % 3 === 0 ? 'Left' : 'Right'),
      racket: playerBios?.[i]?.racket,
      notes: playerBios?.[i]?.notes,
      playerCode: playerBios?.[i]?.playerCode || getPlayerCode(i),
      age: playerBios?.[i]?.age,
      contact: playerBios?.[i]?.contact,
      preferredCategory: playerBios?.[i]?.preferredCategory,
    },
  }));

  fixtures.forEach((match) => {
    // Handle BYE slots cleanly without crashing stats[-1]
    if (match.isBye || match.playerBIndex < 0) {
      return;
    }

    const winner = results[match.id];
    if (winner !== undefined) {
      const a = match.playerAIndex;
      const b = match.playerBIndex;
      if (!stats[a] || !stats[b]) return;

      stats[a].played++;
      stats[b].played++;

      if (winner === a) {
        stats[a].won++;
        stats[a].points += 2;
        stats[a].form.push('W');

        stats[b].lost++;
        stats[b].form.push('L');
      } else if (winner === b) {
        stats[b].won++;
        stats[b].points += 2;
        stats[b].form.push('W');

        stats[a].lost++;
        stats[a].form.push('L');
      }

      const score = scores?.[match.id];
      if (score) {
        const rawSets: Array<[number | undefined, number | undefined]> = [
          [score.s1a, score.s1b],
          [score.s2a, score.s2b],
          [score.s3a, score.s3b],
          [score.s4a, score.s4b],
          [score.s5a, score.s5b],
        ];

        rawSets.forEach(([sa, sb]) => {
          if (sa === undefined || sb === undefined || (sa === 0 && sb === 0)) return;
          stats[a].pointsFor += sa;
          stats[a].pointsAgainst += sb;
          stats[b].pointsFor += sb;
          stats[b].pointsAgainst += sa;

          if (sa > sb) {
            stats[a].setsWon++;
            stats[b].setsLost++;
          } else if (sb > sa) {
            stats[b].setsWon++;
            stats[a].setsLost++;
          }
        });
      }
    }
  });

  return stats.sort((p1, p2) => {
    if (p2.points !== p1.points) return p2.points - p1.points;
    if (p2.won !== p1.won) return p2.won - p1.won;
    const setDiff2 = p2.setsWon - p2.setsLost;
    const setDiff1 = p1.setsWon - p1.setsLost;
    if (setDiff2 !== setDiff1) return setDiff2 - setDiff1;
    const ptDiff2 = p2.pointsFor - p2.pointsAgainst;
    const ptDiff1 = p1.pointsFor - p1.pointsAgainst;
    if (ptDiff2 !== ptDiff1) return ptDiff2 - ptDiff1;
    return p1.name.localeCompare(p2.name);
  });
}

export interface GlobalRankingEntry {
  playerName: string;
  normalizedKey: string;
  ratingPoints: number;
  achievementPoints: number;
  tournamentsPlayed: number;
  matchesPlayed: number;
  wins: number;
  losses: number;
  winRate: number;
  setsWon: number;
  setsLost: number;
  titles: number;
  runnerUps: number;
  mvpAwards: number;
  currentWinStreak: number;
  bestWinStreak: number;
  fairPlayWarnings: number;
  fairPlayScore: number;
  improvementDelta: number;
  club?: string;
  categories: CompetitionCategory[];
  photo?: string;
  history: Array<{
    tournamentTitle: string;
    pointsEarned: number;
    date: string;
    resultLabel: string;
  }>;
}

export function calculateGlobalRankings(
  tournaments: TournamentState[],
  config: RankingConfig = DEFAULT_RANKING_CONFIG,
  categoryFilter: 'all' | CompetitionCategory = 'all',
  timeFilter: 'all' | 'monthly' | 'annual' = 'all'
): GlobalRankingEntry[] {
  const map = new Map<string, GlobalRankingEntry>();
  const streakTrack = new Map<string, string[]>();
  const now = Date.now();
  const cutoffMs =
    timeFilter === 'monthly'
      ? 30 * 24 * 60 * 60 * 1000
      : timeFilter === 'annual'
      ? 365 * 24 * 60 * 60 * 1000
      : Infinity;

  const getOrCreate = (
    name: string,
    photo?: string,
    category: CompetitionCategory = 'singles',
    club?: string
  ) => {
    const clean = name.trim();
    const key = clean.toLowerCase();
    let existing = map.get(key);
    if (!existing) {
      existing = {
        playerName: clean,
        normalizedKey: key,
        ratingPoints: 0,
        achievementPoints: 0,
        tournamentsPlayed: 0,
        matchesPlayed: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
        setsWon: 0,
        setsLost: 0,
        titles: 0,
        runnerUps: 0,
        mvpAwards: 0,
        currentWinStreak: 0,
        bestWinStreak: 0,
        fairPlayWarnings: 0,
        fairPlayScore: 100,
        improvementDelta: 0,
        club,
        categories: [category],
        photo,
        history: [],
      };
      map.set(key, existing);
    } else {
      if (photo && !existing.photo) existing.photo = photo;
      if (club && !existing.club) existing.club = club;
      if (!existing.categories.includes(category)) existing.categories.push(category);
    }
    return existing;
  };

  tournaments.forEach((t) => {
    if (timeFilter !== 'all') {
      const createdTs = new Date(t.createdDate).getTime();
      if (Number.isFinite(createdTs) && now - createdTs > cutoffMs) return;
    }
    const tCategory = t.category || 'singles';
    if (categoryFilter !== 'all' && tCategory !== categoryFilter) return;

    const fmt = t.tournamentFormat || 'round_robin';
    const standings = calculateStandings(
      t.players,
      t.results || {},
      t.scores || {},
      t.playerPhotos,
      t.playerBios,
      fmt,
      t.manualFixtures
    );

    const mvps = t.matchMvps || {};
    const mvpCounts: Record<number, number> = {};
    Object.values(mvps).forEach((pid) => {
      mvpCounts[pid] = (mvpCounts[pid] || 0) + 1;
    });

    // Count warnings/cards per player from matchMeta
    const warningCounts: Record<number, number> = {};
    const fixtures = generateFixtures(t.players.length, fmt, t.manualFixtures);
    fixtures.forEach((f) => {
      const meta = t.matchMeta?.[f.id];
      if (!meta?.incidents) return;
      meta.incidents.forEach((inc) => {
        if (inc.type === 'warning' || inc.type === 'yellow_card' || inc.type === 'red_card') {
          if (inc.playerSide === 'A' && f.playerAIndex >= 0) {
            warningCounts[f.playerAIndex] = (warningCounts[f.playerAIndex] || 0) + 1;
          } else if (inc.playerSide === 'B' && f.playerBIndex >= 0) {
            warningCounts[f.playerBIndex] = (warningCounts[f.playerBIndex] || 0) + 1;
          }
        }
      });
    });

    let runnerUpIdx: number | null = null;
    if (t.finalWinner !== null && t.finalWinner !== undefined) {
      if (
        t.doubleElim?.winnersFinalWinner !== undefined &&
        t.doubleElim?.losersFinalWinner !== undefined
      ) {
        runnerUpIdx =
          t.finalWinner === t.doubleElim.winnersFinalWinner
            ? t.doubleElim.losersFinalWinner
            : t.doubleElim.winnersFinalWinner;
      } else if (t.semis?.[0] !== undefined && t.semis?.[1] !== undefined) {
        runnerUpIdx = t.finalWinner === t.semis[0] ? t.semis[1] : t.semis[0];
      }
    }

    standings.forEach((pStat) => {
      const club = t.playerBios?.[pStat.id]?.club;
      const entry = getOrCreate(pStat.name, pStat.photo, tCategory, club);
      const isChamp = t.finalWinner === pStat.id;
      const isRunner = runnerUpIdx === pStat.id;
      const mvpCount = mvpCounts[pStat.id] || 0;
      const warnings = warningCounts[pStat.id] || 0;

      if (pStat.played > 0 || isChamp || isRunner) {
        entry.tournamentsPlayed += 1;
      }

      const achPts =
        (isChamp ? config.championshipBonus : 0) +
        (isRunner ? config.runnerUpBonus : 0) +
        mvpCount * config.mvpBonus;

      const earned =
        pStat.won * config.winPoints +
        pStat.lost * config.lossPoints +
        pStat.setsWon * config.setWinBonus +
        achPts;

      entry.matchesPlayed += pStat.played;
      entry.wins += pStat.won;
      entry.losses += pStat.lost;
      entry.setsWon += pStat.setsWon;
      entry.setsLost += pStat.setsLost;
      if (isChamp) entry.titles += 1;
      if (isRunner) entry.runnerUps += 1;
      entry.mvpAwards += mvpCount;
      entry.achievementPoints += achPts;
      entry.ratingPoints += earned;
      entry.fairPlayWarnings += warnings;

      const prevForm = streakTrack.get(entry.normalizedKey) || [];
      streakTrack.set(entry.normalizedKey, [...prevForm, ...pStat.form]);

      if (earned > 0 || pStat.played > 0) {
        entry.history.push({
          tournamentTitle: t.tournamentTitle,
          pointsEarned: earned,
          date: t.createdDate,
          resultLabel: isChamp
            ? 'Champion'
            : isRunner
            ? 'Runner-Up'
            : `${pStat.won}W-${pStat.lost}L`,
        });
      }
    });
  });

  const rows = Array.from(map.values()).map((r) => {
    const formArr = streakTrack.get(r.normalizedKey) || [];
    let best = 0;
    let running = 0;
    formArr.forEach((f) => {
      if (f === 'W') {
        running += 1;
        if (running > best) best = running;
      } else {
        running = 0;
      }
    });
    let current = 0;
    for (let i = formArr.length - 1; i >= 0; i--) {
      if (formArr[i] === 'W') current += 1;
      else break;
    }

    const latestPts = r.history[0]?.pointsEarned || 0;
    const prevAvg =
      r.history.length > 1
        ? r.history.slice(1).reduce((s, h) => s + h.pointsEarned, 0) / (r.history.length - 1)
        : 0;

    return {
      ...r,
      winRate: r.matchesPlayed > 0 ? Math.round((r.wins / r.matchesPlayed) * 100) : 0,
      currentWinStreak: current,
      bestWinStreak: best,
      fairPlayScore: Math.max(0, 100 - r.fairPlayWarnings * 10),
      improvementDelta: r.history.length > 1 ? Math.round(latestPts - prevAvg) : latestPts,
    };
  });

  return rows.sort((a, b) => {
    if (b.ratingPoints !== a.ratingPoints) return b.ratingPoints - a.ratingPoints;
    if (b.titles !== a.titles) return b.titles - a.titles;
    if (b.wins !== a.wins) return b.wins - a.wins;
    return b.winRate - a.winRate;
  });
}

export interface AutoScheduleResult {
  schedules: Record<string, MatchScheduleInfo>;
  assignedCount: number;
  conflicts: string[];
  estimatedMinutes: number;
  suggestedOrderIds: string[];
}

export function autoScheduleMatches(
  fixtures: TournamentMatch[],
  results: Record<string, number>,
  courts: CourtRecord[],
  referees: string[],
  players: string[],
  existingSchedules: Record<string, MatchScheduleInfo> = {},
  slotMinutes = 25
): AutoScheduleResult {
  const playable = fixtures.filter((f) => !f.isBye && f.playerBIndex >= 0);
  const pending = playable.filter((f) => results[f.id] === undefined);
  const nextSchedules: Record<string, MatchScheduleInfo> = { ...existingSchedules };
  const conflicts: string[] = [];

  const activeCourts = courts.filter((c) => c.status !== 'maintenance');
  const courtIds = activeCourts.length > 0 ? activeCourts.map((c) => c.id) : [1, 2];
  const refList = referees.length > 0 ? referees : ['Hassan (Chief Referee)'];

  // Sort pending fixtures greedily so players get rest between appearances
  const remaining = [...pending];
  const ordered: TournamentMatch[] = [];
  const lastPlayedSlot = new Map<number, number>();
  let slotIdx = 0;

  while (remaining.length > 0) {
    // Pick fixture whose players rested longest
    let bestIdx = 0;
    let bestRestScore = -Infinity;
    remaining.forEach((m, idx) => {
      const lastA = lastPlayedSlot.get(m.playerAIndex) ?? -10;
      const lastB = lastPlayedSlot.get(m.playerBIndex) ?? -10;
      const rest = (slotIdx - lastA) + (slotIdx - lastB);
      if (rest > bestRestScore) {
        bestRestScore = rest;
        bestIdx = idx;
      }
    });

    const chosen = remaining.splice(bestIdx, 1)[0];
    ordered.push(chosen);
    const wave = Math.floor(ordered.length / courtIds.length);
    lastPlayedSlot.set(chosen.playerAIndex, wave);
    lastPlayedSlot.set(chosen.playerBIndex, wave);
    slotIdx++;
  }

  const baseDate = new Date();
  baseDate.setMinutes(Math.ceil(baseDate.getMinutes() / 15) * 15, 0, 0);

  // Detect conflicts in same wave
  const wavePlayers = new Map<number, Set<number>>();

  ordered.forEach((m, idx) => {
    const courtNumber = courtIds[idx % courtIds.length];
    const wave = Math.floor(idx / courtIds.length);
    const startMs = baseDate.getTime() + wave * slotMinutes * 60 * 1000;
    const timeStr = new Date(startMs).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
    const referee = refList[idx % refList.length];

    const usedInWave = wavePlayers.get(wave) || new Set<number>();
    if (usedInWave.has(m.playerAIndex)) {
      conflicts.push(
        `Wave ${wave + 1} (${timeStr}): ${players[m.playerAIndex]} scheduled back-to-back`
      );
    }
    if (usedInWave.has(m.playerBIndex)) {
      conflicts.push(
        `Wave ${wave + 1} (${timeStr}): ${players[m.playerBIndex]} scheduled back-to-back`
      );
    }
    usedInWave.add(m.playerAIndex);
    usedInWave.add(m.playerBIndex);
    wavePlayers.set(wave, usedInWave);

    nextSchedules[m.id] = {
      time: timeStr,
      courtNumber,
      referee,
    };
  });

  const totalWaves = Math.ceil(ordered.length / Math.max(1, courtIds.length));
  return {
    schedules: nextSchedules,
    assignedCount: ordered.length,
    conflicts,
    estimatedMinutes: totalWaves * slotMinutes,
    suggestedOrderIds: ordered.map((m) => m.id),
  };
}

export interface DatabaseHealthReport {
  healthy: boolean;
  tournamentCount: number;
  totalPlayers: number;
  completedMatches: number;
  storageUsedKB: number;
  duplicateRosters: Array<{ tournamentTitle: string; duplicates: string[] }>;
  issues: string[];
  checkedAt: string;
}

export function runDatabaseHealthCheck(store: TournamentStore): DatabaseHealthReport {
  const issues: string[] = [];
  const duplicateRosters: Array<{ tournamentTitle: string; duplicates: string[] }> = [];
  let totalPlayers = 0;
  let completedMatches = 0;

  if (!Array.isArray(store.tournaments) || store.tournaments.length === 0) {
    issues.push('No tournaments found in local database.');
  }

  store.tournaments.forEach((t) => {
    totalPlayers += t.players.length;
    completedMatches += Object.keys(t.results || {}).length;
    if (t.players.length < 2) {
      issues.push(`"${t.tournamentTitle}" has fewer than 2 players.`);
    }
    const seen = new Set<string>();
    const dups: string[] = [];
    t.players.forEach((name) => {
      const k = name.trim().toLowerCase();
      if (seen.has(k)) dups.push(name);
      seen.add(k);
    });
    if (dups.length > 0) {
      duplicateRosters.push({ tournamentTitle: t.tournamentTitle, duplicates: dups });
    }
  });

  let bytes = 0;
  try {
    bytes = (localStorage.getItem(STORE_KEY) || '').length * 2;
  } catch {
    bytes = 0;
  }

  return {
    healthy: issues.length === 0 && duplicateRosters.length === 0,
    tournamentCount: store.tournaments.length,
    totalPlayers,
    completedMatches,
    storageUsedKB: Math.max(1, Math.round(bytes / 1024)),
    duplicateRosters,
    issues,
    checkedAt: new Date().toLocaleTimeString(),
  };
}

export interface BackupValidationResult {
  valid: boolean;
  kind: 'full_store' | 'single_tournament' | 'invalid';
  tournamentCount: number;
  duplicateIds: string[];
  duplicateTitles: string[];
  summary: string;
  error?: string;
}

export function validateBackupPayload(
  raw: unknown,
  existingTournaments: TournamentState[]
): BackupValidationResult {
  if (!raw || typeof raw !== 'object') {
    return {
      valid: false,
      kind: 'invalid',
      tournamentCount: 0,
      duplicateIds: [],
      duplicateTitles: [],
      summary: 'Invalid JSON payload.',
      error: 'File does not contain a valid JSON object.',
    };
  }

  const obj = raw as Partial<TournamentStore & TournamentState>;
  const existingIds = new Set(existingTournaments.map((t) => t.id).filter(Boolean));
  const existingTitles = new Set(
    existingTournaments.map((t) => (t.tournamentTitle || '').trim().toLowerCase())
  );

  if (Array.isArray(obj.tournaments)) {
    const validItems = obj.tournaments.filter(
      (t) => t && Array.isArray(t.players) && t.players.length >= 2
    );
    if (validItems.length === 0) {
      return {
        valid: false,
        kind: 'invalid',
        tournamentCount: 0,
        duplicateIds: [],
        duplicateTitles: [],
        summary: 'No valid tournaments found in store backup.',
        error: 'Backup contains zero valid tournament rosters.',
      };
    }
    const duplicateIds = validItems
      .map((t) => t.id)
      .filter((id): id is string => Boolean(id && existingIds.has(id)));
    const duplicateTitles = validItems
      .map((t) => t.tournamentTitle)
      .filter((title) => Boolean(title && existingTitles.has(title.trim().toLowerCase())));
    return {
      valid: true,
      kind: 'full_store',
      tournamentCount: validItems.length,
      duplicateIds,
      duplicateTitles,
      summary: `Full App Backup (${validItems.length} tournament${validItems.length > 1 ? 's' : ''})`,
    };
  }

  if (Array.isArray(obj.players) && obj.players.length >= 2) {
    const dupId = obj.id && existingIds.has(obj.id) ? [obj.id] : [];
    const dupTitle =
      obj.tournamentTitle && existingTitles.has(obj.tournamentTitle.trim().toLowerCase())
        ? [obj.tournamentTitle]
        : [];
    return {
      valid: true,
      kind: 'single_tournament',
      tournamentCount: 1,
      duplicateIds: dupId,
      duplicateTitles: dupTitle,
      summary: `Single Tournament "${obj.tournamentTitle || 'Untitled'}" (${obj.players.length} players)`,
    };
  }

  return {
    valid: false,
    kind: 'invalid',
    tournamentCount: 0,
    duplicateIds: [],
    duplicateTitles: [],
    summary: 'Unrecognized backup format.',
    error: 'Missing tournaments array or valid players roster.',
  };
}

export interface TournamentAwards {
  mvp: PlayerStats | null;
  topScorer: PlayerStats | null;
  bestWinRate: PlayerStats | null;
}

export function calculateTournamentAwards(standings: PlayerStats[]): TournamentAwards {
  const active = standings.filter((s) => s.played > 0);
  if (active.length === 0) {
    return { mvp: null, topScorer: null, bestWinRate: null };
  }

  const mvp = active[0];
  const topScorer = [...active].sort((a, b) => b.pointsFor - a.pointsFor)[0] || null;
  const bestWinRate =
    [...active].sort((a, b) => {
      const rateA = a.played > 0 ? a.won / a.played : 0;
      const rateB = b.played > 0 ? b.won / b.played : 0;
      if (rateB !== rateA) return rateB - rateA;
      return b.won - a.won;
    })[0] || null;

  return { mvp, topScorer, bestWinRate };
}

export function formatScore(score?: MatchScore): string {
  if (!score) return '';
  const parts: string[] = [];
  if (score.s1a !== undefined && score.s1b !== undefined) parts.push(`${score.s1a}-${score.s1b}`);
  if (score.s2a !== undefined && score.s2b !== undefined) parts.push(`${score.s2a}-${score.s2b}`);
  if (score.s3a !== undefined && score.s3b !== undefined) parts.push(`${score.s3a}-${score.s3b}`);
  if (score.s4a !== undefined && score.s4b !== undefined) parts.push(`${score.s4a}-${score.s4b}`);
  if (score.s5a !== undefined && score.s5b !== undefined) parts.push(`${score.s5a}-${score.s5b}`);
  return parts.join(', ');
}

export function generateTournamentId(): string {
  return `t-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

export function createDefaultTournamentState(
  overrides: Partial<TournamentState> = {}
): TournamentState {
  return {
    id: overrides.id || generateTournamentId(),
    players: ['Player 1', 'Player 2', 'Player 3', 'Player 4', 'Player 5', 'Player 6'],
    playerPhotos: {},
    playerBios: {},
    matchFormat: 'bo3',
    matchFormats: {},
    tournamentFormat: 'round_robin',
    category: 'singles',
    venue: 'Center Arena Court',
    description: 'Official BWF Rules Badminton Championship',
    customRules: {
      pointsPerSet: 21,
      maxDeuceCap: 30,
      intervalAt: 11,
      refereeName: 'Hassan',
    },
    results: {},
    scores: {},
    matchMeta: {},
    matchMvps: {},
    manualFixtures: [],
    doubleElim: {},
    consolationBracket: {},
    semis: {},
    semiScores: {},
    quarters: {},
    quarterScores: {},
    thirdPlaceWinner: null,
    finalWinner: null,
    started: false,
    archived: false,
    tournamentTitle: 'Smash Championship',
    customLogoUrl: DEFAULT_LOGO_URL,
    createdDate: new Date().toISOString(),
    defaultMatchDurationMinutes: 30,
    announcements: [],
    referees: ['Hassan (Chief Referee)', 'Bilal', 'Tariq'],
    matchSchedules: {},
    ...overrides,
  };
}

function normalizeTournamentState(raw: Partial<TournamentState>): TournamentState {
  const base = createDefaultTournamentState({ id: raw.id || generateTournamentId() });
  const points = clampPointsPerSet(raw.customRules?.pointsPerSet ?? 21);
  return {
    ...base,
    ...raw,
    id: raw.id || base.id,
    players:
      Array.isArray(raw.players) && raw.players.length >= 2 ? raw.players : base.players,
    playerPhotos: raw.playerPhotos || {},
    playerBios: raw.playerBios || {},
    matchFormat: raw.matchFormat || 'bo3',
    matchFormats: raw.matchFormats || {},
    tournamentFormat: raw.tournamentFormat || 'round_robin',
    category: raw.category || 'singles',
    venue: raw.venue || 'Center Arena Court',
    description: raw.description || 'Official BWF Rules Badminton Championship',
    customRules: {
      pointsPerSet: points,
      maxDeuceCap: raw.customRules?.maxDeuceCap || getSuggestedDeuceCap(points),
      intervalAt: raw.customRules?.intervalAt || getSuggestedInterval(points),
      refereeName: raw.customRules?.refereeName ?? 'Hassan',
    },
    results: raw.results || {},
    scores: raw.scores || {},
    matchMeta: raw.matchMeta || {},
    matchMvps: raw.matchMvps || {},
    manualFixtures: Array.isArray(raw.manualFixtures) ? raw.manualFixtures : [],
    doubleElim: raw.doubleElim || {},
    consolationBracket: raw.consolationBracket || {},
    semis: raw.semis || {},
    semiScores: raw.semiScores || {},
    quarters: raw.quarters || {},
    quarterScores: raw.quarterScores || {},
    thirdPlaceWinner: raw.thirdPlaceWinner ?? null,
    finalWinner: raw.finalWinner ?? null,
    started: Boolean(raw.started),
    archived: Boolean(raw.archived),
    tournamentTitle: raw.tournamentTitle || 'Smash Championship',
    customLogoUrl: raw.customLogoUrl || DEFAULT_LOGO_URL,
    createdDate: raw.createdDate || new Date().toISOString(),
    defaultMatchDurationMinutes: raw.defaultMatchDurationMinutes || 30,
    announcements: Array.isArray(raw.announcements) ? raw.announcements : [],
    referees:
      Array.isArray(raw.referees) && raw.referees.length > 0
        ? raw.referees
        : ['Hassan (Chief Referee)', 'Bilal', 'Tariq'],
    matchSchedules: raw.matchSchedules || {},
  };
}

export function saveTournamentState(state: TournamentState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save tournament state:', err);
  }
}

export function loadTournamentState(): TournamentState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed.players) && parsed.players.length >= 2) {
        return normalizeTournamentState(parsed);
      }
    }
  } catch (err) {
    console.error('Failed to load tournament state:', err);
  }
  return createDefaultTournamentState();
}

export function loadTournamentStore(): TournamentStore {
  try {
    const rawStore = localStorage.getItem(STORE_KEY);
    if (rawStore) {
      const parsed = JSON.parse(rawStore) as Partial<TournamentStore>;
      if (Array.isArray(parsed.tournaments) && parsed.tournaments.length > 0) {
        const normalized = parsed.tournaments.map((t) => normalizeTournamentState(t));
        const activeId = normalized.some((t) => t.id === parsed.activeTournamentId)
          ? (parsed.activeTournamentId as string)
          : (normalized[0].id as string);
        return {
          activeTournamentId: activeId,
          tournaments: normalized,
          language: parsed.language === 'ur' ? 'ur' : 'en',
          appPin: parsed.appPin ?? null,
          biometricCredentialId: parsed.biometricCredentialId ?? null,
          hapticsEnabled: parsed.hapticsEnabled ?? true,
          animationsEnabled: parsed.animationsEnabled ?? true,
          notificationsEnabled: parsed.notificationsEnabled ?? true,
          autoBackupEnabled: parsed.autoBackupEnabled ?? false,
          lastBackupAt: parsed.lastBackupAt,
          userRoleMode: parsed.userRoleMode === 'referee' ? 'referee' : 'admin',
          spectatorMode: Boolean(parsed.spectatorMode),
          selectedThemeId: parsed.selectedThemeId || 'black-gold-elite',
          wallpaper: parsed.wallpaper || {
            id: 'none',
            opacity: 45,
            blur: 2,
            scrim: true,
          },
          userAccount: parsed.userAccount ?? null,
          quickMatches: Array.isArray(parsed.quickMatches) ? parsed.quickMatches : [],
          doublesTeams: Array.isArray(parsed.doublesTeams) ? parsed.doublesTeams : [],
          rankingConfig: parsed.rankingConfig || DEFAULT_RANKING_CONFIG,
          courts:
            Array.isArray(parsed.courts) && parsed.courts.length > 0
              ? parsed.courts
              : DEFAULT_COURTS,
          courtHistory: Array.isArray(parsed.courtHistory) ? parsed.courtHistory : [],
          favouriteTournamentIds: Array.isArray(parsed.favouriteTournamentIds)
            ? parsed.favouriteTournamentIds
            : [],
          recentTournamentIds: Array.isArray(parsed.recentTournamentIds)
            ? parsed.recentTournamentIds
            : [activeId],
          financialRecords: Array.isArray(parsed.financialRecords) ? parsed.financialRecords : [],
          adminAccounts:
            Array.isArray(parsed.adminAccounts) && parsed.adminAccounts.length > 0
              ? parsed.adminAccounts
              : [
                  {
                    id: 'admin-default',
                    name: 'Hassan (Chief Organizer)',
                    role: 'organizer',
                    createdAt: new Date().toISOString(),
                  },
                ],
          activeAdminName: parsed.activeAdminName || 'Hassan (Chief Organizer)',
          auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
          accessibility: parsed.accessibility || {
            fontScale: 'md',
            highContrast: false,
            lowPerfMode: false,
          },
          onboardingDone: Boolean(parsed.onboardingDone),
        };
      }
    }
  } catch (err) {
    console.error('Failed to load tournament store:', err);
  }

  const legacy = loadTournamentState();
  const initialStore: TournamentStore = {
    activeTournamentId: legacy.id || 'default-tournament',
    tournaments: [legacy],
    language: 'en',
    appPin: null,
    biometricCredentialId: null,
    hapticsEnabled: true,
    animationsEnabled: true,
    notificationsEnabled: true,
    autoBackupEnabled: false,
    userRoleMode: 'admin',
    spectatorMode: false,
    selectedThemeId: 'black-gold-elite',
    wallpaper: {
      id: 'none',
      opacity: 45,
      blur: 2,
      scrim: true,
    },
    userAccount: null,
    quickMatches: [],
    doublesTeams: [],
    rankingConfig: DEFAULT_RANKING_CONFIG,
    courts: DEFAULT_COURTS,
    courtHistory: [],
    favouriteTournamentIds: [],
    recentTournamentIds: [legacy.id || 'default-tournament'],
    financialRecords: [],
    adminAccounts: [
      {
        id: 'admin-default',
        name: 'Hassan (Chief Organizer)',
        role: 'organizer',
        createdAt: new Date().toISOString(),
      },
    ],
    activeAdminName: 'Hassan (Chief Organizer)',
    auditLogs: [],
    accessibility: {
      fontScale: 'md',
      highContrast: false,
      lowPerfMode: false,
    },
    onboardingDone: false,
  };
  saveTournamentStore(initialStore);
  return initialStore;
}

export function saveTournamentStore(store: TournamentStore) {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(store));
    const active =
      store.tournaments.find((t) => t.id === store.activeTournamentId) || store.tournaments[0];
    if (active) {
      saveTournamentState(active);
    }
  } catch (err) {
    console.error('Failed to save tournament store:', err);
  }
}
