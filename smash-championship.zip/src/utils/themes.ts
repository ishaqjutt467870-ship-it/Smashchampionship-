export type ThemeCategory =
  | 'Pro Arenas'
  | 'Electric & Neon'
  | 'Royal & Luxury'
  | 'Light Editorial'
  | 'Championship'
  | 'Nature & Ocean'
  | 'Sunset & Ember'
  | 'Monochrome';

export interface AppTheme {
  id: string;
  name: string;
  category: ThemeCategory;
  mode: 'dark' | 'light';
  bgCanvas: string;
  bgCard: string;
  bgElevated: string;
  accentPrimary: string;
  accentSecondary: string;
  accentOnPrimary: string;
  textPrimary: string;
  textSecondary: string;
  borderColor: string;
  heroFrom: string;
  heroVia: string;
  heroTo: string;
}

interface ThemeSeed {
  id: string;
  name: string;
  category: ThemeCategory;
  mode: 'dark' | 'light';
  bgCanvas: string;
  bgCard: string;
  accentPrimary: string;
  accentSecondary: string;
  accentOnPrimary?: string;
}

function buildTheme(seed: ThemeSeed): AppTheme {
  const isDark = seed.mode === 'dark';
  const isGoldElite = seed.id === 'black-gold-elite';
  return {
    id: seed.id,
    name: seed.name,
    category: seed.category,
    mode: seed.mode,
    bgCanvas: seed.bgCanvas,
    bgCard: seed.bgCard,
    bgElevated: isGoldElite ? '#0E0E0E' : isDark ? seed.bgCanvas : '#F8FAFC',
    accentPrimary: seed.accentPrimary,
    accentSecondary: seed.accentSecondary,
    accentOnPrimary: seed.accentOnPrimary ?? (isDark ? '#0B1220' : '#FFFFFF'),
    textPrimary: isDark ? '#FFFFFF' : '#111827',
    textSecondary: isGoldElite ? '#A0A0A0' : isDark ? '#94A3B8' : '#475569',
    borderColor: isGoldElite
      ? 'rgba(212, 175, 55, 0.24)'
      : isDark
      ? 'rgba(148, 163, 184, 0.18)'
      : 'rgba(15, 23, 42, 0.1)',
    heroFrom: isGoldElite ? '#1A160B' : isDark ? seed.bgCard : '#172B4D',
    heroVia: isGoldElite ? '#141414' : isDark ? seed.bgCanvas : '#10213E',
    heroTo: isGoldElite ? '#080808' : isDark ? '#060B15' : '#0B1220',
  };
}

// 120+ Hand-Crafted Dynamic & Premium Themes across 8 Categories
const THEME_SEEDS: ThemeSeed[] = [
  // Flagship Default: Black + Gold
  { id: 'black-gold-elite', name: 'Black & Gold Elite (Pro Flagship)', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#080808', bgCard: '#141414', accentPrimary: '#D4AF37', accentSecondary: '#FFD700', accentOnPrimary: '#080808' },
  // 1. Pro Arenas (18)
  { id: 'midnight-lime', name: 'Midnight Pro Sports (Navy & Electric Lime)', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#0B1220', bgCard: '#151F30', accentPrimary: '#B7F500', accentSecondary: '#00D4FF', accentOnPrimary: '#0B1220' },
  { id: 'all-england-emerald', name: 'All-England Emerald Court', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#041410', bgCard: '#0B241D', accentPrimary: '#34D399', accentSecondary: '#FBBF24', accentOnPrimary: '#041410' },
  { id: 'thomas-cup-cobalt', name: 'Thomas Cup Cobalt', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#060F24', bgCard: '#0F1C3A', accentPrimary: '#60A5FA', accentSecondary: '#FACC15', accentOnPrimary: '#060F24' },
  { id: 'istora-senayan', name: 'Istora Senayan Crimson', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#17080C', bgCard: '#281018', accentPrimary: '#FB7185', accentSecondary: '#38BDF8', accentOnPrimary: '#17080C' },
  { id: 'tokyo-dome-slate', name: 'Tokyo Olympic Slate', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#090D16', bgCard: '#141B2B', accentPrimary: '#38BDF8', accentSecondary: '#A78BFA', accentOnPrimary: '#090D16' },
  { id: 'bwf-world-tour', name: 'World Tour Obsidian', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#0B0B10', bgCard: '#161621', accentPrimary: '#F43F5E', accentSecondary: '#F59E0B', accentOnPrimary: '#FFFFFF' },
  { id: 'uber-cup-violet', name: 'Uber Cup Amethyst', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#10081F', bgCard: '#1C1134', accentPrimary: '#C084FC', accentSecondary: '#22D3EE', accentOnPrimary: '#10081F' },
  { id: 'axiata-arena-volt', name: 'Axiata Arena Volt', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#071318', bgCard: '#102129', accentPrimary: '#A3E635', accentSecondary: '#2DD4BF', accentOnPrimary: '#071318' },
  { id: 'denmark-open-frost', name: 'Odense Nordic Court', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#0E121B', bgCard: '#181F2E', accentPrimary: '#F87171', accentSecondary: '#93C5FD', accentOnPrimary: '#0E121B' },
  { id: 'french-open-indigo', name: 'Paris Arena Indigo', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#0A0D22', bgCard: '#141A3D', accentPrimary: '#818CF8', accentSecondary: '#F472B6', accentOnPrimary: '#0A0D22' },
  { id: 'singapore-indoor', name: 'Singapore Indoor Cyan', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#05151C', bgCard: '#0C232E', accentPrimary: '#22D3EE', accentSecondary: '#BEF264', accentOnPrimary: '#05151C' },
  { id: 'korean-masters-navy', name: 'Seoul Masters Deep', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#070E20', bgCard: '#101B39', accentPrimary: '#3B82F6', accentSecondary: '#FB7185', accentOnPrimary: '#FFFFFF' },
  { id: 'swiss-open-basel', name: 'Basel Arena Ruby', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#14090B', bgCard: '#231115', accentPrimary: '#EF4444', accentSecondary: '#E2E8F0', accentOnPrimary: '#FFFFFF' },
  { id: 'dubai-finals-gold', name: 'Dubai Superseries Gold', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#0F0D08', bgCard: '#1E1910', accentPrimary: '#FACC15', accentSecondary: '#38BDF8', accentOnPrimary: '#0F0D08' },
  { id: 'india-open-saffron', name: 'New Delhi Court Saffron', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#130D06', bgCard: '#22180C', accentPrimary: '#FB923C', accentSecondary: '#34D399', accentOnPrimary: '#130D06' },
  { id: 'china-open-jade', name: 'Changzhou Imperial Jade', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#061412', bgCard: '#0D2420', accentPrimary: '#10B981', accentSecondary: '#FDE047', accentOnPrimary: '#061412' },
  { id: 'german-open-steel', name: 'Mulheim Steel & Amber', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#0C0F14', bgCard: '#161B24', accentPrimary: '#F59E0B', accentSecondary: '#60A5FA', accentOnPrimary: '#0C0F14' },
  { id: 'hong-kong-harbor', name: 'Kowloon Harbor Night', category: 'Pro Arenas', mode: 'dark', bgCanvas: '#07101E', bgCard: '#101D33', accentPrimary: '#2DD4BF', accentSecondary: '#F472B6', accentOnPrimary: '#07101E' },

  // 2. Electric & Neon (18)
  { id: 'volt-cyber', name: 'Volt Cyber Court', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#060A12', bgCard: '#101726', accentPrimary: '#D9F99D', accentSecondary: '#06B6D4', accentOnPrimary: '#060A12' },
  { id: 'hyper-cyan', name: 'Hyper Cyan Laser', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#031117', bgCard: '#08202B', accentPrimary: '#00F5D4', accentSecondary: '#38BDF8', accentOnPrimary: '#031117' },
  { id: 'neon-coral', name: 'Neon Coral Velocity', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#140812', bgCard: '#231020', accentPrimary: '#FF4D8D', accentSecondary: '#22D3EE', accentOnPrimary: '#FFFFFF' },
  { id: 'plasma-violet', name: 'Plasma Violet Pulse', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#0E071B', bgCard: '#1A0F30', accentPrimary: '#A855F7', accentSecondary: '#34D399', accentOnPrimary: '#FFFFFF' },
  { id: 'acid-mint', name: 'Acid Mint Overdrive', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#04120D', bgCard: '#0A2118', accentPrimary: '#4ADE80', accentSecondary: '#A3E635', accentOnPrimary: '#04120D' },
  { id: 'synthwave-indigo', name: 'Synthwave Night Rally', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#110924', bgCard: '#1C103B', accentPrimary: '#F472B6', accentSecondary: '#38BDF8', accentOnPrimary: '#110924' },
  { id: 'laser-lime-pro', name: 'Laser Lime Pro', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#081205', bgCard: '#11220C', accentPrimary: '#B7F34A', accentSecondary: '#FDE047', accentOnPrimary: '#081205' },
  { id: 'electric-tangerine', name: 'Electric Tangerine', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#140B06', bgCard: '#24140B', accentPrimary: '#FF7A00', accentSecondary: '#38BDF8', accentOnPrimary: '#140B06' },
  { id: 'arcade-cobalt', name: 'Arcade Cobalt Strike', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#050C1F', bgCard: '#0C1838', accentPrimary: '#00E5FF', accentSecondary: '#B7F34A', accentOnPrimary: '#050C1F' },
  { id: 'ultraviolet-ace', name: 'Ultraviolet Ace', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#0B0617', bgCard: '#160E2B', accentPrimary: '#E879F9', accentSecondary: '#60A5FA', accentOnPrimary: '#0B0617' },
  { id: 'matrix-shuttle', name: 'Matrix Shuttle Grid', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#030E07', bgCard: '#081D10', accentPrimary: '#22C55E', accentSecondary: '#86EFAC', accentOnPrimary: '#030E07' },
  { id: 'photon-magenta', name: 'Photon Magenta', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#160715', bgCard: '#260E24', accentPrimary: '#F0ABFC', accentSecondary: '#FB7185', accentOnPrimary: '#160715' },
  { id: 'neon-ice-blue', name: 'Neon Ice Velocity', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#05121F', bgCard: '#0B1F33', accentPrimary: '#7DD3FC', accentSecondary: '#A3E635', accentOnPrimary: '#05121F' },
  { id: 'crimson-bolt', name: 'Crimson Bolt', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#160709', bgCard: '#280D11', accentPrimary: '#FF3B5C', accentSecondary: '#FACC15', accentOnPrimary: '#FFFFFF' },
  { id: 'turbo-yellow', name: 'Turbo Yellow Surge', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#100E04', bgCard: '#1E1A09', accentPrimary: '#FACC15', accentSecondary: '#22D3EE', accentOnPrimary: '#100E04' },
  { id: 'teal-reactor', name: 'Teal Reactor Core', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#041414', bgCard: '#0A2525', accentPrimary: '#14B8A6', accentSecondary: '#B7F34A', accentOnPrimary: '#041414' },
  { id: 'sky-surge-99', name: 'Sky Surge 99', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#061121', bgCard: '#0E1F38', accentPrimary: '#38BDF8', accentSecondary: '#F43F5E', accentOnPrimary: '#061121' },
  { id: 'aurora-volt', name: 'Aurora Volt Flare', category: 'Electric & Neon', mode: 'dark', bgCanvas: '#061419', bgCard: '#0E242C', accentPrimary: '#A3E635', accentSecondary: '#38BDF8', accentOnPrimary: '#061419' },

  // 3. Royal & Luxury (15)
  { id: 'championship-gold', name: 'Championship Gold & Obsidian', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#0B0B0D', bgCard: '#17161B', accentPrimary: '#F5C451', accentSecondary: '#E2E8F0', accentOnPrimary: '#0B0B0D' },
  { id: 'imperial-sapphire', name: 'Imperial Sapphire Crown', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#060D1F', bgCard: '#0E1A3B', accentPrimary: '#FBBF24', accentSecondary: '#60A5FA', accentOnPrimary: '#060D1F' },
  { id: 'obsidian-emerald', name: 'Obsidian & Royal Emerald', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#070E0C', bgCard: '#101E19', accentPrimary: '#10B981', accentSecondary: '#FCD34D', accentOnPrimary: '#070E0C' },
  { id: 'velvet-burgundy', name: 'Velvet Burgundy Trophy', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#17070E', bgCard: '#290E1A', accentPrimary: '#FDE047', accentSecondary: '#FDA4AF', accentOnPrimary: '#17070E' },
  { id: 'rose-champagne', name: 'Rose Champagne Gala', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#140C10', bgCard: '#24161D', accentPrimary: '#F9A8D4', accentSecondary: '#FDE68A', accentOnPrimary: '#140C10' },
  { id: 'platinum-onyx', name: 'Platinum Onyx Elite', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#0A0C10', bgCard: '#151821', accentPrimary: '#E2E8F0', accentSecondary: '#38BDF8', accentOnPrimary: '#0A0C10' },
  { id: 'bronze-laurel', name: 'Bronze Laurel Classic', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#120C08', bgCard: '#21170F', accentPrimary: '#F59E0B', accentSecondary: '#FDBA74', accentOnPrimary: '#120C08' },
  { id: 'sovereign-plum', name: 'Sovereign Plum & Gold', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#120818', bgCard: '#21102B', accentPrimary: '#FACC15', accentSecondary: '#D8B4FE', accentOnPrimary: '#120818' },
  { id: 'emerald-velvet', name: 'Emerald Velvet Suite', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#05120E', bgCard: '#0B211A', accentPrimary: '#6EE7B7', accentSecondary: '#FBBF24', accentOnPrimary: '#05120E' },
  { id: 'royal-navy-brass', name: 'Royal Navy & Brass', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#071022', bgCard: '#101E3B', accentPrimary: '#EAB308', accentSecondary: '#93C5FD', accentOnPrimary: '#071022' },
  { id: 'midnight-pearl', name: 'Midnight Pearl Luxe', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#0B0E17', bgCard: '#151B2C', accentPrimary: '#F8FAFC', accentSecondary: '#B7F34A', accentOnPrimary: '#0B0E17' },
  { id: 'amber-crown', name: 'Amber Crown Finals', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#130E05', bgCard: '#241B0A', accentPrimary: '#FBBF24', accentSecondary: '#38BDF8', accentOnPrimary: '#130E05' },
  { id: 'ruby-diamond', name: 'Ruby & Diamond Prestige', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#16060C', bgCard: '#290C17', accentPrimary: '#FB7185', accentSecondary: '#FDE047', accentOnPrimary: '#16060C' },
  { id: 'cobalt-champagne', name: 'Cobalt Champagne', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#071226', bgCard: '#10203F', accentPrimary: '#FDE68A', accentSecondary: '#38BDF8', accentOnPrimary: '#071226' },
  { id: 'monarch-slate', name: 'Monarch Slate & Gold', category: 'Royal & Luxury', mode: 'dark', bgCanvas: '#0C1017', bgCard: '#171E2B', accentPrimary: '#FCD34D', accentSecondary: '#94A3B8', accentOnPrimary: '#0C1017' },

  // 4. Light Editorial (18)
  { id: 'crisp-light', name: 'Crisp Light Pavilion', category: 'Light Editorial', mode: 'light', bgCanvas: '#F4F7FB', bgCard: '#FFFFFF', accentPrimary: '#172B4D', accentSecondary: '#8BCB35', accentOnPrimary: '#FFFFFF' },
  { id: 'nordic-ice', name: 'Nordic Ice Court', category: 'Light Editorial', mode: 'light', bgCanvas: '#EEF6FF', bgCard: '#FFFFFF', accentPrimary: '#0284C7', accentSecondary: '#22C55E', accentOnPrimary: '#FFFFFF' },
  { id: 'pearl-mint', name: 'Pearl Mint Studio', category: 'Light Editorial', mode: 'light', bgCanvas: '#ECFDF5', bgCard: '#FFFFFF', accentPrimary: '#059669', accentSecondary: '#0EA5E9', accentOnPrimary: '#FFFFFF' },
  { id: 'ivory-gold', name: 'Ivory Championship Gold', category: 'Light Editorial', mode: 'light', bgCanvas: '#FEFCE8', bgCard: '#FFFFFF', accentPrimary: '#B45309', accentSecondary: '#172B4D', accentOnPrimary: '#FFFFFF' },
  { id: 'sky-pavilion', name: 'Sky Pavilion Daylight', category: 'Light Editorial', mode: 'light', bgCanvas: '#F0F9FF', bgCard: '#FFFFFF', accentPrimary: '#0369A1', accentSecondary: '#84CC16', accentOnPrimary: '#FFFFFF' },
  { id: 'warm-sandstone', name: 'Warm Sandstone Club', category: 'Light Editorial', mode: 'light', bgCanvas: '#FAF7F2', bgCard: '#FFFFFF', accentPrimary: '#9A3412', accentSecondary: '#0D9488', accentOnPrimary: '#FFFFFF' },
  { id: 'lavender-mist', name: 'Lavender Mist Classic', category: 'Light Editorial', mode: 'light', bgCanvas: '#F5F3FF', bgCard: '#FFFFFF', accentPrimary: '#6D28D9', accentSecondary: '#0284C7', accentOnPrimary: '#FFFFFF' },
  { id: 'rose-quartz-light', name: 'Rose Quartz Arena', category: 'Light Editorial', mode: 'light', bgCanvas: '#FFF1F2', bgCard: '#FFFFFF', accentPrimary: '#BE123C', accentSecondary: '#0F172A', accentOnPrimary: '#FFFFFF' },
  { id: 'matcha-cream', name: 'Matcha Cream Court', category: 'Light Editorial', mode: 'light', bgCanvas: '#F4F9EE', bgCard: '#FFFFFF', accentPrimary: '#3F6212', accentSecondary: '#0284C7', accentOnPrimary: '#FFFFFF' },
  { id: 'cobalt-paper', name: 'Cobalt Editorial Paper', category: 'Light Editorial', mode: 'light', bgCanvas: '#EFF4FF', bgCard: '#FFFFFF', accentPrimary: '#1D4ED8', accentSecondary: '#16A34A', accentOnPrimary: '#FFFFFF' },
  { id: 'teal-breeze', name: 'Teal Breeze Daylight', category: 'Light Editorial', mode: 'light', bgCanvas: '#F0FDFA', bgCard: '#FFFFFF', accentPrimary: '#0F766E', accentSecondary: '#2563EB', accentOnPrimary: '#FFFFFF' },
  { id: 'amber-linen', name: 'Amber Linen Morning', category: 'Light Editorial', mode: 'light', bgCanvas: '#FFFBEB', bgCard: '#FFFFFF', accentPrimary: '#D97706', accentSecondary: '#1E293B', accentOnPrimary: '#FFFFFF' },
  { id: 'alpine-frost', name: 'Alpine Frost White', category: 'Light Editorial', mode: 'light', bgCanvas: '#F1F5F9', bgCard: '#FFFFFF', accentPrimary: '#0F172A', accentSecondary: '#0EA5E9', accentOnPrimary: '#FFFFFF' },
  { id: 'orchid-clean', name: 'Orchid Clean Club', category: 'Light Editorial', mode: 'light', bgCanvas: '#FDF4FF', bgCard: '#FFFFFF', accentPrimary: '#A21CAF', accentSecondary: '#0284C7', accentOnPrimary: '#FFFFFF' },
  { id: 'emerald-day', name: 'Wimbledon Grass Light', category: 'Light Editorial', mode: 'light', bgCanvas: '#F2FBF5', bgCard: '#FFFFFF', accentPrimary: '#15803D', accentSecondary: '#6D28D9', accentOnPrimary: '#FFFFFF' },
  { id: 'citrus-pop', name: 'Citrus Lime Light', category: 'Light Editorial', mode: 'light', bgCanvas: '#F7FEE7', bgCard: '#FFFFFF', accentPrimary: '#4D7C0F', accentSecondary: '#0284C7', accentOnPrimary: '#FFFFFF' },
  { id: 'crimson-press', name: 'Crimson Press White', category: 'Light Editorial', mode: 'light', bgCanvas: '#FEF2F2', bgCard: '#FFFFFF', accentPrimary: '#B91C1C', accentSecondary: '#1E293B', accentOnPrimary: '#FFFFFF' },
  { id: 'graphite-light', name: 'Graphite Studio Light', category: 'Light Editorial', mode: 'light', bgCanvas: '#F3F4F6', bgCard: '#FFFFFF', accentPrimary: '#1F2937', accentSecondary: '#8BCB35', accentOnPrimary: '#FFFFFF' },

  // 5. Championship Nations (15)
  { id: 'pakistan-green', name: 'Pakistan Green & Crescent', category: 'Championship', mode: 'dark', bgCanvas: '#04170D', bgCard: '#0A2918', accentPrimary: '#22C55E', accentSecondary: '#F8FAFC', accentOnPrimary: '#04170D' },
  { id: 'malaysia-harimau', name: 'Malaysia Harimau Gold', category: 'Championship', mode: 'dark', bgCanvas: '#0B1020', bgCard: '#151E38', accentPrimary: '#FACC15', accentSecondary: '#EF4444', accentOnPrimary: '#0B1020' },
  { id: 'indonesia-garuda', name: 'Indonesia Garuda Red', category: 'Championship', mode: 'dark', bgCanvas: '#170709', bgCard: '#2B0D11', accentPrimary: '#EF4444', accentSecondary: '#FFFFFF', accentOnPrimary: '#FFFFFF' },
  { id: 'denmark-vikings', name: 'Denmark Nordic Red', category: 'Championship', mode: 'dark', bgCanvas: '#15080B', bgCard: '#261015', accentPrimary: '#F43F5E', accentSecondary: '#F8FAFC', accentOnPrimary: '#FFFFFF' },
  { id: 'japan-sakura', name: 'Japan Sakura & Navy', category: 'Championship', mode: 'dark', bgCanvas: '#0B0F1D', bgCard: '#151C33', accentPrimary: '#FDA4AF', accentSecondary: '#F43F5E', accentOnPrimary: '#0B0F1D' },
  { id: 'china-dragon', name: 'China Dragon Scarlet', category: 'Championship', mode: 'dark', bgCanvas: '#180707', bgCard: '#2C0E0E', accentPrimary: '#FACC15', accentSecondary: '#EF4444', accentOnPrimary: '#180707' },
  { id: 'india-tricolor', name: 'India Blue & Saffron', category: 'Championship', mode: 'dark', bgCanvas: '#070F21', bgCard: '#0F1D3D', accentPrimary: '#FB923C', accentSecondary: '#22C55E', accentOnPrimary: '#070F21' },
  { id: 'korea-taegeuk', name: 'Korea Taegeuk', category: 'Championship', mode: 'dark', bgCanvas: '#081020', bgCard: '#111D38', accentPrimary: '#3B82F6', accentSecondary: '#F43F5E', accentOnPrimary: '#FFFFFF' },
  { id: 'england-lion', name: 'England Royal Lion', category: 'Championship', mode: 'light', bgCanvas: '#F5F7FA', bgCard: '#FFFFFF', accentPrimary: '#DC2626', accentSecondary: '#1E3A8A', accentOnPrimary: '#FFFFFF' },
  { id: 'taipei-azure', name: 'Chinese Taipei Azure', category: 'Championship', mode: 'dark', bgCanvas: '#061124', bgCard: '#0D1F40', accentPrimary: '#38BDF8', accentSecondary: '#F43F5E', accentOnPrimary: '#061124' },
  { id: 'thailand-royal', name: 'Thailand Royal Gold', category: 'Championship', mode: 'dark', bgCanvas: '#0A1022', bgCard: '#141E3D', accentPrimary: '#FBBF24', accentSecondary: '#38BDF8', accentOnPrimary: '#0A1022' },
  { id: 'france-tricolor', name: 'France Bleu Arena', category: 'Championship', mode: 'dark', bgCanvas: '#071024', bgCard: '#0E1C3D', accentPrimary: '#60A5FA', accentSecondary: '#F43F5E', accentOnPrimary: '#071024' },
  { id: 'canada-maple', name: 'Canada Maple Court', category: 'Championship', mode: 'light', bgCanvas: '#FFF5F5', bgCard: '#FFFFFF', accentPrimary: '#DC2626', accentSecondary: '#0F172A', accentOnPrimary: '#FFFFFF' },
  { id: 'uae-crescent', name: 'UAE Falcon Emerald', category: 'Championship', mode: 'dark', bgCanvas: '#07120E', bgCard: '#0F221B', accentPrimary: '#22C55E', accentSecondary: '#EF4444', accentOnPrimary: '#07120E' },
  { id: 'spain-sol', name: 'Spain Championship Sol', category: 'Championship', mode: 'dark', bgCanvas: '#170A06', bgCard: '#2B140C', accentPrimary: '#FACC15', accentSecondary: '#EF4444', accentOnPrimary: '#170A06' },

  // 6. Nature & Ocean (12)
  { id: 'deep-pacific', name: 'Deep Pacific Trench', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#04121C', bgCard: '#092233', accentPrimary: '#38BDF8', accentSecondary: '#2DD4BF', accentOnPrimary: '#04121C' },
  { id: 'alpine-pine', name: 'Alpine Pine Forest', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#06130E', bgCard: '#0D241B', accentPrimary: '#4ADE80', accentSecondary: '#A3E635', accentOnPrimary: '#06130E' },
  { id: 'emerald-lagoon', name: 'Emerald Lagoon', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#041515', bgCard: '#0A2727', accentPrimary: '#2DD4BF', accentSecondary: '#34D399', accentOnPrimary: '#041515' },
  { id: 'arctic-aurora', name: 'Arctic Aurora Borealis', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#061019', bgCard: '#0E1E2E', accentPrimary: '#5EEAD4', accentSecondary: '#818CF8', accentOnPrimary: '#061019' },
  { id: 'coral-reef', name: 'Coral Reef Dive', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#07141F', bgCard: '#0F2436', accentPrimary: '#FB7185', accentSecondary: '#22D3EE', accentOnPrimary: '#07141F' },
  { id: 'monsoon-slate', name: 'Monsoon Storm Slate', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#0A1118', bgCard: '#14202B', accentPrimary: '#60A5FA', accentSecondary: '#A7F3D0', accentOnPrimary: '#0A1118' },
  { id: 'ocean-foam-light', name: 'Ocean Foam Breeze', category: 'Nature & Ocean', mode: 'light', bgCanvas: '#ECFEFF', bgCard: '#FFFFFF', accentPrimary: '#0891B2', accentSecondary: '#10B981', accentOnPrimary: '#FFFFFF' },
  { id: 'rainforest-mist', name: 'Rainforest Mist', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#051410', bgCard: '#0B261E', accentPrimary: '#86EFAC', accentSecondary: '#38BDF8', accentOnPrimary: '#051410' },
  { id: 'fjord-blue', name: 'Norwegian Fjord Blue', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#07121E', bgCard: '#0F2136', accentPrimary: '#7DD3FC', accentSecondary: '#FDE047', accentOnPrimary: '#07121E' },
  { id: 'sage-meadow', name: 'Sage Meadow Light', category: 'Nature & Ocean', mode: 'light', bgCanvas: '#F1F8F4', bgCard: '#FFFFFF', accentPrimary: '#166534', accentSecondary: '#0284C7', accentOnPrimary: '#FFFFFF' },
  { id: 'glacial-spring', name: 'Glacial Spring', category: 'Nature & Ocean', mode: 'light', bgCanvas: '#F0F9FF', bgCard: '#FFFFFF', accentPrimary: '#0E7490', accentSecondary: '#2563EB', accentOnPrimary: '#FFFFFF' },
  { id: 'abyss-turquoise', name: 'Abyssal Turquoise', category: 'Nature & Ocean', mode: 'dark', bgCanvas: '#031317', bgCard: '#07242B', accentPrimary: '#06B6D4', accentSecondary: '#B7F34A', accentOnPrimary: '#031317' },

  // 7. Sunset & Ember (12)
  { id: 'solar-flare', name: 'Solar Flare Gold', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#150B04', bgCard: '#261509', accentPrimary: '#F59E0B', accentSecondary: '#FB7185', accentOnPrimary: '#150B04' },
  { id: 'crimson-dusk', name: 'Crimson Dusk', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#17070D', bgCard: '#2A0E19', accentPrimary: '#F43F5E', accentSecondary: '#FBBF24', accentOnPrimary: '#FFFFFF' },
  { id: 'amber-horizon', name: 'Amber Horizon', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#130D07', bgCard: '#24190E', accentPrimary: '#FBBF24', accentSecondary: '#FB923C', accentOnPrimary: '#130D07' },
  { id: 'copper-forge', name: 'Copper Forge Arena', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#140C09', bgCard: '#241611', accentPrimary: '#FB923C', accentSecondary: '#38BDF8', accentOnPrimary: '#140C09' },
  { id: 'magma-night', name: 'Magma Night Forge', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#120606', bgCard: '#220C0C', accentPrimary: '#EF4444', accentSecondary: '#F97316', accentOnPrimary: '#FFFFFF' },
  { id: 'desert-twilight', name: 'Desert Twilight', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#140B14', bgCard: '#241424', accentPrimary: '#FDBA74', accentSecondary: '#F472B6', accentOnPrimary: '#140B14' },
  { id: 'sunset-peach-light', name: 'Sunset Peach Light', category: 'Sunset & Ember', mode: 'light', bgCanvas: '#FFF7ED', bgCard: '#FFFFFF', accentPrimary: '#EA580C', accentSecondary: '#E11D48', accentOnPrimary: '#FFFFFF' },
  { id: 'flame-scarlet', name: 'Flame Scarlet Strike', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#160708', bgCard: '#290E10', accentPrimary: '#FB7185', accentSecondary: '#FDE047', accentOnPrimary: '#160708' },
  { id: 'marigold-light', name: 'Marigold Sunrise Light', category: 'Sunset & Ember', mode: 'light', bgCanvas: '#FEFCE8', bgCard: '#FFFFFF', accentPrimary: '#CA8A04', accentSecondary: '#DC2626', accentOnPrimary: '#FFFFFF' },
  { id: 'volcanic-ember', name: 'Volcanic Ember', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#110908', bgCard: '#20110F', accentPrimary: '#F97316', accentSecondary: '#FACC15', accentOnPrimary: '#110908' },
  { id: 'sahara-dusk', name: 'Sahara Dusk', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#161009', bgCard: '#261C10', accentPrimary: '#F59E0B', accentSecondary: '#38BDF8', accentOnPrimary: '#161009' },
  { id: 'phoenix-glow', name: 'Phoenix Feather Glow', category: 'Sunset & Ember', mode: 'dark', bgCanvas: '#15080C', bgCard: '#260F16', accentPrimary: '#FB923C', accentSecondary: '#F43F5E', accentOnPrimary: '#15080C' },

  // 8. Monochrome (12)
  { id: 'carbon-stealth', name: 'Carbon Stealth', category: 'Monochrome', mode: 'dark', bgCanvas: '#09090B', bgCard: '#141418', accentPrimary: '#F4F4F5', accentSecondary: '#A1A1AA', accentOnPrimary: '#09090B' },
  { id: 'titanium-graphite', name: 'Titanium Graphite', category: 'Monochrome', mode: 'dark', bgCanvas: '#0D1014', bgCard: '#171C24', accentPrimary: '#CBD5E1', accentSecondary: '#38BDF8', accentOnPrimary: '#0D1014' },
  { id: 'charcoal-lime', name: 'Charcoal & Volt Lime', category: 'Monochrome', mode: 'dark', bgCanvas: '#0B0C0E', bgCard: '#16181D', accentPrimary: '#B7F34A', accentSecondary: '#94A3B8', accentOnPrimary: '#0B0C0E' },
  { id: 'obsidian-contrast', name: 'Obsidian High Contrast', category: 'Monochrome', mode: 'dark', bgCanvas: '#050505', bgCard: '#121212', accentPrimary: '#FFFFFF', accentSecondary: '#D4D4D8', accentOnPrimary: '#050505' },
  { id: 'frost-silver', name: 'Frost Silver Light', category: 'Monochrome', mode: 'light', bgCanvas: '#F8FAFC', bgCard: '#FFFFFF', accentPrimary: '#0F172A', accentSecondary: '#475569', accentOnPrimary: '#FFFFFF' },
  { id: 'studio-paper', name: 'Architectural Paper', category: 'Monochrome', mode: 'light', bgCanvas: '#F5F5F4', bgCard: '#FFFFFF', accentPrimary: '#1C1917', accentSecondary: '#57534E', accentOnPrimary: '#FFFFFF' },
  { id: 'slate-monolith', name: 'Slate Monolith', category: 'Monochrome', mode: 'dark', bgCanvas: '#0F131A', bgCard: '#1A202B', accentPrimary: '#E2E8F0', accentSecondary: '#64748B', accentOnPrimary: '#0F131A' },
  { id: 'ink-charcoal', name: 'Ink Charcoal Pro', category: 'Monochrome', mode: 'dark', bgCanvas: '#0A0B0D', bgCard: '#15171C', accentPrimary: '#A3E635', accentSecondary: '#E2E8F0', accentOnPrimary: '#0A0B0D' },
  { id: 'ash-silver', name: 'Ash Silver Minimal', category: 'Monochrome', mode: 'light', bgCanvas: '#F4F4F5', bgCard: '#FFFFFF', accentPrimary: '#27272A', accentSecondary: '#16A34A', accentOnPrimary: '#FFFFFF' },
  { id: 'matte-onyx', name: 'Matte Onyx Red', category: 'Monochrome', mode: 'dark', bgCanvas: '#0A0A0C', bgCard: '#151519', accentPrimary: '#EF4444', accentSecondary: '#E4E4E7', accentOnPrimary: '#FFFFFF' },
  { id: 'matte-cyan-dark', name: 'Matte Carbon Cyan', category: 'Monochrome', mode: 'dark', bgCanvas: '#080A0C', bgCard: '#12161A', accentPrimary: '#22D3EE', accentSecondary: '#E2E8F0', accentOnPrimary: '#080A0C' },
  { id: 'swiss-grid-light', name: 'Swiss Grid Monochrome', category: 'Monochrome', mode: 'light', bgCanvas: '#FAFAFA', bgCard: '#FFFFFF', accentPrimary: '#18181B', accentSecondary: '#2563EB', accentOnPrimary: '#FFFFFF' },
];

export const PREMIUM_THEMES: AppTheme[] = THEME_SEEDS.map(buildTheme);

export const THEME_CATEGORIES: Array<'All' | ThemeCategory> = [
  'All',
  'Pro Arenas',
  'Electric & Neon',
  'Royal & Luxury',
  'Light Editorial',
  'Championship',
  'Nature & Ocean',
  'Sunset & Ember',
  'Monochrome',
];

export function getThemeById(id?: string): AppTheme {
  return PREMIUM_THEMES.find((t) => t.id === id) || PREMIUM_THEMES[0];
}

export function applyThemeToDocument(theme: AppTheme) {
  const root = document.documentElement;
  if (theme.mode === 'dark') {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  root.style.setProperty('--bg-canvas', theme.bgCanvas);
  root.style.setProperty('--bg-card', theme.bgCard);
  root.style.setProperty('--bg-elevated', theme.bgElevated);
  root.style.setProperty('--accent-primary', theme.accentPrimary);
  root.style.setProperty('--accent-secondary', theme.accentSecondary);
  root.style.setProperty('--accent-on-primary', theme.accentOnPrimary);
  root.style.setProperty('--text-primary', theme.textPrimary);
  root.style.setProperty('--text-secondary', theme.textSecondary);
  root.style.setProperty('--theme-border', theme.borderColor);
  root.style.setProperty('--hero-from', theme.heroFrom);
  root.style.setProperty('--hero-via', theme.heroVia);
  root.style.setProperty('--hero-to', theme.heroTo);
  root.dataset.themeId = theme.id;
}
