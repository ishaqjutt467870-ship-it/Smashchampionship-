import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Palette,
  Image as ImageIcon,
  Search,
  Check,
  Shuffle,
  Upload,
  Sliders,
  Sun,
  Moon,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { WallpaperSettings } from '../types';
import {
  PREMIUM_THEMES,
  THEME_CATEGORIES,
  ThemeCategory,
  AppTheme,
  getThemeById,
} from '../utils/themes';
import { BUILTIN_WALLPAPERS } from '../utils/wallpapers';

interface ThemeWallpaperModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedThemeId: string;
  onSelectTheme: (themeId: string) => void;
  wallpaper: WallpaperSettings;
  onUpdateWallpaper: (next: WallpaperSettings) => void;
  initialSection?: 'themes' | 'wallpapers';
}

export const ThemeWallpaperModal: React.FC<ThemeWallpaperModalProps> = ({
  isOpen,
  onClose,
  selectedThemeId,
  onSelectTheme,
  wallpaper,
  onUpdateWallpaper,
  initialSection = 'themes',
}) => {
  const [section, setSection] = useState<'themes' | 'wallpapers'>(initialSection);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | ThemeCategory>('All');
  const [modeFilter, setModeFilter] = useState<'all' | 'dark' | 'light'>('all');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setSection(initialSection);
    }
  }, [isOpen, initialSection]);

  if (!isOpen) return null;

  const currentTheme: AppTheme = getThemeById(selectedThemeId);

  const filteredThemes = PREMIUM_THEMES.filter((t) => {
    if (selectedCategory !== 'All' && t.category !== selectedCategory) return false;
    if (modeFilter !== 'all' && t.mode !== modeFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.name.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.mode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleSurpriseMe = () => {
    const pool = filteredThemes.length > 1 ? filteredThemes : PREMIUM_THEMES;
    const candidates = pool.filter((t) => t.id !== selectedThemeId);
    const pick = candidates[Math.floor(Math.random() * candidates.length)] || PREMIUM_THEMES[0];
    onSelectTheme(pick.id);
  };

  const handleUploadWallpaper = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (PNG, JPG, WebP).');
      return;
    }

    setUploadError(null);
    setUploading(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1600;
        let w = img.width;
        let h = img.height;
        if (w > MAX_WIDTH) {
          h = Math.round((h * MAX_WIDTH) / w);
          w = MAX_WIDTH;
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
          const compressed = canvas.toDataURL('image/jpeg', 0.82);
          onUpdateWallpaper({
            ...wallpaper,
            id: 'custom',
            customUrl: compressed,
          });
        } else {
          onUpdateWallpaper({
            ...wallpaper,
            id: 'custom',
            customUrl: dataUrl,
          });
        }
        setUploading(false);
      };
      img.onerror = () => {
        setUploadError('Could not load that image. Please try another file.');
        setUploading(false);
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#07111F]/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white dark:bg-[#111E30] rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 my-4 overflow-hidden animate-fade-in flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 sm:px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-[#F4F7FB] dark:bg-[#07111F]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#B7F34A]/15 border border-[#B7F34A]/40 flex items-center justify-center text-[#172B4D] dark:text-[#B7F34A]">
              {section === 'themes' ? <Palette className="w-5 h-5" /> : <ImageIcon className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#172033] dark:text-white tracking-tight">
                Theme &amp; Wallpaper Studio
              </h2>
              <p className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                {PREMIUM_THEMES.length} curated themes &middot; Custom &amp; HD Arena wallpapers
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Section Segmented Control */}
            <div className="flex items-center gap-1 p-1 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setSection('themes')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  section === 'themes'
                    ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                    : 'text-[#64748B] dark:text-[#94A3B8]'
                }`}
              >
                <Palette className="w-3.5 h-3.5" />
                <span>{PREMIUM_THEMES.length} Themes</span>
              </button>
              <button
                type="button"
                onClick={() => setSection('wallpapers')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  section === 'wallpapers'
                    ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                    : 'text-[#64748B] dark:text-[#94A3B8]'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Wallpapers</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-[#64748B] hover:text-[#172033] dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close studio"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-5">
          {section === 'themes' ? (
            <>
              {/* Active Theme Spotlight + Quick Controls */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-[#F4F7FB] dark:bg-[#07111F] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-2xl border border-white/20 shadow-md flex items-center justify-center shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${currentTheme.bgCanvas} 0%, ${currentTheme.bgCard} 60%, ${currentTheme.accentPrimary} 100%)`,
                    }}
                  >
                    <Sparkles className="w-5 h-5" style={{ color: currentTheme.accentPrimary }} />
                  </div>
                  <div>
                    <div className="text-[10px] font-extrabold uppercase tracking-wider text-[#38BDF8]">
                      Active Theme &middot; {currentTheme.category}
                    </div>
                    <div className="text-sm font-black text-[#172033] dark:text-white">
                      {currentTheme.name}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleSurpriseMe}
                    className="px-3.5 py-2 rounded-xl bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] font-extrabold text-xs flex items-center gap-1.5 shadow cursor-pointer hover:opacity-95"
                  >
                    <Shuffle className="w-3.5 h-3.5" />
                    <span>Surprise Me</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectTheme('midnight-lime')}
                    className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#64748B] dark:text-[#94A3B8] hover:text-[#172033] dark:hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Default</span>
                  </button>
                </div>
              </div>

              {/* Search & Mode Filters */}
              <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={`Search ${PREMIUM_THEMES.length} themes (e.g. Emerald, Gold, Neon, Light, Pakistan)...`}
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#B7F34A]"
                  />
                </div>

                <div className="flex items-center gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 self-start sm:self-auto">
                  {(
                    [
                      { id: 'all', label: 'All', icon: null },
                      { id: 'dark', label: 'Dark', icon: <Moon className="w-3 h-3" /> },
                      { id: 'light', label: 'Light', icon: <Sun className="w-3 h-3" /> },
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setModeFilter(m.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                        modeFilter === m.id
                          ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                          : 'text-[#64748B] dark:text-[#94A3B8]'
                      }`}
                    >
                      {m.icon}
                      <span>{m.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Category Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {THEME_CATEGORIES.map((cat) => {
                  const count =
                    cat === 'All'
                      ? PREMIUM_THEMES.length
                      : PREMIUM_THEMES.filter((t) => t.category === cat).length;
                  const active = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer transition-all ${
                        active
                          ? 'bg-[#38BDF8] text-[#07111F] font-extrabold shadow-sm'
                          : 'bg-[#F4F7FB] dark:bg-[#07111F] text-[#64748B] dark:text-[#94A3B8] border border-slate-200 dark:border-slate-800 hover:border-[#38BDF8]/50'
                      }`}
                    >
                      {cat} ({count})
                    </button>
                  );
                })}
              </div>

              {/* Themes Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {filteredThemes.map((theme) => {
                  const isSelected = theme.id === selectedThemeId;
                  return (
                    <button
                      key={theme.id}
                      type="button"
                      onClick={() => onSelectTheme(theme.id)}
                      className={`group rounded-2xl p-3 text-left transition-all cursor-pointer border relative overflow-hidden ${
                        isSelected
                          ? 'ring-2 ring-[#B7F34A] border-[#B7F34A] shadow-lg scale-[1.01]'
                          : 'border-slate-200 dark:border-slate-800 hover:border-[#38BDF8]/60 hover:-translate-y-0.5'
                      }`}
                      style={{ backgroundColor: theme.bgCanvas }}
                    >
                      {/* Mini Card Preview */}
                      <div
                        className="rounded-xl p-2.5 border mb-2.5 space-y-2"
                        style={{
                          backgroundColor: theme.bgCard,
                          borderColor: theme.borderColor,
                        }}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span
                            className="text-[11px] font-black truncate"
                            style={{ color: theme.textPrimary }}
                          >
                            {theme.name}
                          </span>
                          {isSelected && (
                            <span
                              className="w-4 h-4 rounded-full flex items-center justify-center shrink-0"
                              style={{
                                backgroundColor: theme.accentPrimary,
                                color: theme.accentOnPrimary,
                              }}
                            >
                              <Check className="w-2.5 h-2.5 stroke-[3]" />
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5">
                          <span
                            className="h-2.5 flex-1 rounded-full"
                            style={{ backgroundColor: theme.accentPrimary }}
                          />
                          <span
                            className="h-2.5 w-8 rounded-full"
                            style={{ backgroundColor: theme.accentSecondary }}
                          />
                          <span
                            className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase"
                            style={{
                              backgroundColor: theme.accentPrimary,
                              color: theme.accentOnPrimary,
                            }}
                          >
                            21
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[10px] px-0.5">
                        <span style={{ color: theme.textSecondary }}>{theme.category}</span>
                        <span
                          className="font-bold uppercase"
                          style={{ color: theme.accentSecondary }}
                        >
                          {theme.mode}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {filteredThemes.length === 0 && (
                <div className="py-12 text-center text-xs text-[#64748B] dark:text-[#94A3B8]">
                  No themes matched "{searchQuery}". Clear your search to explore all {PREMIUM_THEMES.length} themes.
                </div>
              )}
            </>
          ) : (
            <>
              {/* Custom Upload + Backdrop Tuning */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-black uppercase tracking-wider text-[#172033] dark:text-white flex items-center gap-1.5">
                      <Upload className="w-4 h-4 text-[#B7F34A]" />
                      <span>Upload Any Custom Wallpaper</span>
                    </div>
                    {wallpaper.id === 'custom' && wallpaper.customUrl && (
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateWallpaper({ ...wallpaper, id: 'none', customUrl: undefined })
                        }
                        className="text-[11px] font-bold text-[#EF4444] hover:underline cursor-pointer"
                      >
                        Remove
                      </button>
                    )}
                  </div>

                  <p className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                    Choose any photo, club banner, or arena background from your device. Automatically optimized for offline speed.
                  </p>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleUploadWallpaper}
                    className="hidden"
                  />

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploading}
                      className="flex-1 py-2.5 px-4 rounded-xl bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploading ? 'Optimizing Image...' : 'Choose Wallpaper Image'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onUpdateWallpaper({ ...wallpaper, id: 'none' })}
                      className="px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#64748B] dark:text-[#94A3B8] cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>

                  {uploadError && (
                    <p className="text-[11px] font-semibold text-[#EF4444]">{uploadError}</p>
                  )}
                </div>

                {/* Backdrop Fine-Tuning Controls */}
                <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="text-xs font-black uppercase tracking-wider text-[#172033] dark:text-white flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-[#38BDF8]" />
                    <span>Backdrop Intensity &amp; Clarity</span>
                  </div>

                  <div className="space-y-2.5 text-xs">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-[#64748B] dark:text-[#94A3B8]">
                          Wallpaper Opacity
                        </span>
                        <span className="font-mono font-black text-[#172033] dark:text-[#B7F34A]">
                          {wallpaper.opacity}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={15}
                        max={100}
                        value={wallpaper.opacity}
                        onChange={(e) =>
                          onUpdateWallpaper({ ...wallpaper, opacity: Number(e.target.value) })
                        }
                        className="w-full accent-[#B7F34A] cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-[#64748B] dark:text-[#94A3B8]">
                          Backdrop Soft Blur
                        </span>
                        <span className="font-mono font-black text-[#172033] dark:text-[#38BDF8]">
                          {wallpaper.blur}px
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={16}
                        value={wallpaper.blur}
                        onChange={(e) =>
                          onUpdateWallpaper({ ...wallpaper, blur: Number(e.target.value) })
                        }
                        className="w-full accent-[#38BDF8] cursor-pointer"
                      />
                    </div>

                    <label className="flex items-center justify-between pt-1 cursor-pointer">
                      <span className="font-bold text-[#172033] dark:text-white">
                        Auto Contrast Scrim (Best Legibility)
                      </span>
                      <input
                        type="checkbox"
                        checked={wallpaper.scrim}
                        onChange={(e) =>
                          onUpdateWallpaper({ ...wallpaper, scrim: e.target.checked })
                        }
                        className="w-4 h-4 accent-[#B7F34A] cursor-pointer"
                      />
                    </label>
                  </div>
                </div>
              </div>

              {/* Best Built-in Wallpapers Gallery */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8]">
                    Best Sports &amp; Arena Wallpapers
                  </h3>
                  <span className="text-[11px] text-[#38BDF8] font-bold">
                    {BUILTIN_WALLPAPERS.length} Curated Backdrops
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {wallpaper.customUrl && (
                    <button
                      type="button"
                      onClick={() => onUpdateWallpaper({ ...wallpaper, id: 'custom' })}
                      className={`group rounded-2xl overflow-hidden border text-left transition-all cursor-pointer ${
                        wallpaper.id === 'custom'
                          ? 'ring-2 ring-[#B7F34A] border-[#B7F34A] shadow-lg'
                          : 'border-slate-200 dark:border-slate-800 hover:border-[#38BDF8]'
                      }`}
                    >
                      <div
                        className="h-28 w-full bg-cover bg-center relative"
                        style={{ backgroundImage: `url("${wallpaper.customUrl}")` }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                        <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-white">
                          <span className="text-xs font-black">Your Custom Upload</span>
                          {wallpaper.id === 'custom' && (
                            <Check className="w-4 h-4 text-[#B7F34A]" />
                          )}
                        </div>
                      </div>
                    </button>
                  )}

                  {BUILTIN_WALLPAPERS.map((wp) => {
                    const isSelected = wallpaper.id === wp.id;
                    return (
                      <button
                        key={wp.id}
                        type="button"
                        onClick={() => onUpdateWallpaper({ ...wallpaper, id: wp.id })}
                        className={`group rounded-2xl overflow-hidden border text-left transition-all cursor-pointer ${
                          isSelected
                            ? 'ring-2 ring-[#B7F34A] border-[#B7F34A] shadow-lg'
                            : 'border-slate-200 dark:border-slate-800 hover:border-[#38BDF8]'
                        }`}
                      >
                        <div
                          className="h-28 w-full bg-cover bg-center relative"
                          style={{
                            backgroundColor: currentTheme.bgCanvas,
                            backgroundImage:
                              wp.type === 'image' && wp.imageUrl
                                ? `url("${wp.imageUrl}")`
                                : wp.cssBackground ||
                                  `radial-gradient(circle at 30% 25%, ${currentTheme.accentPrimary}33, transparent 55%), radial-gradient(circle at 80% 75%, ${currentTheme.accentSecondary}33, transparent 55%)`,
                          }}
                        >
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                          <div className="absolute bottom-2.5 left-3 right-3 flex items-end justify-between gap-2 text-white">
                            <div className="min-w-0">
                              <div className="text-xs font-black truncate">{wp.name}</div>
                              <div className="text-[10px] text-slate-300 truncate">
                                {wp.subtitle}
                              </div>
                            </div>
                            {isSelected && (
                              <span className="w-5 h-5 rounded-full bg-[#B7F34A] text-[#07111F] flex items-center justify-center shrink-0">
                                <Check className="w-3 h-3 stroke-[3]" />
                              </span>
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
