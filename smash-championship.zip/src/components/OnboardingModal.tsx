import React, { useState } from 'react';
import { Trophy, Users, Radio, Sparkles, X, ChevronRight, ChevronLeft, ShieldCheck } from 'lucide-react';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const STEPS = [
  {
    title: 'Welcome to Hassan Badminton Tournament Manager',
    subtitle: 'Smash Championship · Black + Gold Elite Edition',
    description:
      'Built offline-first for club organizers, referees, and players. Manage unlimited tournaments, live BWF rally scoring, multi-court assignments, rankings, media posters, and finances cleanly in one app.',
    icon: Trophy,
  },
  {
    title: '1. Create & Configure Any Tournament Format',
    subtitle: 'Round Robin, Double RR, Swiss, League, Group Stage & Double Elimination',
    description:
      'Set Singles, Doubles, or Mixed Doubles divisions, adjust points per set (11 to 21), import players in bulk CSV, detect duplicate registrations, and apply smart or manual seeding.',
    icon: Users,
  },
  {
    title: '2. Official Live Court & TV Scoreboard Mode',
    subtitle: '21-Point BWF Rules · Rally Stats, Cards, Timeouts & Audit Trail',
    description:
      'Track doubles rotation, service faults, lets, medical timeouts, yellow/red cards, countdown clocks, and launch full-screen Arena TV displays.',
    icon: Radio,
  },
  {
    title: '3. Offline-First + Online World Extras',
    subtitle: 'Venue GPS Pinning, World Badminton News & Full Backups',
    description:
      'Everything works offline without losing data. When connected, browse live World Badminton News or pin tournament venues on Google Maps with one-tap directions.',
    icon: ShieldCheck,
  },
];

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ isOpen, onClose }) => {
  const [stepIndex, setStepIndex] = useState(0);

  if (!isOpen) return null;

  const current = STEPS[stepIndex];
  const Icon = current.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080808]/85 backdrop-blur-sm">
      <div className="bg-white dark:bg-[#141414] w-full max-w-lg rounded-3xl border border-[#D4AF37]/40 shadow-2xl overflow-hidden animate-fade-in">
        <div className="p-6 bg-[#080808] text-white flex items-center justify-between border-b border-[#D4AF37]/25">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#FFD700]">Interactive Quick Tour</h3>
              <p className="text-[11px] text-[#A0A0A0]">
                Step {stepIndex + 1} of {STEPS.length}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-[#A0A0A0] hover:text-white hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-5 text-center">
          <div className="w-16 h-16 rounded-2xl mx-auto bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#FFD700]">
            <Icon className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h4 className="text-xl font-black text-[#172033] dark:text-white">{current.title}</h4>
            <p className="text-xs font-bold text-[#D4AF37]">{current.subtitle}</p>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] leading-relaxed pt-1">
              {current.description}
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 pt-2">
            {STEPS.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setStepIndex(i)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  i === stepIndex ? 'w-8 bg-[#FFD700]' : 'w-2 bg-slate-300 dark:bg-white/20'
                }`}
                aria-label={`Step ${i + 1}`}
              />
            ))}
          </div>
        </div>

        <div className="p-4 bg-[#F4F7FB] dark:bg-[#080808] border-t border-slate-200 dark:border-[#D4AF37]/20 flex items-center justify-between">
          <button
            type="button"
            disabled={stepIndex === 0}
            onClick={() => setStepIndex((s) => Math.max(0, s - 1))}
            className="px-4 py-2 rounded-xl border border-slate-300 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white disabled:opacity-40 flex items-center gap-1 cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          {stepIndex < STEPS.length - 1 ? (
            <button
              type="button"
              onClick={() => setStepIndex((s) => s + 1)}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center gap-1 cursor-pointer shadow-md"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs cursor-pointer shadow-md"
            >
              Start Managing
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
