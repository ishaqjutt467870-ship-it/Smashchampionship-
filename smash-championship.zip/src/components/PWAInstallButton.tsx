import React, { useEffect, useState } from 'react';
import {
  Download,
  Smartphone,
  X,
  CheckCircle2,
  ShieldCheck,
  FileCode2,
  Link2,
  Image as ImageIcon,
  Type,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [manifestVerified, setManifestVerified] = useState(true);

  const isHttpsOrLocal =
    typeof window !== 'undefined' &&
    (window.isSecureContext ||
      window.location.protocol === 'https:' ||
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1');

  useEffect(() => {
    if (!showGuide || typeof document === 'undefined') return;
    const manifestLink = document.querySelector('link[rel="manifest"]');
    setManifestVerified(Boolean(manifestLink?.getAttribute('href')));
  }, [showGuide]);

  if (isInstalled) {
    return null;
  }

  const pwaChecks = [
    {
      label: 'HTTPS',
      value: isHttpsOrLocal ? 'Secure Context Active' : 'Requires HTTPS',
      ok: isHttpsOrLocal,
      icon: <ShieldCheck className="w-3.5 h-3.5 text-[#22C55E]" />,
    },
    {
      label: 'Web Manifest',
      value: manifestVerified ? '/manifest.webmanifest (standalone)' : 'Configured via VitePWA',
      ok: true,
      icon: <FileCode2 className="w-3.5 h-3.5 text-[#00D4FF]" />,
    },
    {
      label: 'App Name',
      value: 'Smash Championship (Smash Pro)',
      ok: true,
      icon: <Type className="w-3.5 h-3.5 text-[#B7F500]" />,
    },
    {
      label: 'App Icon & Logo',
      value: '192×192, 512×512, Maskable & SVG',
      ok: true,
      icon: <ImageIcon className="w-3.5 h-3.5 text-amber-400" />,
    },
    {
      label: 'Start URL',
      value: '/ (scope: /)',
      ok: true,
      icon: <Link2 className="w-3.5 h-3.5 text-[#00D4FF]" />,
    },
  ];

  return (
    <>
      {isInstallable ? (
        <button
          onClick={install}
          className={`flex items-center gap-1.5 px-3 py-1.5 bg-[#00D4FF] hover:bg-[#38BDF8] text-[#0B1220] font-extrabold text-xs rounded-xl shadow-sm transition-all whitespace-nowrap shrink-0 cursor-pointer ${className}`}
          title="Install Smash Championship App on your device"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Install App</span>
        </button>
      ) : (
        <button
          onClick={() => setShowGuide(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 bg-[#151F30] hover:bg-slate-800 text-[#B7F500] border border-[#B7F500]/40 text-xs font-bold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer ${className}`}
          title="PWA Setup, App Info & Install Guide"
        >
          <Smartphone className="w-3.5 h-3.5 text-[#00D4FF]" />
          <span>Install App</span>
        </button>
      )}

      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#07111F]/80 backdrop-blur-sm">
          <div className="bg-white dark:bg-[#111E30] w-full max-w-md rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src="/logo.png"
                  alt="Smash Championship App Logo"
                  referrerPolicy="no-referrer"
                  className="w-11 h-11 rounded-2xl object-cover border border-[#B7F500]/50 bg-[#0B1220]"
                />
                <div>
                  <h3 className="text-base font-black text-[#172033] dark:text-white leading-tight">
                    Smash Championship
                  </h3>
                  <p className="text-[11px] font-bold text-[#00D4FF]">
                    PWA Ready &middot; Midnight Pro Edition
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowGuide(false)}
                className="p-1.5 text-[#64748B] hover:text-[#172033] dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* PWA Checklist Grid */}
            <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-[10px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8]">
                PWA Manifest &amp; Security Specs
              </div>
              <div className="space-y-1.5">
                {pwaChecks.map((item) => (
                  <div
                    key={item.label}
                    className="flex items-center justify-between gap-2 text-xs py-1 border-b last:border-b-0 border-slate-200/70 dark:border-slate-800/80"
                  >
                    <div className="flex items-center gap-2 font-bold text-[#172033] dark:text-white">
                      {item.icon}
                      <span>{item.label}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono text-[11px] text-[#64748B] dark:text-slate-300">
                      <span>{item.value}</span>
                      <CheckCircle2
                        className={`w-3.5 h-3.5 shrink-0 ${
                          item.ok ? 'text-[#22C55E]' : 'text-amber-400'
                        }`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2 text-xs text-[#172033] dark:text-slate-200">
              <div className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800">
                <strong className="block text-[#172033] dark:text-white mb-1">
                  Android / Desktop (Chrome, Edge):
                </strong>
                <span>
                  Tap browser menu (<strong>⋮</strong>) or address bar install icon, then select{' '}
                  <strong className="text-[#8BCB35] dark:text-[#B7F500]">Install App</strong>.
                </span>
              </div>

              <div className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800">
                <strong className="block text-[#172033] dark:text-white mb-1">
                  iPhone / iPad (Safari):
                </strong>
                <span>
                  Tap <strong>Share</strong>, then tap{' '}
                  <strong className="text-[#00D4FF]">Add to Home Screen</strong>.
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowGuide(false)}
              className="w-full py-2.5 bg-[#172B4D] dark:bg-[#B7F500] text-white dark:text-[#0B1220] font-black text-xs rounded-xl hover:opacity-95 transition-opacity cursor-pointer"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
