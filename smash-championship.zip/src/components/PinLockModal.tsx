import React, { useState } from 'react';
import { Lock, ShieldCheck, X, Delete, AlertCircle, Fingerprint } from 'lucide-react';
import { verifyBiometricCredential } from '../utils/webauthn';

interface PinLockModalProps {
  mode: 'unlock' | 'setup';
  isOpen: boolean;
  expectedPin?: string | null;
  biometricCredentialId?: string | null;
  onUnlock?: () => void;
  onBiometricUnlock?: () => void;
  onSavePin?: (newPin: string | null) => void;
  onClose?: () => void;
}

export const PinLockModal: React.FC<PinLockModalProps> = ({
  mode,
  isOpen,
  expectedPin,
  biometricCredentialId,
  onUnlock,
  onBiometricUnlock,
  onSavePin,
  onClose,
}) => {
  const [digits, setDigits] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [checkingBio, setCheckingBio] = useState(false);

  if (!isOpen) return null;

  const handleDigit = (d: string) => {
    if (digits.length >= 4) return;
    const next = digits + d;
    setDigits(next);
    setError(null);

    if (next.length === 4) {
      if (mode === 'unlock') {
        if (next === expectedPin) {
          setDigits('');
          onUnlock?.();
        } else {
          setError('Incorrect PIN. Please try again.');
          setTimeout(() => setDigits(''), 350);
        }
      } else if (mode === 'setup') {
        onSavePin?.(next);
        setDigits('');
        onClose?.();
      }
    }
  };

  const handleBackspace = () => {
    setDigits((prev) => prev.slice(0, -1));
    setError(null);
  };

  const handleBiometricCheck = async () => {
    if (!biometricCredentialId) return;
    setCheckingBio(true);
    setError(null);
    const res = await verifyBiometricCredential(biometricCredentialId);
    setCheckingBio(false);
    if (res.ok) {
      setDigits('');
      if (onBiometricUnlock) onBiometricUnlock();
      else onUnlock?.();
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fade-in">
      <div className="w-full max-w-xs bg-[#141414] border border-[#D4AF37]/35 rounded-3xl p-6 text-center text-white shadow-2xl relative">
        {mode === 'setup' && onClose && (
          <button
            type="button"
            onClick={() => {
              setDigits('');
              onClose();
            }}
            className="absolute top-4 right-4 p-1.5 text-[#A0A0A0] hover:text-white rounded-lg hover:bg-white/10 cursor-pointer"
            aria-label="Close PIN setup"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        <div className="w-14 h-14 mx-auto rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/45 flex items-center justify-center text-[#FFD700] mb-3">
          {mode === 'unlock' ? <Lock className="w-6 h-6" /> : <ShieldCheck className="w-6 h-6" />}
        </div>

        <h3 className="text-lg font-black tracking-tight">
          {mode === 'unlock' ? 'Security Lock' : 'Set 4-Digit Security PIN'}
        </h3>
        <p className="text-xs text-[#A0A0A0] mt-1">
          {mode === 'unlock'
            ? 'Enter your 4-digit PIN or use biometrics to unlock'
            : 'Protect tournament edits, deletions, and live scoring controls'}
        </p>

        {/* PIN Dots */}
        <div className="flex items-center justify-center gap-3 my-6">
          {[0, 1, 2, 3].map((idx) => (
            <div
              key={idx}
              className={`w-4 h-4 rounded-full border-2 transition-all ${
                idx < digits.length
                  ? 'bg-[#FFD700] border-[#FFD700] scale-110 shadow-[0_0_12px_rgba(255,215,0,0.6)]'
                  : 'border-white/25 bg-transparent'
              }`}
            />
          ))}
        </div>

        {error && (
          <div className="mb-4 px-3 py-2 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/30 text-[#EF4444] text-xs font-semibold flex items-center justify-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Touch Keypad */}
        <div className="grid grid-cols-3 gap-2.5 max-w-[220px] mx-auto">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              type="button"
              onClick={() => handleDigit(num)}
              className="h-12 rounded-2xl bg-[#080808] hover:bg-white/10 active:scale-95 border border-white/10 text-lg font-black text-white transition-all cursor-pointer"
            >
              {num}
            </button>
          ))}
          <div />
          <button
            type="button"
            onClick={() => handleDigit('0')}
            className="h-12 rounded-2xl bg-[#080808] hover:bg-white/10 active:scale-95 border border-white/10 text-lg font-black text-white transition-all cursor-pointer"
          >
            0
          </button>
          <button
            type="button"
            onClick={handleBackspace}
            className="h-12 rounded-2xl bg-[#080808] hover:bg-white/10 active:scale-95 border border-white/10 flex items-center justify-center text-[#A0A0A0] hover:text-white transition-all cursor-pointer"
            aria-label="Delete digit"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {mode === 'unlock' && biometricCredentialId && (
          <button
            type="button"
            disabled={checkingBio}
            onClick={handleBiometricCheck}
            className="mt-4 w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-xs font-black flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Fingerprint className="w-4 h-4" />
            <span>{checkingBio ? 'Verifying Biometrics...' : 'Unlock with Biometrics'}</span>
          </button>
        )}

        {mode === 'setup' && expectedPin && onSavePin && (
          <button
            type="button"
            onClick={() => {
              onSavePin(null);
              setDigits('');
              onClose?.();
            }}
            className="mt-5 text-xs font-bold text-[#EF4444] hover:underline cursor-pointer"
          >
            Remove Existing PIN Lock
          </button>
        )}
      </div>
    </div>
  );
};
