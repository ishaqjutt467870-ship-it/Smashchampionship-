import React, { useState, useEffect } from 'react';
import {
  Tv,
  Plus,
  Trash2,
  Zap,
  AlertCircle,
  X,
  Clock,
  Megaphone,
  UserCheck,
  Edit3,
  Check,
  ArrowRightLeft,
  History,
  Trophy,
} from 'lucide-react';
import {
  TournamentMatch,
  MatchScore,
  CourtRecord,
  CourtMatchHistoryEntry,
} from '../types';
import { DEFAULT_COURTS } from '../utils/tournament';
import { speakUmpireCall, playAlertTone } from '../utils/audio';

interface CourtManagerProps {
  players: string[];
  fixtures: TournamentMatch[];
  results: Record<string, number>;
  scores: Record<string, MatchScore>;
  playerPhotos?: Record<number, string>;
  referees?: string[];
  onUpdateReferees?: (referees: string[]) => void;
  courts?: CourtRecord[];
  onUpdateCourts?: (courts: CourtRecord[]) => void;
  courtHistory?: CourtMatchHistoryEntry[];
  onLaunchLiveScorer: (matchId: string, courtNumber: number) => void;
}

export const CourtManager: React.FC<CourtManagerProps> = ({
  players,
  fixtures,
  results,
  referees = ['Hassan (Chief Referee)', 'Bilal', 'Tariq'],
  onUpdateReferees,
  courts: externalCourts,
  onUpdateCourts,
  courtHistory = [],
  onLaunchLiveScorer,
}) => {
  const [internalCourts, setInternalCourts] = useState<CourtRecord[]>(() => {
    if (externalCourts && externalCourts.length > 0) return externalCourts;
    try {
      const saved = localStorage.getItem('smash-courts-v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return DEFAULT_COURTS.map((c, i) => ({
      ...c,
      assignedMatchId: i === 0 ? fixtures[0]?.id || null : i === 1 ? fixtures[1]?.id || null : null,
      status: i === 0 && fixtures[0] ? 'in_progress' : i === 1 && fixtures[1] ? 'warmup' : 'available',
    }));
  });

  const courts = externalCourts && externalCourts.length > 0 ? externalCourts : internalCourts;
  const setCourts = (next: CourtRecord[]) => {
    if (onUpdateCourts) {
      onUpdateCourts(next);
    } else {
      setInternalCourts(next);
    }
  };

  useEffect(() => {
    try {
      localStorage.setItem('smash-courts-v1', JSON.stringify(courts));
    } catch {
      // ignore
    }
  }, [courts]);

  const [courtWarning, setCourtWarning] = useState<string | null>(null);
  const [newCourtName, setNewCourtName] = useState('');
  const [newRefereeName, setNewRefereeName] = useState('');
  const [lastAnnouncement, setLastAnnouncement] = useState<string | null>(null);
  const [selectedMatchToAssign, setSelectedMatchToAssign] = useState<Record<number, string>>({});
  const [transferTarget, setTransferTarget] = useState<Record<number, number>>({});
  const [editingCourtId, setEditingCourtId] = useState<number | null>(null);
  const [editingCourtName, setEditingCourtName] = useState('');
  const [historyFilterCourtId, setHistoryFilterCourtId] = useState<number | 'all'>('all');

  const playableFixtures = fixtures.filter((f) => !f.isBye && f.playerBIndex >= 0);
  const pendingFixtures = playableFixtures.filter((f) => results[f.id] === undefined);

  const handleAddCourt = () => {
    if (!newCourtName.trim()) return;
    const nextId = courts.length > 0 ? Math.max(...courts.map((c) => c.id)) + 1 : 1;
    setCourts([
      ...courts,
      {
        id: nextId,
        name: newCourtName.trim(),
        assignedMatchId: null,
        status: 'available',
      },
    ]);
    setNewCourtName('');
    setCourtWarning(null);
  };

  const handleRemoveCourt = (id: number) => {
    if (courts.length <= 1) {
      setCourtWarning('Must have at least one active court.');
      return;
    }
    setCourtWarning(null);
    setCourts(courts.filter((c) => c.id !== id));
  };

  const handleSaveCourtRename = (id: number) => {
    if (!editingCourtName.trim()) {
      setEditingCourtId(null);
      return;
    }
    setCourts(
      courts.map((c) => (c.id === id ? { ...c, name: editingCourtName.trim() } : c))
    );
    setEditingCourtId(null);
    setEditingCourtName('');
  };

  const handleUpdateStatus = (
    courtId: number,
    newStatus: 'available' | 'warmup' | 'in_progress' | 'maintenance'
  ) => {
    setCourts(
      courts.map((c) => {
        if (c.id === courtId) {
          return {
            ...c,
            status: newStatus,
            ...(newStatus === 'available' ? { assignedMatchId: null } : {}),
          };
        }
        return c;
      })
    );
  };

  const handleAssignMatch = (courtId: number, matchId: string) => {
    setCourts(
      courts.map((c) => {
        if (c.id === courtId) {
          return {
            ...c,
            assignedMatchId: matchId,
            status: 'in_progress',
          };
        }
        return c;
      })
    );
  };

  const handleTransferMatch = (sourceCourtId: number, targetCourtId: number) => {
    const src = courts.find((c) => c.id === sourceCourtId);
    const dst = courts.find((c) => c.id === targetCourtId);
    if (!src || !dst || !src.assignedMatchId || sourceCourtId === targetCourtId) return;
    if (dst.assignedMatchId) {
      setCourtWarning(
        `${dst.name} already has a match assigned. Clear it before transferring.`
      );
      return;
    }
    const matchToMove = src.assignedMatchId;
    const refToMove = src.referee;
    setCourtWarning(null);
    setCourts(
      courts.map((c) => {
        if (c.id === sourceCourtId) {
          return { ...c, assignedMatchId: null, status: 'available', referee: undefined };
        }
        if (c.id === targetCourtId) {
          return {
            ...c,
            assignedMatchId: matchToMove,
            status: 'in_progress',
            referee: refToMove || c.referee,
          };
        }
        return c;
      })
    );
  };

  const handleUnassignMatch = (courtId: number) => {
    setCourts(
      courts.map((c) => {
        if (c.id === courtId) {
          return {
            ...c,
            assignedMatchId: null,
            status: 'available',
          };
        }
        return c;
      })
    );
  };

  const handleAssignReferee = (courtId: number, referee: string) => {
    setCourts(
      courts.map((c) => (c.id === courtId ? { ...c, referee: referee || undefined } : c))
    );
  };

  const handleCallCourtMatch = (court: CourtRecord, pA: string, pB: string) => {
    playAlertTone();
    const msg = `Attention players. ${pA} versus ${pB}, please report to ${court.name}.${
      court.referee ? ` Umpire: ${court.referee}.` : ''
    }`;
    speakUmpireCall(msg, true);
    setLastAnnouncement(msg);
  };

  const handleAddReferee = () => {
    if (!onUpdateReferees || !newRefereeName.trim()) return;
    if (!referees.includes(newRefereeName.trim())) {
      onUpdateReferees([...referees, newRefereeName.trim()]);
    }
    setNewRefereeName('');
  };

  const filteredHistory =
    historyFilterCourtId === 'all'
      ? courtHistory
      : courtHistory.filter((h) => h.courtId === historyFilterCourtId);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-[#141414] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Tv className="w-5 h-5 text-[#D4AF37]" />
            <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight">
              Multiple Courts Management
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-1">
            Rename courts, assign fixtures, transfer live matches between courts, and review court history.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Court Name (e.g. Center Court)"
            value={newCourtName}
            onChange={(e) => setNewCourtName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddCourt()}
            className="px-3 py-2 bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 rounded-xl text-xs sm:text-sm text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
          />
          <button
            onClick={handleAddCourt}
            className="px-4 py-2 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Add Court</span>
          </button>
        </div>
      </div>

      {onUpdateReferees && (
        <div className="bg-white dark:bg-[#141414] rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-white/10 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-black uppercase tracking-wider text-[#172033] dark:text-white flex items-center gap-1.5 mr-1">
              <UserCheck className="w-4 h-4 text-[#D4AF37]" />
              <span>Referees &amp; Umpires:</span>
            </span>
            {referees.map((ref) => (
              <span
                key={ref}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-xs font-bold text-[#172033] dark:text-white"
              >
                <span>{ref}</span>
                {referees.length > 1 && (
                  <button
                    type="button"
                    onClick={() => onUpdateReferees(referees.filter((r) => r !== ref))}
                    className="text-[#64748B] hover:text-[#EF4444] cursor-pointer"
                    aria-label={`Remove referee ${ref}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <input
              type="text"
              value={newRefereeName}
              onChange={(e) => setNewRefereeName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddReferee()}
              placeholder="Add referee..."
              className="px-3 py-1.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white focus:outline-none"
            />
            <button
              type="button"
              onClick={handleAddReferee}
              className="px-3 py-1.5 rounded-xl bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] text-xs font-extrabold cursor-pointer"
            >
              Add
            </button>
          </div>
        </div>
      )}

      {lastAnnouncement && (
        <div className="p-3 bg-[#D4AF37]/15 border border-[#D4AF37]/40 rounded-2xl flex items-center justify-between text-xs text-[#172033] dark:text-[#FFD700] font-bold">
          <div className="flex items-center gap-2">
            <Megaphone className="w-4 h-4 shrink-0" />
            <span>PA Call: {lastAnnouncement}</span>
          </div>
          <button
            type="button"
            onClick={() => setLastAnnouncement(null)}
            className="p-1 hover:bg-white/10 rounded-lg cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {courtWarning && (
        <div className="p-3 bg-[#EF4444]/10 border border-[#EF4444]/30 rounded-2xl flex items-center justify-between text-xs text-[#EF4444] font-semibold">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{courtWarning}</span>
          </div>
          <button
            type="button"
            onClick={() => setCourtWarning(null)}
            className="p-1 hover:bg-[#EF4444]/15 rounded-lg cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Courts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {courts.map((court) => {
          const assignedMatch = court.assignedMatchId
            ? playableFixtures.find((f) => f.id === court.assignedMatchId)
            : null;
          const playerA = assignedMatch ? players[assignedMatch.playerAIndex] : null;
          const playerB = assignedMatch ? players[assignedMatch.playerBIndex] : null;
          const isFinished = assignedMatch && results[assignedMatch.id] !== undefined;
          const otherCourts = courts.filter((c) => c.id !== court.id);

          return (
            <div
              key={court.id}
              className={`rounded-3xl border transition-all p-5 flex flex-col justify-between space-y-4 shadow-sm ${
                court.status === 'in_progress'
                  ? 'bg-white dark:bg-[#141414] border-[#D4AF37] ring-1 ring-[#D4AF37]/25'
                  : court.status === 'warmup'
                  ? 'bg-white dark:bg-[#141414] border-amber-400/50'
                  : court.status === 'maintenance'
                  ? 'bg-white dark:bg-[#141414] border-[#EF4444]/40 opacity-80'
                  : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10'
              }`}
            >
              {/* Card Header with Inline Rename */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  <span className="w-7 h-7 rounded-lg bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] font-black text-xs flex items-center justify-center shrink-0">
                    C{court.id}
                  </span>
                  {editingCourtId === court.id ? (
                    <div className="flex items-center gap-1 flex-1 min-w-0">
                      <input
                        type="text"
                        value={editingCourtName}
                        onChange={(e) => setEditingCourtName(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSaveCourtRename(court.id)}
                        className="w-full px-2 py-1 text-xs rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37] text-[#172033] dark:text-white focus:outline-none"
                        autoFocus
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveCourtRename(court.id)}
                        className="p-1 text-[#22C55E] cursor-pointer shrink-0"
                        title="Save Name"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="font-black text-sm text-[#172033] dark:text-white truncate">
                        {court.name}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingCourtId(court.id);
                          setEditingCourtName(court.name);
                        }}
                        className="text-[#64748B] hover:text-[#D4AF37] cursor-pointer shrink-0"
                        title="Rename Court"
                      >
                        <Edit3 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <span
                    className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      court.status === 'in_progress'
                        ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808]'
                        : court.status === 'warmup'
                        ? 'bg-amber-400 text-[#080808]'
                        : court.status === 'maintenance'
                        ? 'bg-[#EF4444] text-white'
                        : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0]'
                    }`}
                  >
                    {court.status === 'in_progress'
                      ? 'Live'
                      : court.status === 'warmup'
                      ? 'Warmup'
                      : court.status === 'maintenance'
                      ? 'Service'
                      : 'Open'}
                  </span>

                  <button
                    onClick={() => handleRemoveCourt(court.id)}
                    className="text-[#64748B] hover:text-[#EF4444] p-1 rounded transition-colors cursor-pointer"
                    title="Remove Court"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Court Visual Floor */}
              <div className="relative h-28 rounded-2xl bg-[#0D2B22] border border-[#D4AF37]/40 overflow-hidden flex items-center justify-center p-3 text-white">
                <div className="absolute inset-2 border border-white/40 rounded pointer-events-none" />
                <div className="absolute inset-y-2 left-1/2 -translate-x-1/2 border-l-2 border-white/60 pointer-events-none" />
                <div className="absolute inset-x-2 top-1/2 -translate-y-1/2 border-t border-white/25 pointer-events-none" />

                {assignedMatch && playerA && playerB ? (
                  <div className="relative z-10 w-full flex items-center justify-between text-xs font-bold px-2">
                    <div className="text-left max-w-[42%] truncate">
                      <div className="truncate text-white">{playerA}</div>
                      <div className="text-[10px] text-[#FFD700] font-mono">Side A</div>
                    </div>
                    <div className="text-[#D4AF37] text-sm font-black px-1">VS</div>
                    <div className="text-right max-w-[42%] truncate">
                      <div className="truncate text-white">{playerB}</div>
                      <div className="text-[10px] text-[#A0A0A0] font-mono">Side B</div>
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-[#A0A0A0] font-medium text-center">
                    {court.status === 'maintenance' ? 'Under Maintenance' : 'Ready for Next Match'}
                  </div>
                )}
              </div>

              {/* Action Controls */}
              {assignedMatch && playerA && playerB ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-[#A0A0A0]">
                    <span>Match #{assignedMatch.roundNumber || assignedMatch.id}</span>
                    {isFinished && (
                      <span className="text-[#22C55E] font-extrabold">Completed</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <select
                      value={court.referee || ''}
                      onChange={(e) => handleAssignReferee(court.id, e.target.value)}
                      className="flex-1 px-2 py-1.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[11px] font-bold text-[#172033] dark:text-white focus:outline-none"
                    >
                      <option value="">Assign Umpire...</option>
                      {referees.map((r) => (
                        <option key={r} value={r}>
                          Umpire: {r}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => handleCallCourtMatch(court, playerA, playerB)}
                      className="px-2.5 py-1.5 rounded-xl bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] text-[11px] font-extrabold flex items-center gap-1 cursor-pointer shrink-0"
                      title="Announce match call over PA / Speaker"
                    >
                      <Megaphone className="w-3 h-3" />
                      <span>Call</span>
                    </button>
                  </div>

                  {otherCourts.length > 0 && (
                    <div className="flex items-center gap-1.5">
                      <select
                        value={transferTarget[court.id] || ''}
                        onChange={(e) =>
                          setTransferTarget({
                            ...transferTarget,
                            [court.id]: Number(e.target.value),
                          })
                        }
                        className="flex-1 px-2 py-1.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[11px] font-semibold text-[#172033] dark:text-white focus:outline-none"
                      >
                        <option value="">Transfer to court...</option>
                        {otherCourts.map((oc) => (
                          <option key={oc.id} value={oc.id} disabled={Boolean(oc.assignedMatchId)}>
                            {oc.name} {oc.assignedMatchId ? '(Busy)' : '(Open)'}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        disabled={!transferTarget[court.id]}
                        onClick={() => {
                          const targetId = transferTarget[court.id];
                          if (targetId) handleTransferMatch(court.id, targetId);
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-[#172B4D] dark:bg-white/15 disabled:opacity-35 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer shrink-0"
                        title="Transfer match to selected court"
                      >
                        <ArrowRightLeft className="w-3 h-3 text-[#D4AF37]" />
                        <span>Move</span>
                      </button>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onLaunchLiveScorer(assignedMatch.id, court.id)}
                      className="py-2 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-sm cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      <span>Live Score</span>
                    </button>

                    <button
                      onClick={() => handleUnassignMatch(court.id)}
                      className="py-2 bg-[#F4F7FB] hover:bg-slate-200 dark:bg-[#080808] dark:hover:bg-white/10 text-[#172033] dark:text-[#A0A0A0] font-bold text-xs rounded-xl transition-colors cursor-pointer"
                    >
                      Clear Court
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <select
                    value={selectedMatchToAssign[court.id] || ''}
                    onChange={(e) =>
                      setSelectedMatchToAssign({
                        ...selectedMatchToAssign,
                        [court.id]: e.target.value,
                      })
                    }
                    className="w-full px-2.5 py-1.5 bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 rounded-xl text-xs text-[#172033] dark:text-white focus:outline-none"
                  >
                    <option value="">-- Assign Queue Match --</option>
                    {pendingFixtures.map((f, i) => (
                      <option key={f.id} value={f.id}>
                        #{f.roundNumber || i + 1}: {players[f.playerAIndex]} vs {players[f.playerBIndex]}
                      </option>
                    ))}
                  </select>

                  <button
                    disabled={!selectedMatchToAssign[court.id]}
                    onClick={() => {
                      const mId = selectedMatchToAssign[court.id];
                      if (mId) handleAssignMatch(court.id, mId);
                    }}
                    className="px-3 py-1.5 bg-[#172B4D] dark:bg-[#D4AF37] disabled:opacity-40 text-white dark:text-[#080808] rounded-xl text-xs font-extrabold transition-colors cursor-pointer shrink-0"
                  >
                    Assign
                  </button>
                </div>
              )}

              {/* Status Switcher */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-white/10 text-[10px]">
                <button
                  onClick={() => handleUpdateStatus(court.id, 'available')}
                  className={`px-2 py-0.5 rounded font-bold cursor-pointer ${
                    court.status === 'available'
                      ? 'text-[#22C55E]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  Open
                </button>
                <button
                  onClick={() => handleUpdateStatus(court.id, 'warmup')}
                  className={`px-2 py-0.5 rounded font-bold cursor-pointer ${
                    court.status === 'warmup'
                      ? 'text-amber-500'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  Warmup
                </button>
                <button
                  onClick={() => handleUpdateStatus(court.id, 'in_progress')}
                  className={`px-2 py-0.5 rounded font-bold cursor-pointer ${
                    court.status === 'in_progress'
                      ? 'text-[#D4AF37]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  In Play
                </button>
                <button
                  onClick={() => handleUpdateStatus(court.id, 'maintenance')}
                  className={`px-2 py-0.5 rounded font-bold cursor-pointer ${
                    court.status === 'maintenance'
                      ? 'text-[#EF4444]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  Service
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Upcoming Match Queue Bar */}
      <div className="bg-white dark:bg-[#141414] rounded-3xl p-5 border border-slate-200 dark:border-white/10 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-black text-[#172033] dark:text-white">
            <Clock className="w-4 h-4 text-[#D4AF37]" />
            <span>Upcoming Match Queue ({pendingFixtures.length})</span>
          </div>
        </div>
        {pendingFixtures.length === 0 ? (
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
            All scheduled playable fixtures are finished!
          </p>
        ) : (
          <div className="flex overflow-x-auto gap-2.5 pb-1">
            {pendingFixtures.slice(0, 8).map((f, idx) => (
              <div
                key={f.id}
                className="min-w-[210px] p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 flex items-center justify-between gap-2 shrink-0"
              >
                <div className="min-w-0">
                  <div className="text-[10px] font-mono text-[#D4AF37]">
                    Match #{f.roundNumber || idx + 1}
                  </div>
                  <div className="text-xs font-bold text-[#172033] dark:text-white truncate">
                    {players[f.playerAIndex]} vs {players[f.playerBIndex]}
                  </div>
                </div>
                <button
                  onClick={() => onLaunchLiveScorer(f.id, courts[0]?.id || 1)}
                  className="p-1.5 rounded-lg bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] shrink-0 cursor-pointer"
                  title="Score Match Live"
                >
                  <Zap className="w-3.5 h-3.5 fill-current" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Court-Wise Match History */}
      <div className="bg-white dark:bg-[#141414] rounded-3xl p-5 border border-slate-200 dark:border-white/10 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm font-black text-[#172033] dark:text-white">
            <History className="w-4 h-4 text-[#D4AF37]" />
            <span>Court-Wise Match History ({filteredHistory.length})</span>
          </div>
          <select
            value={historyFilterCourtId}
            onChange={(e) =>
              setHistoryFilterCourtId(e.target.value === 'all' ? 'all' : Number(e.target.value))
            }
            className="text-xs px-3 py-1.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
          >
            <option value="all">All Courts</option>
            {courts.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        {filteredHistory.length === 0 ? (
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
            Completed matches scored on courts will appear here with court assignments and timestamps.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {filteredHistory.slice(0, 12).map((entry) => (
              <div
                key={entry.id}
                className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-white/10 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-[#9A7B1C] dark:text-[#FFD700]">
                    <span>{entry.courtName}</span>
                    <span className="text-[#64748B]">·</span>
                    <span className="text-[#64748B] dark:text-[#A0A0A0]">
                      {new Date(entry.completedAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div className="font-bold text-[#172033] dark:text-white truncate mt-0.5">
                    {entry.playerA} vs {entry.playerB}
                  </div>
                  <div className="text-[11px] text-[#22C55E] font-bold flex items-center gap-1 mt-0.5">
                    <Trophy className="w-3 h-3" />
                    <span>Winner: {entry.winner}</span>
                  </div>
                </div>
                <span className="font-mono font-black text-xs px-2.5 py-1 rounded-lg bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10 text-[#172033] dark:text-[#FFD700] shrink-0">
                  {entry.score || 'Win'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
