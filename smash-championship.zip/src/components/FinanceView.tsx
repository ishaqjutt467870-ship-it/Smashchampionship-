import React, { useMemo, useState } from 'react';
import {
  Wallet,
  Plus,
  Download,
  CheckCircle2,
  Clock,
  Trash2,
  Receipt,
  TrendingUp,
  TrendingDown,
  Award,
} from 'lucide-react';
import { FinancialRecord, TournamentState } from '../types';
import { downloadFinancialReceiptPNG, downloadFinancialReportCSV } from '../utils/exports';

interface FinanceViewProps {
  records: FinancialRecord[];
  tournaments: TournamentState[];
  activeTournamentId: string;
  onAddRecord: (record: FinancialRecord) => void;
  onTogglePaid: (id: string) => void;
  onDeleteRecord: (id: string) => void;
  spectatorMode?: boolean;
}

export const FinanceView: React.FC<FinanceViewProps> = ({
  records,
  tournaments,
  activeTournamentId,
  onAddRecord,
  onTogglePaid,
  onDeleteRecord,
  spectatorMode,
}) => {
  const [filterTournamentId, setFilterTournamentId] = useState<string>(activeTournamentId);
  const [filterType, setFilterType] = useState<'all' | FinancialRecord['type']>('all');

  const [type, setType] = useState<FinancialRecord['type']>('registration_fee');
  const [title, setTitle] = useState('');
  const [partyName, setPartyName] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('PKR');
  const [status, setStatus] = useState<'paid' | 'pending'>('paid');
  const [notes, setNotes] = useState('');

  const activeTournament = useMemo(
    () => tournaments.find((t) => t.id === filterTournamentId) || tournaments[0],
    [tournaments, filterTournamentId]
  );

  const visibleRecords = useMemo(() => {
    return records.filter((r) => {
      if (filterTournamentId !== 'all' && r.tournamentId !== filterTournamentId) return false;
      if (filterType !== 'all' && r.type !== filterType) return false;
      return true;
    });
  }, [records, filterTournamentId, filterType]);

  const summary = useMemo(() => {
    let incomePaid = 0;
    let incomePending = 0;
    let expenseTotal = 0;
    let prizeTotal = 0;

    visibleRecords.forEach((r) => {
      if (r.type === 'registration_fee' || r.type === 'sponsor') {
        if (r.status === 'paid') incomePaid += r.amount;
        else incomePending += r.amount;
      } else if (r.type === 'expense') {
        expenseTotal += r.amount;
      } else if (r.type === 'prize') {
        prizeTotal += r.amount;
      }
    });

    const netBalance = incomePaid - expenseTotal - prizeTotal;
    return { incomePaid, incomePending, expenseTotal, prizeTotal, netBalance };
  }, [visibleRecords]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numeric = Number(amount);
    if (!title.trim() || !partyName.trim() || !Number.isFinite(numeric) || numeric <= 0) return;

    const record: FinancialRecord = {
      id: `fin-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      tournamentId:
        filterTournamentId === 'all' ? activeTournamentId : filterTournamentId,
      type,
      title: title.trim(),
      partyName: partyName.trim(),
      amount: numeric,
      currency: currency.trim() || 'PKR',
      status,
      date: new Date().toISOString().slice(0, 10),
      receiptNo: `RCP-${String(records.length + 101).padStart(4, '0')}`,
      notes: notes.trim() || undefined,
    };
    onAddRecord(record);
    setTitle('');
    setPartyName('');
    setAmount('');
    setNotes('');
  };

  if (spectatorMode) {
    return (
      <div className="theme-card rounded-3xl p-8 text-center border border-[#D4AF37]/30">
        <Wallet className="w-10 h-10 text-[#D4AF37] mx-auto mb-3" />
        <h3 className="text-lg font-black text-[#172033] dark:text-white">
          Financial Ledger Hidden in Spectator Mode
        </h3>
        <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-1">
          Private tournament finance and receipt details are hidden while Public Spectator Mode is active.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="theme-card rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center shrink-0 shadow-lg">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#172033] dark:text-white">
              Tournament Finance & Prize Ledger
            </h2>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-1">
              Optional organizer ledger for registration fees, sponsor funds, court expenses, prize pools, and printable PNG receipts.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() =>
            downloadFinancialReportCSV(
              visibleRecords,
              filterTournamentId === 'all'
                ? 'All Tournaments'
                : activeTournament?.tournamentTitle || 'Tournament'
            )
          }
          disabled={visibleRecords.length === 0}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center gap-2 shadow-md disabled:opacity-50 cursor-pointer shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Export Finance CSV</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="theme-card rounded-2xl p-4 border border-emerald-500/30">
          <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-[#A0A0A0] font-bold">
            <span>Collected Income</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-xl sm:text-2xl font-black text-emerald-500 mt-1.5 font-mono">
            {summary.incomePaid.toLocaleString()}
          </p>
          <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
            Outstanding: {summary.incomePending.toLocaleString()}
          </p>
        </div>

        <div className="theme-card rounded-2xl p-4 border border-rose-500/30">
          <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-[#A0A0A0] font-bold">
            <span>Expenses</span>
            <TrendingDown className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-xl sm:text-2xl font-black text-rose-500 mt-1.5 font-mono">
            {summary.expenseTotal.toLocaleString()}
          </p>
          <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
            Shuttles, court & operations
          </p>
        </div>

        <div className="theme-card rounded-2xl p-4 border border-[#D4AF37]/30">
          <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-[#A0A0A0] font-bold">
            <span>Prize Pool Paid</span>
            <Award className="w-4 h-4 text-[#FFD700]" />
          </div>
          <p className="text-xl sm:text-2xl font-black text-[#FFD700] mt-1.5 font-mono">
            {summary.prizeTotal.toLocaleString()}
          </p>
          <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
            Winner & runner-up awards
          </p>
        </div>

        <div className="theme-card rounded-2xl p-4 border border-[#D4AF37]/40">
          <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-[#A0A0A0] font-bold">
            <span>Net Balance</span>
            <Wallet className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <p
            className={`text-xl sm:text-2xl font-black mt-1.5 font-mono ${
              summary.netBalance >= 0 ? 'text-[#FFD700]' : 'text-rose-500'
            }`}
          >
            {summary.netBalance >= 0 ? '+' : ''}
            {summary.netBalance.toLocaleString()}
          </p>
          <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
            {visibleRecords.length} ledger entries
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Entry Form */}
        <form
          onSubmit={handleSubmit}
          className="theme-card rounded-3xl p-5 sm:p-6 border border-[#D4AF37]/30 space-y-4 h-fit"
        >
          <h3 className="text-sm font-black uppercase tracking-wider text-[#D4AF37]">
            New Financial Entry
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                Entry Type
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as FinancialRecord['type'])}
                className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-[#172033] dark:text-white font-semibold"
              >
                <option value="registration_fee">Registration Fee (+ Income)</option>
                <option value="sponsor">Sponsor Contribution (+ Income)</option>
                <option value="expense">Tournament Expense (- Cost)</option>
                <option value="prize">Prize Distribution (- Payout)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                Description / Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Singles Entry Fee or Feather Shuttles"
                required
                className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-[#172033] dark:text-white"
              />
            </div>

            <div>
              <label className="block font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                Player / Sponsor / Vendor Name
              </label>
              <input
                type="text"
                value={partyName}
                onChange={(e) => setPartyName(e.target.value)}
                placeholder="e.g. Ali Raza or Yonex Club Sponsor"
                required
                className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-[#172033] dark:text-white"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="col-span-2">
                <label className="block font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                  Amount
                </label>
                <input
                  type="number"
                  min={1}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="2500"
                  required
                  className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-[#172033] dark:text-white font-mono"
                />
              </div>
              <div>
                <label className="block font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                  Currency
                </label>
                <input
                  type="text"
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-[#172033] dark:text-white font-mono uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                Payment Status
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['paid', 'pending'] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setStatus(s)}
                    className={`py-2 rounded-xl font-black uppercase text-xs border cursor-pointer ${
                      status === s
                        ? 'bg-[#D4AF37] text-[#080808] border-[#FFD700]'
                        : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] border-slate-200 dark:border-white/10'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                Notes (Optional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Cash, bank transfer, receipt detail..."
                className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-[#172033] dark:text-white"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record Transaction</span>
            </button>
          </div>
        </form>

        {/* Transactions Table */}
        <div className="lg:col-span-2 theme-card rounded-3xl p-5 sm:p-6 border border-[#D4AF37]/25 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <select
              value={filterTournamentId}
              onChange={(e) => setFilterTournamentId(e.target.value)}
              className="px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-bold text-[#172033] dark:text-white"
            >
              <option value="all">All Tournaments</option>
              {tournaments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.tournamentTitle}
                </option>
              ))}
            </select>

            <div className="flex items-center gap-1.5 flex-wrap">
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'registration_fee', label: 'Fees' },
                  { id: 'sponsor', label: 'Sponsors' },
                  { id: 'expense', label: 'Expenses' },
                  { id: 'prize', label: 'Prizes' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilterType(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-black cursor-pointer ${
                    filterType === tab.id
                      ? 'bg-[#D4AF37] text-[#080808]'
                      : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {visibleRecords.length === 0 ? (
            <div className="py-12 text-center text-xs text-[#64748B] dark:text-[#A0A0A0]">
              No financial records recorded yet for this filter. Add registration fees, sponsorships, expenses, or prize payouts on the left.
            </div>
          ) : (
            <div className="space-y-2.5">
              {visibleRecords.map((rec) => {
                const isIncome = rec.type === 'registration_fee' || rec.type === 'sponsor';
                return (
                  <div
                    key={rec.id}
                    className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#D4AF37] font-bold">
                          {rec.receiptNo}
                        </span>
                        <span className="text-sm font-black text-[#172033] dark:text-white">
                          {rec.title}
                        </span>
                      </div>
                      <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                        {rec.partyName} · {rec.date} · {rec.type.replace('_', ' ')}
                        {rec.notes ? ` · ${rec.notes}` : ''}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <span
                        className={`font-mono font-black text-sm ${
                          isIncome ? 'text-emerald-500' : 'text-rose-500'
                        }`}
                      >
                        {isIncome ? '+' : '-'}
                        {rec.currency || 'PKR'} {rec.amount.toLocaleString()}
                      </span>

                      <button
                        type="button"
                        onClick={() => onTogglePaid(rec.id)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase flex items-center gap-1 cursor-pointer ${
                          rec.status === 'paid'
                            ? 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/30'
                            : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {rec.status === 'paid' ? (
                          <CheckCircle2 className="w-3 h-3" />
                        ) : (
                          <Clock className="w-3 h-3" />
                        )}
                        <span>{rec.status}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          downloadFinancialReceiptPNG(
                            rec,
                            activeTournament?.tournamentTitle || 'Smash Championship'
                          )
                        }
                        title="Download PNG Receipt"
                        className="p-2 rounded-lg bg-[#D4AF37]/15 text-[#D4AF37] hover:bg-[#D4AF37]/25 cursor-pointer"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteRecord(rec.id)}
                        title="Delete Entry"
                        className="p-2 rounded-lg bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
