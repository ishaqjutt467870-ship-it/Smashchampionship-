import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 lg:bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-extrabold text-[#0B1220] shadow-xl border border-amber-300/60">
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>Offline Mode — Local tournament data active</span>
    </div>
  );
};
