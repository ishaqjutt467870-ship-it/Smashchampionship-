import React, { useEffect, useState } from 'react';
import {
  Newspaper,
  WifiOff,
  RefreshCw,
  ExternalLink,
  Globe,
  Trophy,
  Award,
  AlertCircle,
} from 'lucide-react';

interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  source: string;
  publishedAt: string;
  url: string;
  category: string;
}

interface NewsResponse {
  ok: boolean;
  fetchedAt?: string;
  provider?: string;
  groundingSources?: Array<{ title: string; url: string }>;
  articles?: NewsArticle[];
  error?: string;
}

type NewsCategory = 'all' | 'bwf' | 'rankings' | 'tournaments';

export const NewsView: React.FC = () => {
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [category, setCategory] = useState<NewsCategory>('all');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [groundingSources, setGroundingSources] = useState<Array<{ title: string; url: string }>>([]);
  const [provider, setProvider] = useState<string>('');
  const [fetchedAt, setFetchedAt] = useState<string>('');

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const fetchNews = async (cat: NewsCategory) => {
    if (!navigator.onLine) {
      setIsOnline(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/news/badminton?category=${encodeURIComponent(cat)}`);
      const data = (await res.json()) as NewsResponse;
      if (!res.ok || !data.ok) {
        throw new Error(data.error || `News feed error (HTTP ${res.status})`);
      }
      setArticles(data.articles || []);
      setGroundingSources(data.groundingSources || []);
      setProvider(data.provider || 'live-feed');
      setFetchedAt(data.fetchedAt || new Date().toISOString());
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Unable to retrieve live world badminton news.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOnline) {
      void fetchNews(category);
    }
  }, [isOnline, category]);

  if (!isOnline) {
    return (
      <div className="max-w-3xl mx-auto animate-fade-in">
        <div className="theme-card rounded-3xl p-8 sm:p-10 text-center border border-[#D4AF37]/30 shadow-2xl space-y-5">
          <div className="w-16 h-16 rounded-2xl mx-auto bg-amber-500/15 border border-amber-500/35 flex items-center justify-center text-amber-400">
            <WifiOff className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] text-[11px] font-black uppercase tracking-wider">
              Online-Only Feature
            </span>
            <h2 className="text-2xl font-black text-[#172033] dark:text-white">
              World Badminton News Requires Internet
            </h2>
            <p className="text-sm text-[#64748B] dark:text-[#A0A0A0] max-w-md mx-auto">
              You are currently offline. Live BWF tournament reports and world ranking updates only load when an active internet connection is detected. All scoring, brackets, standings, and local data continue working 100% offline.
            </p>
          </div>
          <button
            onClick={() => {
              if (navigator.onLine) {
                setIsOnline(true);
                void fetchNews(category);
              }
            }}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs shadow-md cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Check Connection</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="theme-card rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center shrink-0 shadow-lg">
            <Newspaper className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-black text-[#172033] dark:text-white">
                World Badminton News
              </h2>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/15 text-emerald-500 border border-emerald-500/30">
                <Globe className="w-3 h-3" />
                <span>Live Online Feed</span>
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-1">
              Real-time BWF World Tour highlights, international rankings movement, and major championships.
            </p>
          </div>
        </div>

        <button
          onClick={() => void fetchNews(category)}
          disabled={loading}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center justify-center gap-2 shadow-md hover:opacity-95 disabled:opacity-60 cursor-pointer shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>{loading ? 'Refreshing...' : 'Refresh News'}</span>
        </button>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          {(
            [
              { id: 'all', label: 'All Global News', icon: Globe },
              { id: 'bwf', label: 'BWF World Tour', icon: Trophy },
              { id: 'rankings', label: 'World Rankings', icon: Award },
              { id: 'tournaments', label: 'Major Opens', icon: Newspaper },
            ] as const
          ).map((tab) => {
            const Icon = tab.icon;
            const active = category === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCategory(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer border ${
                  active
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] border-[#FFD700] shadow-md'
                    : 'theme-card text-[#64748B] dark:text-[#A0A0A0] border-slate-200 dark:border-[#D4AF37]/20 hover:border-[#D4AF37]/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {fetchedAt && (
          <span className="text-[11px] font-mono text-[#64748B] dark:text-[#A0A0A0]">
            Updated: {new Date(fetchedAt).toLocaleTimeString()} ·{' '}
            {provider === 'google-search-grounding' ? 'Verified Search Grounding' : 'Live News Wire'}
          </span>
        )}
      </div>

      {/* Error State */}
      {error && (
        <div className="theme-card rounded-2xl p-5 border border-rose-500/40 bg-rose-500/10 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-black text-rose-500">Live News Unavailable</h4>
            <p className="text-xs text-[#64748B] dark:text-slate-300 mt-1">{error}</p>
          </div>
          <button
            onClick={() => void fetchNews(category)}
            className="px-3 py-1.5 rounded-lg bg-rose-500 text-white text-xs font-bold cursor-pointer"
          >
            Retry
          </button>
        </div>
      )}

      {/* Loading Skeletons */}
      {loading && articles.length === 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className="theme-card rounded-2xl p-5 border border-[#D4AF37]/15 animate-pulse space-y-3"
            >
              <div className="h-3 w-24 bg-[#D4AF37]/20 rounded" />
              <div className="h-5 w-4/5 bg-slate-300 dark:bg-white/10 rounded" />
              <div className="h-14 w-full bg-slate-200 dark:bg-white/5 rounded" />
            </div>
          ))}
        </div>
      )}

      {/* Articles Grid */}
      {articles.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {articles.map((article) => (
            <article
              key={article.id}
              className="theme-card rounded-2xl p-5 border border-slate-200 dark:border-[#D4AF37]/20 hover:border-[#D4AF37]/60 transition-all flex flex-col justify-between gap-4 shadow-lg"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2 py-0.5 rounded-md bg-[#D4AF37]/15 text-[#D4AF37] text-[10px] font-black uppercase tracking-wider">
                    {article.category}
                  </span>
                  <span className="text-[11px] font-mono text-[#64748B] dark:text-[#A0A0A0]">
                    {article.publishedAt}
                  </span>
                </div>
                <h3 className="text-base font-black text-[#172033] dark:text-white leading-snug">
                  {article.title}
                </h3>
                <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] leading-relaxed line-clamp-4">
                  {article.summary}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold text-[#172033] dark:text-[#FFD700] truncate">
                  {article.source}
                </span>
                <a
                  href={article.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-black text-[#D4AF37] hover:underline shrink-0"
                >
                  <span>Read Story</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Verified Grounding Citations */}
      {groundingSources.length > 0 && (
        <div className="theme-card rounded-2xl p-4 border border-[#D4AF37]/20">
          <h4 className="text-[11px] font-black uppercase tracking-wider text-[#D4AF37] mb-2">
            Verified Search Grounding Citations
          </h4>
          <div className="flex flex-wrap gap-2">
            {groundingSources.slice(0, 8).map((src, idx) => (
              <a
                key={`${src.url}-${idx}`}
                href={src.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/25 text-xs font-semibold text-[#172033] dark:text-slate-200 hover:border-[#FFD700]"
              >
                <span className="truncate max-w-[200px]">{src.title}</span>
                <ExternalLink className="w-3 h-3 text-[#D4AF37]" />
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
