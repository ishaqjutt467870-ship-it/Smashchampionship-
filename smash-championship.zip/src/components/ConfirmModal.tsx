import React from 'react';
import { AlertTriangle, CheckCircle, X, Info } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDanger?: boolean;
  type?: 'danger' | 'warning' | 'info' | 'success';
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  isDanger = false,
  type = isDanger ? 'danger' : 'warning',
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  const getIcon = () => {
    switch (type) {
      case 'danger':
        return <AlertTriangle className="w-6 h-6 text-[#EF4444]" />;
      case 'warning':
        return <AlertTriangle className="w-6 h-6 text-[#B7F34A]" />;
      case 'success':
        return <CheckCircle className="w-6 h-6 text-[#22C55E]" />;
      default:
        return <Info className="w-6 h-6 text-[#38BDF8]" />;
    }
  };

  const getConfirmButtonClass = () => {
    if (type === 'danger' || isDanger) {
      return 'bg-[#EF4444] hover:bg-red-500 text-white shadow-lg shadow-red-500/20 border-red-500/30';
    }
    if (type === 'warning') {
      return 'bg-[#B7F34A] hover:bg-[#c8f86e] text-[#07111F] font-extrabold shadow-lg shadow-[#B7F34A]/20 border-[#B7F34A]';
    }
    if (type === 'success') {
      return 'bg-[#22C55E] hover:bg-emerald-500 text-[#07111F] font-extrabold shadow-lg border-emerald-500/30';
    }
    return 'bg-[#38BDF8] hover:bg-sky-400 text-[#07111F] font-extrabold shadow-lg border-sky-400/30';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#07111F]/80 backdrop-blur-sm animate-fade-in">
      <div
        className="w-full max-w-md bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-6 relative overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-modal-title"
      >
        <div
          className={`absolute -top-16 -right-16 w-36 h-36 rounded-full blur-3xl pointer-events-none opacity-20 ${
            type === 'danger'
              ? 'bg-[#EF4444]'
              : type === 'warning'
              ? 'bg-[#B7F34A]'
              : 'bg-[#38BDF8]'
          }`}
        />

        <div className="flex items-start gap-4">
          <div
            className={`p-3 rounded-2xl border shrink-0 ${
              type === 'danger'
                ? 'bg-[#EF4444]/10 border-[#EF4444]/25'
                : type === 'warning'
                ? 'bg-[#B7F34A]/10 border-[#B7F34A]/25'
                : 'bg-[#38BDF8]/10 border-[#38BDF8]/25'
            }`}
          >
            {getIcon()}
          </div>
          <div className="flex-1 min-w-0 pr-6">
            <h3
              id="confirm-modal-title"
              className="text-lg font-black text-[#172033] dark:text-white mb-1 leading-snug"
            >
              {title}
            </h3>
            <p className="text-sm text-[#64748B] dark:text-[#94A3B8] leading-relaxed">
              {message}
            </p>
          </div>
          <button
            onClick={onCancel}
            className="absolute top-4 right-4 p-1.5 text-[#64748B] dark:text-[#94A3B8] hover:text-[#172033] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center justify-end gap-3 mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F4F7FB] dark:bg-[#07111F] text-[#172033] dark:text-slate-300 font-bold text-xs sm:text-sm transition-all cursor-pointer"
          >
            {cancelText}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-5 py-2.5 rounded-xl border font-bold text-xs sm:text-sm transition-all active:scale-[0.98] cursor-pointer ${getConfirmButtonClass()}`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};
