import React, { useState } from 'react';
import {
  BookOpen,
  Trophy,
  Zap,
  Users,
  Target,
  ArrowRightLeft,
  CheckCircle2,
  Play,
} from 'lucide-react';
import { AppTab } from './Header';

interface HowToPlayGuideProps {
  onNavigateTab?: (tab: AppTab) => void;
}

export const HowToPlayGuide: React.FC<HowToPlayGuideProps> = ({ onNavigateTab }) => {
  const [selectedTopic, setSelectedTopic] = useState<'scoring' | 'service' | 'formats' | 'workflow'>(
    'scoring'
  );
  const [demoScoreA, setDemoScoreA] = useState(10);
  const [demoScoreB, setDemoScoreB] = useState(9);

  const serverSide = demoScoreA % 2 === 0 ? 'Right Service Box (Even)' : 'Left Service Box (Odd)';

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Guide Intro Banner */}
      <div className="bg-white dark:bg-[#111E30] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#B7F34A]/15 border border-[#B7F34A]/40 flex items-center justify-center text-[#172B4D] dark:text-[#B7F34A]">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-[#172033] dark:text-white tracking-tight">
                How to Play &amp; Official Badminton Rules
              </h3>
              <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
                Master official rally scoring (11–21 pts), service rotation, match formats (BO1/BO2/BO3), and tournament brackets.
              </p>
            </div>
          </div>

          {onNavigateTab && (
            <button
              type="button"
              onClick={() => onNavigateTab('live')}
              className="px-4 py-2 rounded-xl bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] font-extrabold text-xs flex items-center gap-1.5 cursor-pointer shrink-0 self-start sm:self-auto"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Open Live Scorer</span>
            </button>
          )}
        </div>

        {/* Topic Switcher */}
        <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
          {(
            [
              { id: 'scoring', label: '1. Scoring (11–21 Pts)' },
              { id: 'service', label: '2. Service & Court Boxes' },
              { id: 'formats', label: '3. BO1 / BO2 / BO3 Formats' },
              { id: 'workflow', label: '4. Tournament App Guide' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSelectedTopic(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                selectedTopic === tab.id
                  ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] shadow-sm'
                  : 'bg-[#F4F7FB] dark:bg-[#07111F] text-[#64748B] dark:text-[#94A3B8] border border-slate-200 dark:border-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Topic 1: Scoring */}
      {selectedTopic === 'scoring' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white dark:bg-[#111E30] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-sm font-black text-[#172033] dark:text-white">
              <Target className="w-4 h-4 text-[#B7F34A]" />
              <span>Rally Point System (11 to 21 Points)</span>
            </div>
            <ul className="space-y-2.5 text-xs text-[#64748B] dark:text-[#94A3B8] leading-relaxed">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0 mt-0.5" />
                <span>
                  <strong className="text-[#172033] dark:text-white">Every rally scores 1 point:</strong>{' '}
                  Whether serving or receiving, winning a rally awards 1 point and grants the next serve.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0 mt-0.5" />
                <span>
                  <strong className="text-[#172033] dark:text-white">Adjustable Target (11–21 Pts):</strong>{' '}
                  Standard BWF matches play to <strong>21 points</strong>, while fast club sprints can be tuned anywhere between <strong>11 and 21 points</strong>.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0 mt-0.5" />
                <span>
                  <strong className="text-[#172033] dark:text-white">Deuce (2-Point Lead):</strong>{' '}
                  If both players reach 1 point below the target (e.g. 20–20), play continues until one leads by 2 points, up to the Deuce Cap (e.g. 29–29 &rarr; 30 wins).
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0 mt-0.5" />
                <span>
                  <strong className="text-[#172033] dark:text-white">Mid-Game Interval:</strong>{' '}
                  A 60-second hydration break automatically triggers at the halfway mark (11 pts in 21-pt games, 6 pts in 11-pt games).
                </span>
              </li>
            </ul>
          </div>

          {/* Interactive Rule Tester */}
          <div className="bg-white dark:bg-[#111E30] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="text-sm font-black text-[#172033] dark:text-white">
              Interactive Service &amp; Interval Simulator
            </div>
            <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              Tap +1 below to see how BWF service box side and halfway interval rules update automatically.
            </p>
            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-[#B7F34A]/40">
                <div className="text-[11px] font-bold text-[#64748B] dark:text-[#94A3B8]">
                  Server A Score
                </div>
                <div className="text-3xl font-black font-mono text-[#172B4D] dark:text-[#B7F34A] my-1">
                  {demoScoreA}
                </div>
                <button
                  type="button"
                  onClick={() => setDemoScoreA((p) => (p >= 21 ? 0 : p + 1))}
                  className="px-3 py-1.5 rounded-lg bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] text-xs font-extrabold cursor-pointer"
                >
                  +1 Rally
                </button>
              </div>
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800">
                <div className="text-[11px] font-bold text-[#64748B] dark:text-[#94A3B8]">
                  Receiver B Score
                </div>
                <div className="text-3xl font-black font-mono text-[#172033] dark:text-white my-1">
                  {demoScoreB}
                </div>
                <button
                  type="button"
                  onClick={() => setDemoScoreB((p) => (p >= 21 ? 0 : p + 1))}
                  className="px-3 py-1.5 rounded-lg bg-[#38BDF8] text-[#07111F] text-xs font-extrabold cursor-pointer"
                >
                  +1 Rally
                </button>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-[#38BDF8]/10 border border-[#38BDF8]/30 text-xs flex items-center justify-between">
              <span className="text-[#64748B] dark:text-[#94A3B8] font-semibold">
                Active Service Court:
              </span>
              <strong className="text-[#0284C7] dark:text-[#38BDF8]">{serverSide}</strong>
            </div>
          </div>
        </div>
      )}

      {/* Topic 2: Service & Court Zones */}
      {selectedTopic === 'service' && (
        <div className="bg-white dark:bg-[#111E30] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3 text-xs text-[#64748B] dark:text-[#94A3B8] leading-relaxed">
            <h4 className="text-sm font-black text-[#172033] dark:text-white flex items-center gap-2">
              <ArrowRightLeft className="w-4 h-4 text-[#38BDF8]" />
              <span>Service Court Rotation Rules</span>
            </h4>
            <p>
              <strong className="text-[#172033] dark:text-white">Even Score (0, 2, 4...):</strong>{' '}
              Server serves from the <strong>Right</strong> service court diagonally to the opponent&apos;s Right court.
            </p>
            <p>
              <strong className="text-[#172033] dark:text-white">Odd Score (1, 3, 5...):</strong>{' '}
              Server serves from the <strong>Left</strong> service court diagonally to the opponent&apos;s Left court.
            </p>
            <p>
              <strong className="text-[#172033] dark:text-white">Underhand Serve Rule:</strong>{' '}
              The racket head must point downward and contact the shuttle below the server&apos;s waist/1.15m height, hitting diagonally across the net.
            </p>
            <p>
              <strong className="text-[#172033] dark:text-white">Changing Ends:</strong>{' '}
              Players switch sides of the court after Set 1, after Set 2 (if Set 3 is played), and at the halfway interval of the deciding Set 3.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-[#0B2B3F] text-white border-2 border-white/80 flex flex-col justify-between space-y-3">
            <div className="text-xs font-black text-[#B7F34A] uppercase tracking-wider text-center">
              Diagonal Service Court Guide
            </div>
            <div className="grid grid-cols-2 gap-2 h-36">
              <div className="rounded-xl border border-dashed border-white/40 flex flex-col items-center justify-center p-2 text-center bg-white/5">
                <span className="text-[10px] text-[#38BDF8] font-bold">ODD SCORE</span>
                <span className="text-xs font-black">Left Box (1, 3, 5...)</span>
              </div>
              <div className="rounded-xl border-2 border-[#B7F34A] flex flex-col items-center justify-center p-2 text-center bg-[#B7F34A]/15">
                <span className="text-[10px] text-[#B7F34A] font-bold">EVEN SCORE</span>
                <span className="text-xs font-black">Right Box (0, 2, 4...)</span>
              </div>
              <div className="rounded-xl border border-dashed border-white/40 flex flex-col items-center justify-center p-2 text-center bg-white/5">
                <span className="text-[10px] text-[#94A3B8]">Doubles: Wide &amp; Short</span>
              </div>
              <div className="rounded-xl border border-dashed border-white/40 flex flex-col items-center justify-center p-2 text-center bg-white/5">
                <span className="text-[10px] text-[#94A3B8]">Singles: Narrow &amp; Long</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Topic 3: Formats */}
      {selectedTopic === 'formats' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              tag: 'BO1',
              title: 'Best of 1 Set',
              desc: 'Fast knockout or league sprint format. Winner of the single set immediately takes the match. Ideal for large group stages or quick club nights.',
              accent: '#B7F34A',
            },
            {
              tag: 'BO2',
              title: 'Best of 2 Sets',
              desc: 'Two-game tactical match. A 2–0 sweep wins outright. If tied 1–1 after Set 2, the match automatically resolves by total points scored across both sets!',
              accent: '#38BDF8',
            },
            {
              tag: 'BO3',
              title: 'Best of 3 Sets (BWF Official)',
              desc: 'Official championship format. First player to win 2 sets wins the match, with a deciding 3rd set played if sets are level at 1–1.',
              accent: '#22C55E',
            },
          ].map((fmt) => (
            <div
              key={fmt.tag}
              className="bg-white dark:bg-[#111E30] rounded-3xl p-5 border border-slate-200 dark:border-slate-800 space-y-2.5"
            >
              <span
                className="inline-block px-2.5 py-1 rounded-lg text-xs font-black text-[#07111F]"
                style={{ backgroundColor: fmt.accent }}
              >
                {fmt.tag}
              </span>
              <h4 className="text-base font-black text-[#172033] dark:text-white">{fmt.title}</h4>
              <p className="text-xs text-[#64748B] dark:text-[#94A3B8] leading-relaxed">
                {fmt.desc}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* Topic 4: App Workflow */}
      {selectedTopic === 'workflow' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {[
            {
              step: '01',
              title: 'Setup Players & Points',
              desc: 'Register singles or doubles teams, adjust target points (11–21), and choose Round-Robin, Group Stage, or Knockout.',
              icon: <Users className="w-4 h-4 text-[#B7F34A]" />,
              tab: 'roster' as AppTab,
              cta: 'Go to Players',
            },
            {
              step: '02',
              title: 'Run Match Fixtures',
              desc: 'Pick BO1, BO2, or BO3 individually on any fixture, enter quick results, or open the Live Court Umpire Scorer.',
              icon: <Zap className="w-4 h-4 text-[#38BDF8]" />,
              tab: 'matches' as AppTab,
              cta: 'Open Matches',
            },
            {
              step: '03',
              title: 'Live Umpire & TV Mode',
              desc: 'Track every smash, net shot, service side, interval countdown, and project the live Big Screen scoreboard.',
              icon: <Play className="w-4 h-4 text-[#22C55E]" />,
              tab: 'live' as AppTab,
              cta: 'Launch Scorer',
            },
            {
              step: '04',
              title: 'Playoffs & Certificates',
              desc: 'Top seeds qualify automatically into Quarter-Finals, Semi-Finals, 3rd Place, Grand Final, and printable PDF certificates.',
              icon: <Trophy className="w-4 h-4 text-amber-400" />,
              tab: 'knockout' as AppTab,
              cta: 'View Playoffs',
            },
          ].map((item) => (
            <div
              key={item.step}
              className="bg-white dark:bg-[#111E30] rounded-3xl p-5 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-black text-[#38BDF8]">{item.step}</span>
                  {item.icon}
                </div>
                <h4 className="text-sm font-black text-[#172033] dark:text-white">{item.title}</h4>
                <p className="text-xs text-[#64748B] dark:text-[#94A3B8] leading-relaxed">
                  {item.desc}
                </p>
              </div>
              {onNavigateTab && (
                <button
                  type="button"
                  onClick={() => onNavigateTab(item.tab)}
                  className="w-full py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 hover:border-[#B7F34A] text-xs font-extrabold text-[#172033] dark:text-white cursor-pointer"
                >
                  {item.cta} &rarr;
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
