import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  APIProvider,
  Map as GoogleMap,
  AdvancedMarker,
  Pin,
  InfoWindow,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  MapPin,
  Search,
  Navigation,
  Save,
  WifiOff,
  CheckCircle2,
  ExternalLink,
  Compass,
  Trash2,
} from 'lucide-react';
import { VenueLocation } from '../types';

interface VenueMapViewProps {
  tournamentTitle: string;
  venueName: string;
  savedLocation?: VenueLocation;
  onSaveVenueLocation: (loc: VenueLocation | undefined) => void;
  spectatorMode?: boolean;
}

const DEFAULT_CENTER = { lat: 31.5204, lng: 74.3587 }; // Default center (Lahore Sports Arena region)

function isQuotaError(err: unknown): boolean {
  const msg = String(err || '').toUpperCase();
  return (
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('OVER_QUERY_LIMIT') ||
    msg.includes('429') ||
    msg.includes('QUOTA')
  );
}

interface MapInnerProps {
  tournamentTitle: string;
  venueName: string;
  savedLocation?: VenueLocation;
  onSaveVenueLocation: (loc: VenueLocation | undefined) => void;
  spectatorMode?: boolean;
}

const VenueMapInner: React.FC<MapInnerProps> = ({
  tournamentTitle,
  venueName,
  savedLocation,
  onSaveVenueLocation,
  spectatorMode,
}) => {
  const placesLib = useMapsLibrary('places');
  const sessionTokenRef = useRef<google.maps.places.AutocompleteSessionToken | null>(null);

  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<google.maps.places.AutocompleteSuggestion[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  const [selectedLoc, setSelectedLoc] = useState<VenueLocation>(
    savedLocation || {
      name: venueName || tournamentTitle || 'Tournament Arena',
      address: 'Search using Google Places or drop pin on the map',
      lat: DEFAULT_CENTER.lat,
      lng: DEFAULT_CENTER.lng,
    }
  );
  const [showInfo, setShowInfo] = useState(true);
  const [savedNotice, setSavedNotice] = useState(false);
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    if (savedLocation) {
      setSelectedLoc(savedLocation);
    }
  }, [savedLocation]);

  useEffect(() => {
    if (!placesLib || !query.trim()) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        const { AutocompleteSessionToken, AutocompleteSuggestion } = placesLib;
        if (!sessionTokenRef.current) {
          sessionTokenRef.current = new AutocompleteSessionToken();
        }
        setSearching(true);
        setSearchError(null);
        const res = await AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: query.trim(),
          sessionToken: sessionTokenRef.current,
        });
        setSuggestions(res.suggestions || []);
      } catch (err) {
        if (isQuotaError(err)) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        setSearchError('Could not load place suggestions right now.');
      } finally {
        setSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [placesLib, query]);

  const handleSelectSuggestion = useCallback(
    async (suggestion: google.maps.places.AutocompleteSuggestion) => {
      if (!placesLib || !suggestion.placePrediction) return;
      try {
        const place = suggestion.placePrediction.toPlace();
        await place.fetchFields({
          fields: ['id', 'displayName', 'formattedAddress', 'location', 'googleMapsURI'],
        });
        const loc = place.location;
        if (loc) {
          const next: VenueLocation = {
            name: place.displayName || suggestion.placePrediction.text.text,
            address: place.formattedAddress || suggestion.placePrediction.text.text,
            placeId: place.id,
            lat: loc.lat(),
            lng: loc.lng(),
            googleMapsUri:
              place.googleMapsURI ||
              `https://www.google.com/maps/search/?api=1&query=${loc.lat()},${loc.lng()}`,
          };
          setSelectedLoc(next);
          setShowInfo(true);
        }
        setQuery('');
        sessionTokenRef.current = null;
        setSuggestions([]);
      } catch (err) {
        if (isQuotaError(err)) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        setSearchError('Failed to retrieve details for selected place.');
      }
    },
    [placesLib]
  );

  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      setSearchError('Browser geolocation is unavailable on this device.');
      return;
    }
    setLocating(true);
    setSearchError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        setSelectedLoc({
          name: `${venueName || 'Arena'} (Current Location)`,
          address: `Lat ${pos.coords.latitude.toFixed(5)}, Lng ${pos.coords.longitude.toFixed(5)}`,
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          googleMapsUri: `https://www.google.com/maps/search/?api=1&query=${pos.coords.latitude},${pos.coords.longitude}`,
        });
        setShowInfo(true);
      },
      (err) => {
        setLocating(false);
        setSearchError(err.message || 'Location permission denied.');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSave = () => {
    onSaveVenueLocation({
      ...selectedLoc,
      savedAt: new Date().toISOString(),
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const directionsHref = `https://www.google.com/maps/dir/?api=1&destination=${selectedLoc.lat},${selectedLoc.lng}`;

  return (
    <div className="space-y-5">
      {/* Search & Controls */}
      <div className="theme-card rounded-3xl p-5 border border-[#D4AF37]/30 shadow-xl space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#D4AF37] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search badminton hall, sports complex, or street address..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-sm text-[#172033] dark:text-white focus:outline-none focus:border-[#FFD700]"
            />
            {suggestions.length > 0 && (
              <ul className="absolute left-0 right-0 top-full mt-1.5 z-40 rounded-2xl bg-white dark:bg-[#141414] border border-[#D4AF37]/40 shadow-2xl overflow-hidden max-h-64 overflow-y-auto">
                {suggestions.map((sug, idx) => (
                  <li key={idx}>
                    <button
                      type="button"
                      onClick={() => void handleSelectSuggestion(sug)}
                      className="w-full text-left px-4 py-2.5 hover:bg-[#D4AF37]/15 text-xs text-[#172033] dark:text-white flex items-center gap-2.5 border-b border-slate-100 dark:border-white/5 last:border-b-0 cursor-pointer"
                    >
                      <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0" />
                      <span className="truncate">{sug.placePrediction?.text.text}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleLocateMe}
              disabled={locating}
              className="px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/35 text-xs font-bold text-[#172033] dark:text-white hover:border-[#FFD700] flex items-center gap-1.5 cursor-pointer"
            >
              <Compass className={`w-4 h-4 text-[#D4AF37] ${locating ? 'animate-spin' : ''}`} />
              <span>{locating ? 'Locating...' : 'Near Me'}</span>
            </button>

            {!spectatorMode && (
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Arena Pin</span>
              </button>
            )}

            <a
              href={directionsHref}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-500 font-black text-xs flex items-center gap-1.5 hover:bg-emerald-500/20"
            >
              <Navigation className="w-4 h-4" />
              <span>Directions</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {(searching || searchError || savedNotice) && (
          <div className="flex items-center justify-between text-xs">
            {searching && <span className="text-[#D4AF37] font-semibold">Searching Google Places...</span>}
            {searchError && <span className="text-rose-500 font-semibold">{searchError}</span>}
            {savedNotice && (
              <span className="inline-flex items-center gap-1.5 text-emerald-500 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Venue coordinates & address saved to tournament!</span>
              </span>
            )}
          </div>
        )}
      </div>

      {/* Map Container with explicit dimensions */}
      <div className="theme-card rounded-3xl overflow-hidden border border-[#D4AF37]/30 shadow-2xl">
        <div className="h-[380px] sm:h-[460px] w-full relative">
          <GoogleMap
            mapId="DEMO_MAP_ID"
            center={{ lat: selectedLoc.lat, lng: selectedLoc.lng }}
            defaultZoom={14}
            gestureHandling="greedy"
            internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            onClick={(e) => {
              if (spectatorMode) return;
              const latLng = e.detail.latLng;
              if (!latLng) return;
              setSelectedLoc((prev) => ({
                ...prev,
                name: venueName || prev.name,
                address: `Dropped Pin (${latLng.lat.toFixed(5)}, ${latLng.lng.toFixed(5)})`,
                lat: latLng.lat,
                lng: latLng.lng,
                googleMapsUri: `https://www.google.com/maps/search/?api=1&query=${latLng.lat},${latLng.lng}`,
              }));
              setShowInfo(true);
            }}
          >
            <AdvancedMarker
              position={{ lat: selectedLoc.lat, lng: selectedLoc.lng }}
              onClick={() => setShowInfo((s) => !s)}
            >
              <Pin background="#FFD700" glyphColor="#080808" borderColor="#080808" />
            </AdvancedMarker>

            {showInfo && (
              <InfoWindow
                position={{ lat: selectedLoc.lat, lng: selectedLoc.lng }}
                onCloseClick={() => setShowInfo(false)}
              >
                <div className="p-1 text-[#080808] max-w-[220px]">
                  <p className="font-black text-sm">{selectedLoc.name}</p>
                  <p className="text-xs text-slate-600 mt-0.5">{selectedLoc.address}</p>
                </div>
              </InfoWindow>
            )}
          </GoogleMap>
        </div>

        {/* Selected Venue Summary Strip */}
        <div className="p-4 sm:p-5 bg-[#F4F7FB] dark:bg-[#080808] border-t border-slate-200 dark:border-[#D4AF37]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-sm font-black text-[#172033] dark:text-white">
                {selectedLoc.name}
              </span>
              {savedLocation && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-500 text-[10px] font-black uppercase">
                  Saved Pin
                </span>
              )}
            </div>
            <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-1">
              {selectedLoc.address} · ({selectedLoc.lat.toFixed(4)}, {selectedLoc.lng.toFixed(4)})
            </p>
          </div>

          {!spectatorMode && savedLocation && (
            <button
              type="button"
              onClick={() => onSaveVenueLocation(undefined)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-500 border border-rose-500/30 text-xs font-bold cursor-pointer self-start sm:self-auto"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Saved Pin</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export const VenueMapView: React.FC<VenueMapViewProps> = (props) => {
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="theme-card rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/30 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center shrink-0 shadow-lg">
            <MapPin className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#172033] dark:text-white">
              Venue Location & Arena Map
            </h2>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-1">
              Pin the official badminton venue for <strong>{props.tournamentTitle}</strong>, look up sports complexes, and share one-tap directions.
            </p>
          </div>
        </div>
      </div>

      {!isOnline ? (
        <div className="theme-card rounded-3xl p-8 text-center border border-[#D4AF37]/30 space-y-4">
          <WifiOff className="w-10 h-10 text-amber-400 mx-auto" />
          <h3 className="text-lg font-black text-[#172033] dark:text-white">
            Interactive Map Requires Internet
          </h3>
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] max-w-md mx-auto">
            {props.savedLocation
              ? `Saved Arena: ${props.savedLocation.name} — ${props.savedLocation.address}. Live map tiles and Google Places search will resume once connected.`
              : `Current Venue Text: ${props.venueName || 'Center Arena Court'}. Connect to the internet to pin GPS coordinates on Google Maps.`}
          </p>
        </div>
      ) : !apiKey ? (
        <div className="theme-card rounded-3xl p-8 text-center border border-amber-500/40 space-y-3">
          <MapPin className="w-10 h-10 text-[#D4AF37] mx-auto" />
          <h3 className="text-lg font-black text-[#172033] dark:text-white">
            Google Maps API Key Not Loaded
          </h3>
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] max-w-md mx-auto">
            Configure <code className="font-mono text-[#D4AF37]">VITE_GOOGLE_MAPS_API_KEY</code> to activate interactive Google Maps pins and venue autocomplete.
          </p>
          {props.savedLocation && (
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${props.savedLocation.lat},${props.savedLocation.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs"
            >
              <Navigation className="w-4 h-4" />
              <span>Open Directions for {props.savedLocation.name}</span>
            </a>
          )}
        </div>
      ) : (
        <APIProvider apiKey={apiKey}>
          <VenueMapInner {...props} />
        </APIProvider>
      )}
    </div>
  );
};
