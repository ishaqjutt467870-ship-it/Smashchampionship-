import React, { useMemo, useState } from 'react';
import { Palette, Download, Trophy, Award, Share2, FileText, Sparkles } from 'lucide-react';
import { PlayerStats, TournamentMatch, TournamentState } from '../types';
import { formatScore, getTournamentFormatLabel } from '../utils/tournament';
import {
  downloadAnnouncementPoster,
  downloadMatchResultPoster,
  downloadPlayerAchievementCard,
  downloadSocialGraphic,
  downloadTournamentWinnerPoster,
} from '../utils/exports';

interface MediaStudioViewProps {
  state: TournamentState;
  standings: PlayerStats[];
  fixtures: TournamentMatch[];
  onOpenPDFModal: () => void;
}

export const MediaStudioView: React.FC<MediaStudioViewProps> = ({
  state,
  standings,
  fixtures,
  onOpenPDFModal,
}) => {
  const [clubName, setClubName] = useState('Hassan Badminton Club');
  const [sponsorText, setSponsorText] = useState('Smash Championship Gold Series');
  const [entryInfo, setEntryInfo] = useState('Official BWF 21-Point Rules · Register Now');

  const completedFixtures = useMemo(
    () => fixtures.filter((f) => state.results[f.id] !== undefined && f.playerBIndex >= 0),
    [fixtures, state.results]
  );
  const [selectedMatchId, setSelectedMatchId] = useState<string>(
    () => completedFixtures[0]?.id || ''
  );
  const [selectedPlayerIdx, setSelectedPlayerIdx] = useState<number>(
    () => standings[0]?.id ?? 0
  );

  const selectedMatch = useMemo(
    () =>
      completedFixtures.find((m) => m.id === selectedMatchId) || completedFixtures[0] || null,
    [completedFixtures, selectedMatchId]
  );

  const selectedPlayer = useMemo(
    () => standings.find((p) => p.id === selectedPlayerIdx) || standings[0],
    [standings, selectedPlayerIdx]
  );

  const championName =
    state.finalWinner !== null && state.finalWinner !== undefined
      ? state.players[state.finalWinner]
      : standings[0]?.name || 'Champion TBD';

  const runnerUpName = useMemo(() => {
    if (state.finalWinner !== null && state.semis?.[0] !== undefined && state.semis?.[1] !== undefined) {
      const rIdx = state.finalWinner === state.semis[0] ? state.semis[1] : state.semis[0];
      return state.players[rIdx];
    }
    return standings[1]?.name || 'Runner-Up TBD';
  }, [state.finalWinner, state.semis, state.players, standings]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Studio Banner */}
      <div className="theme-card rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center shrink-0 shadow-lg">
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#172033] dark:text-white">
              Media & Design Studio
            </h2>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-1">
              Generate high-resolution Black + Gold tournament posters, winner graphics, player achievement cards, social square/story visuals, and printable reports offline.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenPDFModal}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center gap-2 shadow-md cursor-pointer shrink-0"
        >
          <FileText className="w-4 h-4" />
          <span>Printable Reports & Certificates</span>
        </button>
      </div>

      {/* Custom Branding Inputs */}
      <div className="theme-card rounded-3xl p-5 sm:p-6 border border-[#D4AF37]/25 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-[#D4AF37] mb-1.5">
            Club Branding Header
          </label>
          <input
            type="text"
            value={clubName}
            onChange={(e) => setClubName(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-bold text-[#172033] dark:text-white"
          />
        </div>
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-[#D4AF37] mb-1.5">
            Sponsor Strip Text
          </label>
          <input
            type="text"
            value={sponsorText}
            onChange={(e) => setSponsorText(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-bold text-[#172033] dark:text-white"
          />
        </div>
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-[#D4AF37] mb-1.5">
            Announcement Footer / Note
          </label>
          <input
            type="text"
            value={entryInfo}
            onChange={(e) => setEntryInfo(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-bold text-[#172033] dark:text-white"
          />
        </div>
      </div>

      {/* Studio Generators */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* 1. Winner & Announcement Posters */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center gap-2 text-[#FFD700]">
            <Trophy className="w-5 h-5" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Championship & Announcement Posters
            </h3>
          </div>
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
            1080×1350 HD PNG graphics ready for WhatsApp, Instagram, and arena screens.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={() =>
                downloadTournamentWinnerPoster({
                  tournamentTitle: state.tournamentTitle,
                  championName,
                  runnerUpName,
                  thirdPlaceName:
                    state.thirdPlaceWinner !== null && state.thirdPlaceWinner !== undefined
                      ? state.players[state.thirdPlaceWinner]
                      : standings[2]?.name,
                  venue: state.venue,
                  date: new Date(state.createdDate).toLocaleDateString(),
                  totalMatches: completedFixtures.length,
                })
              }
              className="px-4 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <Download className="w-4 h-4" />
              <span>Winner Poster PNG</span>
            </button>

            <button
              type="button"
              onClick={() =>
                downloadAnnouncementPoster({
                  tournamentTitle: state.tournamentTitle,
                  date: new Date(state.createdDate).toLocaleDateString(),
                  venue: state.venue || 'Center Arena Court',
                  category: state.category || 'singles',
                  formatLabel: getTournamentFormatLabel(state.tournamentFormat),
                  clubName,
                  sponsorText,
                  entryInfo,
                })
              }
              className="px-4 py-3 rounded-xl bg-[#080808] border border-[#D4AF37] text-[#FFD700] font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Announcement Poster</span>
            </button>
          </div>
        </div>

        {/* 2. Match Result Graphic */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center gap-2 text-[#FFD700]">
            <Share2 className="w-5 h-5" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Match Result Poster (1080×1080)
            </h3>
          </div>
          {completedFixtures.length === 0 ? (
            <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
              Complete at least one match to generate an official match result card.
            </p>
          ) : (
            <>
              <select
                value={selectedMatch?.id || ''}
                onChange={(e) => setSelectedMatchId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-bold text-[#172033] dark:text-white"
              >
                {completedFixtures.map((m, idx) => (
                  <option key={m.id} value={m.id}>
                    M{m.roundNumber || idx + 1}: {state.players[m.playerAIndex]} vs{' '}
                    {state.players[m.playerBIndex]} ({formatScore(state.scores?.[m.id]) || 'Win'})
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => {
                  if (!selectedMatch) return;
                  const winnerIdx = state.results[selectedMatch.id];
                  downloadMatchResultPoster({
                    tournamentTitle: state.tournamentTitle,
                    stageLabel: selectedMatch.group ? `Group ${selectedMatch.group}` : 'Official Match',
                    playerA: state.players[selectedMatch.playerAIndex] || 'Player A',
                    playerB: state.players[selectedMatch.playerBIndex] || 'Player B',
                    winnerName: state.players[winnerIdx] || 'Winner',
                    scoreSummary: formatScore(state.scores?.[selectedMatch.id]) || 'Official Win',
                    isMvp: state.matchMvps?.[selectedMatch.id] === winnerIdx,
                    venue: state.venue,
                  });
                }}
                className="w-full px-4 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Match Poster PNG</span>
              </button>
            </>
          )}
        </div>

        {/* 3. Player Achievement Card */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center gap-2 text-[#FFD700]">
            <Award className="w-5 h-5" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Player Career Card
            </h3>
          </div>
          <select
            value={selectedPlayerIdx}
            onChange={(e) => setSelectedPlayerIdx(Number(e.target.value))}
            className="w-full px-3 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-bold text-[#172033] dark:text-white"
          >
            {standings.map((p, idx) => (
              <option key={p.id} value={p.id}>
                #{idx + 1} · {p.name} ({p.won}W-{p.lost}L)
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => {
              if (!selectedPlayer) return;
              const rank = standings.findIndex((p) => p.id === selectedPlayer.id) + 1;
              const winRate =
                selectedPlayer.played > 0
                  ? Math.round((selectedPlayer.won / selectedPlayer.played) * 100)
                  : 0;
              const mvpCount = Object.values(state.matchMvps || {}).filter(
                (id) => id === selectedPlayer.id
              ).length;
              downloadPlayerAchievementCard({
                playerName: selectedPlayer.name,
                playerCode:
                  selectedPlayer.bio?.playerCode || `#SC-${String(selectedPlayer.id + 1).padStart(2, '0')}`,
                rank,
                ratingPoints: selectedPlayer.points,
                wins: selectedPlayer.won,
                losses: selectedPlayer.lost,
                winRate,
                titles: state.finalWinner === selectedPlayer.id ? 1 : 0,
                mvpCount,
                category: state.category || 'singles',
              });
            }}
            className="w-full px-4 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download Player Card PNG</span>
          </button>
        </div>

        {/* 4. Social Square & Story Graphics */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center gap-2 text-[#FFD700]">
            <Palette className="w-5 h-5" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Social Media Graphics (Square & Story)
            </h3>
          </div>
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
            Branded tournament leader & progress highlight cards for Instagram Feed (1:1) and Status/Story (9:16).
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={() =>
                downloadSocialGraphic({
                  tournamentTitle: state.tournamentTitle,
                  headline: state.finalWinner !== null ? 'TOURNAMENT CHAMPION' : 'STANDINGS LEADER',
                  highlightValue: championName,
                  subline: `${completedFixtures.length} Matches Completed · ${state.venue || 'Arena'}`,
                  clubName,
                  sponsorText,
                  aspect: 'square',
                })
              }
              className="px-4 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>1:1 Square Card</span>
            </button>

            <button
              type="button"
              onClick={() =>
                downloadSocialGraphic({
                  tournamentTitle: state.tournamentTitle,
                  headline: state.finalWinner !== null ? 'CROWNED CHAMPION' : 'CURRENT #1 SEED',
                  highlightValue: championName,
                  subline: `${standings[0]?.won || 0} Wins · ${state.players.length} Competitors`,
                  clubName,
                  sponsorText,
                  aspect: 'story',
                })
              }
              className="px-4 py-3 rounded-xl bg-[#080808] border border-[#D4AF37] text-[#FFD700] font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>9:16 Story Card</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
