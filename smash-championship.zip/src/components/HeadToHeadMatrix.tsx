import React, { useState, useMemo } from 'react';
import { Users2, ArrowLeftRight } from 'lucide-react';
import { TournamentMatch, MatchScore } from '../types';
import {
  getPlayerColor,
  getInitials,
  formatScore,
  calculateStandings,
} from '../utils/tournament';

interface HeadToHeadMatrixProps {
  players: string[];
  fixtures: TournamentMatch[];
  results: Record<string, number>;
  scores: Record<string, MatchScore>;
  playerPhotos?: Record<number, string>;
  onOpenPlayerProfile?: (playerId: number) => void;
}

export const HeadToHeadMatrix: React.FC<HeadToHeadMatrixProps> = ({
  players,
  fixtures,
  results,
  scores,
  playerPhotos,
  onOpenPlayerProfile,
}) => {
  const [compareA, setCompareA] = useState<number>(0);
  const [compareB, setCompareB] = useState<number>(players.length > 1 ? 1 : 0);

  const standings = useMemo(
    () => calculateStandings(players, results, scores, playerPhotos),
    [players, results, scores, playerPhotos]
  );

  // Build lookup map for match outcome between any two players
  const matchMap: Record<string, { winner?: number; matchId: string; score?: MatchScore }> = {};

  fixtures.forEach((m) => {
    const key1 = `${m.playerAIndex}-${m.playerBIndex}`;
    const key2 = `${m.playerBIndex}-${m.playerAIndex}`;
    const data = {
      winner: results[m.id],
      matchId: m.id,
      score: scores[m.id],
    };
    matchMap[key1] = data;
    matchMap[key2] = data;
  });

  const statA = standings.find((s) => s.id === compareA);
  const statB = standings.find((s) => s.id === compareB);
  const directMatch = matchMap[`${compareA}-${compareB}`];
  const directScore = formatScore(directMatch?.score);

  const winPct = (played: number, won: number) =>
    played > 0 ? `${Math.round((won / played) * 100)}%` : '0%';

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Interactive Player vs Player Comparison Card */}
      {players.length >= 2 && (
        <div className="bg-white dark:bg-[#111E30] rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <ArrowLeftRight className="w-5 h-5 text-[#38BDF8]" />
              <h2 className="text-lg font-black text-[#172033] dark:text-white tracking-tight">
                Player Comparison &amp; Rivalry Stats
              </h2>
            </div>
            <span className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              Select any two competitors to compare stats &amp; head-to-head record
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            {/* Player 1 Selector */}
            <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-[#8BCB35]/40 dark:border-[#B7F34A]/40 space-y-2">
              <label className="text-[10px] font-black uppercase tracking-wider text-[#8BCB35] dark:text-[#B7F34A] block">
                Competitor 1
              </label>
              <select
                value={compareA}
                onChange={(e) => setCompareA(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#172033] dark:text-white"
              >
                {players.map((p, idx) => (
                  <option key={idx} value={idx}>
                    {p}
                  </option>
                ))}
              </select>
              {statA && (
                <div className="grid grid-cols-3 gap-1.5 pt-2 text-center text-[11px]">
                  <div className="p-2 rounded-lg bg-white dark:bg-[#111E30]">
                    <span className="text-[#64748B] block text-[9px]">W-L</span>
                    <strong className="text-[#172033] dark:text-white font-mono">
                      {statA.won}-{statA.lost}
                    </strong>
                  </div>
                  <div className="p-2 rounded-lg bg-white dark:bg-[#111E30]">
                    <span className="text-[#64748B] block text-[9px]">Win %</span>
                    <strong className="text-[#22C55E] font-mono">
                      {winPct(statA.played, statA.won)}
                    </strong>
                  </div>
                  <div className="p-2 rounded-lg bg-white dark:bg-[#111E30]">
                    <span className="text-[#64748B] block text-[9px]">Pts</span>
                    <strong className="text-[#8BCB35] dark:text-[#B7F34A] font-mono">
                      {statA.points}
                    </strong>
                  </div>
                </div>
              )}
            </div>

            {/* Direct H2H Result Center */}
            <div className="p-4 rounded-2xl bg-[#172B4D] dark:bg-[#07111F] border border-[#38BDF8]/40 text-center text-white space-y-2">
              <div className="text-[10px] font-extrabold uppercase tracking-widest text-[#38BDF8]">
                Direct Matchup
              </div>
              {compareA === compareB ? (
                <div className="text-xs text-[#94A3B8] py-2">
                  Pick two different players
                </div>
              ) : directMatch?.winner !== undefined ? (
                <>
                  <div className="text-sm font-black text-[#B7F34A]">
                    Winner: {players[directMatch.winner]}
                  </div>
                  <div className="text-xs font-mono text-slate-300">
                    {directScore || 'Match Recorded'}
                  </div>
                </>
              ) : (
                <div className="text-xs text-[#94A3B8] py-2">
                  Not yet played in schedule
                </div>
              )}
              {statA && statB && compareA !== compareB && (
                <div className="text-[10px] text-[#94A3B8] pt-1 border-t border-slate-800">
                  Sets Won: {statA.setsWon} vs {statB.setsWon} · Rally Pts: {statA.pointsFor} vs{' '}
                  {statB.pointsFor}
                </div>
              )}
            </div>

            {/* Player 2 Selector */}
            <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-[#38BDF8]/40 space-y-2">
              <label className="text-[10px] font-black uppercase tracking-wider text-[#38BDF8] block">
                Competitor 2
              </label>
              <select
                value={compareB}
                onChange={(e) => setCompareB(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#172033] dark:text-white"
              >
                {players.map((p, idx) => (
                  <option key={idx} value={idx}>
                    {p}
                  </option>
                ))}
              </select>
              {statB && (
                <div className="grid grid-cols-3 gap-1.5 pt-2 text-center text-[11px]">
                  <div className="p-2 rounded-lg bg-white dark:bg-[#111E30]">
                    <span className="text-[#64748B] block text-[9px]">W-L</span>
                    <strong className="text-[#172033] dark:text-white font-mono">
                      {statB.won}-{statB.lost}
                    </strong>
                  </div>
                  <div className="p-2 rounded-lg bg-white dark:bg-[#111E30]">
                    <span className="text-[#64748B] block text-[9px]">Win %</span>
                    <strong className="text-[#22C55E] font-mono">
                      {winPct(statB.played, statB.won)}
                    </strong>
                  </div>
                  <div className="p-2 rounded-lg bg-white dark:bg-[#111E30]">
                    <span className="text-[#64748B] block text-[9px]">Pts</span>
                    <strong className="text-[#38BDF8] font-mono">{statB.points}</strong>
                  </div>
                </div>
              )}
            </div>
          </div>

          {statA && statB && compareA !== compareB && (
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5 text-xs">
              {[
                {
                  label: 'Win Rate',
                  valA: statA.played > 0 ? Math.round((statA.won / statA.played) * 100) : 0,
                  valB: statB.played > 0 ? Math.round((statB.won / statB.played) * 100) : 0,
                  suffix: '%',
                },
                {
                  label: 'Rally Points Scored',
                  valA: statA.pointsFor,
                  valB: statB.pointsFor,
                  suffix: '',
                },
                {
                  label: 'Sets Won',
                  valA: statA.setsWon,
                  valB: statB.setsWon,
                  suffix: '',
                },
              ].map((metric) => {
                const total = metric.valA + metric.valB;
                const pctA = total > 0 ? Math.round((metric.valA / total) * 100) : 50;
                return (
                  <div key={metric.label} className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-[#8BCB35] dark:text-[#B7F34A] font-mono tabular-nums">
                        {metric.valA}
                        {metric.suffix}
                      </span>
                      <span className="text-[#64748B] dark:text-[#94A3B8] uppercase tracking-wider text-[10px]">
                        {metric.label}
                      </span>
                      <span className="text-[#38BDF8] font-mono tabular-nums">
                        {metric.valB}
                        {metric.suffix}
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-[#38BDF8]/40 overflow-hidden flex">
                      <div
                        className="h-full bg-[#8BCB35] dark:bg-[#B7F34A] transition-all duration-300"
                        style={{ width: `${pctA}%` }}
                      />
                      <div
                        className="h-full bg-[#38BDF8] transition-all duration-300"
                        style={{ width: `${100 - pctA}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Full Head-to-Head Matrix Grid */}
      <div className="bg-white dark:bg-[#111E30] rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6">
        <div className="mb-4 pb-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight flex items-center gap-2">
              <Users2 className="w-5 h-5 text-[#8BCB35] dark:text-[#B7F34A]" />
              <span>Head-to-Head Matrix</span>
            </h2>
            <p className="text-xs text-[#64748B] dark:text-[#94A3B8] mt-0.5">
              Cross-grid view of all match outcomes across the active tournament.
            </p>
          </div>
          <div className="text-xs text-[#64748B] dark:text-[#94A3B8] flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded bg-[#22C55E] inline-block" />
              <span>Win</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded bg-[#EF4444] inline-block" />
              <span>Loss</span>
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-center border-collapse text-xs">
            <thead>
              <tr>
                <th className="p-2 text-left font-bold text-[#64748B] dark:text-[#94A3B8] border-b border-slate-200 dark:border-slate-800 min-w-[130px]">
                  Player (Row) vs
                </th>
                {players.map((p, idx) => (
                  <th
                    key={idx}
                    className="p-2 font-bold text-[#172033] dark:text-slate-300 border-b border-slate-200 dark:border-slate-800 min-w-[50px]"
                    title={p}
                  >
                    <div
                      onClick={() => onOpenPlayerProfile?.(idx)}
                      className="flex flex-col items-center cursor-pointer group"
                    >
                      {playerPhotos?.[idx] ? (
                        <img
                          src={playerPhotos[idx]}
                          alt={p}
                          className="w-6 h-6 rounded-md object-cover border border-[#B7F34A]/50 shadow-sm mb-1"
                        />
                      ) : (
                        <div
                          className="w-6 h-6 rounded-md text-[#07111F] font-black text-[10px] flex items-center justify-center mb-1 shadow-sm"
                          style={{ backgroundColor: getPlayerColor(idx) }}
                        >
                          {getInitials(p)}
                        </div>
                      )}
                      <span className="truncate max-w-[44px] block group-hover:text-[#B7F34A] transition-colors">
                        {idx + 1}
                      </span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {players.map((rowPlayer, rIdx) => (
                <tr
                  key={rIdx}
                  className="hover:bg-[#F4F7FB] dark:hover:bg-[#07111F]/60 border-b border-slate-100 dark:border-slate-800/80"
                >
                  <td className="p-2 text-left font-semibold text-[#172033] dark:text-white">
                    <div
                      onClick={() => onOpenPlayerProfile?.(rIdx)}
                      className="flex items-center gap-2 cursor-pointer group"
                    >
                      {playerPhotos?.[rIdx] ? (
                        <img
                          src={playerPhotos[rIdx]}
                          alt={rowPlayer}
                          className="w-5 h-5 rounded object-cover border border-[#B7F34A]/50 shadow-sm shrink-0"
                        />
                      ) : (
                        <div
                          className="w-5 h-5 rounded text-[#07111F] font-black text-[9px] flex items-center justify-center shrink-0"
                          style={{ backgroundColor: getPlayerColor(rIdx) }}
                        >
                          {getInitials(rowPlayer)}
                        </div>
                      )}
                      <span className="truncate max-w-[115px] block font-bold group-hover:text-[#B7F34A] transition-colors">
                        {rIdx + 1}. {rowPlayer}
                      </span>
                    </div>
                  </td>

                  {players.map((colPlayer, cIdx) => {
                    if (rIdx === cIdx) {
                      return (
                        <td
                          key={cIdx}
                          className="p-2 bg-slate-100/60 dark:bg-[#07111F] text-slate-300 dark:text-slate-600 font-bold"
                        >
                          —
                        </td>
                      );
                    }

                    const key = `${rIdx}-${cIdx}`;
                    const matchInfo = matchMap[key];
                    const winner = matchInfo?.winner;
                    const hasResult = winner !== undefined;
                    const isWin = winner === rIdx;
                    const scoreStr = formatScore(matchInfo?.score);

                    return (
                      <td key={cIdx} className="p-1.5">
                        {hasResult ? (
                          <div
                            className={`py-1 px-1 rounded-md text-[11px] font-black ${
                              isWin
                                ? 'bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/40'
                                : 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40'
                            }`}
                            title={`${rowPlayer} vs ${colPlayer}: ${isWin ? 'Won' : 'Lost'}${scoreStr ? ` (${scoreStr})` : ''}`}
                          >
                            {isWin ? 'W' : 'L'}
                          </div>
                        ) : (
                          <div className="py-1 px-1 text-[#64748B] dark:text-slate-600 font-medium">
                            ·
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
