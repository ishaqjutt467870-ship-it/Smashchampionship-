import React from 'react';
import {
  X,
  Trophy,
  ShieldCheck,
  Database,
  Tv,
  QrCode,
  FileText,
  Smartphone,
  Award,
  Medal,
} from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAndroidModal?: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({
  isOpen,
  onClose,
  onOpenAndroidModal,
}) => {
  if (!isOpen) return null;

  const features = [
    {
      icon: <Trophy className="w-4 h-4 text-[#FFD700]" />,
      title: '5 Competition Formats',
      desc: 'Round-Robin, Group Stage (A & B), Single Elimination, Double Elimination (WB + LB), and Knockout with auto-BYE seeding.',
    },
    {
      icon: <Award className="w-4 h-4 text-[#D4AF37]" />,
      title: 'Official BWF Scoring Engine',
      desc: '21-point deuce cap to 30, adjustable 11–21 rules, doubles server box rotation, Undo/Redo, Retirement & Walkover handling.',
    },
    {
      icon: <Tv className="w-4 h-4 text-[#22C55E]" />,
      title: 'Full-Screen TV & Referee Mode',
      desc: 'Landscape-ready stadium scoreboard, sound/haptic alerts, court assignment & transfer, plus role-based Admin/Referee controls.',
    },
    {
      icon: <Medal className="w-4 h-4 text-[#FFD700]" />,
      title: 'Configurable Rankings & H2H',
      desc: 'Category leaderboards (Singles, Doubles, Mixed), tournament history breakdown, and Head-to-Head player comparison matrix.',
    },
    {
      icon: <FileText className="w-4 h-4 text-[#D4AF37]" />,
      title: 'PDF Reports & Black + Gold Posters',
      desc: 'Print certificates, standings, fixtures & scorecards or download 1080px PNG match, winner, and achievement cards.',
    },
    {
      icon: <Database className="w-4 h-4 text-[#22C55E]" />,
      title: 'Offline-First + Validated Backups',
      desc: 'Works 100% offline with instant local persistence, duplicate-checked JSON restore, and optional WebAuthn biometric lock.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-[#D4AF37]/35 rounded-3xl shadow-2xl overflow-hidden animate-fade-in my-6">
        <div className="p-6 bg-[#172B4D] dark:bg-[#080808] text-white border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/logo.png"
              alt="Hassan Badminton Tournament Manager"
              className="w-12 h-12 rounded-2xl object-cover border-2 border-[#D4AF37]"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/icon.svg';
              }}
            />
            <div>
              <h2 className="text-lg font-black tracking-tight">
                Hassan Badminton Tournament Manager
              </h2>
              <p className="text-xs text-[#FFD700] font-bold">
                Smash Championship · Black + Gold Elite v3.0
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-[#A0A0A0] hover:text-white hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {features.map((f) => (
              <div
                key={f.title}
                className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-1.5"
              >
                <div className="flex items-center gap-2 font-black text-xs text-[#172033] dark:text-white">
                  {f.icon}
                  <span>{f.title}</span>
                </div>
                <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] leading-relaxed">
                  {f.desc}
                </p>
              </div>
            ))}
          </div>

          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#080808] to-[#141414] border border-[#D4AF37]/40 text-white flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-6 h-6 text-[#FFD700] shrink-0" />
              <div>
                <div className="text-xs font-black text-[#FFD700]">
                  Developed By Hassan · Hassan developers
                </div>
                <div className="text-[11px] text-[#A0A0A0]">
                  HTTPS PWA Ready (Manifest, Icons, Offline SW) &amp; Android Studio APK/AAB Export
                </div>
              </div>
            </div>
            {onOpenAndroidModal && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAndroidModal();
                }}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-xs font-black flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Android ZIP</span>
              </button>
            )}
          </div>

          <div className="flex items-center justify-between text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
            <span className="inline-flex items-center gap-1">
              <QrCode className="w-3.5 h-3.5 text-[#D4AF37]" />
              Offline-First Local Persistence
            </span>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-[#172B4D] dark:bg-white/10 text-white font-bold text-xs cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
