import React, { useState, useEffect } from 'react';
import {
  X,
  Zap,
  Users,
  Trophy,
  RotateCcw,
  ArrowRightLeft,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Clock,
  Camera,
  History,
  Trash2,
  Sparkles,
  Minus,
  Plus,
  Shuffle,
  CheckCircle2,
  Sliders,
  Award,
} from 'lucide-react';
import { MatchFormat, QuickMatchRecord } from '../types';
import {
  clampPointsPerSet,
  getSuggestedInterval,
  getSuggestedDeuceCap,
  getSetsRequiredToWin,
  getFormatLabel,
  getInitials,
} from '../utils/tournament';
import {
  playShuttleHitSound,
  playPointChime,
  playAlertTone,
  playIntervalBuzzer,
  toggleAudioMute,
  getAudioMuted,
} from '../utils/audio';
import { downloadScoreboardImage } from '../utils/exports';

interface QuickMatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  rosterPlayers: string[];
  defaultMatchFormat: MatchFormat;
  defaultPointsPerSet: number;
  quickMatches: QuickMatchRecord[];
  onSaveQuickMatch: (record: QuickMatchRecord) => void;
  onDeleteQuickMatch: (id: string) => void;
  onToggleQuickMatchMvp?: (id: string) => void;
}

export const QuickMatchModal: React.FC<QuickMatchModalProps> = ({
  isOpen,
  onClose,
  rosterPlayers,
  defaultMatchFormat,
  defaultPointsPerSet,
  quickMatches,
  onSaveQuickMatch,
  onDeleteQuickMatch,
  onToggleQuickMatchMvp,
}) => {
  const [view, setView] = useState<'setup' | 'live' | 'history'>('setup');

  // Setup state
  const [title, setTitle] = useState('Quick Court Match');
  const [category, setCategory] = useState<'singles' | 'doubles'>('singles');
  const [playerAName, setPlayerAName] = useState(() => rosterPlayers[0] || 'Player A');
  const [playerBName, setPlayerBName] = useState(() => rosterPlayers[1] || 'Player B');
  const [matchFormat, setMatchFormat] = useState<MatchFormat>(
    defaultMatchFormat === 'bo2' ? 'bo3' : defaultMatchFormat || 'bo3'
  );
  const [pointsPerSet, setPointsPerSet] = useState<number>(
    clampPointsPerSet(defaultPointsPerSet || 21)
  );
  const [firstServer, setFirstServer] = useState<'A' | 'B'>('A');
  const [tossBanner, setTossBanner] = useState<string | null>(null);

  // Live scoring state
  const [currentSet, setCurrentSet] = useState(1);
  const [pointsA, setPointsA] = useState(0);
  const [pointsB, setPointsB] = useState(0);
  const [server, setServer] = useState<'A' | 'B'>('A');
  const [sideAOnLeft, setSideAOnLeft] = useState(true);
  const [completedSets, setCompletedSets] = useState<Array<{ a: number; b: number }>>([]);
  const [history, setHistory] = useState<
    Array<{
      a: number;
      b: number;
      server: 'A' | 'B';
      completedSets: Array<{ a: number; b: number }>;
      currentSet: number;
      sideAOnLeft: boolean;
    }>
  >([]);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [timerRunning, setTimerRunning] = useState(false);
  const [intervalSec, setIntervalSec] = useState<number | null>(null);
  const [intervalActive, setIntervalActive] = useState(false);
  const [intervalLabel, setIntervalLabel] = useState('');
  const [isMuted, setIsMuted] = useState(getAudioMuted());
  const [savedCurrentMatch, setSavedCurrentMatch] = useState(false);
  const [savedQuickMatchId, setSavedQuickMatchId] = useState<string | null>(null);
  const [pickSlot, setPickSlot] = useState<'A' | 'B'>('A');

  useEffect(() => {
    if (isOpen && view === 'setup') {
      setMatchFormat(defaultMatchFormat === 'bo2' ? 'bo3' : defaultMatchFormat || 'bo3');
      setPointsPerSet(clampPointsPerSet(defaultPointsPerSet || 21));
    }
  }, [isOpen, defaultMatchFormat, defaultPointsPerSet, view]);

  const setsToWin = getSetsRequiredToWin(matchFormat);
  const setsWonA = completedSets.filter((s) => s.a > s.b).length;
  const setsWonB = completedSets.filter((s) => s.b > s.a).length;

  let matchWinner: 'A' | 'B' | null = null;
  if (matchFormat === 'bo2') {
    if (setsWonA >= 2) matchWinner = 'A';
    else if (setsWonB >= 2) matchWinner = 'B';
    else if (completedSets.length >= 2) {
      const totalA = completedSets.reduce((sum, s) => sum + s.a, 0);
      const totalB = completedSets.reduce((sum, s) => sum + s.b, 0);
      matchWinner = totalA >= totalB ? 'A' : 'B';
    }
  } else {
    matchWinner = setsWonA >= setsToWin ? 'A' : setsWonB >= setsToWin ? 'B' : null;
  }

  // Match clock ticker
  useEffect(() => {
    if (!isOpen || view !== 'live' || !timerRunning || matchWinner) return;
    const id = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(id);
  }, [isOpen, view, timerRunning, matchWinner]);

  // Interval countdown ticker
  useEffect(() => {
    if (!intervalActive || intervalSec === null || intervalSec <= 0) return;
    const id = setInterval(() => {
      setIntervalSec((prev) => {
        if (prev === null || prev <= 1) {
          setIntervalActive(false);
          playIntervalBuzzer();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [intervalActive, intervalSec]);

  if (!isOpen) return null;

  const targetPoints = clampPointsPerSet(pointsPerSet);
  const intervalPoint = getSuggestedInterval(targetPoints);
  const maxDeuceCap = getSuggestedDeuceCap(targetPoints);
  const cleanNameA = playerAName.trim() || (category === 'doubles' ? 'Pair A' : 'Player A');
  const cleanNameB = playerBName.trim() || (category === 'doubles' ? 'Pair B' : 'Player B');

  const formatClock = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const resetLiveState = (startingServer: 'A' | 'B' = firstServer) => {
    setCurrentSet(1);
    setPointsA(0);
    setPointsB(0);
    setServer(startingServer);
    setSideAOnLeft(true);
    setCompletedSets([]);
    setHistory([]);
    setElapsedSeconds(0);
    setTimerRunning(true);
    setIntervalSec(null);
    setIntervalActive(false);
    setSavedCurrentMatch(false);
    setSavedQuickMatchId(null);
  };

  const handleStartMatch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    resetLiveState(firstServer);
    setView('live');
  };

  const handleQuickToss = () => {
    const picked: 'A' | 'B' = Math.random() >= 0.5 ? 'A' : 'B';
    setFirstServer(picked);
    setTossBanner(`${picked === 'A' ? cleanNameA : cleanNameB} won the toss and serves first`);
  };

  const handlePickRosterPlayer = (name: string) => {
    if (pickSlot === 'A') {
      setPlayerAName(name);
      setPickSlot('B');
    } else {
      setPlayerBName(name);
      setPickSlot('A');
    }
  };

  const handlePointScored = (winner: 'A' | 'B') => {
    if (matchWinner) return;

    playShuttleHitSound();
    playPointChime();

    setHistory((prev) => [
      ...prev,
      {
        a: pointsA,
        b: pointsB,
        server,
        completedSets: [...completedSets],
        currentSet,
        sideAOnLeft,
      },
    ]);

    const nextA = winner === 'A' ? pointsA + 1 : pointsA;
    const nextB = winner === 'B' ? pointsB + 1 : pointsB;

    setPointsA(nextA);
    setPointsB(nextB);
    setServer(winner);

    if (
      (nextA === intervalPoint && nextB < intervalPoint) ||
      (nextB === intervalPoint && nextA < intervalPoint)
    ) {
      playIntervalBuzzer();
      setIntervalSec(60);
      setIntervalActive(true);
      setIntervalLabel(`${intervalPoint}-Point Mid-Game Interval (60s)`);
    }

    const hasWonSet =
      (nextA >= targetPoints && nextA - nextB >= 2) ||
      (nextB >= targetPoints && nextB - nextA >= 2) ||
      nextA >= maxDeuceCap ||
      nextB >= maxDeuceCap;

    if (hasWonSet) {
      playAlertTone();
      const updatedSets = [...completedSets, { a: nextA, b: nextB }];
      setCompletedSets(updatedSets);

      const nextWonA = updatedSets.filter((s) => s.a > s.b).length;
      const nextWonB = updatedSets.filter((s) => s.b > s.a).length;

      const concluded =
        matchFormat === 'bo2'
          ? nextWonA >= 2 || nextWonB >= 2 || updatedSets.length >= 2
          : nextWonA >= setsToWin || nextWonB >= setsToWin;

      if (!concluded) {
        setCurrentSet((prev) => prev + 1);
        setPointsA(0);
        setPointsB(0);
        setSideAOnLeft((prev) => !prev);
        setIntervalSec(120);
        setIntervalActive(true);
        setIntervalLabel('Set Break Interval (120s)');
      } else {
        setTimerRunning(false);
        let finalWinner: 'A' | 'B' = nextWonA >= nextWonB ? 'A' : 'B';
        if (matchFormat === 'bo2' && nextWonA === nextWonB) {
          const sumA = updatedSets.reduce((acc, s) => acc + s.a, 0);
          const sumB = updatedSets.reduce((acc, s) => acc + s.b, 0);
          finalWinner = sumA >= sumB ? 'A' : 'B';
        }
        const newQuickMatchId = `qm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        onSaveQuickMatch({
          id: newQuickMatchId,
          title: title.trim() || 'Quick Court Match',
          category,
          playerAName: cleanNameA,
          playerBName: cleanNameB,
          matchFormat,
          pointsPerSet: targetPoints,
          setScores: updatedSets,
          winner: finalWinner,
          mvpWinner: false,
          durationSeconds: elapsedSeconds,
          playedAt: new Date().toISOString(),
        });
        setSavedQuickMatchId(newQuickMatchId);
        setSavedCurrentMatch(true);
      }
    }
  };

  const handleUndoPoint = () => {
    if (history.length === 0) return;
    const last = history[history.length - 1];
    setPointsA(last.a);
    setPointsB(last.b);
    setServer(last.server);
    setCompletedSets(last.completedSets);
    setCurrentSet(last.currentSet);
    setSideAOnLeft(last.sideAOnLeft);
    setHistory((prev) => prev.slice(0, -1));
  };

  const handleRematchFromRecord = (rec: QuickMatchRecord) => {
    setTitle(rec.title);
    setCategory(rec.category);
    setPlayerAName(rec.playerAName);
    setPlayerBName(rec.playerBName);
    setMatchFormat(rec.matchFormat);
    setPointsPerSet(clampPointsPerSet(rec.pointsPerSet));
    setFirstServer('A');
    resetLiveState('A');
    setView('live');
  };

  const serverPoints = server === 'A' ? pointsA : pointsB;
  const serverCourtSide: 'right' | 'left' = serverPoints % 2 === 0 ? 'right' : 'left';
  const isGamePointA =
    (pointsA >= targetPoints - 1 && pointsA - pointsB >= 1) || pointsA === maxDeuceCap - 1;
  const isGamePointB =
    (pointsB >= targetPoints - 1 && pointsB - pointsA >= 1) || pointsB === maxDeuceCap - 1;
  const isMatchPointA = isGamePointA && setsWonA === setsToWin - 1;
  const isMatchPointB = isGamePointB && setsWonB === setsToWin - 1;
  const isDeuce =
    pointsA >= targetPoints - 1 && pointsB >= targetPoints - 1 && pointsA === pointsB;

  const leftPlayer = sideAOnLeft
    ? { name: cleanNameA, letter: 'A' as const, points: pointsA }
    : { name: cleanNameB, letter: 'B' as const, points: pointsB };
  const rightPlayer = sideAOnLeft
    ? { name: cleanNameB, letter: 'B' as const, points: pointsB }
    : { name: cleanNameA, letter: 'A' as const, points: pointsA };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#07111F]/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white dark:bg-[#111E30] rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 my-4 overflow-hidden animate-fade-in">
        {/* Top Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-[#F4F7FB] dark:bg-[#07111F]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#B7F34A] text-[#07111F] flex items-center justify-center shadow-sm shrink-0">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#172033] dark:text-white tracking-tight leading-tight">
                Quick Match Arena
              </h2>
              <p className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                Instant 1v1 or 2v2 exhibition scoring without touching league standings
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Sub-view Switcher */}
            <div className="flex items-center gap-1 p-1 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setView('setup')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1 cursor-pointer whitespace-nowrap transition-colors ${
                  view === 'setup'
                    ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                    : 'text-[#64748B] dark:text-[#94A3B8]'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Setup</span>
              </button>
              <button
                type="button"
                onClick={() => setView('live')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1 cursor-pointer whitespace-nowrap transition-colors ${
                  view === 'live'
                    ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                    : 'text-[#64748B] dark:text-[#94A3B8]'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Scoreboard</span>
              </button>
              <button
                type="button"
                onClick={() => setView('history')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1 cursor-pointer whitespace-nowrap transition-colors ${
                  view === 'history'
                    ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                    : 'text-[#64748B] dark:text-[#94A3B8]'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>History ({quickMatches.length})</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-[#64748B] hover:text-[#172033] dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close Quick Match"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-5 sm:p-6 max-h-[80vh] overflow-y-auto">
          {/* VIEW 1: INSTANT SETUP */}
          {view === 'setup' && (
            <form onSubmit={handleStartMatch} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                    Match Label / Court
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Court 1 Friendly"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-bold text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#B7F34A]"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                    Category
                  </label>
                  <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700">
                    {(
                      [
                        { id: 'singles', label: 'Singles (1v1)' },
                        { id: 'doubles', label: 'Doubles (2v2)' },
                      ] as const
                    ).map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => {
                          setCategory(cat.id);
                          if (cat.id === 'doubles' && playerAName === (rosterPlayers[0] || 'Player A')) {
                            setPlayerAName('Team Alpha');
                            setPlayerBName('Team Bravo');
                          } else if (cat.id === 'singles' && playerAName === 'Team Alpha') {
                            setPlayerAName(rosterPlayers[0] || 'Player A');
                            setPlayerBName(rosterPlayers[1] || 'Player B');
                          }
                        }}
                        className={`py-2 px-3 rounded-lg text-xs font-extrabold transition-all cursor-pointer whitespace-nowrap ${
                          category === cat.id
                            ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] shadow-sm'
                            : 'text-[#64748B] dark:text-[#94A3B8]'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Players / Pairs Input */}
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-[#172033] dark:text-white flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-[#8BCB35] dark:text-[#B7F34A]" />
                    <span>{category === 'doubles' ? 'Doubles Pairs' : 'Players'}</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const prevA = playerAName;
                      setPlayerAName(playerBName);
                      setPlayerBName(prevA);
                    }}
                    className="text-xs font-bold text-[#38BDF8] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                    <span>Swap Sides</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1">
                      Side A {pickSlot === 'A' ? '(Tap chip below to fill)' : ''}
                    </label>
                    <input
                      type="text"
                      value={playerAName}
                      onFocus={() => setPickSlot('A')}
                      onChange={(e) => setPlayerAName(e.target.value)}
                      placeholder={category === 'doubles' ? 'e.g. Ali / Hamza' : 'Player A Name'}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-sm font-bold text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#B7F34A]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1">
                      Side B {pickSlot === 'B' ? '(Tap chip below to fill)' : ''}
                    </label>
                    <input
                      type="text"
                      value={playerBName}
                      onFocus={() => setPickSlot('B')}
                      onChange={(e) => setPlayerBName(e.target.value)}
                      placeholder={category === 'doubles' ? 'e.g. Usman / Bilal' : 'Player B Name'}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-sm font-bold text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#38BDF8]"
                    />
                  </div>
                </div>

                {rosterPlayers.length > 0 && (
                  <div className="pt-1">
                    <span className="text-[11px] font-semibold text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                      Quick-pick from tournament roster (assigns Side {pickSlot}):
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {rosterPlayers.map((p, idx) => (
                        <button
                          key={`${p}-${idx}`}
                          type="button"
                          onClick={() => handlePickRosterPlayer(p)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                            playerAName === p
                              ? 'bg-[#B7F34A]/20 border-[#B7F34A] text-[#172B4D] dark:text-[#B7F34A]'
                              : playerBName === p
                              ? 'bg-[#38BDF8]/20 border-[#38BDF8] text-[#0284C7] dark:text-[#38BDF8]'
                              : 'bg-white dark:bg-[#111E30] border-slate-200 dark:border-slate-700 text-[#172033] dark:text-slate-200 hover:border-[#B7F34A]'
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Format & Points Configuration */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold uppercase tracking-wider text-[#172033] dark:text-white">
                      Match Format
                    </span>
                    <span className="text-[11px] font-semibold text-[#38BDF8]">
                      {matchFormat === 'bo1'
                        ? '1 Set'
                        : matchFormat === 'bo5'
                        ? 'First to 3'
                        : 'First to 2'}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-800">
                    {(
                      [
                        { id: 'bo1', label: 'Best of 1' },
                        { id: 'bo3', label: 'Best of 3' },
                        { id: 'bo5', label: 'Best of 5' },
                      ] as const
                    ).map((fmt) => (
                      <button
                        key={fmt.id}
                        type="button"
                        onClick={() => setMatchFormat(fmt.id)}
                        className={`py-2 px-2 rounded-lg text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer ${
                          matchFormat === fmt.id
                            ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                            : 'text-[#64748B] dark:text-[#94A3B8]'
                        }`}
                      >
                        {fmt.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold uppercase tracking-wider text-[#172033] dark:text-white">
                      Points Per Set (11–21)
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setPointsPerSet((p) => clampPointsPerSet(p - 1))}
                        disabled={pointsPerSet <= 11}
                        className="w-6 h-6 rounded-md bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-7 text-center font-mono font-black text-sm text-[#172B4D] dark:text-[#B7F34A] tabular-nums">
                        {pointsPerSet}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPointsPerSet((p) => clampPointsPerSet(p + 1))}
                        disabled={pointsPerSet >= 21}
                        className="w-6 h-6 rounded-md bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                  <input
                    type="range"
                    min={11}
                    max={21}
                    step={1}
                    value={pointsPerSet}
                    onChange={(e) => setPointsPerSet(clampPointsPerSet(Number(e.target.value)))}
                    className="w-full accent-[#B7F34A] cursor-pointer"
                  />
                  <div className="grid grid-cols-4 gap-1">
                    {[11, 15, 18, 21].map((pts) => (
                      <button
                        key={pts}
                        type="button"
                        onClick={() => setPointsPerSet(pts)}
                        className={`py-1 rounded-lg text-[11px] font-extrabold cursor-pointer ${
                          pointsPerSet === pts
                            ? 'bg-[#172B4D] dark:bg-[#38BDF8] text-white dark:text-[#07111F]'
                            : 'bg-white dark:bg-[#111E30] text-[#64748B] dark:text-[#94A3B8]'
                        }`}
                      >
                        {pts}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* First Server + Coin Toss */}
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-extrabold uppercase tracking-wider text-[#172033] dark:text-white">
                    First Server
                  </span>
                  <p className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                    {tossBanner || 'Choose who serves first or run a random coin toss'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setFirstServer('A');
                      setTossBanner(null);
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-extrabold border cursor-pointer max-w-[140px] truncate ${
                      firstServer === 'A'
                        ? 'bg-[#B7F34A] text-[#07111F] border-transparent'
                        : 'bg-white dark:bg-[#111E30] border-slate-200 dark:border-slate-700 text-[#64748B] dark:text-[#94A3B8]'
                    }`}
                  >
                    {cleanNameA}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setFirstServer('B');
                      setTossBanner(null);
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-extrabold border cursor-pointer max-w-[140px] truncate ${
                      firstServer === 'B'
                        ? 'bg-[#38BDF8] text-[#07111F] border-transparent'
                        : 'bg-white dark:bg-[#111E30] border-slate-200 dark:border-slate-700 text-[#64748B] dark:text-[#94A3B8]'
                    }`}
                  >
                    {cleanNameB}
                  </button>
                  <button
                    type="button"
                    onClick={handleQuickToss}
                    className="px-3 py-2 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#172033] dark:text-white hover:border-[#B7F34A] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Shuffle className="w-3.5 h-3.5 text-[#B7F34A]" />
                    <span>Coin Toss</span>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-2xl bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] font-black text-sm shadow-lg hover:opacity-95 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>Start Quick Match</span>
              </button>
            </form>
          )}

          {/* VIEW 2: LIVE SCOREBOARD */}
          {view === 'live' && (
            <div className="space-y-4">
              {/* Live Console Strip */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-black text-[#172033] dark:text-white">
                    {title.trim() || 'Quick Court Match'}
                  </span>
                  <span className="text-[#64748B]" aria-hidden="true">
                    ·
                  </span>
                  <span className="font-bold text-[#38BDF8]">
                    {getFormatLabel(matchFormat)} ({targetPoints} pts)
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 font-mono font-bold text-[#172033] dark:text-[#38BDF8] tabular-nums">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{formatClock(elapsedSeconds)}</span>
                    <button
                      type="button"
                      onClick={() => setTimerRunning((r) => !r)}
                      className="ml-1 text-[#64748B] hover:text-[#B7F34A] cursor-pointer"
                      aria-label={timerRunning ? 'Pause clock' : 'Resume clock'}
                    >
                      {timerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsMuted(toggleAudioMute())}
                    className="p-2 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-[#64748B] dark:text-[#94A3B8] cursor-pointer"
                    aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Interval Alert */}
              {intervalSec !== null && intervalSec > 0 && (
                <div className="p-3.5 rounded-2xl bg-[#B7F34A] text-[#07111F] flex items-center justify-between gap-3">
                  <div>
                    <div className="text-[11px] font-black uppercase tracking-wider">
                      {intervalLabel}
                    </div>
                    <div className="text-xl font-black font-mono tabular-nums">
                      {Math.floor(intervalSec / 60)}:{String(intervalSec % 60).padStart(2, '0')}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIntervalActive((a) => !a)}
                      className="px-3 py-1.5 rounded-xl bg-[#07111F] text-white text-xs font-bold cursor-pointer"
                    >
                      {intervalActive ? 'Pause' : 'Resume'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIntervalSec(null);
                        setIntervalActive(false);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-white/80 text-[#07111F] text-xs font-bold cursor-pointer"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              )}

              {/* Game/Match Point & Deuce Alert */}
              {(isMatchPointA || isMatchPointB || isGamePointA || isGamePointB || isDeuce) &&
                !matchWinner && (
                  <div className="p-2.5 rounded-2xl bg-gradient-to-r from-[#B7F34A] to-[#38BDF8] text-[#07111F] font-black text-xs text-center flex items-center justify-center gap-2 uppercase tracking-wide">
                    <Sparkles className="w-4 h-4 shrink-0" />
                    <span>
                      {isMatchPointA
                        ? `MATCH POINT: ${cleanNameA} (Set ${currentSet})`
                        : isMatchPointB
                        ? `MATCH POINT: ${cleanNameB} (Set ${currentSet})`
                        : isGamePointA
                        ? `GAME POINT: ${cleanNameA}`
                        : isGamePointB
                        ? `GAME POINT: ${cleanNameB}`
                        : `DEUCE ${pointsA}-${pointsB} (Win by 2, Cap ${maxDeuceCap})`}
                    </span>
                  </div>
                )}

              {/* Set Status & Completed Sets */}
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs px-1">
                <div className="font-black text-[#172033] dark:text-white">
                  Set {currentSet} &middot;{' '}
                  <span className="text-[#64748B] dark:text-[#94A3B8] font-semibold">
                    Games: {setsWonA} - {setsWonB}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {completedSets.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-lg bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 font-mono font-bold text-[#172033] dark:text-white tabular-nums"
                    >
                      S{idx + 1}: {s.a}-{s.b}
                    </span>
                  ))}
                </div>
              </div>

              {/* Side-by-Side Score Cards */}
              <div className="grid grid-cols-2 gap-3 sm:gap-5 text-center">
                {/* Side A */}
                <div
                  className={`p-4 sm:p-5 rounded-3xl border-2 transition-all flex flex-col items-center justify-between ${
                    server === 'A'
                      ? 'border-[#8BCB35] dark:border-[#B7F34A] bg-[#8BCB35]/10 dark:bg-[#B7F34A]/10 shadow-md'
                      : 'border-slate-200 dark:border-slate-800 bg-[#F4F7FB] dark:bg-[#07111F]/80'
                  }`}
                >
                  <div className="flex items-center gap-2 w-full justify-center sm:justify-start">
                    <div className="w-8 h-8 rounded-xl bg-[#B7F34A] text-[#07111F] font-black text-xs flex items-center justify-center shrink-0">
                      {getInitials(cleanNameA)}
                    </div>
                    <div className="text-left min-w-0">
                      <div className="font-black text-xs sm:text-sm text-[#172033] dark:text-white truncate">
                        {cleanNameA}
                      </div>
                      <div
                        className={`text-[10px] font-extrabold uppercase ${
                          server === 'A'
                            ? 'text-[#172B4D] dark:text-[#B7F34A]'
                            : 'text-[#64748B] dark:text-[#94A3B8]'
                        }`}
                      >
                        {server === 'A' ? `Serving (${serverCourtSide})` : 'Receiving'}
                      </div>
                    </div>
                  </div>

                  <div
                    key={`qmA-${pointsA}`}
                    className={`animate-score-pop text-5xl sm:text-7xl font-black font-mono tabular-nums py-3 ${
                      server === 'A'
                        ? 'text-[#172B4D] dark:text-[#B7F34A]'
                        : 'text-[#172033] dark:text-white'
                    }`}
                  >
                    {pointsA}
                  </div>

                  {!matchWinner && (
                    <button
                      type="button"
                      onClick={() => handlePointScored('A')}
                      className={`w-full min-h-[48px] py-3 rounded-2xl font-black text-sm shadow-md active:scale-[0.97] transition-all cursor-pointer ${
                        server === 'A'
                          ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                          : 'bg-[#172B4D] dark:bg-[#38BDF8] text-white dark:text-[#07111F]'
                      }`}
                    >
                      +1 Point
                    </button>
                  )}
                </div>

                {/* Side B */}
                <div
                  className={`p-4 sm:p-5 rounded-3xl border-2 transition-all flex flex-col items-center justify-between ${
                    server === 'B'
                      ? 'border-[#8BCB35] dark:border-[#B7F34A] bg-[#8BCB35]/10 dark:bg-[#B7F34A]/10 shadow-md'
                      : 'border-slate-200 dark:border-slate-800 bg-[#F4F7FB] dark:bg-[#07111F]/80'
                  }`}
                >
                  <div className="flex items-center gap-2 w-full justify-center sm:justify-start">
                    <div className="w-8 h-8 rounded-xl bg-[#38BDF8] text-[#07111F] font-black text-xs flex items-center justify-center shrink-0">
                      {getInitials(cleanNameB)}
                    </div>
                    <div className="text-left min-w-0">
                      <div className="font-black text-xs sm:text-sm text-[#172033] dark:text-white truncate">
                        {cleanNameB}
                      </div>
                      <div
                        className={`text-[10px] font-extrabold uppercase ${
                          server === 'B'
                            ? 'text-[#172B4D] dark:text-[#B7F34A]'
                            : 'text-[#64748B] dark:text-[#94A3B8]'
                        }`}
                      >
                        {server === 'B' ? `Serving (${serverCourtSide})` : 'Receiving'}
                      </div>
                    </div>
                  </div>

                  <div
                    key={`qmB-${pointsB}`}
                    className={`animate-score-pop text-5xl sm:text-7xl font-black font-mono tabular-nums py-3 ${
                      server === 'B'
                        ? 'text-[#172B4D] dark:text-[#B7F34A]'
                        : 'text-[#172033] dark:text-white'
                    }`}
                  >
                    {pointsB}
                  </div>

                  {!matchWinner && (
                    <button
                      type="button"
                      onClick={() => handlePointScored('B')}
                      className={`w-full min-h-[48px] py-3 rounded-2xl font-black text-sm shadow-md active:scale-[0.97] transition-all cursor-pointer ${
                        server === 'B'
                          ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                          : 'bg-[#172B4D] dark:bg-[#38BDF8] text-white dark:text-[#07111F]'
                      }`}
                    >
                      +1 Point
                    </button>
                  )}
                </div>
              </div>

              {/* Compact Service Box Visualizer */}
              <div className="p-3 rounded-2xl bg-[#0B2B3F] border-2 border-white/80 text-white">
                <div className="flex items-center justify-between text-[11px] mb-2">
                  <span className="font-bold text-[#B7F34A]">Service Box Alignment</span>
                  <span className="text-slate-300">
                    {server === 'A' ? cleanNameA : cleanNameB} serves from{' '}
                    <strong className="text-[#B7F34A] uppercase">{serverCourtSide}</strong> box
                  </span>
                </div>
                <div className="relative h-24 rounded-xl border-2 border-white/80 flex overflow-hidden">
                  <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-1 bg-white z-10" />
                  <div className="flex-1 grid grid-rows-2 border-r border-white/40">
                    <div
                      className={`border-b border-white/40 flex items-center justify-center text-[11px] font-bold ${
                        server === leftPlayer.letter && serverCourtSide === 'left'
                          ? 'bg-[#B7F34A]/30 text-[#B7F34A]'
                          : 'text-white/50'
                      }`}
                    >
                      {leftPlayer.name} (L)
                    </div>
                    <div
                      className={`flex items-center justify-center text-[11px] font-bold ${
                        server === leftPlayer.letter && serverCourtSide === 'right'
                          ? 'bg-[#B7F34A]/30 text-[#B7F34A]'
                          : 'text-white/50'
                      }`}
                    >
                      {leftPlayer.name} (R)
                    </div>
                  </div>
                  <div className="flex-1 grid grid-rows-2 border-l border-white/40">
                    <div
                      className={`border-b border-white/40 flex items-center justify-center text-[11px] font-bold ${
                        server === rightPlayer.letter && serverCourtSide === 'right'
                          ? 'bg-[#B7F34A]/30 text-[#B7F34A]'
                          : 'text-white/50'
                      }`}
                    >
                      {rightPlayer.name} (R)
                    </div>
                    <div
                      className={`flex items-center justify-center text-[11px] font-bold ${
                        server === rightPlayer.letter && serverCourtSide === 'left'
                          ? 'bg-[#B7F34A]/30 text-[#B7F34A]'
                          : 'text-white/50'
                      }`}
                    >
                      {rightPlayer.name} (L)
                    </div>
                  </div>
                </div>
              </div>

              {/* Match Winner Summary Banner */}
              {matchWinner && (
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#B7F34A] to-[#38BDF8] text-[#07111F] text-center space-y-3">
                  <div className="flex items-center justify-center gap-2 font-black text-base sm:text-lg">
                    <Trophy className="w-5 h-5" />
                    <span>{matchWinner === 'A' ? cleanNameA : cleanNameB} WINS QUICK MATCH!</span>
                  </div>
                  <div className="text-xs font-bold font-mono">
                    Sets: {completedSets.map((s) => `${s.a}-${s.b}`).join(', ')} &middot; Duration:{' '}
                    {formatClock(elapsedSeconds)}
                  </div>
                  {savedCurrentMatch && (
                    <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#07111F]">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Saved to Quick Match History</span>
                    </div>
                  )}
                  <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                    {savedQuickMatchId && onToggleQuickMatchMvp && (() => {
                      const savedRec = quickMatches.find((q) => q.id === savedQuickMatchId);
                      const isMvpAwarded = Boolean(savedRec?.mvpWinner);
                      return (
                        <button
                          type="button"
                          onClick={() => onToggleQuickMatchMvp(savedQuickMatchId)}
                          className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-sm border ${
                            isMvpAwarded
                              ? 'bg-amber-400 text-[#07111F] border-[#07111F]/25'
                              : 'bg-white text-[#07111F] border-[#07111F]/15 hover:bg-amber-50'
                          }`}
                        >
                          <Award className="w-3.5 h-3.5" />
                          <span>
                            {isMvpAwarded
                              ? `Match MVP: ${matchWinner === 'A' ? cleanNameA : cleanNameB}`
                              : `Designate ${matchWinner === 'A' ? cleanNameA : cleanNameB} as Match MVP`}
                          </span>
                        </button>
                      );
                    })()}
                    <button
                      type="button"
                      onClick={() =>
                        downloadScoreboardImage({
                          tournamentTitle: title.trim() || 'Quick Court Match',
                          courtNumber: 1,
                          currentSet,
                          playerA: cleanNameA,
                          playerB: cleanNameB,
                          pointsA,
                          pointsB,
                          setsWonA,
                          setsWonB,
                          completedSets,
                          server,
                        })
                      }
                      className="px-4 py-2 rounded-xl bg-[#07111F] text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5 text-[#38BDF8]" />
                      <span>Share Scoreboard PNG</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => resetLiveState(firstServer)}
                      className="px-4 py-2 rounded-xl bg-white text-[#07111F] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Play Rematch</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Controls Footer */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={handleUndoPoint}
                    disabled={history.length === 0}
                    className="px-3.5 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 font-bold text-[#172033] dark:text-white disabled:opacity-35 flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-[#38BDF8]" />
                    <span>Undo Point</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSideAOnLeft((s) => !s)}
                    className="px-3.5 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 font-bold text-[#172033] dark:text-white flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5 text-[#B7F34A]" />
                    <span>Switch Ends</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => resetLiveState(firstServer)}
                  className="text-xs font-bold text-[#EF4444] hover:underline cursor-pointer"
                >
                  Reset Match
                </button>
              </div>
            </div>
          )}

          {/* VIEW 3: QUICK MATCH HISTORY */}
          {view === 'history' && (
            <div className="space-y-3">
              {quickMatches.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 space-y-3">
                  <Trophy className="w-8 h-8 mx-auto text-[#8BCB35] dark:text-[#B7F34A]" />
                  <h3 className="text-sm font-black text-[#172033] dark:text-white">
                    No Quick Matches Played Yet
                  </h3>
                  <p className="text-xs text-[#64748B] dark:text-[#94A3B8] max-w-sm mx-auto">
                    Start an instant 1v1 or 2v2 match in Setup to track scores and save results here.
                  </p>
                  <button
                    type="button"
                    onClick={() => setView('setup')}
                    className="px-4 py-2 rounded-xl bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] text-xs font-extrabold cursor-pointer"
                  >
                    Create Quick Match
                  </button>
                </div>
              ) : (
                quickMatches.map((rec) => {
                  const winnerName = rec.winner === 'A' ? rec.playerAName : rec.playerBName;
                  return (
                    <div
                      key={rec.id}
                      className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="text-xs text-[#64748B] dark:text-[#94A3B8] font-medium flex flex-wrap items-center gap-1.5">
                          <span className="font-bold text-[#172033] dark:text-white">
                            {rec.title}
                          </span>
                          <span aria-hidden="true">&middot;</span>
                          <span className="capitalize">{rec.category}</span>
                          <span aria-hidden="true">&middot;</span>
                          <span>
                            {rec.matchFormat.toUpperCase()} ({rec.pointsPerSet} pts)
                          </span>
                          <span aria-hidden="true">&middot;</span>
                          <span>{formatClock(rec.durationSeconds)}</span>
                        </div>
                        <div className="text-sm font-black text-[#172033] dark:text-white flex flex-wrap items-center gap-1.5">
                          <span className={rec.winner === 'A' ? 'text-[#22C55E]' : ''}>
                            {rec.playerAName}
                          </span>
                          {rec.winner === 'A' && rec.mvpWinner && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-600 dark:text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase">
                              <Award className="w-3 h-3" />
                              <span>Match MVP</span>
                            </span>
                          )}
                          <span className="text-xs font-semibold text-[#64748B]">vs</span>
                          <span className={rec.winner === 'B' ? 'text-[#22C55E]' : ''}>
                            {rec.playerBName}
                          </span>
                          {rec.winner === 'B' && rec.mvpWinner && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-600 dark:text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase">
                              <Award className="w-3 h-3" />
                              <span>Match MVP</span>
                            </span>
                          )}
                        </div>
                        <div className="text-xs font-mono font-bold text-[#38BDF8] tabular-nums">
                          Winner: {winnerName} &middot;{' '}
                          {rec.setScores.map((s) => `${s.a}-${s.b}`).join(', ')}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {onToggleQuickMatchMvp && (
                          <button
                            type="button"
                            onClick={() => onToggleQuickMatchMvp(rec.id)}
                            className={`px-2.5 py-2 rounded-xl border text-xs font-extrabold flex items-center gap-1 cursor-pointer transition-colors ${
                              rec.mvpWinner
                                ? 'bg-amber-400/20 border-amber-400/50 text-amber-600 dark:text-amber-300'
                                : 'bg-white dark:bg-[#111E30] border-slate-200 dark:border-slate-700 text-[#64748B] dark:text-[#94A3B8] hover:border-amber-400/50'
                            }`}
                          >
                            <Award className="w-3.5 h-3.5" />
                            <span>{rec.mvpWinner ? 'Match MVP' : 'MVP'}</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRematchFromRecord(rec)}
                          className="px-3 py-2 rounded-xl bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] text-xs font-extrabold cursor-pointer whitespace-nowrap"
                        >
                          Rematch
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteQuickMatch(rec.id)}
                          className="p-2 rounded-xl bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-[#EF4444] hover:bg-[#EF4444]/10 cursor-pointer"
                          aria-label="Delete quick match record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
