import React, { useEffect, useState, useRef } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Trophy,
  Zap,
  Clock,
  RotateCcw,
  RotateCw,
  Camera,
  Sun,
  Mic,
  MicOff,
} from 'lucide-react';
import { LiveMatchState } from '../types';
import {
  playShuttleHitSound,
  playPointChime,
  toggleAudioMute,
  getAudioMuted,
  getVoiceUmpireEnabled,
  toggleVoiceUmpire,
  speakUmpireCall,
} from '../utils/audio';
import { downloadScoreboardImage } from '../utils/exports';

interface BigScreenScoreboardProps {
  matchState: LiveMatchState;
  tournamentTitle?: string;
  courtLabel?: string;
  playerAName: string;
  playerBName: string;
  playerAPhoto?: string;
  playerBPhoto?: string;
  servingPartnerLabel?: string;
  targetPoints?: number;
  maxDeuceCap?: number;
  maxSets?: number;
  setsRequiredToWin?: number;
  canUndo?: boolean;
  canRedo?: boolean;
  onClose: () => void;
  onAddPointA: () => void;
  onAddPointB: () => void;
  onUndo: () => void;
  onRedo?: () => void;
}

export const BigScreenScoreboard: React.FC<BigScreenScoreboardProps> = ({
  matchState,
  tournamentTitle = 'SMASH CHAMPIONSHIP',
  courtLabel,
  playerAName,
  playerBName,
  playerAPhoto,
  playerBPhoto,
  servingPartnerLabel,
  targetPoints = 21,
  maxDeuceCap = 30,
  maxSets = 3,
  setsRequiredToWin = 2,
  canUndo = true,
  canRedo = false,
  onClose,
  onAddPointA,
  onAddPointB,
  onUndo,
  onRedo,
}) => {
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(getAudioMuted());
  const [voiceEnabled, setVoiceEnabled] = useState(getVoiceUmpireEnabled());
  const [keepAwake, setKeepAwake] = useState(true);
  const wakeLockRef = useRef<{ release: () => Promise<void> } | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let active = true;
    const requestWakeLock = async () => {
      try {
        if (keepAwake && 'wakeLock' in navigator) {
          const sentinel = await (
            navigator as unknown as {
              wakeLock: { request: (type: 'screen') => Promise<{ release: () => Promise<void> }> };
            }
          ).wakeLock.request('screen');
          if (active) wakeLockRef.current = sentinel;
        }
      } catch {
        // Silently ignore if browser/iframe restricts WakeLock
      }
    };
    requestWakeLock();
    return () => {
      active = false;
      wakeLockRef.current?.release().catch(() => {});
      wakeLockRef.current = null;
    };
  }, [keepAwake]);

  const formatTimer = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleScorePointA = () => {
    playShuttleHitSound();
    playPointChime();
    onAddPointA();
  };

  const handleScorePointB = () => {
    playShuttleHitSound();
    playPointChime();
    onAddPointB();
  };

  const setsWonA = matchState.setScores.filter((s) => s.a > s.b).length;
  const setsWonB = matchState.setScores.filter((s) => s.b > s.a).length;
  const diff = Math.abs(matchState.currentPointsA - matchState.currentPointsB);
  const maxScore = Math.max(matchState.currentPointsA, matchState.currentPointsB);
  const deuceThreshold = Math.max(1, targetPoints - 1);
  const isDeuce =
    matchState.currentPointsA >= deuceThreshold &&
    matchState.currentPointsB >= deuceThreshold &&
    diff === 0;
  const isGamePoint =
    ((matchState.currentPointsA >= deuceThreshold || matchState.currentPointsB >= deuceThreshold) &&
      diff >= 1 &&
      maxScore < maxDeuceCap) ||
    maxScore === maxDeuceCap - 1;
  const isMatchPoint =
    isGamePoint &&
    ((matchState.currentPointsA > matchState.currentPointsB && setsWonA === setsRequiredToWin - 1) ||
      (matchState.currentPointsB > matchState.currentPointsA && setsWonB === setsRequiredToWin - 1));

  const serverPoints =
    matchState.server === 'A' ? matchState.currentPointsA : matchState.currentPointsB;
  const isEvenServer = serverPoints % 2 === 0;

  return (
    <div className="fixed inset-0 z-50 bg-[#080808] text-white flex flex-col justify-between overflow-hidden select-none w-screen h-screen max-w-full font-sans">
      <div className="absolute inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute -top-32 left-1/4 w-[600px] h-[600px] bg-[#D4AF37]/12 rounded-full blur-[150px]" />
        <div className="absolute -bottom-32 right-1/4 w-[600px] h-[600px] bg-[#FFD700]/8 rounded-full blur-[150px]" />
      </div>

      {/* Broadcast Header */}
      <header className="relative z-20 flex flex-wrap items-center justify-between gap-2 px-4 sm:px-8 py-3 bg-[#141414]/95 border-b border-[#D4AF37]/25 backdrop-blur-md shrink-0 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#FFD700] to-[#D4AF37] flex items-center justify-center text-[#080808] font-black text-xl shadow-lg">
            🏸
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm sm:text-xl font-black tracking-tight text-white uppercase">
                {tournamentTitle}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#FFD700] font-extrabold text-[10px] sm:text-xs uppercase">
                {courtLabel || `Court ${matchState.courtNumber || 1}`}
              </span>
            </div>
            <div className="text-[11px] text-[#D4AF37] font-bold flex items-center gap-1.5">
              <span>HASSAN BADMINTON TOURNAMENT MANAGER</span>
              <span className="text-white/30">&bull;</span>
              <span className="text-[#A0A0A0] font-medium">PRO TV SCOREBOARD</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <div className="px-3 sm:px-4 py-1.5 rounded-2xl bg-[#080808] border border-[#D4AF37]/25 text-center">
            <div className="text-[9px] text-[#A0A0A0] font-mono tracking-widest uppercase flex items-center justify-center gap-1">
              <Clock className="w-3 h-3 text-[#D4AF37]" />
              <span>Clock</span>
            </div>
            <div className="text-base sm:text-xl font-mono font-black text-[#FFD700]">
              {formatTimer(elapsedSeconds)}
            </div>
          </div>

          <div className="px-3 sm:px-4 py-1.5 rounded-2xl bg-[#080808] border border-[#D4AF37]/25 text-center">
            <div className="text-[9px] text-[#A0A0A0] font-mono tracking-widest uppercase">
              Game {matchState.currentSet} / {maxSets}
            </div>
            <div className="text-xs sm:text-sm font-black uppercase">
              {isMatchPoint ? (
                <span className="text-[#FFD700] animate-pulse flex items-center gap-1">
                  <Trophy className="w-3.5 h-3.5" /> MATCH POINT
                </span>
              ) : isGamePoint ? (
                <span className="text-[#D4AF37] animate-pulse flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5" /> GAME POINT
                </span>
              ) : isDeuce ? (
                <span className="text-[#FFD700]">DEUCE</span>
              ) : (
                <span className="text-[#22C55E]">LIVE IN PLAY</span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setKeepAwake(!keepAwake)}
            className={`px-2.5 py-2 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer ${
              keepAwake
                ? 'bg-[#D4AF37]/15 border-[#D4AF37]/45 text-[#FFD700]'
                : 'bg-[#080808] border-white/15 text-[#A0A0A0]'
            }`}
            title="Keep screen awake during match"
          >
            <Sun className="w-4 h-4" />
            <span className="hidden md:inline">{keepAwake ? 'Always On' : 'Auto Sleep'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const next = toggleVoiceUmpire();
              setVoiceEnabled(next);
              if (next) speakUmpireCall('Voice umpire ready', true);
            }}
            className={`px-2.5 py-2 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer ${
              voiceEnabled
                ? 'bg-[#D4AF37]/15 border-[#D4AF37]/45 text-[#FFD700]'
                : 'bg-[#080808] border-white/15 text-[#A0A0A0]'
            }`}
            title="Toggle Voice Umpire Announcements"
          >
            {voiceEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            <span className="hidden lg:inline">Voice</span>
          </button>

          <button
            type="button"
            onClick={() =>
              downloadScoreboardImage({
                tournamentTitle,
                courtNumber: matchState.courtNumber,
                currentSet: matchState.currentSet,
                playerA: playerAName,
                playerB: playerBName,
                pointsA: matchState.currentPointsA,
                pointsB: matchState.currentPointsB,
                setsWonA,
                setsWonB,
                completedSets: matchState.setScores,
                server: matchState.server,
              })
            }
            className="p-2.5 rounded-xl bg-[#080808] border border-[#D4AF37]/30 text-[#FFD700] hover:border-[#FFD700] cursor-pointer"
            title="Download Scoreboard PNG"
          >
            <Camera className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => setIsMuted(toggleAudioMute())}
            className="p-2.5 rounded-xl bg-[#080808] border border-white/15 text-[#A0A0A0] hover:text-white cursor-pointer"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5 text-[#FFD700]" />}
          </button>

          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-xl bg-[#EF4444]/20 hover:bg-[#EF4444]/30 border border-[#EF4444]/40 text-[#EF4444] hover:text-white cursor-pointer"
            aria-label="Exit Big Screen Display"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Split Screen Scoreboard (Supports Portrait & Landscape) */}
      <main className="flex-1 grid grid-cols-1 md:grid-cols-2 landscape:grid-cols-2 gap-4 sm:gap-6 p-4 sm:p-8 items-stretch overflow-y-auto">
        {/* Player A */}
        <div
          onClick={handleScorePointA}
          className={`relative rounded-3xl p-5 sm:p-8 flex flex-col justify-between border-2 transition-all cursor-pointer shadow-2xl overflow-hidden group ${
            matchState.server === 'A'
              ? 'bg-[#141414] border-[#D4AF37] ring-4 ring-[#D4AF37]/25'
              : 'bg-[#101010] border-white/10 hover:border-[#D4AF37]/40'
          }`}
        >
          <div className="flex items-center justify-between gap-4 z-10">
            {matchState.server === 'A' ? (
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs sm:text-sm rounded-full shadow-lg">
                <span>🏸 SERVING</span>
                <span className="text-[10px] font-mono uppercase bg-[#080808]/15 px-1.5 py-0.5 rounded-full">
                  {isEvenServer ? 'RIGHT' : 'LEFT'}
                  {servingPartnerLabel ? ` · ${servingPartnerLabel}` : ''}
                </span>
              </div>
            ) : (
              <span className="text-xs font-mono tracking-widest text-[#A0A0A0] uppercase">
                RECEIVING
              </span>
            )}

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#A0A0A0] font-bold uppercase">Games:</span>
              <div className="flex items-center gap-1.5">
                {Array.from({ length: setsRequiredToWin }, (_, idx) => idx).map((idx) => (
                  <div
                    key={idx}
                    className={`w-4 h-4 rounded-full border-2 ${
                      idx < setsWonA
                        ? 'bg-[#FFD700] border-[#D4AF37]'
                        : 'border-white/20 bg-[#080808]'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 my-3 sm:my-4 z-10">
            {playerAPhoto ? (
              <img
                src={playerAPhoto}
                alt={playerAName}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl object-cover border-2 border-[#D4AF37]/60 shrink-0"
              />
            ) : (
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-br from-[#FFD700] to-[#D4AF37] text-[#080808] flex items-center justify-center text-2xl sm:text-3xl font-black shrink-0">
                {playerAName.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div className="min-w-0 flex-1">
              <span className="text-xs font-mono font-bold text-[#D4AF37] uppercase tracking-widest block">
                PLAYER / TEAM A
              </span>
              <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white truncate mt-1">
                {playerAName}
              </h2>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center my-auto py-2 z-10">
            <div
              key={`bigA-${matchState.currentPointsA}`}
              className={`animate-score-pop text-8xl sm:text-9xl lg:text-[165px] font-black tracking-tighter leading-none font-mono tabular-nums ${
                matchState.server === 'A' ? 'text-[#FFD700]' : 'text-white'
              }`}
            >
              {matchState.currentPointsA}
            </div>
            <div className="mt-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-[#A0A0A0]">
              Tap Card to Score (+1 Point)
            </div>
          </div>

          <div className="flex items-center gap-2 pt-4 border-t border-white/10 flex-wrap z-10">
            <span className="text-[11px] text-[#A0A0A0] font-mono uppercase">Previous Games:</span>
            {matchState.setScores.length === 0 ? (
              <span className="text-[11px] text-[#A0A0A0]/70 font-mono">Game 1 in progress</span>
            ) : (
              matchState.setScores.map((s, idx) => (
                <span
                  key={idx}
                  className={`px-3 py-1 rounded-xl text-xs font-mono font-black ${
                    s.a > s.b
                      ? 'bg-[#D4AF37] text-[#080808]'
                      : 'bg-[#080808] text-[#A0A0A0] border border-white/10'
                  }`}
                >
                  G{idx + 1}: {s.a}-{s.b}
                </span>
              ))
            )}
          </div>
        </div>

        {/* Player B */}
        <div
          onClick={handleScorePointB}
          className={`relative rounded-3xl p-5 sm:p-8 flex flex-col justify-between border-2 transition-all cursor-pointer shadow-2xl overflow-hidden group ${
            matchState.server === 'B'
              ? 'bg-[#141414] border-[#D4AF37] ring-4 ring-[#D4AF37]/25'
              : 'bg-[#101010] border-white/10 hover:border-[#D4AF37]/40'
          }`}
        >
          <div className="flex items-center justify-between gap-4 z-10">
            {matchState.server === 'B' ? (
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs sm:text-sm rounded-full shadow-lg">
                <span>🏸 SERVING</span>
                <span className="text-[10px] font-mono uppercase bg-[#080808]/15 px-1.5 py-0.5 rounded-full">
                  {isEvenServer ? 'RIGHT' : 'LEFT'}
                  {servingPartnerLabel ? ` · ${servingPartnerLabel}` : ''}
                </span>
              </div>
            ) : (
              <span className="text-xs font-mono tracking-widest text-[#A0A0A0] uppercase">
                RECEIVING
              </span>
            )}

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#A0A0A0] font-bold uppercase">Games:</span>
              <div className="flex items-center gap-1.5">
                {Array.from({ length: setsRequiredToWin }, (_, idx) => idx).map((idx) => (
                  <div
                    key={idx}
                    className={`w-4 h-4 rounded-full border-2 ${
                      idx < setsWonB
                        ? 'bg-[#FFD700] border-[#D4AF37]'
                        : 'border-white/20 bg-[#080808]'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 my-3 sm:my-4 z-10">
            {playerBPhoto ? (
              <img
                src={playerBPhoto}
                alt={playerBName}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl object-cover border-2 border-[#D4AF37]/60 shrink-0"
              />
            ) : (
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-white/10 border border-[#D4AF37]/40 text-[#FFD700] flex items-center justify-center text-2xl sm:text-3xl font-black shrink-0">
                {playerBName.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div className="min-w-0 flex-1">
              <span className="text-xs font-mono font-bold text-[#A0A0A0] uppercase tracking-widest block">
                PLAYER / TEAM B
              </span>
              <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white truncate mt-1">
                {playerBName}
              </h2>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center my-auto py-2 z-10">
            <div
              key={`bigB-${matchState.currentPointsB}`}
              className={`animate-score-pop text-8xl sm:text-9xl lg:text-[165px] font-black tracking-tighter leading-none font-mono tabular-nums ${
                matchState.server === 'B' ? 'text-[#FFD700]' : 'text-white'
              }`}
            >
              {matchState.currentPointsB}
            </div>
            <div className="mt-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-[#A0A0A0]">
              Tap Card to Score (+1 Point)
            </div>
          </div>

          <div className="flex items-center gap-2 pt-4 border-t border-white/10 flex-wrap z-10">
            <span className="text-[11px] text-[#A0A0A0] font-mono uppercase">Previous Games:</span>
            {matchState.setScores.length === 0 ? (
              <span className="text-[11px] text-[#A0A0A0]/70 font-mono">Game 1 in progress</span>
            ) : (
              matchState.setScores.map((s, idx) => (
                <span
                  key={idx}
                  className={`px-3 py-1 rounded-xl text-xs font-mono font-black ${
                    s.b > s.a
                      ? 'bg-[#D4AF37] text-[#080808]'
                      : 'bg-[#080808] text-[#A0A0A0] border border-white/10'
                  }`}
                >
                  G{idx + 1}: {s.b}-{s.a}
                </span>
              ))
            )}
          </div>
        </div>
      </main>

      {/* Bottom Broadcast Footer */}
      <footer className="relative z-20 flex flex-wrap items-center justify-between px-4 sm:px-8 py-3 bg-[#141414] border-t border-[#D4AF37]/25 text-xs">
        <div className="flex items-center gap-3 text-[#A0A0A0] text-[11px]">
          <span className="font-bold text-[#FFD700]">BWF Official Scoring</span>
          <span>&bull;</span>
          <span>
            {targetPoints}-Point Game ({maxDeuceCap}-Point Cap)
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onUndo}
            disabled={!canUndo}
            className="px-4 py-1.5 rounded-xl bg-[#080808] hover:bg-white/10 disabled:opacity-35 text-[#FFD700] font-bold text-xs flex items-center gap-1.5 border border-[#D4AF37]/35 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Undo</span>
          </button>

          {onRedo && (
            <button
              type="button"
              onClick={onRedo}
              disabled={!canRedo}
              className="px-4 py-1.5 rounded-xl bg-[#080808] hover:bg-white/10 disabled:opacity-35 text-white font-bold text-xs flex items-center gap-1.5 border border-white/15 cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Redo</span>
            </button>
          )}

          <div className="hidden sm:flex items-center gap-1.5 text-[11px] font-bold text-[#D4AF37] ml-2">
            <span>Developed By Hassan</span>
            <span className="text-white/25">&bull;</span>
            <span className="text-[#A0A0A0] font-normal">HASSAN DEVELOPERS</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
