import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Settings,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  ShieldAlert,
  RotateCcw,
  Smartphone,
  Save,
  Check,
  Upload,
  Image as ImageIcon,
  Camera,
  RefreshCw,
  Vibrate,
  Lock,
  Globe,
  Palette,
  UserCheck,
  Minus,
  Plus,
  Award,
  Sparkles,
  Fingerprint,
  Database,
  Shield,
  QrCode,
  Info,
  Eye,
  Gauge,
  HelpCircle,
} from 'lucide-react';
import {
  MatchFormat,
  CustomTournamentRules,
  AppLanguage,
  UserAccount,
  UserRoleMode,
  AccessibilitySettings,
} from '../types';
import {
  isAudioMuted,
  toggleAudioMute,
  getHapticsEnabled,
  toggleHaptics,
} from '../utils/audio';
import {
  DEFAULT_LOGO_URL,
  LEGACY_GOLD_LOGO_URL,
  clampPointsPerSet,
  getSuggestedInterval,
  getSuggestedDeuceCap,
} from '../utils/tournament';
import { isBiometricSupported, enrollBiometricCredential } from '../utils/webauthn';
import { ConfirmModal } from './ConfirmModal';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDark: boolean;
  setIsDark: (val: boolean) => void;
  matchFormat: MatchFormat;
  setMatchFormat: (fmt: MatchFormat) => void;
  customRules?: CustomTournamentRules;
  onUpdateCustomRules?: (rules: CustomTournamentRules) => void;
  language?: AppLanguage;
  setLanguage?: (lang: AppLanguage) => void;
  hasPin?: boolean;
  onOpenPinSetup?: () => void;
  animationsEnabled?: boolean;
  onToggleAnimations?: () => void;
  autoBackupEnabled?: boolean;
  onToggleAutoBackup?: () => void;
  lastBackupAt?: string;
  userRoleMode?: UserRoleMode;
  onChangeUserRoleMode?: (mode: UserRoleMode) => void;
  spectatorMode?: boolean;
  onToggleSpectatorMode?: () => void;
  accessibility?: AccessibilitySettings;
  onUpdateAccessibility?: (next: AccessibilitySettings) => void;
  onOpenTutorial?: () => void;
  biometricCredentialId?: string | null;
  onUpdateBiometric?: (credentialId: string | null) => void;
  onOpenQRModal?: () => void;
  onOpenAboutModal?: () => void;
  onResetTournament: () => void;
  onResetAll: () => void;
  onOpenAndroidModal: () => void;
  customLogoUrl?: string;
  onUpdateLogo: (logoUrl: string) => void;
  activeThemeName?: string;
  onOpenThemeStudio?: (section: 'themes' | 'wallpapers') => void;
  userAccount?: UserAccount | null;
  onOpenAuthModal?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  isDark,
  setIsDark,
  matchFormat,
  setMatchFormat,
  customRules,
  onUpdateCustomRules,
  language = 'en',
  setLanguage,
  hasPin = false,
  onOpenPinSetup,
  animationsEnabled = true,
  onToggleAnimations,
  autoBackupEnabled = false,
  onToggleAutoBackup,
  lastBackupAt,
  userRoleMode = 'admin',
  onChangeUserRoleMode,
  spectatorMode = false,
  onToggleSpectatorMode,
  accessibility = { fontScale: 'md', highContrast: false, lowPerfMode: false },
  onUpdateAccessibility,
  onOpenTutorial,
  biometricCredentialId,
  onUpdateBiometric,
  onOpenQRModal,
  onOpenAboutModal,
  onResetTournament,
  onResetAll,
  onOpenAndroidModal,
  customLogoUrl = DEFAULT_LOGO_URL,
  onUpdateLogo,
  activeThemeName = 'Black + Gold Elite',
  onOpenThemeStudio,
  userAccount,
  onOpenAuthModal,
}) => {
  const [muted, setMuted] = useState(isAudioMuted());
  const [haptics, setHaptics] = useState(getHapticsEnabled());
  const [pointsPerSet, setPointsPerSet] = useState<number>(
    clampPointsPerSet(customRules?.pointsPerSet ?? 21)
  );
  const [maxDeuceCap, setMaxDeuceCap] = useState<number>(
    customRules?.maxDeuceCap ?? 30
  );
  const [intervalAt, setIntervalAt] = useState<number>(
    customRules?.intervalAt ?? 11
  );
  const [refereeName, setRefereeName] = useState(
    customRules?.refereeName ?? 'Hassan'
  );
  const [savedNotification, setSavedNotification] = useState(false);
  const [logoNotification, setLogoNotification] = useState<string | null>(null);
  const [bioMessage, setBioMessage] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [confirmFactoryResetOpen, setConfirmFactoryResetOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && customRules) {
      const pts = clampPointsPerSet(customRules.pointsPerSet);
      setPointsPerSet(pts);
      setMaxDeuceCap(customRules.maxDeuceCap);
      setIntervalAt(customRules.intervalAt);
      setRefereeName(customRules.refereeName || 'Hassan');
    }
  }, [isOpen, customRules]);

  if (!isOpen) return null;

  const handlePointsChange = (nextRaw: number) => {
    const p = clampPointsPerSet(nextRaw);
    setPointsPerSet(p);
    setIntervalAt(getSuggestedInterval(p));
    setMaxDeuceCap(getSuggestedDeuceCap(p));
  };

  const handleToggleSound = () => {
    setMuted(toggleAudioMute());
  };

  const handleToggleHaptics = () => {
    setHaptics(toggleHaptics());
  };

  const handleSaveRules = () => {
    onUpdateCustomRules?.({
      pointsPerSet: clampPointsPerSet(pointsPerSet),
      maxDeuceCap: Math.max(pointsPerSet + 2, maxDeuceCap),
      intervalAt,
      refereeName: refereeName.trim() || 'Hassan',
    });
    setSavedNotification(true);
    setTimeout(() => setSavedNotification(false), 2000);
  };

  const handleEnrollBiometric = async () => {
    if (!onUpdateBiometric) return;
    if (biometricCredentialId) {
      onUpdateBiometric(null);
      setBioMessage('Biometric unlock removed.');
      setTimeout(() => setBioMessage(null), 2500);
      return;
    }
    const res = await enrollBiometricCredential(userAccount?.name || 'Hassan Admin');
    if (res.ok && res.credentialId) {
      onUpdateBiometric(res.credentialId);
    }
    setBioMessage(res.message);
    setTimeout(() => setBioMessage(null), 3000);
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (PNG, JPG, SVG, WebP).');
      return;
    }
    setUploadError(null);
    setIsUploading(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX = 320;
        let w = img.width;
        let h = img.height;
        if (w > h) {
          if (w > MAX) {
            h = Math.round((h * MAX) / w);
            w = MAX;
          }
        } else if (h > MAX) {
          w = Math.round((w * MAX) / h);
          h = MAX;
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
          onUpdateLogo(canvas.toDataURL('image/png', 0.92));
        } else {
          onUpdateLogo(result);
        }
        setIsUploading(false);
        setLogoNotification('Custom tournament logo applied!');
        setTimeout(() => setLogoNotification(null), 2500);
      };
      img.onerror = () => {
        onUpdateLogo(result);
        setIsUploading(false);
        setLogoNotification('Custom tournament logo applied!');
        setTimeout(() => setLogoNotification(null), 2500);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSelectPreset = (url: string, name: string) => {
    onUpdateLogo(url);
    setLogoNotification(`Preset applied: ${name}`);
    setTimeout(() => setLogoNotification(null), 2000);
  };

  const handleResetToDefaultLogo = () => {
    onUpdateLogo(DEFAULT_LOGO_URL);
    setLogoNotification('Restored official Smash Championship logo!');
    setTimeout(() => setLogoNotification(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-[#141414] rounded-3xl shadow-2xl border border-slate-200 dark:border-[#D4AF37]/30 my-8 overflow-hidden animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808]">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#D4AF37]" />
            <h2 className="text-lg font-black text-[#172033] dark:text-white">
              Settings, Security &amp; Rules
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#64748B] hover:text-[#172033] dark:hover:text-white rounded-xl hover:bg-slate-200/60 dark:hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* SECTION 1: BRANDING */}
          <div className="space-y-3.5 p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/35">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#D4AF37]" />
                <h3 className="text-xs font-black text-[#172033] dark:text-white uppercase tracking-wider">
                  Tournament Branding &amp; Logo
                </h3>
              </div>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808]">
                Customizable
              </span>
            </div>

            <div className="p-3.5 rounded-2xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10 flex flex-col sm:flex-row items-center gap-4">
              <div className="relative group shrink-0">
                <div className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-[#D4AF37] shadow-md bg-[#080808] flex items-center justify-center">
                  {customLogoUrl ? (
                    <img
                      src={customLogoUrl}
                      alt="Tournament Logo"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-3xl">🏸</span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-black/50 rounded-2xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-bold transition-opacity cursor-pointer"
                >
                  <Camera className="w-4 h-4 mb-0.5" />
                  <span>Change</span>
                </button>
              </div>

              <div className="flex-1 space-y-2 text-center sm:text-left w-full">
                <div className="flex flex-col">
                  <span className="font-black text-sm text-[#172033] dark:text-white">
                    Hassan Badminton Tournament Manager
                  </span>
                  <span className="text-[11px] text-[#9A7B1C] dark:text-[#FFD700] font-bold">
                    Smash Championship &bull; Hassan developers
                  </span>
                </div>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleLogoFileChange}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="px-3.5 py-1.5 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-extrabold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploading ? 'Processing...' : 'Upload Logo'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleResetToDefaultLogo}
                    className="px-2.5 py-1.5 bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] hover:text-white font-semibold text-xs rounded-xl border border-slate-200 dark:border-white/10 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Default</span>
                  </button>
                </div>
              </div>
            </div>

            {uploadError && (
              <div className="p-2.5 bg-[#EF4444]/10 border border-[#EF4444]/30 rounded-xl flex items-center justify-between text-xs text-[#EF4444]">
                <span>{uploadError}</span>
                <button type="button" onClick={() => setUploadError(null)}>
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { url: DEFAULT_LOGO_URL, title: 'Black + Gold', sub: 'Elite Shield' },
                { url: '/icon.svg', title: 'Vector SVG', sub: 'Shuttle Shield' },
                { url: '/apple-touch-icon.png', title: 'App Crest', sub: 'Home Icon' },
                { url: LEGACY_GOLD_LOGO_URL, title: 'Official 3D', sub: 'Gold Crest' },
              ].map((preset) => (
                <button
                  key={preset.url}
                  type="button"
                  onClick={() => handleSelectPreset(preset.url, preset.title)}
                  className={`p-2 rounded-xl border flex items-center gap-2 transition-all cursor-pointer text-left ${
                    customLogoUrl === preset.url
                      ? 'border-[#FFD700] bg-[#D4AF37]/15 ring-1 ring-[#FFD700]'
                      : 'border-slate-200 dark:border-white/10 bg-white dark:bg-[#141414] hover:border-[#D4AF37]'
                  }`}
                >
                  <img
                    src={preset.url}
                    alt={preset.title}
                    referrerPolicy="no-referrer"
                    className="w-7 h-7 rounded-lg object-cover shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="text-[11px] font-bold text-[#172033] dark:text-white truncate">
                      {preset.title}
                    </div>
                    <div className="text-[9px] text-[#64748B] dark:text-[#A0A0A0] truncate">
                      {preset.sub}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {logoNotification && (
              <div className="p-2.5 rounded-xl bg-[#22C55E] text-[#080808] font-extrabold text-xs flex items-center gap-2 shadow-sm">
                <Check className="w-4 h-4 shrink-0" />
                <span>{logoNotification}</span>
              </div>
            )}
          </div>

          {/* SECTION 1.5: ROLE MODE & ACCESS PERMISSIONS */}
          {onChangeUserRoleMode && (
            <div className="space-y-3 p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[#D4AF37]" />
                  <h3 className="text-xs font-black text-[#172033] dark:text-white uppercase tracking-wider">
                    Access Role &amp; Permissions
                  </h3>
                </div>
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-[#D4AF37]/20 text-[#9A7B1C] dark:text-[#FFD700]">
                  {userRoleMode === 'admin' ? 'Admin Full Access' : 'Referee Safe Mode'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onChangeUserRoleMode('admin')}
                  className={`p-3 rounded-2xl border text-left cursor-pointer transition-all ${
                    userRoleMode === 'admin'
                      ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] border-transparent font-black'
                      : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                  }`}
                >
                  <div className="text-xs font-black">Administrator Mode</div>
                  <div className="text-[10px] opacity-80 mt-0.5">
                    Create, delete, reset, rank config &amp; score
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => onChangeUserRoleMode('referee')}
                  className={`p-3 rounded-2xl border text-left cursor-pointer transition-all ${
                    userRoleMode === 'referee'
                      ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] border-transparent font-black'
                      : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                  }`}
                >
                  <div className="text-xs font-black">Referee Mode</div>
                  <div className="text-[10px] opacity-80 mt-0.5">
                    Live scoring &amp; courts; deletes locked
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* SECTION 2: THEMES (120+), WALLPAPERS & ACCOUNT */}
          <div className="space-y-3">
            <h3 className="text-xs font-extrabold text-[#64748B] dark:text-[#A0A0A0] uppercase tracking-wider">
              Themes, Wallpapers &amp; Account
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {onOpenThemeStudio && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenThemeStudio('themes');
                    }}
                    className="p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 flex items-center justify-between hover:border-[#FFD700] transition-colors cursor-pointer text-left"
                  >
                    <div className="min-w-0 pr-2">
                      <div className="text-xs font-black text-[#172033] dark:text-white">
                        120+ Premium Themes
                      </div>
                      <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] truncate">
                        {activeThemeName}
                      </div>
                    </div>
                    <Palette className="w-5 h-5 text-[#D4AF37] shrink-0" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenThemeStudio('wallpapers');
                    }}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
                  >
                    <div>
                      <div className="text-xs font-black text-[#172033] dark:text-white">
                        Custom Wallpapers
                      </div>
                      <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                        Upload or Arena HD
                      </div>
                    </div>
                    <ImageIcon className="w-5 h-5 text-[#FFD700] shrink-0" />
                  </button>
                </>
              )}
            </div>

            {onOpenAuthModal && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAuthModal();
                }}
                className="w-full p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#22C55E] transition-colors cursor-pointer text-left"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <UserCheck
                    className={`w-5 h-5 shrink-0 ${
                      userAccount?.verified ? 'text-[#22C55E]' : 'text-[#D4AF37]'
                    }`}
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-[#172033] dark:text-white truncate">
                      {userAccount?.verified
                        ? `${userAccount.name} (Verified ${userAccount.role})`
                        : 'Sign Up & Verify Account'}
                    </div>
                    <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] truncate">
                      {userAccount?.verified
                        ? userAccount.email || userAccount.mobile
                        : 'Register with Name & Email or Mobile OTP'}
                    </div>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#22C55E] shrink-0">
                  {userAccount?.verified ? 'Manage →' : 'Sign Up →'}
                </span>
              </button>
            )}
          </div>

          {/* SECTION 3: EXPERIENCE, ANIMATIONS, BIOMETRICS & AUTO-BACKUP */}
          <div className="space-y-3">
            <h3 className="text-xs font-extrabold text-[#64748B] dark:text-[#A0A0A0] uppercase tracking-wider">
              Experience, Language &amp; Security
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setIsDark(!isDark)}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
              >
                <div>
                  <div className="text-xs font-bold text-[#172033] dark:text-white">Theme Mode</div>
                  <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    {isDark ? 'Black + Gold Dark' : 'Crisp Light'}
                  </div>
                </div>
                {isDark ? (
                  <Moon className="w-5 h-5 text-[#FFD700]" />
                ) : (
                  <Sun className="w-5 h-5 text-[#172B4D]" />
                )}
              </button>

              <button
                onClick={handleToggleSound}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
              >
                <div>
                  <div className="text-xs font-bold text-[#172033] dark:text-white">
                    Sound Effects
                  </div>
                  <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    {muted ? 'Audio Muted' : 'Audio Active'}
                  </div>
                </div>
                {muted ? (
                  <VolumeX className="w-5 h-5 text-[#EF4444]" />
                ) : (
                  <Volume2 className="w-5 h-5 text-[#22C55E]" />
                )}
              </button>

              <button
                onClick={handleToggleHaptics}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
              >
                <div>
                  <div className="text-xs font-bold text-[#172033] dark:text-white">
                    Haptic Feedback
                  </div>
                  <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    {haptics ? 'Vibration On' : 'Disabled'}
                  </div>
                </div>
                <Vibrate className={`w-5 h-5 ${haptics ? 'text-[#FFD700]' : 'text-[#64748B]'}`} />
              </button>

              {onToggleAnimations && (
                <button
                  type="button"
                  onClick={onToggleAnimations}
                  className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
                >
                  <div>
                    <div className="text-xs font-bold text-[#172033] dark:text-white">
                      Animations
                    </div>
                    <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                      {animationsEnabled ? 'Enabled (Smooth)' : 'Reduced Motion'}
                    </div>
                  </div>
                  <Sparkles
                    className={`w-5 h-5 ${animationsEnabled ? 'text-[#FFD700]' : 'text-[#64748B]'}`}
                  />
                </button>
              )}

              {setLanguage && (
                <button
                  type="button"
                  onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
                  className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
                >
                  <div>
                    <div className="text-xs font-bold text-[#172033] dark:text-white">Language</div>
                    <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                      {language === 'ur' ? 'اردو (Urdu)' : 'English (US)'}
                    </div>
                  </div>
                  <Globe className="w-5 h-5 text-[#D4AF37]" />
                </button>
              )}

              {onToggleAutoBackup && (
                <button
                  type="button"
                  onClick={onToggleAutoBackup}
                  className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#22C55E] transition-colors cursor-pointer text-left"
                >
                  <div>
                    <div className="text-xs font-bold text-[#172033] dark:text-white">
                      Auto Local Backup
                    </div>
                    <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] truncate">
                      {autoBackupEnabled
                        ? lastBackupAt
                          ? `Saved ${new Date(lastBackupAt).toLocaleTimeString()}`
                          : 'Enabled (Active)'
                        : 'Disabled'}
                    </div>
                  </div>
                  <Database
                    className={`w-5 h-5 ${autoBackupEnabled ? 'text-[#22C55E]' : 'text-[#64748B]'}`}
                  />
                </button>
              )}
            </div>

            {onOpenPinSetup && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenPinSetup();
                }}
                className="w-full p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
              >
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-[#FFD700]" />
                  <div>
                    <div className="text-xs font-bold text-[#172033] dark:text-white">
                      App Security PIN Lock
                    </div>
                    <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                      {hasPin
                        ? '4-Digit PIN active — tap to change or remove'
                        : 'Optional 4-digit passcode protection'}
                    </div>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#D4AF37]">
                  {hasPin ? 'Manage →' : 'Enable →'}
                </span>
              </button>
            )}

            {onUpdateBiometric && (
              <button
                type="button"
                onClick={() => void handleEnrollBiometric()}
                className="w-full p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between hover:border-[#D4AF37] transition-colors cursor-pointer text-left"
              >
                <div className="flex items-center gap-3">
                  <Fingerprint
                    className={`w-5 h-5 ${
                      biometricCredentialId ? 'text-[#22C55E]' : 'text-[#D4AF37]'
                    }`}
                  />
                  <div>
                    <div className="text-xs font-bold text-[#172033] dark:text-white">
                      Biometric Unlock (WebAuthn)
                    </div>
                    <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                      {biometricCredentialId
                        ? 'Enrolled on this device — tap to remove'
                        : isBiometricSupported()
                        ? 'Enable FaceID / Fingerprint unlock alongside PIN'
                        : 'Requires HTTPS & platform biometric authenticator'}
                    </div>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#D4AF37]">
                  {biometricCredentialId ? 'Disable' : 'Enroll →'}
                </span>
              </button>
            )}

            {bioMessage && (
              <div className="p-2.5 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-xs font-bold text-[#9A7B1C] dark:text-[#FFD700]">
                {bioMessage}
              </div>
            )}

            {/* Spectator Mode + Accessibility & Performance */}
            {(onToggleSpectatorMode || onUpdateAccessibility || onOpenTutorial) && (
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/25 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-[#D4AF37]" />
                    <span className="text-xs font-black text-[#172033] dark:text-white uppercase tracking-wider">
                      Spectator, Accessibility &amp; Guide
                    </span>
                  </div>
                </div>

                {onToggleSpectatorMode && (
                  <button
                    type="button"
                    onClick={onToggleSpectatorMode}
                    className={`w-full p-3 rounded-xl border flex items-center justify-between cursor-pointer text-left ${
                      spectatorMode
                        ? 'bg-[#22C55E]/15 border-[#22C55E]/50'
                        : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Eye className="w-4 h-4 text-[#22C55E]" />
                      <div>
                        <div className="text-xs font-bold text-[#172033] dark:text-white">
                          Public Spectator Mode
                        </div>
                        <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                          Hides finance, private contact info, and admin controls
                        </div>
                      </div>
                    </div>
                    <span className="text-[11px] font-black text-[#FFD700]">
                      {spectatorMode ? 'ON' : 'OFF'}
                    </span>
                  </button>
                )}

                {onUpdateAccessibility && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-bold text-[#172033] dark:text-white">Text Scale</span>
                      <div className="flex gap-1">
                        {(['sm', 'md', 'lg'] as const).map((sz) => (
                          <button
                            key={sz}
                            type="button"
                            onClick={() =>
                              onUpdateAccessibility({ ...accessibility, fontScale: sz })
                            }
                            className={`px-2.5 py-1 rounded-lg font-extrabold uppercase text-[10px] cursor-pointer ${
                              accessibility.fontScale === sz
                                ? 'bg-[#D4AF37] text-[#080808]'
                                : 'bg-white dark:bg-[#141414] text-[#64748B] dark:text-[#A0A0A0] border border-slate-200 dark:border-white/10'
                            }`}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateAccessibility({
                            ...accessibility,
                            highContrast: !accessibility.highContrast,
                          })
                        }
                        className={`p-2.5 rounded-xl border text-left cursor-pointer ${
                          accessibility.highContrast
                            ? 'bg-[#D4AF37]/20 border-[#FFD700]'
                            : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10'
                        }`}
                      >
                        <div className="text-[11px] font-bold text-[#172033] dark:text-white">
                          High Contrast
                        </div>
                        <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                          {accessibility.highContrast ? 'Enabled' : 'Standard'}
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          onUpdateAccessibility({
                            ...accessibility,
                            lowPerfMode: !accessibility.lowPerfMode,
                          })
                        }
                        className={`p-2.5 rounded-xl border text-left cursor-pointer ${
                          accessibility.lowPerfMode
                            ? 'bg-[#D4AF37]/20 border-[#FFD700]'
                            : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10'
                        }`}
                      >
                        <div className="text-[11px] font-bold text-[#172033] dark:text-white">
                          Battery / Low-Perf
                        </div>
                        <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                          {accessibility.lowPerfMode ? 'No Blur/Glow' : 'Full FX'}
                        </div>
                      </button>
                    </div>
                  </div>
                )}

                {onOpenTutorial && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenTutorial();
                    }}
                    className="w-full py-2.5 px-3 rounded-xl bg-white dark:bg-[#141414] border border-[#D4AF37]/40 text-xs font-bold text-[#172033] dark:text-[#FFD700] flex items-center justify-center gap-2 cursor-pointer hover:border-[#FFD700]"
                  >
                    <HelpCircle className="w-4 h-4" />
                    <span>Launch Interactive Quick Tour</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* SECTION 4: MATCH FORMAT & BWF RULES */}
          <div className="space-y-3 p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/30">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#D4AF37]" />
                <h3 className="text-xs font-black text-[#172033] dark:text-white uppercase tracking-wider">
                  Default Match Format &amp; BWF Rules
                </h3>
              </div>
              <span className="text-[11px] font-bold text-[#D4AF37]">Entire Tournament</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: 'bo1', label: 'Best of 1', sub: '1 Set Sprint' },
                  { id: 'bo3', label: 'Best of 3', sub: 'BWF Standard' },
                  { id: 'bo5', label: 'Best of 5', sub: 'Championship' },
                ] as const
              ).map((opt) => {
                const active = matchFormat === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setMatchFormat(opt.id)}
                    className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
                      active
                        ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] border-transparent shadow-md scale-[1.02]'
                        : 'bg-white dark:bg-[#141414] text-[#172033] dark:text-white border-slate-200 dark:border-white/10 hover:border-[#D4AF37]'
                    }`}
                  >
                    <div className="text-xs font-black whitespace-nowrap">{opt.label}</div>
                    <div className="text-[10px] mt-0.5 opacity-80 font-semibold">{opt.sub}</div>
                  </button>
                );
              })}
            </div>

            <div className="space-y-3 text-xs pt-2">
              <div className="p-3.5 rounded-2xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-[#172033] dark:text-white">
                      Points Per Game (11–21)
                    </span>
                    <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                      Interval at {intervalAt} pts &middot; Sudden-death cap {maxDeuceCap}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handlePointsChange(pointsPerSet - 1)}
                      disabled={pointsPerSet <= 11}
                      className="w-7 h-7 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 flex items-center justify-center text-[#172033] dark:text-white disabled:opacity-30 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-9 text-center font-mono font-black text-base text-[#172B4D] dark:text-[#FFD700]">
                      {pointsPerSet}
                    </span>
                    <button
                      type="button"
                      onClick={() => handlePointsChange(pointsPerSet + 1)}
                      disabled={pointsPerSet >= 21}
                      className="w-7 h-7 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 flex items-center justify-center text-[#172033] dark:text-white disabled:opacity-30 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <input
                  type="range"
                  min={11}
                  max={21}
                  step={1}
                  value={pointsPerSet}
                  onChange={(e) => handlePointsChange(Number(e.target.value))}
                  className="w-full accent-[#D4AF37] cursor-pointer"
                />

                <div className="flex items-center justify-between gap-1.5">
                  {[11, 13, 15, 18, 21].map((pts) => (
                    <button
                      key={pts}
                      type="button"
                      onClick={() => handlePointsChange(pts)}
                      className={`flex-1 py-1 rounded-lg font-extrabold text-[11px] cursor-pointer ${
                        pointsPerSet === pts
                          ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808]'
                          : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0]'
                      }`}
                    >
                      {pts} pts
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10">
                <div>
                  <span className="font-bold text-[#172033] dark:text-white">Max Deuce Cap</span>
                  <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Sudden-death ceiling
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {[15, 21, 25, 30].map((cap) => (
                    <button
                      key={cap}
                      type="button"
                      onClick={() => setMaxDeuceCap(Math.max(pointsPerSet + 2, cap))}
                      className={`px-2 py-1 rounded-lg font-extrabold text-xs cursor-pointer ${
                        maxDeuceCap === cap
                          ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                          : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0]'
                      }`}
                    >
                      {cap}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10">
                <span className="font-bold text-[#172033] dark:text-white shrink-0">
                  Chief Referee
                </span>
                <input
                  type="text"
                  value={refereeName}
                  onChange={(e) => setRefereeName(e.target.value)}
                  placeholder="Referee Name"
                  className="w-40 px-2.5 py-1 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white text-right focus:outline-none"
                />
              </div>
            </div>

            <button
              onClick={handleSaveRules}
              className="w-full py-2.5 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] font-black text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm"
            >
              {savedNotification ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Custom Rules Applied!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Save Rules to Active Tournament</span>
                </>
              )}
            </button>
          </div>

          {/* SECTION 5: QR TOOLS, PWA, ANDROID STUDIO & ABOUT */}
          <div className="space-y-3">
            <h3 className="text-xs font-extrabold text-[#64748B] dark:text-[#A0A0A0] uppercase tracking-wider">
              QR Codes, PWA, Mobile Package &amp; Info
            </h3>

            {(onOpenQRModal || onOpenAboutModal) && (
              <div className="grid grid-cols-2 gap-2.5">
                {onOpenQRModal && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenQRModal();
                    }}
                    className="p-3 rounded-2xl border border-[#D4AF37]/35 bg-[#D4AF37]/10 text-left flex items-center gap-2 cursor-pointer"
                  >
                    <QrCode className="w-4 h-4 text-[#FFD700]" />
                    <span className="text-xs font-bold text-[#172033] dark:text-white">
                      QR Code Center
                    </span>
                  </button>
                )}
                {onOpenAboutModal && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenAboutModal();
                    }}
                    className="p-3 rounded-2xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-left flex items-center gap-2 cursor-pointer"
                  >
                    <Info className="w-4 h-4 text-[#D4AF37]" />
                    <span className="text-xs font-bold text-[#172033] dark:text-white">
                      About the App
                    </span>
                  </button>
                )}
              </div>
            )}

            <div className="p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src="/logo.png"
                  alt="App Icon"
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-xl object-cover border border-[#D4AF37]/50 shrink-0"
                />
                <div className="min-w-0">
                  <div className="text-xs font-black text-[#172033] dark:text-white truncate">
                    Install Web App (PWA)
                  </div>
                  <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] truncate">
                    HTTPS &bull; Manifest &bull; Start URL: /
                  </div>
                </div>
              </div>
              <PWAInstallButton />
            </div>

            <button
              onClick={() => {
                onClose();
                onOpenAndroidModal();
              }}
              className="w-full p-3.5 rounded-2xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] hover:border-[#D4AF37] flex items-center justify-between transition-colors cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <Smartphone className="w-5 h-5 text-[#FFD700]" />
                <div>
                  <div className="text-xs font-bold text-[#172033] dark:text-white">
                    Android Studio Project ZIP
                  </div>
                  <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Kotlin &bull; Jetpack Compose &bull; Room DB &bull; PWABuilder Ready
                  </div>
                </div>
              </div>
              <span className="text-xs font-extrabold text-[#D4AF37]">Download &rarr;</span>
            </button>
          </div>

          {/* SECTION 6: RESET OPTIONS */}
          <div className="space-y-3">
            <h3 className="text-xs font-extrabold text-[#64748B] dark:text-[#A0A0A0] uppercase tracking-wider">
              Data Management &amp; Reset
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  onResetTournament();
                  onClose();
                }}
                disabled={userRoleMode === 'referee'}
                className="p-3 rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-left transition-colors cursor-pointer disabled:opacity-40"
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-[#172033] dark:text-white">
                  <RotateCcw className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Reset Scores</span>
                </div>
                <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] mt-1">
                  Clears match results, keeps players
                </div>
              </button>

              <button
                onClick={() => setConfirmFactoryResetOpen(true)}
                disabled={userRoleMode === 'referee'}
                className="p-3 rounded-2xl border border-[#EF4444]/40 bg-[#EF4444]/10 text-left transition-colors cursor-pointer disabled:opacity-40"
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-[#EF4444]">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Factory Reset</span>
                </div>
                <div className="text-[10px] text-[#EF4444]/80 mt-1">
                  {userRoleMode === 'referee'
                    ? 'Admin Mode required'
                    : 'Resets active tournament'}
                </div>
              </button>
            </div>
          </div>

          {/* Developer Attribution Card */}
          <div className="rounded-2xl bg-gradient-to-r from-[#080808] to-[#141414] border border-[#D4AF37]/40 p-4 text-white text-center space-y-1 shadow-inner">
            <div className="text-xs text-[#A0A0A0] font-medium">Software Engineering</div>
            <div className="text-base font-black text-[#FFD700]">Developed By Hassan</div>
            <div className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider">
              Hassan developers
            </div>
            <p className="text-[10px] text-[#A0A0A0] pt-1">
              Hassan Badminton Tournament Manager &bull; Black + Gold Edition
            </p>
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={confirmFactoryResetOpen}
        title="Factory Reset Tournament?"
        message="This will reset players, match records, custom scores, and branding for the active tournament back to default. This cannot be undone."
        confirmText="Factory Reset"
        cancelText="Cancel"
        type="danger"
        onConfirm={() => {
          setConfirmFactoryResetOpen(false);
          onResetAll();
          onClose();
        }}
        onCancel={() => setConfirmFactoryResetOpen(false)}
      />
    </div>
  );
};
