import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Search,
  X,
  Trophy,
  Users,
  Calendar,
  Palette,
  Zap,
  ArrowRight,
  BookOpen,
  Megaphone,
  Compass,
} from 'lucide-react';
import {
  TournamentState,
  TournamentMatch,
  QuickMatchRecord,
} from '../types';
import { PREMIUM_THEMES } from '../utils/themes';
import { getPlayerCode, getPlayerColor, getInitials } from '../utils/tournament';
import { AppTab } from './Header';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournaments: TournamentState[];
  activeTournament: TournamentState;
  fixtures: TournamentMatch[];
  quickMatches: QuickMatchRecord[];
  onSelectTournament: (id: string, tab?: 'dashboard' | 'matches' | 'knockout') => void;
  onOpenPlayerProfile: (playerId: number) => void;
  onLaunchLiveMatch: (matchId: string) => void;
  onSelectTheme: (themeId: string) => void;
  onNavigateTab: (tab: AppTab) => void;
  onOpenQuickMatch: () => void;
}

const RULE_SNIPPETS = [
  {
    id: 'rule-21',
    title: 'Adjustable 11–21 Point Rally Scoring & 30-Pt Deuce Cap',
    detail: 'Every rally scores a point. At 20-20 (or N-1 tie), a 2-point lead wins up to the deuce cap.',
  },
  {
    id: 'rule-service',
    title: 'Service Court Rotation (Even = Right, Odd = Left)',
    detail: 'Server serves from the Right box on even scores (0, 2, 4...) and Left box on odd scores.',
  },
  {
    id: 'rule-interval',
    title: 'Mid-Game Interval & Change of Ends',
    detail: '60s break at mid-game interval (e.g. 11 pts) and 120s break between sets with end change.',
  },
  {
    id: 'rule-format',
    title: 'Best of 1, Best of 3, and Best of 5 Match Formats',
    detail: 'Configure format globally in Settings or per individual fixture & playoff tie.',
  },
];

const APP_SECTIONS: Array<{ id: AppTab; title: string; keywords: string; subtitle: string }> = [
  { id: 'live', title: 'Live Court Scoreboard', keywords: 'live score rally referee court timer', subtitle: 'BWF 21-pt scorer & Big Screen TV mode' },
  { id: 'venue', title: 'Venue GPS Map & Directions', keywords: 'map google venue location gps directions pin', subtitle: 'Pin tournament hall & share directions' },
  { id: 'news', title: 'World Badminton News', keywords: 'news bwf articles rankings headlines online', subtitle: 'Live international BWF news feed' },
  { id: 'studio', title: 'Media & Design Studio', keywords: 'poster certificate graphic studio share social', subtitle: 'Generate posters, scorecards & certificates' },
  { id: 'finance', title: 'Tournament Finance Ledger', keywords: 'finance money fee prize sponsor expense receipt', subtitle: 'Track entry fees, sponsors, prizes & expenses' },
  { id: 'admin', title: 'Admin & Automation Center', keywords: 'admin audit auto schedule bulk csv backup database', subtitle: 'Auto-schedule, audit log & DB health check' },
  { id: 'rankings', title: 'World & Club Rankings', keywords: 'rankings leaderboard mvp streak points', subtitle: 'Global, Singles, Doubles, Club & Annual tables' },
  { id: 'courts', title: 'Multi-Court Manager', keywords: 'courts referee queue assign schedule', subtitle: 'Manage courts & transfer live matches' },
];

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  tournaments,
  activeTournament,
  fixtures,
  quickMatches,
  onSelectTournament,
  onOpenPlayerProfile,
  onLaunchLiveMatch,
  onSelectTheme,
  onNavigateTab,
  onOpenQuickMatch,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setTimeout(() => inputRef.current?.focus(), 40);
    }
  }, [isOpen]);

  const q = query.trim().toLowerCase();

  const matchedPlayers = useMemo(() => {
    return activeTournament.players
      .map((name, idx) => ({ name, idx, code: getPlayerCode(idx) }))
      .filter(
        (p) =>
          !q ||
          p.name.toLowerCase().includes(q) ||
          p.code.toLowerCase().includes(q)
      )
      .slice(0, 6);
  }, [activeTournament.players, q]);

  const matchedTournaments = useMemo(() => {
    return tournaments
      .filter(
        (t) =>
          !q ||
          t.tournamentTitle.toLowerCase().includes(q) ||
          (t.venue || '').toLowerCase().includes(q)
      )
      .slice(0, 5);
  }, [tournaments, q]);

  const matchedFixtures = useMemo(() => {
    return fixtures
      .filter((m) => {
        const a = activeTournament.players[m.playerAIndex] || '';
        const b = activeTournament.players[m.playerBIndex] || '';
        return (
          !q ||
          a.toLowerCase().includes(q) ||
          b.toLowerCase().includes(q) ||
          `match #${m.roundNumber || ''}`.includes(q)
        );
      })
      .slice(0, 5);
  }, [fixtures, activeTournament.players, q]);

  const matchedThemes = useMemo(() => {
    if (!q) return [];
    return PREMIUM_THEMES.filter(
      (th) =>
        th.name.toLowerCase().includes(q) ||
        th.category.toLowerCase().includes(q)
    ).slice(0, 5);
  }, [q]);

  const matchedQuickMatches = useMemo(() => {
    if (!q) return quickMatches.slice(0, 2);
    return quickMatches
      .filter(
        (qm) =>
          qm.title.toLowerCase().includes(q) ||
          qm.playerAName.toLowerCase().includes(q) ||
          qm.playerBName.toLowerCase().includes(q)
      )
      .slice(0, 3);
  }, [quickMatches, q]);

  const matchedAnnouncements = useMemo(() => {
    const items = activeTournament.announcements || [];
    if (!q) return items.slice(0, 2);
    return items.filter((a) => a.text.toLowerCase().includes(q)).slice(0, 3);
  }, [activeTournament.announcements, q]);

  const matchedRules = useMemo(() => {
    if (!q) return [];
    return RULE_SNIPPETS.filter(
      (r) =>
        r.title.toLowerCase().includes(q) || r.detail.toLowerCase().includes(q)
    );
  }, [q]);

  const matchedSections = useMemo(() => {
    if (!q) return APP_SECTIONS.slice(0, 4);
    return APP_SECTIONS.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.keywords.toLowerCase().includes(q) ||
        s.subtitle.toLowerCase().includes(q)
    );
  }, [q]);

  if (!isOpen) return null;

  const hasAny =
    matchedSections.length > 0 ||
    matchedPlayers.length > 0 ||
    matchedTournaments.length > 0 ||
    matchedFixtures.length > 0 ||
    matchedThemes.length > 0 ||
    matchedQuickMatches.length > 0 ||
    matchedAnnouncements.length > 0 ||
    matchedRules.length > 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:pt-16 bg-[#07111F]/80 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-[#111E30] w-full max-w-2xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-fade-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3 bg-[#F4F7FB] dark:bg-[#07111F]">
          <Search className="w-5 h-5 text-[#8BCB35] dark:text-[#B7F34A] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onClose();
            }}
            placeholder="Search players, #SC-ID, fixtures, tournaments, 120+ themes, rules..."
            className="flex-1 bg-transparent text-sm sm:text-base font-bold text-[#172033] dark:text-white placeholder:text-[#64748B] dark:placeholder:text-[#94A3B8] focus:outline-none"
          />
          <kbd className="hidden sm:inline-block px-2 py-0.5 rounded bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 text-[10px] font-mono text-[#64748B]">
            ESC
          </kbd>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#64748B] hover:text-[#172033] dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 cursor-pointer"
            aria-label="Close Search"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results Body */}
        <div className="max-h-[70vh] overflow-y-auto p-4 space-y-5">
          {!hasAny && (
            <div className="py-10 text-center text-sm text-[#64748B] dark:text-[#94A3B8]">
              No matches found for &ldquo;<strong className="text-[#172033] dark:text-white">{query}</strong>&rdquo;. Try searching a player name, match, venue, news, finance, or theme.
            </div>
          )}

          {/* Quick Jump Hubs */}
          {matchedSections.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <Compass className="w-3.5 h-3.5 text-[#FFD700]" />
                <span>App Hubs &amp; Tools</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {matchedSections.map((sec) => (
                  <button
                    key={sec.id}
                    type="button"
                    onClick={() => {
                      onNavigateTab(sec.id);
                      onClose();
                    }}
                    className="p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 hover:border-[#D4AF37] flex items-center justify-between gap-2 text-left cursor-pointer"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-[#172033] dark:text-white truncate">
                        {sec.title}
                      </div>
                      <div className="text-[10px] text-[#64748B] dark:text-[#94A3B8] truncate">
                        {sec.subtitle}
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Players */}
          {matchedPlayers.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <Users className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Players ({matchedPlayers.length})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {matchedPlayers.map((p) => {
                  const photo = activeTournament.playerPhotos?.[p.idx];
                  return (
                    <button
                      key={p.idx}
                      type="button"
                      onClick={() => {
                        onOpenPlayerProfile(p.idx);
                        onClose();
                      }}
                      className="p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 hover:border-[#B7F34A] flex items-center justify-between gap-2 text-left cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {photo ? (
                          <img
                            src={photo}
                            alt={p.name}
                            className="w-8 h-8 rounded-xl object-cover shrink-0"
                          />
                        ) : (
                          <div
                            className="w-8 h-8 rounded-xl flex items-center justify-center text-[#07111F] font-black text-xs shrink-0"
                            style={{ backgroundColor: getPlayerColor(p.idx) }}
                          >
                            {getInitials(p.name)}
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="text-xs font-black text-[#172033] dark:text-white truncate">
                            {p.name}
                          </div>
                          <div className="text-[10px] font-mono text-[#38BDF8]">
                            {p.code}
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-[#64748B] shrink-0" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Fixtures */}
          {matchedFixtures.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <Calendar className="w-3.5 h-3.5 text-[#B7F34A]" />
                <span>Fixtures — Tap to Score Live</span>
              </div>
              <div className="space-y-1.5">
                {matchedFixtures.map((m, idx) => {
                  const isDone = activeTournament.results[m.id] !== undefined;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        onLaunchLiveMatch(m.id);
                        onClose();
                      }}
                      className="w-full p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 hover:border-[#38BDF8] flex items-center justify-between gap-2 text-left cursor-pointer"
                    >
                      <div className="min-w-0">
                        <div className="text-[10px] font-mono text-[#38BDF8]">
                          Match #{m.roundNumber || idx + 1}
                          {m.group ? ` · Group ${m.group}` : ''}
                        </div>
                        <div className="text-xs font-bold text-[#172033] dark:text-white truncate">
                          {activeTournament.players[m.playerAIndex]} vs{' '}
                          {activeTournament.players[m.playerBIndex]}
                        </div>
                      </div>
                      <span
                        className={`text-[10px] font-extrabold px-2 py-0.5 rounded-lg shrink-0 ${
                          isDone
                            ? 'bg-[#22C55E]/15 text-[#22C55E]'
                            : 'bg-[#B7F34A] text-[#07111F]'
                        }`}
                      >
                        {isDone ? 'Completed' : 'Score Live'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tournaments */}
          {matchedTournaments.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <Trophy className="w-3.5 h-3.5 text-[#B7F34A]" />
                <span>Tournaments ({matchedTournaments.length})</span>
              </div>
              <div className="space-y-1.5">
                {matchedTournaments.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => {
                      if (t.id) onSelectTournament(t.id, 'dashboard');
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 hover:border-[#B7F34A] flex items-center justify-between gap-2 text-left cursor-pointer"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-black text-[#172033] dark:text-white truncate">
                        {t.tournamentTitle}
                      </div>
                      <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8] truncate">
                        {t.venue || 'Center Arena'} · {t.players.length} players
                      </div>
                    </div>
                    {t.id === activeTournament.id && (
                      <span className="text-[10px] font-black text-[#8BCB35] dark:text-[#B7F34A] shrink-0">
                        Active
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quick Matches */}
          {matchedQuickMatches.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <Zap className="w-3.5 h-3.5 text-[#B7F34A]" />
                <span>Quick Matches</span>
              </div>
              <div className="space-y-1.5">
                {matchedQuickMatches.map((qm) => (
                  <button
                    key={qm.id}
                    type="button"
                    onClick={() => {
                      onOpenQuickMatch();
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 hover:border-[#B7F34A] flex items-center justify-between gap-2 text-left cursor-pointer"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-[#172033] dark:text-white truncate">
                        {qm.playerAName} vs {qm.playerBName}
                      </div>
                      <div className="text-[10px] font-mono text-[#64748B] dark:text-[#94A3B8]">
                        {qm.setScores.map((s) => `${s.a}-${s.b}`).join(', ')}
                      </div>
                    </div>
                    <span className="text-[10px] font-black text-[#22C55E] shrink-0">
                      {qm.winner === 'A' ? qm.playerAName : qm.playerBName}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Announcements */}
          {matchedAnnouncements.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <Megaphone className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Tournament Notice Board</span>
              </div>
              <div className="space-y-1.5">
                {matchedAnnouncements.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => {
                      onNavigateTab('dashboard');
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 text-left text-xs font-semibold text-[#172033] dark:text-white cursor-pointer"
                  >
                    {a.text}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Dynamic Themes */}
          {matchedThemes.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <Palette className="w-3.5 h-3.5 text-[#B7F34A]" />
                <span>120+ Dynamic Themes — Tap to Apply</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {matchedThemes.map((th) => (
                  <button
                    key={th.id}
                    type="button"
                    onClick={() => {
                      onSelectTheme(th.id);
                      onClose();
                    }}
                    className="p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 hover:border-[#B7F34A] flex items-center justify-between gap-2 text-left cursor-pointer"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-5 h-5 rounded-full border border-white/20 shrink-0"
                        style={{ backgroundColor: th.accentPrimary }}
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-[#172033] dark:text-white truncate">
                          {th.name}
                        </div>
                        <div className="text-[10px] text-[#64748B] dark:text-[#94A3B8]">
                          {th.category} · {th.mode}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-extrabold text-[#38BDF8] shrink-0">
                      Apply
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* How to Play Rules */}
          {matchedRules.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5 px-1">
                <BookOpen className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Badminton Rules &amp; How to Play</span>
              </div>
              <div className="space-y-1.5">
                {matchedRules.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      onNavigateTab('history');
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 text-left cursor-pointer"
                  >
                    <div className="text-xs font-bold text-[#172033] dark:text-white">
                      {r.title}
                    </div>
                    <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8] mt-0.5">
                      {r.detail}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
