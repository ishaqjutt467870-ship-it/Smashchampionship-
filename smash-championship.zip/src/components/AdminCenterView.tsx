import React, { useMemo, useState } from 'react';
import {
  ShieldCheck,
  UserPlus,
  History,
  Zap,
  Database,
  CheckCircle2,
  AlertTriangle,
  Download,
  Upload,
  Trash2,
  Clock,
} from 'lucide-react';
import {
  AdminAccount,
  AdminAuditLog,
  CourtRecord,
  MatchScheduleInfo,
  TournamentMatch,
  TournamentState,
  TournamentStore,
} from '../types';
import { autoScheduleMatches, runDatabaseHealthCheck } from '../utils/tournament';
import { downloadPlayerBulkCSV } from '../utils/exports';

interface AdminCenterViewProps {
  store: TournamentStore;
  activeTournament: TournamentState;
  fixtures: TournamentMatch[];
  courts: CourtRecord[];
  onAddAdminAccount: (name: string, role: AdminAccount['role']) => void;
  onSwitchActiveAdmin: (name: string) => void;
  onDeleteAdminAccount: (id: string) => void;
  onApplyAutoSchedule: (
    schedules: Record<string, MatchScheduleInfo>,
    assignedCount: number
  ) => void;
  onBulkImportPlayers: (names: string[]) => void;
  onDeduplicatePlayers: () => void;
  onClearAuditLogs: () => void;
}

export const AdminCenterView: React.FC<AdminCenterViewProps> = ({
  store,
  activeTournament,
  fixtures,
  courts,
  onAddAdminAccount,
  onSwitchActiveAdmin,
  onDeleteAdminAccount,
  onApplyAutoSchedule,
  onBulkImportPlayers,
  onDeduplicatePlayers,
  onClearAuditLogs,
}) => {
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<AdminAccount['role']>('referee');
  const [slotMinutes, setSlotMinutes] = useState<number>(25);
  const [autoMsg, setAutoMsg] = useState<string>('');
  const [bulkText, setBulkText] = useState('');
  const [bulkNotice, setBulkNotice] = useState('');

  const health = useMemo(() => runDatabaseHealthCheck(store), [store]);

  const adminAccounts = store.adminAccounts || [];
  const auditLogs: AdminAuditLog[] = store.auditLogs || [];

  const handleCreateAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    onAddAdminAccount(newName.trim(), newRole);
    setNewName('');
  };

  const handleRunAutoSchedule = () => {
    const res = autoScheduleMatches(
      fixtures,
      activeTournament.results,
      courts,
      activeTournament.referees || ['Hassan (Chief Referee)'],
      activeTournament.players,
      activeTournament.matchSchedules || {},
      slotMinutes
    );
    onApplyAutoSchedule(res.schedules, res.assignedCount);
    setAutoMsg(
      res.assignedCount > 0
        ? `Auto-scheduled ${res.assignedCount} pending matches across ${courts.length} courts (~${res.estimatedMinutes} min). ${
            res.conflicts.length === 0
              ? 'Zero rest conflicts!'
              : `${res.conflicts.length} tight turnarounds flagged.`
          }`
        : 'All playable matches are already completed.'
    );
  };

  const handleBulkAdd = () => {
    const names = bulkText
      .split(/[\n,;]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (names.length === 0) return;
    onBulkImportPlayers(names);
    setBulkText('');
    setBulkNotice(`Added ${names.length} players into ${activeTournament.tournamentTitle}.`);
    setTimeout(() => setBulkNotice(''), 3000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="theme-card rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center shrink-0 shadow-lg">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#172033] dark:text-white">
              Administration, Automation & Health Center
            </h2>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-1">
              Manage multiple officials & admin operators, run conflict-free automatic match scheduling, inspect database integrity, and review audit logs.
            </p>
          </div>
        </div>
        <div className="px-3.5 py-2 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/35 text-xs font-black text-[#FFD700]">
          Active Operator: {store.activeAdminName || 'Hassan'}
        </div>
      </div>

      {/* Top Row: Automation Engine + Database Health */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Automation Engine */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-[#FFD700]" />
              <h3 className="text-base font-black text-[#172033] dark:text-white">
                Match Automation & Conflict Scheduler
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#D4AF37]">
              {courts.length} Courts
            </span>
          </div>
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
            Automatically assigns pending matches to open courts and referees in waves that maximize player recovery intervals.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#D4AF37]" />
              <span>Slot Duration (min):</span>
              <input
                type="number"
                min={10}
                max={90}
                value={slotMinutes}
                onChange={(e) => setSlotMinutes(Math.max(10, Number(e.target.value) || 25))}
                className="w-20 px-2.5 py-1.5 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-mono text-[#172033] dark:text-white"
              />
            </label>

            <button
              type="button"
              onClick={handleRunAutoSchedule}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center gap-2 shadow-md cursor-pointer"
            >
              <Zap className="w-4 h-4" />
              <span>Auto-Schedule Pending Matches</span>
            </button>
          </div>

          {autoMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs font-semibold text-emerald-500">
              {autoMsg}
            </div>
          )}
        </div>

        {/* Database Health Check */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-[#D4AF37]" />
              <h3 className="text-base font-black text-[#172033] dark:text-white">
                Local Database Health Check
              </h3>
            </div>
            <span
              className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-1 ${
                health.healthy
                  ? 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/30'
                  : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
              }`}
            >
              {health.healthy ? (
                <CheckCircle2 className="w-3.5 h-3.5" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5" />
              )}
              <span>{health.healthy ? 'Healthy' : 'Attention'}</span>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
            <div className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808]">
              <p className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] font-bold">Tournaments</p>
              <p className="text-lg font-black text-[#172033] dark:text-white font-mono">
                {health.tournamentCount}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808]">
              <p className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] font-bold">Total Players</p>
              <p className="text-lg font-black text-[#172033] dark:text-white font-mono">
                {health.totalPlayers}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808]">
              <p className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] font-bold">Completed</p>
              <p className="text-lg font-black text-[#FFD700] font-mono">
                {health.completedMatches}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808]">
              <p className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] font-bold">Storage</p>
              <p className="text-lg font-black text-emerald-500 font-mono">
                {health.storageUsedKB} KB
              </p>
            </div>
          </div>

          {health.duplicateRosters.length > 0 && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-2 text-xs">
              <span className="text-amber-400 font-semibold">
                Duplicates found in:{' '}
                {health.duplicateRosters
                  .map((d) => `${d.tournamentTitle} (${d.duplicates.join(', ')})`)
                  .join('; ')}
              </span>
              <button
                type="button"
                onClick={onDeduplicatePlayers}
                className="px-3 py-1 rounded-lg bg-amber-500 text-[#080808] font-black text-[11px] shrink-0 cursor-pointer"
              >
                Clean Duplicates
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Middle Row: Multi-Admin RBAC + Bulk Import/Export */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Multi-Admin Accounts */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Admin & Official Accounts
            </h3>
          </div>

          <form onSubmit={handleCreateAdmin} className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Officer name (e.g. Coach Bilal)"
              className="flex-1 px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs text-[#172033] dark:text-white"
            />
            <select
              value={newRole}
              onChange={(e) => setNewRole(e.target.value as AdminAccount['role'])}
              className="px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs font-bold text-[#172033] dark:text-white"
            >
              <option value="organizer">Organizer</option>
              <option value="admin">Admin</option>
              <option value="referee">Referee</option>
            </select>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs cursor-pointer"
            >
              Add
            </button>
          </form>

          <div className="space-y-2 max-h-56 overflow-y-auto">
            {adminAccounts.map((acc) => {
              const isCurrent = store.activeAdminName === acc.name;
              return (
                <div
                  key={acc.id}
                  className={`p-3 rounded-xl border flex items-center justify-between gap-2 ${
                    isCurrent
                      ? 'bg-[#D4AF37]/15 border-[#FFD700]'
                      : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200 dark:border-white/10'
                  }`}
                >
                  <div>
                    <p className="text-xs font-black text-[#172033] dark:text-white">{acc.name}</p>
                    <p className="text-[10px] uppercase font-bold text-[#D4AF37]">{acc.role}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {!isCurrent && (
                      <button
                        type="button"
                        onClick={() => onSwitchActiveAdmin(acc.name)}
                        className="px-2.5 py-1 rounded-lg bg-[#D4AF37]/20 text-[#FFD700] text-[10px] font-black cursor-pointer"
                      >
                        Switch
                      </button>
                    )}
                    {adminAccounts.length > 1 && (
                      <button
                        type="button"
                        onClick={() => onDeleteAdminAccount(acc.id)}
                        className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/15 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bulk Import & Export Players */}
        <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-[#D4AF37]" />
              <h3 className="text-base font-black text-[#172033] dark:text-white">
                Bulk Player Import & Export
              </h3>
            </div>
            <button
              type="button"
              onClick={() => downloadPlayerBulkCSV(activeTournament)}
              className="px-3 py-1.5 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/35 text-[#FFD700] text-[11px] font-black flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Roster CSV</span>
            </button>
          </div>

          <textarea
            rows={4}
            value={bulkText}
            onChange={(e) => setBulkText(e.target.value)}
            placeholder="Paste player names separated by new lines or commas (e.g. Hamza Khan, Usman Tariq, Bilal Ahmed)..."
            className="w-full p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/30 text-xs text-[#172033] dark:text-white"
          />

          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={handleBulkAdd}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs cursor-pointer"
            >
              Import to Active Roster
            </button>
            {bulkNotice && <span className="text-xs font-bold text-emerald-500">{bulkNotice}</span>}
          </div>
        </div>
      </div>

      {/* Audit Log Viewer */}
      <div className="theme-card rounded-3xl p-6 border border-[#D4AF37]/30 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Administrative Activity Audit Log ({auditLogs.length})
            </h3>
          </div>
          {auditLogs.length > 0 && (
            <button
              type="button"
              onClick={onClearAuditLogs}
              className="px-3 py-1.5 rounded-lg bg-rose-500/10 text-rose-500 border border-rose-500/25 text-xs font-bold cursor-pointer"
            >
              Clear Logs
            </button>
          )}
        </div>

        {auditLogs.length === 0 ? (
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
            Actions like creating tournaments, saving scores, verification locks, and auto-scheduling are recorded here automatically.
          </p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs"
              >
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#D4AF37] font-black text-[10px]">
                    {log.actor}
                  </span>
                  <span className="font-bold text-[#172033] dark:text-white">{log.action}</span>
                  <span className="text-[#64748B] dark:text-[#A0A0A0]">· {log.target}</span>
                </div>
                <span className="font-mono text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                  {new Date(log.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
