import React, { useState, useEffect } from 'react';
import {
  X,
  UserPlus,
  Mail,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  RefreshCw,
  LogOut,
  UserCheck,
  KeyRound,
} from 'lucide-react';
import { UserAccount } from '../types';

interface AuthSignUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  userAccount: UserAccount | null;
  onSaveAccount: (account: UserAccount | null) => void;
}

const COUNTRY_CODES = [
  { code: '+92', label: 'PK +92' },
  { code: '+1', label: 'US +1' },
  { code: '+44', label: 'UK +44' },
  { code: '+971', label: 'UAE +971' },
  { code: '+91', label: 'IN +91' },
  { code: '+60', label: 'MY +60' },
  { code: '+65', label: 'SG +65' },
  { code: '+62', label: 'ID +62' },
];

export const AuthSignUpModal: React.FC<AuthSignUpModalProps> = ({
  isOpen,
  onClose,
  userAccount,
  onSaveAccount,
}) => {
  const [step, setStep] = useState<'form' | 'verify' | 'profile'>(
    userAccount?.verified ? 'profile' : 'form'
  );
  const [name, setName] = useState(userAccount?.name || '');
  const [method, setMethod] = useState<'email' | 'mobile'>(userAccount?.method || 'email');
  const [email, setEmail] = useState(userAccount?.email || '');
  const [countryCode, setCountryCode] = useState('+92');
  const [mobileNumber, setMobileNumber] = useState('');
  const [role, setRole] = useState<'Organizer' | 'Referee' | 'Player'>(
    userAccount?.role || 'Organizer'
  );

  const [generatedOtp, setGeneratedOtp] = useState('');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [resendSeconds, setResendSeconds] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setStep(userAccount?.verified ? 'profile' : 'form');
      setError(null);
      setEnteredOtp('');
    }
  }, [isOpen, userAccount?.verified]);

  useEffect(() => {
    if (resendSeconds <= 0) return;
    const timer = setInterval(() => {
      setResendSeconds((s) => Math.max(0, s - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendSeconds]);

  if (!isOpen) return null;

  const generateCode = () => {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    setGeneratedOtp(code);
    setResendSeconds(60);
    setEnteredOtp('');
  };

  const handleSendVerification = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (cleanName.length < 2) {
      setError('Please enter your full name (at least 2 characters).');
      return;
    }

    if (method === 'email') {
      const cleanEmail = email.trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        setError('Please enter a valid email address.');
        return;
      }
    } else {
      const digits = mobileNumber.replace(/\D/g, '');
      if (digits.length < 7 || digits.length > 14) {
        setError('Please enter a valid mobile number (7–14 digits).');
        return;
      }
    }

    setError(null);
    generateCode();
    setStep('verify');
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredOtp.trim() !== generatedOtp) {
      setError('Invalid 6-digit verification code. Please check the code and try again.');
      return;
    }

    const fullMobile = `${countryCode} ${mobileNumber.trim()}`;
    const newAccount: UserAccount = {
      id: `usr-${Date.now()}`,
      name: name.trim(),
      method,
      email: method === 'email' ? email.trim() : undefined,
      mobile: method === 'mobile' ? fullMobile : undefined,
      role,
      verified: true,
      verifiedAt: new Date().toISOString(),
    };
    onSaveAccount(newAccount);
    setError(null);
    setStep('profile');
  };

  const targetDestination =
    method === 'email' ? email.trim() : `${countryCode} ${mobileNumber.trim()}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#07111F]/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-md bg-white dark:bg-[#111E30] rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 my-6 overflow-hidden animate-fade-in">
        {/* Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-[#F4F7FB] dark:bg-[#07111F]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[#B7F34A]/15 border border-[#B7F34A]/40 flex items-center justify-center text-[#172B4D] dark:text-[#B7F34A]">
              {step === 'profile' ? (
                <UserCheck className="w-5 h-5" />
              ) : (
                <UserPlus className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-base font-black text-[#172033] dark:text-white">
                {step === 'profile'
                  ? 'Verified Account'
                  : step === 'verify'
                  ? 'Verify Your Identity'
                  : 'Create Verified Account'}
              </h2>
              <p className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                Sign up with Name &amp; Email or Mobile OTP
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-[#64748B] hover:text-[#172033] dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {step === 'form' && (
            <form onSubmit={handleSendVerification} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Hassan Raza"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 text-sm font-semibold text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#B7F34A]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                  Verify With
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setMethod('email');
                      setError(null);
                    }}
                    className={`py-2 px-3 rounded-lg text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      method === 'email'
                        ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                        : 'text-[#64748B] dark:text-[#94A3B8]'
                    }`}
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Email Address</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMethod('mobile');
                      setError(null);
                    }}
                    className={`py-2 px-3 rounded-lg text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      method === 'mobile'
                        ? 'bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F]'
                        : 'text-[#64748B] dark:text-[#94A3B8]'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>Mobile Number</span>
                  </button>
                </div>
              </div>

              {method === 'email' ? (
                <div>
                  <label className="text-xs font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 text-sm font-semibold text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#B7F34A]"
                  />
                </div>
              ) : (
                <div>
                  <label className="text-xs font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                    Mobile Number
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="px-2.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#172033] dark:text-white focus:outline-none"
                    >
                      {COUNTRY_CODES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                    <input
                      type="tel"
                      required
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      placeholder="300 1234567"
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 text-sm font-semibold text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#B7F34A]"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                  Tournament Role
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Organizer', 'Referee', 'Player'] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={`py-2 rounded-xl border text-xs font-bold cursor-pointer transition-colors ${
                        role === r
                          ? 'bg-[#38BDF8]/15 border-[#38BDF8] text-[#0284C7] dark:text-[#38BDF8]'
                          : 'bg-[#F4F7FB] dark:bg-[#07111F] border-slate-200 dark:border-slate-800 text-[#64748B] dark:text-[#94A3B8]'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              {error && (
                <div className="p-3 rounded-xl bg-[#EF4444]/10 border border-[#EF4444]/30 text-xs font-semibold text-[#EF4444]">
                  {error}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg hover:opacity-95 cursor-pointer"
              >
                <span>Send Verification Code</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {step === 'verify' && (
            <form onSubmit={handleVerifyCode} className="space-y-4">
              {/* Instant Verification Code Delivery Card */}
              <div className="p-3.5 rounded-2xl bg-[#38BDF8]/10 border border-[#38BDF8]/30 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-black text-[#0284C7] dark:text-[#38BDF8] flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Verification Code Sent</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setEnteredOtp(generatedOtp)}
                    className="text-[11px] font-extrabold text-[#172B4D] dark:text-[#B7F34A] hover:underline cursor-pointer"
                  >
                    Auto-Fill
                  </button>
                </div>
                <p className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">
                  Sent to <strong className="text-[#172033] dark:text-white">{targetDestination}</strong>.
                  Enter the 6-digit verification code below:
                </p>
                <div className="py-1.5 px-3 rounded-xl bg-white dark:bg-[#07111F] border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-[#64748B] dark:text-[#94A3B8]">Your Code:</span>
                  <span className="font-mono font-black text-base tracking-[0.25em] text-[#172B4D] dark:text-[#B7F34A]">
                    {generatedOtp}
                  </span>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#64748B] dark:text-[#94A3B8] block mb-1.5">
                  6-Digit Verification Code
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-[#64748B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    required
                    value={enteredOtp}
                    onChange={(e) => {
                      setEnteredOtp(e.target.value.replace(/\D/g, '').slice(0, 6));
                      if (error) setError(null);
                    }}
                    placeholder="Enter 6-digit OTP"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 text-center font-mono text-lg font-black tracking-[0.35em] text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#B7F34A]"
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 rounded-xl bg-[#EF4444]/10 border border-[#EF4444]/30 text-xs font-semibold text-[#EF4444]">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={enteredOtp.length !== 6}
                className="w-full py-3 rounded-xl bg-[#22C55E] hover:opacity-95 disabled:opacity-40 text-[#07111F] font-black text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Verify &amp; Activate Account</span>
              </button>

              <div className="flex items-center justify-between text-xs pt-1">
                <button
                  type="button"
                  onClick={() => setStep('form')}
                  className="text-[#64748B] dark:text-[#94A3B8] hover:text-[#172033] dark:hover:text-white font-semibold cursor-pointer"
                >
                  &larr; Edit {method === 'email' ? 'Email' : 'Mobile'}
                </button>
                <button
                  type="button"
                  disabled={resendSeconds > 0}
                  onClick={generateCode}
                  className="text-[#38BDF8] disabled:opacity-50 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>{resendSeconds > 0 ? `Resend in ${resendSeconds}s` : 'Resend Code'}</span>
                </button>
              </div>
            </form>
          )}

          {step === 'profile' && userAccount && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#22C55E]/10 border border-[#22C55E]/30 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-[#22C55E] text-[#07111F] flex items-center justify-center font-black text-lg shrink-0">
                  {userAccount.name.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-black text-base text-[#172033] dark:text-white truncate">
                      {userAccount.name}
                    </span>
                    <CheckCircle2 className="w-4 h-4 text-[#22C55E] shrink-0" />
                  </div>
                  <div className="text-xs text-[#64748B] dark:text-[#94A3B8] truncate">
                    {userAccount.email || userAccount.mobile}
                  </div>
                  <div className="text-[11px] font-bold text-[#22C55E] mt-0.5">
                    Verified {userAccount.role} &middot;{' '}
                    {new Date(userAccount.verifiedAt).toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setStep('form')}
                  className="py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#172033] dark:text-white hover:border-[#38BDF8] cursor-pointer"
                >
                  Update / Re-verify
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSaveAccount(null);
                    setStep('form');
                  }}
                  className="py-2.5 px-3 rounded-xl border border-[#EF4444]/40 bg-[#EF4444]/10 text-[#EF4444] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
