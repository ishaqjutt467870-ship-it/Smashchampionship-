import React, { useRef, useState } from 'react';
import {
  X,
  Printer,
  Award,
  Trophy,
  Download,
  MapPin,
  Calendar,
  UserCheck,
  FileText,
  Copy,
  Check,
  FileJson,
  FileArchive,
  Image as ImageIcon,
} from 'lucide-react';
import { TournamentState, PlayerStats, TournamentMatch } from '../types';
import {
  calculateTournamentAwards,
  formatScore,
  getTournamentFormatLabel,
} from '../utils/tournament';
import {
  downloadStandingsCSV,
  downloadMatchesCSV,
  downloadTournamentAnalyticsCSV,
  downloadTournamentAnalyticsJSON,
  downloadTournamentZip,
  downloadTournamentWinnerPoster,
} from '../utils/exports';
import { generateTournamentAutoReport } from '../utils/reports';

interface PDFReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournamentState: TournamentState;
  standings: PlayerStats[];
  fixtures?: TournamentMatch[];
}

type ReportSectionFilter =
  | 'all'
  | 'certificate'
  | 'standings'
  | 'fixtures'
  | 'player_stats'
  | 'ranking'
  | 'scorecard';

export const PDFReportModal: React.FC<PDFReportModalProps> = ({
  isOpen,
  onClose,
  tournamentState,
  standings,
  fixtures = [],
}) => {
  const certificateRef = useRef<HTMLDivElement>(null);
  const [copiedReport, setCopiedReport] = useState(false);
  const [sectionFilter, setSectionFilter] = useState<ReportSectionFilter>('all');

  if (!isOpen) return null;

  const autoReport = generateTournamentAutoReport(tournamentState, standings, fixtures);

  const handleCopyReport = async () => {
    try {
      await navigator.clipboard.writeText(autoReport.markdownText);
      setCopiedReport(true);
      setTimeout(() => setCopiedReport(false), 2200);
    } catch {
      // Clipboard fallback ignored cleanly
    }
  };

  const handleDownloadMarkdown = () => {
    const blob = new Blob([autoReport.markdownText], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(tournamentState.tournamentTitle || 'tournament')
      .toLowerCase()
      .replace(/\s+/g, '-')}-report.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const championName =
    tournamentState.finalWinner !== null
      ? tournamentState.players[tournamentState.finalWinner]
      : standings[0]?.name || 'Tournament Winner';

  const runnerUpName =
    tournamentState.semis && tournamentState.finalWinner !== null
      ? tournamentState.players[
          tournamentState.semis[0] === tournamentState.finalWinner
            ? tournamentState.semis[1]
            : tournamentState.semis[0]
        ] || standings[1]?.name || 'Runner Up'
      : standings[1]?.name || 'Runner Up';

  const thirdPlaceName =
    tournamentState.thirdPlaceWinner !== null && tournamentState.thirdPlaceWinner !== undefined
      ? tournamentState.players[tournamentState.thirdPlaceWinner]
      : standings[2]?.name;

  const awards = calculateTournamentAwards(standings);
  const refereeName = tournamentState.customRules?.refereeName || 'Hassan';
  const showAll = sectionFilter === 'all';
  const playableFixtures = fixtures.filter((f) => !f.isBye && f.playerBIndex >= 0);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white dark:bg-[#141414] rounded-3xl shadow-2xl border border-slate-200 dark:border-[#D4AF37]/30 my-8 overflow-hidden">
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-6 py-4 border-b border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] print:hidden">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-[#D4AF37]" />
            <h2 className="text-base sm:text-lg font-black text-[#172033] dark:text-white">
              Official Championship Certificate, PDF &amp; Posters
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() =>
                downloadTournamentWinnerPoster({
                  tournamentTitle: tournamentState.tournamentTitle || 'Smash Championship',
                  championName,
                  runnerUpName,
                  thirdPlaceName,
                  venue: tournamentState.venue,
                  date: tournamentState.createdDate
                    ? new Date(tournamentState.createdDate).toLocaleDateString()
                    : undefined,
                  totalMatches: Object.keys(tournamentState.results || {}).length,
                })
              }
              className="px-3 py-2 bg-[#D4AF37]/15 border border-[#D4AF37]/50 hover:border-[#FFD700] text-[#9A7B1C] dark:text-[#FFD700] rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Winner Poster PNG</span>
            </button>
            <button
              type="button"
              onClick={handleCopyReport}
              className="px-3 py-2 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 hover:border-[#D4AF37] text-[#172033] dark:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedReport ? (
                <Check className="w-3.5 h-3.5 text-[#22C55E]" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-[#D4AF37]" />
              )}
              <span>{copiedReport ? 'Copied!' : 'Copy Summary'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadMarkdown}
              className="px-3 py-2 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 hover:border-[#D4AF37] text-[#172033] dark:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>.MD</span>
            </button>
            <button
              type="button"
              onClick={() => downloadStandingsCSV(tournamentState, standings)}
              className="px-3 py-2 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 hover:border-[#D4AF37] text-[#172033] dark:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Standings CSV</span>
            </button>
            {fixtures.length > 0 && (
              <button
                type="button"
                onClick={() => downloadMatchesCSV(tournamentState, fixtures, standings)}
                className="px-3 py-2 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 hover:border-[#D4AF37] text-[#172033] dark:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#22C55E]" />
                <span>Matches CSV</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => downloadTournamentAnalyticsCSV(tournamentState, standings, fixtures)}
              className="px-3 py-2 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 hover:border-[#D4AF37] text-[#172033] dark:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Full CSV</span>
            </button>
            <button
              type="button"
              onClick={() => downloadTournamentAnalyticsJSON(tournamentState, standings, fixtures)}
              className="px-3 py-2 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 hover:border-[#D4AF37] text-[#172033] dark:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <FileJson className="w-3.5 h-3.5 text-[#FFD700]" />
              <span>JSON</span>
            </button>
            <button
              type="button"
              onClick={() => void downloadTournamentZip(tournamentState, standings, fixtures)}
              className="px-3 py-2 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 hover:border-[#FFD700] text-[#172033] dark:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Download all CSV, JSON & Markdown reports in one ZIP archive"
            >
              <FileArchive className="w-3.5 h-3.5 text-[#FFD700]" />
              <span>ZIP</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] rounded-xl text-xs font-black flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#64748B] hover:text-[#172033] dark:hover:text-white rounded-xl hover:bg-slate-200/60 dark:hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close report"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Section Filter Tabs */}
        <div className="px-6 py-2.5 bg-white dark:bg-[#080808]/60 border-b border-slate-200 dark:border-white/10 flex flex-wrap gap-1.5 print:hidden">
          {(
            [
              { id: 'all', label: 'All Sections' },
              { id: 'certificate', label: 'Championship Certificate' },
              { id: 'standings', label: 'Final Standings' },
              { id: 'fixtures', label: 'Tournament Fixtures' },
              { id: 'player_stats', label: 'Player Statistics' },
              { id: 'ranking', label: 'Ranking Report' },
              { id: 'scorecard', label: 'Match Scorecard' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSectionFilter(tab.id)}
              className={`px-3 py-1 rounded-xl text-[11px] font-extrabold cursor-pointer transition-all ${
                sectionFilter === tab.id
                  ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808]'
                  : 'bg-[#F4F7FB] dark:bg-[#141414] text-[#64748B] dark:text-[#A0A0A0] border border-slate-200 dark:border-white/10'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Printable Content */}
        <div className="p-6 sm:p-8 space-y-8 print:p-0 print:m-0 max-h-[72vh] overflow-y-auto" id="printable-area">
          {/* Official Black + Gold Certificate */}
          {(showAll || sectionFilter === 'certificate') && (
            <div
              ref={certificateRef}
              className="relative rounded-3xl border-4 border-[#D4AF37] bg-gradient-to-br from-[#141414] via-[#0B0B0B] to-[#080808] p-8 sm:p-12 text-white shadow-2xl overflow-hidden print:rounded-none"
            >
              <div className="absolute inset-3 border border-[#D4AF37]/40 rounded-2xl pointer-events-none" />
              <div className="absolute inset-5 border border-dashed border-[#FFD700]/30 rounded-xl pointer-events-none" />

              <div className="text-center relative z-10 space-y-3">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#080808] border-2 border-[#D4AF37] p-1 shadow-lg mx-auto mb-2 overflow-hidden">
                  {tournamentState.customLogoUrl ? (
                    <img
                      src={tournamentState.customLogoUrl}
                      alt="Emblem"
                      className="w-full h-full object-cover rounded-xl"
                    />
                  ) : (
                    <span className="text-3xl">🏆</span>
                  )}
                </div>

                <div className="text-xs sm:text-sm uppercase tracking-[0.25em] text-[#D4AF37] font-black font-mono">
                  Hassan Badminton Tournament Manager
                </div>

                <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white uppercase drop-shadow-md">
                  CERTIFICATE OF CHAMPIONSHIP
                </h1>

                <div className="w-32 h-1 bg-gradient-to-r from-[#D4AF37] via-[#FFD700] to-[#D4AF37] mx-auto my-3 rounded-full" />

                <p className="text-xs sm:text-sm text-[#A0A0A0] italic">
                  This is proudly presented to certify that
                </p>

                <div className="py-3">
                  <span className="text-3xl sm:text-5xl font-black text-[#FFD700] tracking-wide underline decoration-[#D4AF37]/70 underline-offset-8 drop-shadow-md">
                    {championName}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-200 max-w-xl mx-auto leading-relaxed">
                  has emerged as the victorious <strong className="text-[#FFD700]">CHAMPION</strong> of{' '}
                  <strong className="text-white">
                    {tournamentState.tournamentTitle || 'Smash Championship'}
                  </strong>{' '}
                  (Runner-Up: <strong className="text-[#D4AF37]">{runnerUpName}</strong>), demonstrating
                  exceptional agility, sportsmanship, and mastery on court.
                </p>

                {/* Venue / Date / MVP Meta Strip */}
                <div className="pt-3 flex flex-wrap items-center justify-center gap-4 text-[11px] text-[#A0A0A0]">
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                    {tournamentState.venue || 'Center Arena Court'}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#FFD700]" />
                    {tournamentState.createdDate
                      ? new Date(tournamentState.createdDate).toLocaleDateString()
                      : 'Official Event'}
                  </span>
                  {awards.mvp && (
                    <span className="inline-flex items-center gap-1 text-[#FFD700] font-bold">
                      <Award className="w-3.5 h-3.5" />
                      Tournament MVP: {awards.mvp.name}
                    </span>
                  )}
                </div>
              </div>

              {/* Official Seal & Signatures */}
              <div className="mt-10 pt-8 border-t border-white/15 grid grid-cols-3 items-center text-center relative z-10 gap-4">
                <div className="space-y-1">
                  <div className="h-10 flex items-end justify-center font-serif italic text-[#FFD700] text-base sm:text-xl">
                    {refereeName}
                  </div>
                  <div className="w-32 sm:w-36 h-0.5 bg-[#D4AF37]/60 mx-auto" />
                  <div className="text-[11px] font-bold text-white uppercase tracking-wider flex items-center justify-center gap-1">
                    <UserCheck className="w-3 h-3 text-[#D4AF37]" />
                    <span>Chief Referee</span>
                  </div>
                  <div className="text-[9px] text-[#A0A0A0]">Smash Championship Board</div>
                </div>

                <div className="flex flex-col items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#D4AF37] to-[#FFD700] p-1 shadow-2xl flex items-center justify-center border-2 border-white/60">
                    <div className="w-full h-full rounded-full bg-[#080808] border border-dashed border-[#FFD700] flex flex-col items-center justify-center text-white font-black p-1 text-center">
                      <span className="text-[8px] uppercase text-[#FFD700] leading-none">
                        OFFICIAL
                      </span>
                      <span className="text-lg leading-none my-0.5">🏸</span>
                      <span className="text-[7px] uppercase text-[#D4AF37] leading-none">
                        CHAMPION
                      </span>
                    </div>
                  </div>
                  <div className="text-[10px] text-[#FFD700] font-mono mt-1 font-bold">
                    BWF STANDARD
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="h-10 flex items-end justify-center font-serif italic text-[#D4AF37] text-sm sm:text-lg">
                    Developed By Hassan
                  </div>
                  <div className="w-32 sm:w-36 h-0.5 bg-[#D4AF37]/60 mx-auto" />
                  <div className="text-[11px] font-bold text-white uppercase tracking-wider">
                    Platform Authority
                  </div>
                  <div className="text-[9px] text-[#A0A0A0] uppercase tracking-widest font-mono">
                    Hassan developers
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Official Standings / Player Statistics / Ranking Report Table */}
          {(showAll ||
            sectionFilter === 'standings' ||
            sectionFilter === 'player_stats' ||
            sectionFilter === 'ranking') && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-[#172033] dark:text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-[#D4AF37]" />
                <span>
                  {sectionFilter === 'player_stats'
                    ? 'Player Statistics Report'
                    : sectionFilter === 'ranking'
                    ? 'Official Ranking Report'
                    : 'Official Tournament Final Standings'}
                </span>
              </h3>

              <div className="overflow-x-auto border border-slate-200 dark:border-white/10 rounded-2xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] uppercase font-mono text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">Rank</th>
                      <th className="py-2.5 px-3">Player</th>
                      <th className="py-2.5 px-3 text-center">MP</th>
                      <th className="py-2.5 px-3 text-center">W</th>
                      <th className="py-2.5 px-3 text-center">L</th>
                      <th className="py-2.5 px-3 text-center">Win %</th>
                      <th className="py-2.5 px-3 text-center">Sets (W-L)</th>
                      <th className="py-2.5 px-3 text-center">Points (F-A)</th>
                      <th className="py-2.5 px-3 text-right">Pts</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                    {standings.map((p, idx) => (
                      <tr key={p.id} className="hover:bg-[#F4F7FB] dark:hover:bg-[#080808]/50">
                        <td className="py-2 px-3 font-black text-[#172033] dark:text-[#FFD700]">
                          #{idx + 1}
                        </td>
                        <td className="py-2 px-3 font-bold text-[#172033] dark:text-white">
                          {p.name}
                        </td>
                        <td className="py-2 px-3 text-center font-mono text-[#64748B] dark:text-[#A0A0A0]">
                          {p.played}
                        </td>
                        <td className="py-2 px-3 text-center font-mono text-[#22C55E] font-bold">
                          {p.won}
                        </td>
                        <td className="py-2 px-3 text-center font-mono text-[#EF4444]">{p.lost}</td>
                        <td className="py-2 px-3 text-center font-mono text-[#172033] dark:text-white">
                          {p.played > 0 ? Math.round((p.won / p.played) * 100) : 0}%
                        </td>
                        <td className="py-2 px-3 text-center font-mono text-[#64748B] dark:text-[#A0A0A0]">
                          {p.setsWon} - {p.setsLost}
                        </td>
                        <td className="py-2 px-3 text-center font-mono text-[#64748B] dark:text-[#A0A0A0]">
                          {p.pointsFor} - {p.pointsAgainst}
                        </td>
                        <td className="py-2 px-3 text-right font-black text-[#9A7B1C] dark:text-[#FFD700]">
                          {p.points}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tournament Fixtures & Scorecards */}
          {(showAll || sectionFilter === 'fixtures' || sectionFilter === 'scorecard') &&
            playableFixtures.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-base font-black text-[#172033] dark:text-white flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#D4AF37]" />
                  <span>
                    {sectionFilter === 'scorecard'
                      ? 'Official Match Scorecards'
                      : `Tournament Fixtures (${getTournamentFormatLabel(tournamentState.tournamentFormat)})`}
                  </span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  {playableFixtures.map((f, idx) => {
                    const winner = tournamentState.results?.[f.id];
                    const scoreStr = formatScore(tournamentState.scores?.[f.id]);
                    const pA = tournamentState.players[f.playerAIndex] || `Player ${f.playerAIndex + 1}`;
                    const pB = tournamentState.players[f.playerBIndex] || `Player ${f.playerBIndex + 1}`;
                    return (
                      <div
                        key={f.id}
                        className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0">
                          <div className="text-[10px] font-mono text-[#D4AF37] font-bold">
                            Match #{f.roundNumber || idx + 1}
                            {f.group ? ` · Group ${f.group}` : ''}
                          </div>
                          <div className="font-bold text-[#172033] dark:text-white truncate">
                            {pA} vs {pB}
                          </div>
                        </div>
                        <div className="text-right shrink-0 font-mono">
                          {winner !== undefined ? (
                            <>
                              <div className="text-[11px] font-black text-[#22C55E]">
                                {tournamentState.players[winner]}
                              </div>
                              <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                                {scoreStr || 'Completed'}
                              </div>
                            </>
                          ) : (
                            <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                              Scheduled
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

          {/* Auto-Generated Executive Tournament Report */}
          {(showAll || sectionFilter === 'scorecard' || sectionFilter === 'ranking') && (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] p-5 sm:p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#D4AF37]" />
                  <h3 className="text-sm sm:text-base font-black text-[#172033] dark:text-white">
                    Auto-Generated Tournament Summary &amp; Insights
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-[#64748B] dark:text-[#A0A0A0]">
                  {autoReport.matchBreakdown.length} results analyzed
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="space-y-2">
                  <div className="font-extrabold uppercase tracking-wider text-[10px] text-[#D4AF37]">
                    Executive Overview
                  </div>
                  <ul className="space-y-1.5 text-[#172033] dark:text-slate-200">
                    {autoReport.executiveSummary.map((line, i) => (
                      <li key={i} className="leading-relaxed">
                        · {line}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <div className="font-extrabold uppercase tracking-wider text-[10px] text-[#FFD700]">
                    Statistical Highlights &amp; Awards
                  </div>
                  <ul className="space-y-1.5 text-[#172033] dark:text-slate-200">
                    {autoReport.standingsHighlights.map((line, i) => (
                      <li key={i} className="leading-relaxed">
                        · {line}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {autoReport.matchBreakdown.length > 0 && (
                <div className="pt-3 border-t border-slate-200 dark:border-white/10 space-y-2">
                  <div className="font-extrabold uppercase tracking-wider text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                    Match-by-Match Results Ledger
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px] font-mono text-[#172033] dark:text-slate-300">
                    {autoReport.matchBreakdown.map((item, i) => (
                      <div
                        key={i}
                        className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-[#141414] border border-slate-200/80 dark:border-white/10 truncate"
                      >
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
