import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Plus,
  Copy,
  Trash2,
  CheckCircle2,
  MapPin,
  Calendar,
  Users,
  Search,
  Edit3,
  Layers,
  ArrowRight,
  RotateCcw,
  Award,
  X,
  BookOpen,
  History,
  Download,
  FileJson,
  FileArchive,
  Lock,
  Star,
  Archive,
  Compass,
} from 'lucide-react';
import {
  TournamentState,
  TournamentFormatType,
  CompetitionCategory,
  MatchFormat,
  UserRoleMode,
} from '../types';
import {
  generateFixtures,
  calculateStandings,
  getTournamentFormatLabel,
  getFormatLabel,
  formatScore,
  getPlayerColor,
  getInitials,
  clampPointsPerSet,
} from '../utils/tournament';
import {
  downloadTournamentAnalyticsCSV,
  downloadTournamentAnalyticsJSON,
  downloadTournamentZip,
} from '../utils/exports';
import { ConfirmModal } from './ConfirmModal';
import { HowToPlayGuide } from './HowToPlayGuide';
import { AppTab } from './Header';

interface TournamentsViewProps {
  mode: 'tournaments' | 'history';
  tournaments: TournamentState[];
  activeTournamentId: string;
  userRoleMode?: UserRoleMode;
  spectatorMode?: boolean;
  favouriteIds?: string[];
  recentIds?: string[];
  onToggleFavourite?: (id: string) => void;
  onToggleArchive?: (id: string) => void;
  onSelectTournament: (id: string, navigateTo?: 'dashboard' | 'matches' | 'knockout') => void;
  onCreateTournament: (payload: {
    tournamentTitle: string;
    venue: string;
    createdDate: string;
    category: CompetitionCategory;
    tournamentFormat: TournamentFormatType;
    matchFormat: MatchFormat;
    pointsPerSet: number;
    description: string;
  }) => void;
  onUpdateTournamentMeta: (
    id: string,
    payload: {
      tournamentTitle: string;
      venue: string;
      createdDate: string;
      category: CompetitionCategory;
      tournamentFormat: TournamentFormatType;
      matchFormat: MatchFormat;
      pointsPerSet: number;
      description: string;
    }
  ) => void;
  onDuplicateTournament: (id: string) => void;
  onDeleteTournament: (id: string) => void;
  onReopenTournament: (id: string) => void;
  onToggleMatchMvp?: (tournamentId: string, matchId: string, playerIndex: number | null) => void;
  onNavigateTab?: (tab: AppTab) => void;
}

export const TournamentsView: React.FC<TournamentsViewProps> = ({
  mode,
  tournaments,
  activeTournamentId,
  userRoleMode = 'admin',
  spectatorMode = false,
  favouriteIds = [],
  recentIds = [],
  onToggleFavourite,
  onToggleArchive,
  onSelectTournament,
  onCreateTournament,
  onUpdateTournamentMeta,
  onDuplicateTournament,
  onDeleteTournament,
  onReopenTournament,
  onToggleMatchMvp,
  onNavigateTab,
}) => {
  const [historySubTab, setHistorySubTab] = useState<'matches' | 'records' | 'howtoplay'>(
    mode === 'history' ? 'matches' : 'records'
  );
  const [matchHistoryFilter, setMatchHistoryFilter] = useState<'all' | 'mvp'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed' | 'archived'>(
    mode === 'history' ? 'completed' : 'all'
  );
  const [categoryFilter, setCategoryFilter] = useState<'all' | CompetitionCategory>('all');
  const [formatFilter, setFormatFilter] = useState<'all' | TournamentFormatType>('all');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingTournamentId, setEditingTournamentId] = useState<string | null>(null);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [venue, setVenue] = useState('Center Arena Court');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [category, setCategory] = useState<CompetitionCategory>('singles');
  const [tournamentFormat, setTournamentFormat] = useState<TournamentFormatType>('round_robin');
  const [matchFormat, setMatchFormat] = useState<MatchFormat>('bo3');
  const [pointsPerSet, setPointsPerSet] = useState<number>(21);
  const [description, setDescription] = useState('Official BWF Rules Championship');

  useEffect(() => {
    setStatusFilter(mode === 'history' ? 'completed' : 'all');
    if (mode === 'tournaments') {
      setHistorySubTab('records');
    } else {
      setHistorySubTab('matches');
    }
  }, [mode]);

  const openCreateModal = () => {
    setEditingTournamentId(null);
    setTitle(`Smash Championship #${tournaments.length + 1}`);
    setVenue('Center Arena Court');
    setDate(new Date().toISOString().slice(0, 10));
    setCategory('singles');
    setTournamentFormat('round_robin');
    setMatchFormat('bo3');
    setPointsPerSet(21);
    setDescription('Official BWF Rules Badminton Championship');
    setShowCreateForm(true);
  };

  const openEditModal = (t: TournamentState) => {
    setEditingTournamentId(t.id || null);
    setTitle(t.tournamentTitle);
    setVenue(t.venue || 'Center Arena Court');
    setDate((t.createdDate || new Date().toISOString()).slice(0, 10));
    setCategory(t.category || 'singles');
    setTournamentFormat(t.tournamentFormat || 'round_robin');
    setMatchFormat(t.matchFormat || 'bo3');
    setPointsPerSet(clampPointsPerSet(t.customRules?.pointsPerSet ?? 21));
    setDescription(t.description || '');
    setShowCreateForm(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanTitle = title.trim() || 'Smash Championship';
    const payload = {
      tournamentTitle: cleanTitle,
      venue: venue.trim() || 'Main Sports Hall',
      createdDate: date ? new Date(date).toISOString() : new Date().toISOString(),
      category,
      tournamentFormat,
      matchFormat,
      pointsPerSet: clampPointsPerSet(pointsPerSet),
      description: description.trim(),
    };

    if (editingTournamentId) {
      onUpdateTournamentMeta(editingTournamentId, payload);
    } else {
      onCreateTournament(payload);
    }
    setShowCreateForm(false);
    setEditingTournamentId(null);
  };

  const filtered = tournaments
    .filter((item) => {
      const isCompleted = item.finalWinner !== null;
      const isArchived = Boolean(item.archived);
      if (statusFilter === 'archived') {
        if (!isArchived) return false;
      } else {
        if (isArchived && statusFilter === 'active') return false;
        if (statusFilter === 'completed' && !isCompleted) return false;
        if (statusFilter === 'active' && isCompleted) return false;
      }
      if (categoryFilter !== 'all' && (item.category || 'singles') !== categoryFilter) return false;
      if (formatFilter !== 'all' && (item.tournamentFormat || 'round_robin') !== formatFilter)
        return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = item.tournamentTitle.toLowerCase().includes(q);
        const matchVenue = (item.venue || '').toLowerCase().includes(q);
        const championName =
          item.finalWinner !== null ? (item.players[item.finalWinner] || '').toLowerCase() : '';
        return matchTitle || matchVenue || championName.includes(q);
      }
      return true;
    })
    .sort((a, b) => {
      const favA = a.id && favouriteIds.includes(a.id) ? 1 : 0;
      const favB = b.id && favouriteIds.includes(b.id) ? 1 : 0;
      return favB - favA;
    });

  const archivedCount = tournaments.filter((t) => Boolean(t.archived)).length;
  const completedCount = tournaments.filter((t) => t.finalWinner !== null).length;
  const recentTournaments = recentIds
    .map((id) => tournaments.find((t) => t.id === id))
    .filter((t): t is TournamentState => Boolean(t));

  interface CompletedHistoryMatch {
    tournamentId: string;
    tournamentTitle: string;
    isActiveTournament: boolean;
    matchId: string;
    stageLabel: string;
    playerAIndex: number;
    playerBIndex: number;
    playerAName: string;
    playerBName: string;
    playerAPhoto?: string;
    playerBPhoto?: string;
    winnerIndex: number;
    scoreText: string;
    formatLabel: string;
    pointsPerSet: number;
    mvpPlayerIndex?: number;
  }

  const allCompletedMatches: CompletedHistoryMatch[] = [];
  const orderedTournaments = [...tournaments].sort((a, b) =>
    a.id === activeTournamentId ? -1 : b.id === activeTournamentId ? 1 : 0
  );

  orderedTournaments.forEach((item) => {
    const tId = item.id || 'default';
    const fmt = item.tournamentFormat || 'round_robin';
    const itemFixtures = generateFixtures(item.players.length, fmt, item.manualFixtures);
    const pts = item.customRules?.pointsPerSet ?? 21;
    const defaultMatchFmt = item.matchFormat || 'bo3';
    const mvps = item.matchMvps || {};

    itemFixtures.forEach((m, idx) => {
      if (m.isBye || m.playerBIndex < 0) return;
      const winnerIdx = item.results?.[m.id];
      if (winnerIdx === undefined) return;
      const mFmt = item.matchFormats?.[m.id] || defaultMatchFmt;
      allCompletedMatches.push({
        tournamentId: tId,
        tournamentTitle: item.tournamentTitle,
        isActiveTournament: tId === activeTournamentId,
        matchId: m.id,
        stageLabel: `${m.group ? `Group ${m.group} · ` : ''}Match #${m.roundNumber || idx + 1}`,
        playerAIndex: m.playerAIndex,
        playerBIndex: m.playerBIndex,
        playerAName: item.players[m.playerAIndex] || `Player ${m.playerAIndex + 1}`,
        playerBName: item.players[m.playerBIndex] || `Player ${m.playerBIndex + 1}`,
        playerAPhoto: item.playerPhotos?.[m.playerAIndex],
        playerBPhoto: item.playerPhotos?.[m.playerBIndex],
        winnerIndex: winnerIdx,
        scoreText: formatScore(item.scores?.[m.id]),
        formatLabel: mFmt.toUpperCase(),
        pointsPerSet: pts,
        mvpPlayerIndex: mvps[m.id],
      });
    });

    const standings = calculateStandings(
      item.players,
      item.results || {},
      item.scores || {},
      item.playerPhotos,
      item.playerBios,
      fmt,
      item.manualFixtures
    );
    const groupA = standings.filter((p) => p.group === 'A');
    const groupB = standings.filter((p) => p.group === 'B');
    const useGroupSeeding = fmt === 'group_stage' && groupA.length >= 2 && groupB.length >= 2;
    const quarters = item.quarters || {};
    const allQuartersComplete =
      standings.length >= 8 &&
      quarters[0] !== undefined &&
      quarters[1] !== undefined &&
      quarters[2] !== undefined &&
      quarters[3] !== undefined;

    if (standings.length >= 8) {
      const qfPairs: Array<[number, number]> = [
        [standings[0].id, standings[7].id],
        [standings[3].id, standings[4].id],
        [standings[1].id, standings[6].id],
        [standings[2].id, standings[5].id],
      ];
      qfPairs.forEach(([aId, bId], qIdx) => {
        const w = quarters[qIdx];
        if (w === undefined) return;
        const mId = `ko:qf-${qIdx}`;
        allCompletedMatches.push({
          tournamentId: tId,
          tournamentTitle: item.tournamentTitle,
          isActiveTournament: tId === activeTournamentId,
          matchId: mId,
          stageLabel: `Quarter-Final ${qIdx + 1}`,
          playerAIndex: aId,
          playerBIndex: bId,
          playerAName: item.players[aId] || `Player ${aId + 1}`,
          playerBName: item.players[bId] || `Player ${bId + 1}`,
          playerAPhoto: item.playerPhotos?.[aId],
          playerBPhoto: item.playerPhotos?.[bId],
          winnerIndex: w,
          scoreText: formatScore(item.quarterScores?.[qIdx]),
          formatLabel: (item.matchFormats?.[`qf-${qIdx}`] || defaultMatchFmt).toUpperCase(),
          pointsPerSet: pts,
          mvpPlayerIndex: mvps[mId],
        });
      });
    }

    if (standings.length >= 4) {
      const sf1A = allQuartersComplete ? quarters[0] : useGroupSeeding ? groupA[0].id : standings[0].id;
      const sf1B = allQuartersComplete ? quarters[1] : useGroupSeeding ? groupB[1].id : standings[3].id;
      const sf2A = allQuartersComplete ? quarters[2] : useGroupSeeding ? groupB[0].id : standings[1].id;
      const sf2B = allQuartersComplete ? quarters[3] : useGroupSeeding ? groupA[1].id : standings[2].id;

      [
        { idx: 0, a: sf1A, b: sf1B, label: 'Semi-Final 1' },
        { idx: 1, a: sf2A, b: sf2B, label: 'Semi-Final 2' },
      ].forEach((sf) => {
        const w = item.semis?.[sf.idx];
        if (w === undefined) return;
        const mId = `ko:sf-${sf.idx}`;
        allCompletedMatches.push({
          tournamentId: tId,
          tournamentTitle: item.tournamentTitle,
          isActiveTournament: tId === activeTournamentId,
          matchId: mId,
          stageLabel: sf.label,
          playerAIndex: sf.a,
          playerBIndex: sf.b,
          playerAName: item.players[sf.a] || `Player ${sf.a + 1}`,
          playerBName: item.players[sf.b] || `Player ${sf.b + 1}`,
          playerAPhoto: item.playerPhotos?.[sf.a],
          playerBPhoto: item.playerPhotos?.[sf.b],
          winnerIndex: w,
          scoreText: formatScore(item.semiScores?.[sf.idx]),
          formatLabel: (item.matchFormats?.[`sf-${sf.idx}`] || defaultMatchFmt).toUpperCase(),
          pointsPerSet: pts,
          mvpPlayerIndex: mvps[mId],
        });
      });

      const sf1W = item.semis?.[0];
      const sf2W = item.semis?.[1];
      if (sf1W !== undefined && sf2W !== undefined) {
        if (item.finalWinner !== null && item.finalWinner !== undefined) {
          allCompletedMatches.push({
            tournamentId: tId,
            tournamentTitle: item.tournamentTitle,
            isActiveTournament: tId === activeTournamentId,
            matchId: 'ko:final',
            stageLabel: 'Grand Championship Final',
            playerAIndex: sf1W,
            playerBIndex: sf2W,
            playerAName: item.players[sf1W] || `Player ${sf1W + 1}`,
            playerBName: item.players[sf2W] || `Player ${sf2W + 1}`,
            playerAPhoto: item.playerPhotos?.[sf1W],
            playerBPhoto: item.playerPhotos?.[sf2W],
            winnerIndex: item.finalWinner,
            scoreText: formatScore(item.finalScore),
            formatLabel: (item.matchFormats?.['final'] || defaultMatchFmt).toUpperCase(),
            pointsPerSet: pts,
            mvpPlayerIndex: mvps['ko:final'],
          });
        }
        const sf1L = sf1W === sf1A ? sf1B : sf1A;
        const sf2L = sf2W === sf2A ? sf2B : sf2A;
        if (item.thirdPlaceWinner !== null && item.thirdPlaceWinner !== undefined) {
          allCompletedMatches.push({
            tournamentId: tId,
            tournamentTitle: item.tournamentTitle,
            isActiveTournament: tId === activeTournamentId,
            matchId: 'ko:third',
            stageLabel: '3rd Place Bronze Playoff',
            playerAIndex: sf1L,
            playerBIndex: sf2L,
            playerAName: item.players[sf1L] || `Player ${sf1L + 1}`,
            playerBName: item.players[sf2L] || `Player ${sf2L + 1}`,
            playerAPhoto: item.playerPhotos?.[sf1L],
            playerBPhoto: item.playerPhotos?.[sf2L],
            winnerIndex: item.thirdPlaceWinner,
            scoreText: formatScore(item.thirdPlaceScore),
            formatLabel: (item.matchFormats?.['third'] || defaultMatchFmt).toUpperCase(),
            pointsPerSet: pts,
            mvpPlayerIndex: mvps['ko:third'],
          });
        }
      }
    }
  });

  const mvpMatchCount = allCompletedMatches.filter(
    (m) => m.mvpPlayerIndex !== undefined && m.mvpPlayerIndex === m.winnerIndex
  ).length;

  const filteredHistoryMatches = allCompletedMatches.filter((m) => {
    const hasMvp = m.mvpPlayerIndex !== undefined && m.mvpPlayerIndex === m.winnerIndex;
    if (matchHistoryFilter === 'mvp' && !hasMvp) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        m.playerAName.toLowerCase().includes(q) ||
        m.playerBName.toLowerCase().includes(q) ||
        m.tournamentTitle.toLowerCase().includes(q) ||
        m.stageLabel.toLowerCase().includes(q) ||
        (hasMvp && 'mvp'.includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-white dark:bg-[#141414] theme-card rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#172B4D] dark:text-[#FFD700] shrink-0">
              {mode === 'history' ? <Award className="w-5 h-5" /> : <Layers className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight">
                {mode === 'history' ? 'Match & Tournament History' : 'Tournament Hub & Manager'}
              </h2>
              <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                {mode === 'history'
                  ? 'Review completed matches, Match MVP winners, past champions, and official rules.'
                  : 'Create, edit, duplicate, search, and filter unlimited badminton competitions offline.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {mode === 'history' && (
              <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
                <button
                  type="button"
                  onClick={() => setHistorySubTab('matches')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-all ${
                    historySubTab === 'matches'
                      ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  <History className="w-3.5 h-3.5" />
                  <span>Match History ({allCompletedMatches.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHistorySubTab('records')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-all ${
                    historySubTab === 'records'
                      ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  <Trophy className="w-3.5 h-3.5" />
                  <span>Tournaments</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHistorySubTab('howtoplay')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-all ${
                    historySubTab === 'howtoplay'
                      ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>How to Play</span>
                </button>
              </div>
            )}

            {!spectatorMode && (
              <button
                type="button"
                onClick={openCreateModal}
                className="px-4 py-2.5 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 active:scale-[0.98] text-white dark:text-[#080808] font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>New Tournament</span>
              </button>
            )}
          </div>
        </div>

        {/* Search & Multi-Criteria Filter Row */}
        {(mode !== 'history' || historySubTab === 'records' || historySubTab === 'matches') && (
          <div className="mt-5 pt-4 border-t border-slate-100 dark:border-white/10 space-y-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-[#64748B] dark:text-[#A0A0A0] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={
                    mode === 'history' && historySubTab === 'matches'
                      ? 'Search player, match, tournament, or MVP...'
                      : 'Search tournament, venue, or champion...'
                  }
                  className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs sm:text-sm text-[#172033] dark:text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                />
              </div>

              {mode === 'history' && historySubTab === 'matches' ? (
                <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                  <div className="flex items-center gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
                    <button
                      type="button"
                      onClick={() => setMatchHistoryFilter('all')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        matchHistoryFilter === 'all'
                          ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-sm'
                          : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white'
                      }`}
                    >
                      All Completed ({allCompletedMatches.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setMatchHistoryFilter('mvp')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                        matchHistoryFilter === 'mvp'
                          ? 'bg-[#FFD700] text-[#080808] shadow-sm'
                          : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white'
                      }`}
                    >
                      <Award className="w-3.5 h-3.5" />
                      <span>Match MVPs ({mvpMatchCount})</span>
                    </button>
                  </div>

                  {(() => {
                    const activeT =
                      tournaments.find((t) => t.id === activeTournamentId) || tournaments[0];
                    if (!activeT) return null;
                    const activeFmt = activeT.tournamentFormat || 'round_robin';
                    const activeStandings = calculateStandings(
                      activeT.players,
                      activeT.results || {},
                      activeT.scores || {},
                      activeT.playerPhotos,
                      activeT.playerBios,
                      activeFmt,
                      activeT.manualFixtures
                    );
                    const activeFixtures = generateFixtures(
                      activeT.players.length,
                      activeFmt,
                      activeT.manualFixtures
                    );
                    return (
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            downloadTournamentAnalyticsCSV(activeT, activeStandings, activeFixtures)
                          }
                          className="px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 hover:border-[#D4AF37] text-[#172033] dark:text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                          title="Export active tournament standings & match history as CSV"
                        >
                          <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
                          <span>Export CSV</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            downloadTournamentAnalyticsJSON(activeT, activeStandings, activeFixtures)
                          }
                          className="px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 hover:border-[#FFD700] text-[#172033] dark:text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                          title="Export active tournament standings & match history as JSON"
                        >
                          <FileJson className="w-3.5 h-3.5 text-[#FFD700]" />
                          <span>Export JSON</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            void downloadTournamentZip(activeT, activeStandings, activeFixtures)
                          }
                          className="px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 hover:border-[#FFD700] text-[#172033] dark:text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                          title="Download complete tournament ZIP bundle (CSV, JSON & Report)"
                        >
                          <FileArchive className="w-3.5 h-3.5 text-[#FFD700]" />
                          <span>Export ZIP</span>
                        </button>
                      </div>
                    );
                  })()}
                </div>
              ) : (
                <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                  <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
                    {(
                      [
                        { id: 'all', label: `All (${tournaments.length})` },
                        { id: 'active', label: `Active (${tournaments.length - completedCount})` },
                        { id: 'completed', label: `Completed (${completedCount})` },
                        { id: 'archived', label: `Archived (${archivedCount})` },
                      ] as const
                    ).map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setStatusFilter(f.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          statusFilter === f.id
                            ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-sm'
                            : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>

                  <select
                    value={categoryFilter}
                    onChange={(e) =>
                      setCategoryFilter(e.target.value as 'all' | CompetitionCategory)
                    }
                    className="px-2.5 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white"
                    aria-label="Filter by Category"
                  >
                    <option value="all">All Categories</option>
                    <option value="singles">Singles</option>
                    <option value="doubles">Doubles</option>
                    <option value="mixed_doubles">Mixed Doubles</option>
                  </select>

                  <select
                    value={formatFilter}
                    onChange={(e) =>
                      setFormatFilter(e.target.value as 'all' | TournamentFormatType)
                    }
                    className="px-2.5 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white"
                    aria-label="Filter by Format"
                  >
                    <option value="all">All Formats</option>
                    <option value="round_robin">Round-Robin</option>
                    <option value="double_round_robin">Double Round-Robin</option>
                    <option value="swiss">Swiss System</option>
                    <option value="league">Pro League</option>
                    <option value="group_stage">Group Stage</option>
                    <option value="single_elimination">Single Elimination</option>
                    <option value="double_elimination">Double Elimination</option>
                    <option value="team_championship">Team Championship</option>
                    <option value="knockout">Knockout</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Recently Viewed Strip */}
      {mode === 'tournaments' && recentTournaments.length > 1 && (
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="font-black uppercase tracking-wider text-[10px] text-[#D4AF37]">
            Recently Viewed:
          </span>
          {recentTournaments.slice(0, 4).map((rt) => (
            <button
              key={rt.id}
              type="button"
              onClick={() => rt.id && onSelectTournament(rt.id, 'dashboard')}
              className={`px-3 py-1 rounded-xl border text-[11px] font-bold cursor-pointer transition-colors ${
                rt.id === activeTournamentId
                  ? 'bg-[#D4AF37]/20 border-[#FFD700] text-[#9A7B1C] dark:text-[#FFD700]'
                  : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#64748B] dark:text-[#A0A0A0] hover:border-[#D4AF37]'
              }`}
            >
              {rt.tournamentTitle}
            </button>
          ))}
        </div>
      )}

      {/* How to Play Guide inside History Section */}
      {mode === 'history' && historySubTab === 'howtoplay' ? (
        <HowToPlayGuide onNavigateTab={onNavigateTab} />
      ) : mode === 'history' && historySubTab === 'matches' ? (
        <div className="space-y-4">
          {filteredHistoryMatches.length === 0 ? (
            <div className="bg-white dark:bg-[#141414] theme-card rounded-3xl p-12 border border-slate-200 dark:border-white/10 text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-[#D4AF37]/15 flex items-center justify-center text-[#172B4D] dark:text-[#FFD700]">
                <Award className="w-7 h-7" />
              </div>
              <h3 className="text-base font-black text-[#172033] dark:text-white">
                {matchHistoryFilter === 'mvp'
                  ? 'No Match MVPs Designated Yet'
                  : 'No Completed Matches in History Yet'}
              </h3>
              <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] max-w-md mx-auto">
                {matchHistoryFilter === 'mvp'
                  ? 'Complete a match and designate a Match MVP after the game finishes to highlight standout winners here.'
                  : 'Complete matches in Live Court Scorer or Match Fixtures to view full results and Match MVP badges here.'}
              </p>
              {onNavigateTab && (
                <button
                  type="button"
                  onClick={() => onNavigateTab('matches')}
                  className="px-4 py-2 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-xs font-extrabold cursor-pointer"
                >
                  Go to Match Fixtures
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredHistoryMatches.map((m) => {
                const isWinnerA = m.winnerIndex === m.playerAIndex;
                const isWinnerB = m.winnerIndex === m.playerBIndex;
                const isMvpAwarded = m.mvpPlayerIndex !== undefined && m.mvpPlayerIndex === m.winnerIndex;
                const winnerName = isWinnerA ? m.playerAName : m.playerBName;

                return (
                  <div
                    key={`${m.tournamentId}-${m.matchId}`}
                    className="rounded-3xl p-5 bg-white dark:bg-[#141414] theme-card border border-slate-200 dark:border-white/10 shadow-sm space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                      <div className="flex flex-wrap items-center gap-1.5 min-w-0">
                        <span className="font-black text-[#172033] dark:text-white truncate max-w-[180px]">
                          {m.tournamentTitle}
                        </span>
                        <span className="text-[#64748B]" aria-hidden="true">
                          &middot;
                        </span>
                        <span className="font-bold text-[#D4AF37]">{m.stageLabel}</span>
                      </div>
                      <span className="text-[10px] font-bold text-[#64748B] dark:text-[#A0A0A0] font-mono">
                        {m.formatLabel} &middot; {m.pointsPerSet}p
                      </span>
                    </div>

                    <div className="space-y-2">
                      {/* Player A Row */}
                      <div
                        className={`flex items-center justify-between gap-2 p-2.5 rounded-2xl border ${
                          isWinnerA
                            ? 'bg-[#22C55E]/12 border-[#22C55E]/40'
                            : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200/70 dark:border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {m.playerAPhoto ? (
                            <img
                              src={m.playerAPhoto}
                              alt={m.playerAName}
                              className="w-8 h-8 rounded-xl object-cover shrink-0"
                            />
                          ) : (
                            <div
                              className="w-8 h-8 rounded-xl flex items-center justify-center text-[#080808] font-black text-xs shrink-0"
                              style={{ backgroundColor: getPlayerColor(m.playerAIndex) }}
                            >
                              {getInitials(m.playerAName)}
                            </div>
                          )}
                          <span className="font-bold text-sm text-[#172033] dark:text-white truncate">
                            {m.playerAName}
                          </span>
                        </div>
                        {isWinnerA && (
                          <div className="flex items-center gap-1.5 shrink-0">
                            {isMvpAwarded && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#FFD700]/20 text-[#9A7B1C] dark:text-[#FFD700] border border-[#D4AF37]/50 text-[10px] font-black uppercase tracking-wide">
                                <Award className="w-3 h-3" />
                                <span>Match MVP</span>
                              </span>
                            )}
                            <span className="text-xs font-extrabold text-[#22C55E] flex items-center gap-1">
                              <Trophy className="w-3.5 h-3.5" />
                              <span>Winner</span>
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Player B Row */}
                      <div
                        className={`flex items-center justify-between gap-2 p-2.5 rounded-2xl border ${
                          isWinnerB
                            ? 'bg-[#22C55E]/12 border-[#22C55E]/40'
                            : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200/70 dark:border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {m.playerBPhoto ? (
                            <img
                              src={m.playerBPhoto}
                              alt={m.playerBName}
                              className="w-8 h-8 rounded-xl object-cover shrink-0"
                            />
                          ) : (
                            <div
                              className="w-8 h-8 rounded-xl flex items-center justify-center text-[#080808] font-black text-xs shrink-0"
                              style={{ backgroundColor: getPlayerColor(m.playerBIndex) }}
                            >
                              {getInitials(m.playerBName)}
                            </div>
                          )}
                          <span className="font-bold text-sm text-[#172033] dark:text-white truncate">
                            {m.playerBName}
                          </span>
                        </div>
                        {isWinnerB && (
                          <div className="flex items-center gap-1.5 shrink-0">
                            {isMvpAwarded && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#FFD700]/20 text-[#9A7B1C] dark:text-[#FFD700] border border-[#D4AF37]/50 text-[10px] font-black uppercase tracking-wide">
                                <Award className="w-3 h-3" />
                                <span>Match MVP</span>
                              </span>
                            )}
                            <span className="text-xs font-extrabold text-[#22C55E] flex items-center gap-1">
                              <Trophy className="w-3.5 h-3.5" />
                              <span>Winner</span>
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="pt-2.5 border-t border-slate-100 dark:border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="text-[#64748B] dark:text-[#A0A0A0] font-mono tabular-nums">
                        {m.scoreText ? (
                          <span>
                            Sets:{' '}
                            <strong className="text-[#172033] dark:text-white">{m.scoreText}</strong>
                          </span>
                        ) : (
                          <span>
                            Winner: <strong className="text-[#22C55E]">{winnerName}</strong>
                          </span>
                        )}
                      </div>

                      {onToggleMatchMvp && !spectatorMode && (
                        <button
                          type="button"
                          onClick={() =>
                            onToggleMatchMvp(
                              m.tournamentId,
                              m.matchId,
                              isMvpAwarded ? null : m.winnerIndex
                            )
                          }
                          className={`px-3 py-1.5 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 cursor-pointer transition-colors ${
                            isMvpAwarded
                              ? 'bg-[#D4AF37]/20 border-[#D4AF37]/50 text-[#9A7B1C] dark:text-[#FFD700]'
                              : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200 dark:border-white/15 text-[#172033] dark:text-slate-200 hover:border-[#D4AF37]'
                          }`}
                        >
                          <Award className="w-3.5 h-3.5" />
                          <span>{isMvpAwarded ? 'Match MVP Awarded' : 'Designate Match MVP'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Create / Edit Tournament Form Drawer */}
          {showCreateForm && (
            <form
              onSubmit={handleSubmitForm}
              className="bg-white dark:bg-[#141414] rounded-3xl p-6 border-2 border-[#D4AF37]/60 shadow-xl space-y-4 animate-fade-in"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-white/10">
                <h3 className="text-base font-black text-[#172033] dark:text-white">
                  {editingTournamentId ? 'Edit Tournament Details' : 'Create New Tournament'}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="p-1.5 rounded-lg text-[#64748B] hover:text-white hover:bg-white/10"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Tournament Name
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Smash Championship"
                    className="w-full px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Venue / Sports Complex
                  </label>
                  <input
                    type="text"
                    value={venue}
                    onChange={(e) => setVenue(e.target.value)}
                    placeholder="e.g. National Badminton Hall"
                    className="w-full px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Tournament Date
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Competition Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as CompetitionCategory)}
                    className="w-full px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold focus:outline-none"
                  >
                    <option value="singles">Singles</option>
                    <option value="doubles">Doubles</option>
                    <option value="mixed_doubles">Mixed Doubles</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Stage Format
                  </label>
                  <select
                    value={tournamentFormat}
                    onChange={(e) => setTournamentFormat(e.target.value as TournamentFormatType)}
                    className="w-full px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold focus:outline-none"
                  >
                    <option value="round_robin">Round-Robin League</option>
                    <option value="double_round_robin">Double Round-Robin (2 Legs)</option>
                    <option value="swiss">Swiss System</option>
                    <option value="league">Pro League Format</option>
                    <option value="group_stage">Group Stage (Group A &amp; B)</option>
                    <option value="single_elimination">Single Elimination Bracket</option>
                    <option value="double_elimination">Double Elimination (WB + LB)</option>
                    <option value="team_championship">Team Championship</option>
                    <option value="knockout">Knockout Elimination</option>
                    <option value="custom">Custom Format</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Match Format (Entire Tournament)
                  </label>
                  <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15">
                    {(
                      [
                        { id: 'bo1', label: 'Best of 1' },
                        { id: 'bo3', label: 'Best of 3' },
                        { id: 'bo5', label: 'Best of 5' },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setMatchFormat(opt.id)}
                        className={`py-1.5 px-2 rounded-lg text-[11px] font-extrabold transition-all whitespace-nowrap cursor-pointer ${
                          matchFormat === opt.id
                            ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-sm'
                            : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Adjustable Points Target (11-21) */}
              <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#64748B] dark:text-[#A0A0A0]">
                    Points Per Set (Adjustable 11–21)
                  </span>
                  <span className="font-mono font-black text-sm text-[#172B4D] dark:text-[#FFD700]">
                    {pointsPerSet} Points
                  </span>
                </div>
                <input
                  type="range"
                  min={11}
                  max={21}
                  step={1}
                  value={pointsPerSet}
                  onChange={(e) => setPointsPerSet(Number(e.target.value))}
                  className="w-full accent-[#D4AF37] cursor-pointer"
                />
              </div>

              <div>
                <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] text-xs block mb-1">
                  Description / Notes
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Optional rules or sponsorship notes..."
                  className="w-full px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-extrabold text-xs shadow cursor-pointer"
                >
                  {editingTournamentId ? 'Save Changes' : 'Create & Launch'}
                </button>
              </div>
            </form>
          )}

          {/* Tournaments Grid */}
          {filtered.length === 0 ? (
            <div className="bg-white dark:bg-[#141414] theme-card rounded-3xl p-12 border border-slate-200 dark:border-white/10 text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-[#D4AF37]/15 flex items-center justify-center text-2xl">
                🏆
              </div>
              <h3 className="text-base font-black text-[#172033] dark:text-white">
                {mode === 'history' && statusFilter === 'completed'
                  ? 'No Completed Tournaments Yet'
                  : 'No Matching Tournaments'}
              </h3>
              <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] max-w-md mx-auto">
                {mode === 'history' && statusFilter === 'completed'
                  ? 'Crown a champion in the Playoffs Bracket to archive completed tournaments here.'
                  : 'Try clearing your search filter or create a new tournament above.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filtered.map((item) => {
                const isActive = item.id === activeTournamentId;
                const itemFixtures = generateFixtures(
                  item.players.length,
                  item.tournamentFormat || 'round_robin',
                  item.manualFixtures
                ).filter((f) => !f.isBye && f.playerBIndex >= 0);
                const totalFixtures = itemFixtures.length;
                const completedFixtures = itemFixtures.filter(
                  (f) => item.results?.[f.id] !== undefined
                ).length;
                const isCompleted = item.finalWinner !== null;
                const championName = isCompleted ? item.players[item.finalWinner as number] : null;
                const sf1 = item.semis?.[0];
                const sf2 = item.semis?.[1];
                const runnerUpIdx =
                  isCompleted && sf1 !== undefined && sf2 !== undefined
                    ? item.finalWinner === sf1
                      ? sf2
                      : sf1
                    : null;
                const runnerUpName = runnerUpIdx !== null ? item.players[runnerUpIdx] : null;

                return (
                  <div
                    key={item.id}
                    className={`rounded-3xl p-5 border transition-all flex flex-col justify-between space-y-4 theme-card hover:-translate-y-0.5 ${
                      isActive
                        ? 'bg-white dark:bg-[#141414] border-[#D4AF37] ring-2 ring-[#D4AF37]/25 shadow-md'
                        : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 shadow-sm hover:border-[#D4AF37]/50'
                    }`}
                  >
                    <div className="space-y-3">
                      {/* Top Badges Row */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {isActive && (
                            <span className="px-2.5 py-0.5 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-[10px] font-black uppercase tracking-wider">
                              Active Now
                            </span>
                          )}
                          <span
                            className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                              isCompleted
                                ? 'bg-[#22C55E]/15 text-[#22C55E] border border-[#22C55E]/30'
                                : 'bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] border border-[#D4AF37]/30'
                            }`}
                          >
                            {isCompleted ? 'Completed' : item.started ? 'In Progress' : 'Setup'}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] text-[10px] font-bold uppercase">
                            {(item.category || 'singles').replace('_', ' ')}
                          </span>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {onToggleFavourite && item.id && (
                            <button
                              type="button"
                              onClick={() => item.id && onToggleFavourite(item.id)}
                              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                favouriteIds.includes(item.id)
                                  ? 'text-[#FFD700] bg-[#D4AF37]/15'
                                  : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#FFD700]'
                              }`}
                              title="Toggle Favourite Tournament"
                            >
                              <Star
                                className={`w-3.5 h-3.5 ${
                                  favouriteIds.includes(item.id) ? 'fill-current' : ''
                                }`}
                              />
                            </button>
                          )}
                          {!spectatorMode && onToggleArchive && item.id && (
                            <button
                              type="button"
                              onClick={() => item.id && onToggleArchive(item.id)}
                              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                item.archived
                                  ? 'text-[#D4AF37] bg-[#D4AF37]/15'
                                  : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#D4AF37]'
                              }`}
                              title={item.archived ? 'Unarchive Tournament' : 'Archive Tournament'}
                            >
                              <Archive className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {!spectatorMode && (
                            <>
                              <button
                                type="button"
                                onClick={() => openEditModal(item)}
                                className="p-1.5 rounded-lg text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                                title="Edit Tournament Info"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => item.id && onDuplicateTournament(item.id)}
                                className="p-1.5 rounded-lg text-[#64748B] dark:text-[#A0A0A0] hover:text-[#FFD700] hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                                title="Duplicate Tournament"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                              {tournaments.length > 1 && (
                                <button
                                  type="button"
                                  disabled={userRoleMode === 'referee'}
                                  onClick={() => item.id && setDeleteTargetId(item.id)}
                                  className="p-1.5 rounded-lg text-[#64748B] dark:text-[#A0A0A0] hover:text-[#EF4444] hover:bg-rose-500/10 transition-colors cursor-pointer disabled:opacity-35"
                                  title={
                                    userRoleMode === 'referee'
                                      ? 'Switch to Admin Mode to delete tournaments'
                                      : 'Delete Tournament'
                                  }
                                >
                                  {userRoleMode === 'referee' ? (
                                    <Lock className="w-3.5 h-3.5" />
                                  ) : (
                                    <Trash2 className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      </div>

                      {/* Title & Metadata */}
                      <div>
                        <h3 className="text-lg font-black text-[#172033] dark:text-white tracking-tight flex items-center gap-2">
                          <span>{item.tournamentTitle}</span>
                          {item.archived && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-500/20 text-[#A0A0A0] uppercase">
                              Archived
                            </span>
                          )}
                        </h3>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-1">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-[#D4AF37]" />
                            {item.venue || 'Main Arena'}
                          </span>
                          {item.venueLocation && (
                            <span className="inline-flex items-center gap-1 text-[#22C55E] font-bold">
                              <Compass className="w-3 h-3" />
                              <span>GPS Pinned</span>
                            </span>
                          )}
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-[#FFD700]" />
                            {new Date(item.createdDate).toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {item.players.length} Players
                          </span>
                        </div>
                      </div>

                      {/* Format Info */}
                      <div className="grid grid-cols-2 gap-2 text-[11px] p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/70 dark:border-white/10">
                        <div>
                          <span className="text-[#64748B] dark:text-[#A0A0A0] block">Stage Format</span>
                          <span className="font-bold text-[#172033] dark:text-white">
                            {getTournamentFormatLabel(item.tournamentFormat)}
                          </span>
                        </div>
                        <div>
                          <span className="text-[#64748B] dark:text-[#A0A0A0] block">
                            Matches Progress
                          </span>
                          <span className="font-bold text-[#172033] dark:text-white tabular-nums">
                            {completedFixtures} / {totalFixtures} (
                            {getFormatLabel(item.matchFormat).split(' ')[2] || '3'} Sets &middot;{' '}
                            {item.customRules?.pointsPerSet ?? 21}p)
                          </span>
                        </div>
                      </div>

                      {/* Champion Summary Banner (if completed) */}
                      {isCompleted && championName && (
                        <div className="p-3 rounded-2xl bg-[#22C55E]/10 border border-[#22C55E]/30 flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <Trophy className="w-4 h-4 text-[#FFD700] shrink-0" />
                            <div>
                              <span className="font-black text-[#172033] dark:text-white block">
                                Champion: {championName}
                              </span>
                              {runnerUpName && (
                                <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                                  Runner-Up: {runnerUpName}
                                </span>
                              )}
                            </div>
                          </div>
                          <CheckCircle2 className="w-4 h-4 text-[#22C55E]" />
                        </div>
                      )}
                    </div>

                    {/* Action Footer */}
                    <div className="pt-3 border-t border-slate-100 dark:border-white/10 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          item.id &&
                          onSelectTournament(item.id, isCompleted ? 'knockout' : 'dashboard')
                        }
                        className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                          isActive
                            ? 'bg-[#172B4D] dark:bg-[#D4AF37]/15 text-white dark:text-[#FFD700] border border-transparent dark:border-[#D4AF37]/40'
                            : 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] hover:opacity-95'
                        }`}
                      >
                        <span>{isActive ? 'Open Active Dashboard' : 'Switch to Tournament'}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>

                      {isCompleted && !spectatorMode && (
                        <button
                          type="button"
                          onClick={() => item.id && onReopenTournament(item.id)}
                          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white flex items-center gap-1 cursor-pointer"
                          title="Reopen tournament playoffs"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Reopen</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Delete Tournament Confirmation */}
      <ConfirmModal
        isOpen={deleteTargetId !== null}
        title="Delete Tournament?"
        message="This will permanently remove this tournament, its roster, and all recorded match scores from offline storage."
        confirmText="Delete Tournament"
        cancelText="Keep Tournament"
        type="danger"
        onConfirm={() => {
          if (deleteTargetId) onDeleteTournament(deleteTargetId);
          setDeleteTargetId(null);
        }}
        onCancel={() => setDeleteTargetId(null)}
      />
    </div>
  );
};
