import React, { useMemo, useState } from 'react';
import {
  Medal,
  Trophy,
  Sliders,
  ArrowLeftRight,
  Download,
  Lock,
  History,
  X,
  Check,
  Flame,
  Building2,
} from 'lucide-react';
import {
  TournamentState,
  RankingConfig,
  CompetitionCategory,
  UserRoleMode,
} from '../types';
import {
  calculateGlobalRankings,
  GlobalRankingEntry,
  DEFAULT_RANKING_CONFIG,
  getInitials,
  getPlayerColor,
  generateFixtures,
} from '../utils/tournament';
import { downloadPlayerAchievementCard } from '../utils/exports';

interface RankingsViewProps {
  tournaments: TournamentState[];
  rankingConfig?: RankingConfig;
  onUpdateRankingConfig?: (config: RankingConfig) => void;
  userRoleMode?: UserRoleMode;
}

export const RankingsView: React.FC<RankingsViewProps> = ({
  tournaments,
  rankingConfig = DEFAULT_RANKING_CONFIG,
  onUpdateRankingConfig,
  userRoleMode = 'admin',
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'all' | CompetitionCategory>('all');
  const [timeFilter, setTimeFilter] = useState<'all' | 'monthly' | 'annual'>('all');
  const [viewMode, setViewMode] = useState<'players' | 'clubs'>('players');
  const [showConfig, setShowConfig] = useState(false);
  const [draftConfig, setDraftConfig] = useState<RankingConfig>(rankingConfig);
  const [selectedHistoryPlayer, setSelectedHistoryPlayer] =
    useState<GlobalRankingEntry | null>(null);
  const [compareA, setCompareA] = useState<string>('');
  const [compareB, setCompareB] = useState<string>('');

  const rankings = calculateGlobalRankings(
    tournaments,
    rankingConfig,
    categoryFilter,
    timeFilter
  );

  const clubRankings = useMemo(() => {
    const map = new Map<
      string,
      { club: string; members: number; points: number; wins: number; titles: number; mvps: number }
    >();
    rankings.forEach((r) => {
      const clubName = r.club?.trim() || 'Independent / Unattached';
      const existing = map.get(clubName) || {
        club: clubName,
        members: 0,
        points: 0,
        wins: 0,
        titles: 0,
        mvps: 0,
      };
      existing.members += 1;
      existing.points += r.ratingPoints;
      existing.wins += r.wins;
      existing.titles += r.titles;
      existing.mvps += r.mvpAwards;
      map.set(clubName, existing);
    });
    return Array.from(map.values()).sort((a, b) => b.points - a.points);
  }, [rankings]);

  const playerAEntry = rankings.find((r) => r.normalizedKey === compareA) || rankings[0];
  const playerBEntry = rankings.find((r) => r.normalizedKey === compareB) || rankings[1];

  // Calculate true Head-to-Head across all saved tournaments
  const computeH2H = (nameA?: string, nameB?: string) => {
    if (!nameA || !nameB || nameA.toLowerCase() === nameB.toLowerCase()) {
      return { winsA: 0, winsB: 0, total: 0 };
    }
    let winsA = 0;
    let winsB = 0;
    const keyA = nameA.trim().toLowerCase();
    const keyB = nameB.trim().toLowerCase();

    tournaments.forEach((t) => {
      const idxA = t.players.findIndex((p) => p.trim().toLowerCase() === keyA);
      const idxB = t.players.findIndex((p) => p.trim().toLowerCase() === keyB);
      if (idxA < 0 || idxB < 0) return;
      const fixtures = generateFixtures(
        t.players.length,
        t.tournamentFormat || 'round_robin',
        t.manualFixtures
      );
      fixtures.forEach((f) => {
        if (f.isBye || f.playerBIndex < 0) return;
        const hasBoth =
          (f.playerAIndex === idxA && f.playerBIndex === idxB) ||
          (f.playerAIndex === idxB && f.playerBIndex === idxA);
        if (!hasBoth) return;
        const winner = t.results?.[f.id];
        if (winner === idxA) winsA += 1;
        else if (winner === idxB) winsB += 1;
      });
    });

    return { winsA, winsB, total: winsA + winsB };
  };

  const h2h = computeH2H(playerAEntry?.playerName, playerBEntry?.playerName);

  const handleSaveConfig = () => {
    if (onUpdateRankingConfig) {
      onUpdateRankingConfig(draftConfig);
    }
    setShowConfig(false);
  };

  const handleExportRankingsCSV = () => {
    const headers = [
      'Rank',
      'Player Name',
      'Categories',
      'Ranking Points',
      'Tournaments',
      'Matches Played',
      'Wins',
      'Losses',
      'Win Rate',
      'Titles',
      'Runner-Ups',
      'Match MVPs',
    ];
    const rows = rankings.map((r, idx) =>
      [
        idx + 1,
        `"${r.playerName.replace(/"/g, '""')}"`,
        `"${r.categories.join(', ')}"`,
        r.ratingPoints,
        r.tournamentsPlayed,
        r.matchesPlayed,
        r.wins,
        r.losses,
        `${r.winRate}%`,
        r.titles,
        r.runnerUps,
        r.mvpAwards,
      ].join(',')
    );
    const csv = '\uFEFF' + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hassan-badminton-rankings-${categoryFilter}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header & Category Tabs */}
      <div className="bg-white dark:bg-[#141414] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Medal className="w-5 h-5 text-[#FFD700]" />
              <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight">
                Official Player Rankings &amp; Leaderboards
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-1">
              Computed dynamically across all saved tournaments using configurable match, title, and MVP points.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setDraftConfig(rankingConfig);
                setShowConfig((p) => !p);
              }}
              className="px-3.5 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs font-extrabold text-[#172033] dark:text-white hover:border-[#D4AF37] flex items-center gap-1.5 cursor-pointer"
            >
              {userRoleMode === 'referee' ? (
                <Lock className="w-3.5 h-3.5 text-[#EF4444]" />
              ) : (
                <Sliders className="w-3.5 h-3.5 text-[#D4AF37]" />
              )}
              <span>Point Rules</span>
            </button>

            <button
              type="button"
              onClick={handleExportRankingsCSV}
              className="px-3.5 py-2 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Category, Timeframe & View Mode Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { id: 'all', label: 'All Categories' },
                { id: 'singles', label: 'Singles' },
                { id: 'doubles', label: 'Doubles' },
                { id: 'mixed_doubles', label: 'Mixed Doubles' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setCategoryFilter(tab.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer transition-all ${
                  categoryFilter === tab.id
                    ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-sm'
                    : 'bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[#64748B] dark:text-[#A0A0A0]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
              {(
                [
                  { id: 'all', label: 'All-Time' },
                  { id: 'annual', label: 'Annual' },
                  { id: 'monthly', label: 'Monthly' },
                ] as const
              ).map((tf) => (
                <button
                  key={tf.id}
                  type="button"
                  onClick={() => setTimeFilter(tf.id)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                    timeFilter === tf.id
                      ? 'bg-[#D4AF37] text-[#080808] font-black'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  {tf.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
              <button
                type="button"
                onClick={() => setViewMode('players')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                  viewMode === 'players'
                    ? 'bg-[#172B4D] dark:bg-[#FFD700] text-white dark:text-[#080808] font-black'
                    : 'text-[#64748B] dark:text-[#A0A0A0]'
                }`}
              >
                Players
              </button>
              <button
                type="button"
                onClick={() => setViewMode('clubs')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer ${
                  viewMode === 'clubs'
                    ? 'bg-[#172B4D] dark:bg-[#FFD700] text-white dark:text-[#080808] font-black'
                    : 'text-[#64748B] dark:text-[#A0A0A0]'
                }`}
              >
                <Building2 className="w-3 h-3" />
                <span>Clubs</span>
              </button>
            </div>
          </div>
        </div>

        {/* Admin Configurable Ranking Points Panel */}
        {showConfig && (
          <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/35 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-black text-[#172033] dark:text-[#FFD700]">
                Administrator Ranking Points Formula
              </span>
              {userRoleMode === 'referee' && (
                <span className="text-[11px] font-bold text-[#EF4444]">
                  Switch to Admin Mode in Settings to modify formula
                </span>
              )}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
              {(
                [
                  { key: 'winPoints', label: 'Match Win' },
                  { key: 'lossPoints', label: 'Participation / Loss' },
                  { key: 'setWinBonus', label: 'Game Won Bonus' },
                  { key: 'championshipBonus', label: 'Champion Bonus' },
                  { key: 'runnerUpBonus', label: 'Runner-Up Bonus' },
                  { key: 'mvpBonus', label: 'Match MVP Bonus' },
                ] as const
              ).map((field) => (
                <div key={field.key}>
                  <label className="text-[10px] font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    {field.label}
                  </label>
                  <input
                    type="number"
                    disabled={userRoleMode === 'referee'}
                    value={draftConfig[field.key]}
                    onChange={(e) =>
                      setDraftConfig({
                        ...draftConfig,
                        [field.key]: Math.max(0, Number(e.target.value) || 0),
                      })
                    }
                    className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 font-mono font-bold text-[#172033] dark:text-white disabled:opacity-50"
                  />
                </div>
              ))}
            </div>
            {userRoleMode !== 'referee' && (
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDraftConfig(DEFAULT_RANKING_CONFIG)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0] font-bold cursor-pointer"
                >
                  Reset Defaults
                </button>
                <button
                  type="button"
                  onClick={handleSaveConfig}
                  className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black flex items-center gap-1 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Apply Formula</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Rankings Table (Players vs Clubs) */}
      <div className="bg-white dark:bg-[#141414] rounded-3xl p-5 border border-slate-200 dark:border-white/10 shadow-sm overflow-x-auto">
        {viewMode === 'clubs' ? (
          clubRankings.length === 0 ? (
            <div className="py-10 text-center text-xs text-[#64748B] dark:text-[#A0A0A0]">
              No club standings recorded yet. Assign club names inside Player Profiles!
            </div>
          ) : (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-white/10 text-[10px] uppercase tracking-wider text-[#64748B] dark:text-[#A0A0A0]">
                  <th className="py-2.5 px-2">Rank</th>
                  <th className="py-2.5 px-2">Club Name</th>
                  <th className="py-2.5 px-2 text-center">Players</th>
                  <th className="py-2.5 px-2 text-center">Wins</th>
                  <th className="py-2.5 px-2 text-center">Titles</th>
                  <th className="py-2.5 px-2 text-center">MVPs</th>
                  <th className="py-2.5 px-2 text-right">Club Points</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                {clubRankings.map((c, idx) => (
                  <tr key={c.club} className="hover:bg-[#F4F7FB] dark:hover:bg-[#080808]/60">
                    <td className="py-3 px-2 font-mono font-black text-[#FFD700]">#{idx + 1}</td>
                    <td className="py-3 px-2 font-black text-[#172033] dark:text-white">{c.club}</td>
                    <td className="py-3 px-2 text-center font-mono">{c.members}</td>
                    <td className="py-3 px-2 text-center font-mono text-[#22C55E] font-bold">{c.wins}</td>
                    <td className="py-3 px-2 text-center font-mono text-[#FFD700] font-bold">{c.titles}</td>
                    <td className="py-3 px-2 text-center font-mono text-[#D4AF37] font-bold">{c.mvps}</td>
                    <td className="py-3 px-2 text-right font-mono font-black text-sm text-[#FFD700]">
                      {c.points}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        ) : rankings.length === 0 ? (
          <div className="py-10 text-center text-xs text-[#64748B] dark:text-[#A0A0A0]">
            No players found in this category/timeframe yet. Play matches in a tournament to populate live rankings!
          </div>
        ) : (
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-white/10 text-[10px] uppercase tracking-wider text-[#64748B] dark:text-[#A0A0A0]">
                <th className="py-2.5 px-2">Rank</th>
                <th className="py-2.5 px-2">Player</th>
                <th className="py-2.5 px-2 text-center">Events</th>
                <th className="py-2.5 px-2 text-center">W - L</th>
                <th className="py-2.5 px-2 text-center">Win %</th>
                <th className="py-2.5 px-2 text-center">Streak</th>
                <th className="py-2.5 px-2 text-center">Fair-Play</th>
                <th className="py-2.5 px-2 text-center">Titles / MVPs</th>
                <th className="py-2.5 px-2 text-right">Points</th>
                <th className="py-2.5 px-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-white/5">
              {rankings.map((entry, idx) => (
                <tr
                  key={entry.normalizedKey}
                  className="hover:bg-[#F4F7FB] dark:hover:bg-[#080808]/60 transition-colors"
                >
                  <td className="py-3 px-2 font-mono font-black">
                    <span
                      className={`inline-flex items-center justify-center w-6 h-6 rounded-lg ${
                        idx === 0
                          ? 'bg-gradient-to-br from-[#FFD700] to-[#D4AF37] text-[#080808]'
                          : idx === 1
                          ? 'bg-slate-300 text-[#080808]'
                          : idx === 2
                          ? 'bg-amber-700 text-white'
                          : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0]'
                      }`}
                    >
                      {idx + 1}
                    </span>
                  </td>
                  <td className="py-3 px-2">
                    <div className="flex items-center gap-2.5">
                      {entry.photo ? (
                        <img
                          src={entry.photo}
                          alt={entry.playerName}
                          className="w-8 h-8 rounded-xl object-cover border border-[#D4AF37]/50 shrink-0"
                        />
                      ) : (
                        <div
                          className="w-8 h-8 rounded-xl text-[#080808] font-black text-[10px] flex items-center justify-center shrink-0"
                          style={{ backgroundColor: getPlayerColor(idx) }}
                        >
                          {getInitials(entry.playerName)}
                        </div>
                      )}
                      <div>
                        <div className="font-black text-[#172033] dark:text-white flex items-center gap-1.5">
                          <span>{entry.playerName}</span>
                          {entry.improvementDelta > 0 && entry.history.length > 1 && (
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 font-bold">
                              +{entry.improvementDelta}▲
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] uppercase">
                          {entry.club ? `${entry.club} · ` : ''}
                          {entry.categories.map((c) => c.replace('_', ' ')).join(' · ')}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-2 text-center font-mono font-bold text-[#64748B] dark:text-[#A0A0A0]">
                    {entry.tournamentsPlayed}
                  </td>
                  <td className="py-3 px-2 text-center font-mono font-bold text-[#172033] dark:text-white">
                    {entry.wins}W - {entry.losses}L
                  </td>
                  <td className="py-3 px-2 text-center font-mono font-bold text-[#22C55E]">
                    {entry.winRate}%
                  </td>
                  <td className="py-3 px-2 text-center font-mono font-bold text-[#FFD700]">
                    {entry.bestWinStreak > 0 ? (
                      <span className="inline-flex items-center gap-0.5">
                        <Flame className="w-3 h-3 text-amber-400" />
                        <span>{entry.currentWinStreak}/{entry.bestWinStreak}</span>
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>
                  <td className="py-3 px-2 text-center font-mono font-bold">
                    <span
                      className={
                        entry.fairPlayScore >= 90
                          ? 'text-[#22C55E]'
                          : entry.fairPlayScore >= 70
                          ? 'text-amber-400'
                          : 'text-[#EF4444]'
                      }
                    >
                      {entry.fairPlayScore}%
                    </span>
                  </td>
                  <td className="py-3 px-2 text-center font-mono font-bold text-[#FFD700]">
                    {entry.titles > 0 || entry.mvpAwards > 0
                      ? `${entry.titles}🏆 / ${entry.mvpAwards}★`
                      : '—'}
                  </td>
                  <td className="py-3 px-2 text-right font-mono font-black text-sm text-[#9A7B1C] dark:text-[#FFD700]">
                    {entry.ratingPoints}
                    {entry.achievementPoints > 0 && (
                      <span className="block text-[9px] font-bold text-[#A0A0A0]">
                        ({entry.achievementPoints} ach)
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-2 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setSelectedHistoryPlayer(entry)}
                        className="p-1.5 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[#64748B] hover:text-[#FFD700] cursor-pointer"
                        title="View Ranking History"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          downloadPlayerAchievementCard({
                            playerName: entry.playerName,
                            playerCode: `#SC-${String(idx + 1).padStart(2, '0')}`,
                            rank: idx + 1,
                            ratingPoints: entry.ratingPoints,
                            wins: entry.wins,
                            losses: entry.losses,
                            winRate: entry.winRate,
                            titles: entry.titles,
                            mvpCount: entry.mvpAwards,
                            category: entry.categories[0],
                          })
                        }
                        className="p-1.5 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[#D4AF37] hover:border-[#FFD700] cursor-pointer"
                        title="Download Achievement Card PNG"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Player Comparison Matrix */}
      {rankings.length >= 2 && playerAEntry && playerBEntry && (
        <div className="bg-white dark:bg-[#141414] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ArrowLeftRight className="w-5 h-5 text-[#D4AF37]" />
              <h3 className="text-base font-black text-[#172033] dark:text-white">
                Head-to-Head &amp; Player Comparison Matrix
              </h3>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <select
                value={playerAEntry.normalizedKey}
                onChange={(e) => setCompareA(e.target.value)}
                className="px-3 py-1.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 font-bold text-[#172033] dark:text-white"
              >
                {rankings.map((r) => (
                  <option key={r.normalizedKey} value={r.normalizedKey}>
                    {r.playerName}
                  </option>
                ))}
              </select>
              <span className="font-black text-[#D4AF37]">VS</span>
              <select
                value={playerBEntry.normalizedKey}
                onChange={(e) => setCompareB(e.target.value)}
                className="px-3 py-1.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 font-bold text-[#172033] dark:text-white"
              >
                {rankings.map((r) => (
                  <option key={r.normalizedKey} value={r.normalizedKey}>
                    {r.playerName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center text-xs">
            {[
              {
                label: 'Global Ranking Points',
                valA: playerAEntry.ratingPoints,
                valB: playerBEntry.ratingPoints,
              },
              {
                label: 'Win Percentage',
                valA: `${playerAEntry.winRate}%`,
                valB: `${playerBEntry.winRate}%`,
              },
              {
                label: 'Direct H2H Record',
                valA: h2h.winsA,
                valB: h2h.winsB,
              },
              {
                label: 'Career Wins',
                valA: playerAEntry.wins,
                valB: playerBEntry.wins,
              },
              {
                label: 'Championship Titles',
                valA: playerAEntry.titles,
                valB: playerBEntry.titles,
              },
              {
                label: 'Match MVP Awards',
                valA: playerAEntry.mvpAwards,
                valB: playerBEntry.mvpAwards,
              },
            ].map((row) => (
              <React.Fragment key={row.label}>
                <div className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] font-mono font-black text-sm text-[#172033] dark:text-[#FFD700]">
                  {row.valA}
                </div>
                <div className="p-2.5 rounded-xl flex items-center justify-center font-bold text-[#64748B] dark:text-[#A0A0A0]">
                  {row.label}
                </div>
                <div className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] font-mono font-black text-sm text-[#172033] dark:text-white">
                  {row.valB}
                </div>
              </React.Fragment>
            ))}
          </div>
        </div>
      )}

      {/* Ranking History Drawer/Modal */}
      {selectedHistoryPlayer && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-[#141414] border border-slate-200 dark:border-[#D4AF37]/35 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-[#FFD700]" />
                <h3 className="text-base font-black text-[#172033] dark:text-white">
                  {selectedHistoryPlayer.playerName} · Ranking History
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedHistoryPlayer(null)}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-white/10 text-[#64748B] dark:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {selectedHistoryPlayer.history.length === 0 ? (
              <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                No completed match points recorded yet for this player.
              </p>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto text-xs">
                {selectedHistoryPlayer.history.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-black text-[#172033] dark:text-white">
                        {item.tournamentTitle}
                      </div>
                      <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                        {item.resultLabel} · {new Date(item.date).toLocaleDateString()}
                      </div>
                    </div>
                    <span className="font-mono font-black text-[#FFD700] text-sm">
                      +{item.pointsEarned}
                    </span>
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedHistoryPlayer(null)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-xs font-black cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
