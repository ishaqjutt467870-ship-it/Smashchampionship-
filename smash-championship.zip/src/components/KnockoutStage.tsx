import React, { useState } from 'react';
import { Trophy, Medal, RotateCcw, AlertTriangle, Zap, Edit3, Award, GitBranch } from 'lucide-react';
import {
  PlayerStats,
  MatchFormat,
  TournamentFormatType,
  MatchScore,
  DoubleElimBracketState,
  ConsolationBracketState,
} from '../types';
import {
  getPlayerColor,
  getInitials,
  getFormatLabel,
  formatScore,
  getTournamentFormatLabel,
} from '../utils/tournament';

export interface KnockoutLaunchPayload {
  knockoutKey: string;
  label: string;
  playerAIndex: number;
  playerBIndex: number;
}

interface KnockoutStageProps {
  players: string[];
  standings: PlayerStats[];
  allLeagueMatchesDone: boolean;
  semis: Record<number, number>;
  semiScores?: Record<number, MatchScore>;
  quarters?: Record<number, number>;
  quarterScores?: Record<number, MatchScore>;
  finalWinner: number | null;
  finalScore?: MatchScore;
  thirdPlaceWinner: number | null;
  thirdPlaceScore?: MatchScore;
  targetPoints?: number;
  matchFormat?: MatchFormat;
  matchFormats?: Record<string, MatchFormat>;
  tournamentFormat?: TournamentFormatType;
  doubleElim?: DoubleElimBracketState;
  onUpdateDoubleElim?: (next: DoubleElimBracketState) => void;
  consolationBracket?: ConsolationBracketState;
  onUpdateConsolation?: (next: ConsolationBracketState) => void;
  onSetMatchItemFormat?: (matchId: string, fmt: MatchFormat) => void;
  onSetQuarterWinner?: (quarterIndex: number, winnerIndex: number, score?: MatchScore) => void;
  onUndoQuarter?: (quarterIndex: number) => void;
  onSetSemiWinner: (semiIndex: number, winnerIndex: number, score?: MatchScore) => void;
  onUndoSemi: (semiIndex: number) => void;
  onSetFinalWinner: (winnerIndex: number, score?: MatchScore) => void;
  onUndoFinal: () => void;
  onSetThirdPlaceWinner: (winnerIndex: number, score?: MatchScore) => void;
  onUndoThirdPlace: () => void;
  onLaunchKnockoutLive?: (payload: KnockoutLaunchPayload) => void;
  matchMvps?: Record<string, number>;
  onToggleMatchMvp?: (matchId: string, playerIndex: number | null) => void;
  onNavigateToMatches: () => void;
  onOpenPlayerProfile?: (playerId: number) => void;
}

export const KnockoutStage: React.FC<KnockoutStageProps> = ({
  players,
  standings,
  allLeagueMatchesDone,
  semis,
  semiScores = {},
  quarters = {},
  quarterScores = {},
  finalWinner,
  finalScore,
  thirdPlaceWinner,
  thirdPlaceScore,
  targetPoints = 21,
  matchFormat = 'bo3',
  matchFormats = {},
  tournamentFormat = 'round_robin',
  doubleElim = {},
  onUpdateDoubleElim,
  consolationBracket = {},
  onUpdateConsolation,
  onSetMatchItemFormat,
  onSetQuarterWinner,
  onUndoQuarter,
  onSetSemiWinner,
  onUndoSemi,
  onSetFinalWinner,
  onUndoFinal,
  onSetThirdPlaceWinner,
  onUndoThirdPlace,
  onLaunchKnockoutLive,
  matchMvps = {},
  onToggleMatchMvp,
  onNavigateToMatches,
  onOpenPlayerProfile,
}) => {
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [draftScores, setDraftScores] = useState<
    Record<string, { s1a: string; s1b: string; s2a: string; s2b: string; s3a: string; s3b: string }>
  >({});

  const getDraft = (key: string) =>
    draftScores[key] || {
      s1a: String(targetPoints),
      s1b: String(Math.max(5, targetPoints - 4)),
      s2a: String(targetPoints),
      s2b: String(Math.max(5, targetPoints - 5)),
      s3a: '',
      s3b: '',
    };

  const updateDraftField = (
    key: string,
    field: 's1a' | 's1b' | 's2a' | 's2b' | 's3a' | 's3b',
    val: string
  ) => {
    const cur = getDraft(key);
    setDraftScores((prev) => ({ ...prev, [key]: { ...cur, [field]: val } }));
  };

  const resolveScoreAndWinner = (key: string, playerAId: number, playerBId: number) => {
    const d = getDraft(key);
    const s1a = parseInt(d.s1a || String(targetPoints), 10);
    const s1b = parseInt(d.s1b || String(Math.max(5, targetPoints - 4)), 10);
    const fmt = matchFormats[key] || matchFormat;
    const s2a = fmt !== 'bo1' ? parseInt(d.s2a || String(targetPoints), 10) : undefined;
    const s2b =
      fmt !== 'bo1' ? parseInt(d.s2b || String(Math.max(5, targetPoints - 5)), 10) : undefined;
    const s3a = d.s3a ? parseInt(d.s3a, 10) : undefined;
    const s3b = d.s3b ? parseInt(d.s3b, 10) : undefined;

    let setsA = 0;
    let setsB = 0;
    const pairs: Array<[number | undefined, number | undefined]> = [
      [s1a, s1b],
      [s2a, s2b],
      [s3a, s3b],
    ];
    pairs.forEach(([a, b]) => {
      if (a !== undefined && b !== undefined && (a > 0 || b > 0)) {
        if (a > b) setsA++;
        else if (b > a) setsB++;
      }
    });
    const winnerId = setsA >= setsB ? playerAId : playerBId;
    const score: MatchScore = {
      s1a,
      s1b,
      ...(s2a !== undefined && s2b !== undefined ? { s2a, s2b } : {}),
      ...(s3a !== undefined && s3b !== undefined ? { s3a, s3b } : {}),
    };
    return { winnerId, score };
  };

  const renderFormatToggle = (matchKey: string) => {
    const activeFmt = matchFormats[matchKey] || matchFormat;
    if (!onSetMatchItemFormat) return null;
    return (
      <div className="inline-flex items-center gap-0.5 p-0.5 rounded-lg bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15">
        {(['bo1', 'bo3', 'bo5'] as MatchFormat[]).map((fmt) => (
          <button
            key={fmt}
            type="button"
            onClick={() => onSetMatchItemFormat(matchKey, fmt)}
            className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase cursor-pointer transition-colors ${
              activeFmt === fmt
                ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                : 'text-[#64748B] dark:text-[#A0A0A0]'
            }`}
          >
            {fmt}
          </button>
        ))}
      </div>
    );
  };

  if (standings.length < 4) {
    return (
      <div className="p-8 text-center bg-white dark:bg-[#141414] rounded-3xl border border-slate-200 dark:border-white/10">
        <p className="text-sm text-[#64748B] dark:text-[#A0A0A0]">
          At least 4 players are required to hold Knockout playoffs.
        </p>
      </div>
    );
  }

  // DOUBLE ELIMINATION BRACKET MODE (Winners Bracket + Losers Bracket + Grand Final)
  if (tournamentFormat === 'double_elimination' && onUpdateDoubleElim) {
    const s1 = standings[0];
    const s2 = standings[1];
    const s3 = standings[2];
    const s4 = standings[3];

    const wbSf1W = doubleElim.winnersSemis?.[0];
    const wbSf2W = doubleElim.winnersSemis?.[1];
    const wbSf1L = wbSf1W !== undefined ? (wbSf1W === s1.id ? s4.id : s1.id) : undefined;
    const wbSf2L = wbSf2W !== undefined ? (wbSf2W === s2.id ? s3.id : s2.id) : undefined;

    const wbFinalW = doubleElim.winnersFinalWinner ?? undefined;
    const wbFinalL =
      wbFinalW !== undefined && wbSf1W !== undefined && wbSf2W !== undefined
        ? wbFinalW === wbSf1W
          ? wbSf2W
          : wbSf1W
        : undefined;

    const lbR1W = doubleElim.losersR1?.[0];
    const lbFinalW = doubleElim.losersFinalWinner ?? undefined;
    const gfW = finalWinner ?? doubleElim.grandFinalWinner ?? null;

    return (
      <div className="space-y-6 animate-fade-in">
        <div className="bg-white dark:bg-[#141414] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-white/10">
            <div>
              <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-[#D4AF37]" />
                <span>Double Elimination Bracket</span>
              </h2>
              <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
                Winners Bracket &amp; Losers Elimination Bracket leading to the Grand Final. A player must lose twice to be eliminated.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-[#D4AF37] font-bold">
              <span>{getTournamentFormatLabel(tournamentFormat)}</span>
              <span>·</span>
              <span>{getFormatLabel(matchFormat)}</span>
            </div>
          </div>

          {/* Winners Bracket */}
          <div className="space-y-3">
            <div className="text-xs font-black uppercase tracking-wider text-[#D4AF37]">
              Winners Bracket (Upper Seeded Draw)
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* WB SF1 */}
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2.5">
                <div className="flex justify-between text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0]">
                  <span className="text-[#172033] dark:text-white">WB Semi-Final 1</span>
                  <span>#1 vs #4</span>
                </div>
                {[s1, s4].map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    disabled={wbSf1W !== undefined}
                    onClick={() =>
                      onUpdateDoubleElim({
                        ...doubleElim,
                        winnersSemis: { ...(doubleElim.winnersSemis || {}), 0: p.id },
                      })
                    }
                    className={`w-full p-2.5 rounded-xl border text-left text-xs font-bold flex items-center justify-between cursor-pointer ${
                      wbSf1W === p.id
                        ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] border-transparent font-black'
                        : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                    }`}
                  >
                    <span className="truncate">{p.name}</span>
                    {wbSf1W === p.id && <span>WB Final ✓</span>}
                  </button>
                ))}
                {wbSf1W !== undefined && (
                  <button
                    type="button"
                    onClick={() => {
                      const nextSemis = { ...(doubleElim.winnersSemis || {}) };
                      delete nextSemis[0];
                      onUpdateDoubleElim({
                        ...doubleElim,
                        winnersSemis: nextSemis,
                        winnersFinalWinner: null,
                      });
                    }}
                    className="text-[11px] text-[#64748B] hover:text-white underline cursor-pointer"
                  >
                    Undo WB SF1
                  </button>
                )}
              </div>

              {/* WB SF2 */}
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2.5">
                <div className="flex justify-between text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0]">
                  <span className="text-[#172033] dark:text-white">WB Semi-Final 2</span>
                  <span>#2 vs #3</span>
                </div>
                {[s2, s3].map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    disabled={wbSf2W !== undefined}
                    onClick={() =>
                      onUpdateDoubleElim({
                        ...doubleElim,
                        winnersSemis: { ...(doubleElim.winnersSemis || {}), 1: p.id },
                      })
                    }
                    className={`w-full p-2.5 rounded-xl border text-left text-xs font-bold flex items-center justify-between cursor-pointer ${
                      wbSf2W === p.id
                        ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] border-transparent font-black'
                        : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                    }`}
                  >
                    <span className="truncate">{p.name}</span>
                    {wbSf2W === p.id && <span>WB Final ✓</span>}
                  </button>
                ))}
                {wbSf2W !== undefined && (
                  <button
                    type="button"
                    onClick={() => {
                      const nextSemis = { ...(doubleElim.winnersSemis || {}) };
                      delete nextSemis[1];
                      onUpdateDoubleElim({
                        ...doubleElim,
                        winnersSemis: nextSemis,
                        winnersFinalWinner: null,
                      });
                    }}
                    className="text-[11px] text-[#64748B] hover:text-white underline cursor-pointer"
                  >
                    Undo WB SF2
                  </button>
                )}
              </div>

              {/* WB Final */}
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/30 space-y-2.5">
                <div className="flex justify-between text-[11px] font-bold text-[#D4AF37]">
                  <span>Winners Final</span>
                  <span>Direct to Grand Final</span>
                </div>
                {wbSf1W !== undefined && wbSf2W !== undefined ? (
                  <>
                    {[wbSf1W, wbSf2W].map((pid) => (
                      <button
                        key={pid}
                        type="button"
                        disabled={wbFinalW !== undefined}
                        onClick={() =>
                          onUpdateDoubleElim({ ...doubleElim, winnersFinalWinner: pid })
                        }
                        className={`w-full p-2.5 rounded-xl border text-left text-xs font-bold flex items-center justify-between cursor-pointer ${
                          wbFinalW === pid
                            ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] border-transparent font-black'
                            : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                        }`}
                      >
                        <span className="truncate">{players[pid]}</span>
                        {wbFinalW === pid && <span>Grand Finalist ✓</span>}
                      </button>
                    ))}
                    {wbFinalW !== undefined && (
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateDoubleElim({ ...doubleElim, winnersFinalWinner: null })
                        }
                        className="text-[11px] text-[#64748B] hover:text-white underline cursor-pointer"
                      >
                        Undo Winners Final
                      </button>
                    )}
                  </>
                ) : (
                  <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] py-4 text-center">
                    Complete both WB Semi-Finals first.
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Losers Bracket */}
          <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-white/10">
            <div className="text-xs font-black uppercase tracking-wider text-[#A0A0A0]">
              Losers Bracket (Lower Second-Chance Draw)
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* LB R1 */}
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2.5">
                <div className="flex justify-between text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0]">
                  <span className="text-[#172033] dark:text-white">Losers Elimination Match</span>
                  <span>WB SF1 Loser vs WB SF2 Loser</span>
                </div>
                {wbSf1L !== undefined && wbSf2L !== undefined ? (
                  <>
                    {[wbSf1L, wbSf2L].map((pid) => (
                      <button
                        key={pid}
                        type="button"
                        disabled={lbR1W !== undefined}
                        onClick={() =>
                          onUpdateDoubleElim({
                            ...doubleElim,
                            losersR1: { ...(doubleElim.losersR1 || {}), 0: pid },
                          })
                        }
                        className={`w-full p-2.5 rounded-xl border text-left text-xs font-bold flex items-center justify-between cursor-pointer ${
                          lbR1W === pid
                            ? 'bg-[#22C55E] text-[#080808] border-transparent font-black'
                            : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                        }`}
                      >
                        <span className="truncate">{players[pid]}</span>
                        {lbR1W === pid && <span>Advances to LB Final ✓</span>}
                      </button>
                    ))}
                    {lbR1W !== undefined && (
                      <button
                        type="button"
                        onClick={() => {
                          const nextL = { ...(doubleElim.losersR1 || {}) };
                          delete nextL[0];
                          onUpdateDoubleElim({
                            ...doubleElim,
                            losersR1: nextL,
                            losersFinalWinner: null,
                          });
                        }}
                        className="text-[11px] text-[#64748B] hover:text-white underline cursor-pointer"
                      >
                        Undo LB Elimination
                      </button>
                    )}
                  </>
                ) : (
                  <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] py-4 text-center">
                    Awaiting WB Semi-Final losers.
                  </p>
                )}
              </div>

              {/* LB Final */}
              <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2.5">
                <div className="flex justify-between text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0]">
                  <span className="text-[#172033] dark:text-white">Losers Bracket Final</span>
                  <span>LB R1 Winner vs WB Final Loser</span>
                </div>
                {lbR1W !== undefined && wbFinalL !== undefined ? (
                  <>
                    {[lbR1W, wbFinalL].map((pid) => (
                      <button
                        key={pid}
                        type="button"
                        disabled={lbFinalW !== undefined}
                        onClick={() =>
                          onUpdateDoubleElim({ ...doubleElim, losersFinalWinner: pid })
                        }
                        className={`w-full p-2.5 rounded-xl border text-left text-xs font-bold flex items-center justify-between cursor-pointer ${
                          lbFinalW === pid
                            ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] border-transparent font-black'
                            : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                        }`}
                      >
                        <span className="truncate">{players[pid]}</span>
                        {lbFinalW === pid && <span>Grand Finalist ✓</span>}
                      </button>
                    ))}
                    {lbFinalW !== undefined && (
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateDoubleElim({ ...doubleElim, losersFinalWinner: null })
                        }
                        className="text-[11px] text-[#64748B] hover:text-white underline cursor-pointer"
                      >
                        Undo LB Final
                      </button>
                    )}
                  </>
                ) : (
                  <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] py-4 text-center">
                    Complete WB Final and LB Elimination match first.
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Grand Final */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-[#141414] to-[#080808] border border-[#D4AF37]/45 text-white shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="w-6 h-6 text-[#FFD700]" />
                <h3 className="text-lg font-black">Double Elimination Grand Final</h3>
              </div>
              <span className="text-xs font-bold text-[#D4AF37] uppercase">WB Champ vs LB Champ</span>
            </div>

            {wbFinalW !== undefined && lbFinalW !== undefined ? (
              gfW === null ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    { idx: wbFinalW, tag: 'Winners Bracket Champion' },
                    { idx: lbFinalW, tag: 'Losers Bracket Champion' },
                  ].map((f) => (
                    <button
                      key={f.idx}
                      type="button"
                      onClick={() => {
                        onUpdateDoubleElim({ ...doubleElim, grandFinalWinner: f.idx });
                        onSetFinalWinner(f.idx);
                      }}
                      className="p-4 rounded-2xl bg-[#141414] hover:border-[#FFD700] border border-[#D4AF37]/40 text-left cursor-pointer"
                    >
                      <div className="text-sm font-black text-white">{players[f.idx]}</div>
                      <div className="text-[11px] text-[#D4AF37] mt-0.5">{f.tag} · Crown Champion</div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-sm font-black text-[#FFD700]">
                    🏆 Undisputed Champion: {players[gfW]}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateDoubleElim({ ...doubleElim, grandFinalWinner: null });
                      onUndoFinal();
                    }}
                    className="px-3 py-1.5 rounded-xl border border-white/20 text-xs text-white/80 hover:text-white cursor-pointer"
                  >
                    Undo Grand Final
                  </button>
                </div>
              )
            ) : (
              <p className="text-xs text-[#A0A0A0] text-center py-4">
                Awaiting both Winners Finalist and Losers Finalist.
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  const hasTop8 = standings.length >= 8 && Boolean(onSetQuarterWinner);
  const qfPairs: Array<[PlayerStats, PlayerStats, string]> = hasTop8
    ? [
        [standings[0], standings[7], '#1 vs #8'],
        [standings[3], standings[4], '#4 vs #5'],
        [standings[1], standings[6], '#2 vs #7'],
        [standings[2], standings[5], '#3 vs #6'],
      ]
    : [];

  const allQuartersComplete =
    hasTop8 &&
    quarters[0] !== undefined &&
    quarters[1] !== undefined &&
    quarters[2] !== undefined &&
    quarters[3] !== undefined;

  const groupA = standings.filter((p) => p.group === 'A');
  const groupB = standings.filter((p) => p.group === 'B');
  const useGroupSeeding =
    tournamentFormat === 'group_stage' && groupA.length >= 2 && groupB.length >= 2;

  const findStat = (id: number) => standings.find((s) => s.id === id) || standings[0];

  let sf1A: PlayerStats;
  let sf1B: PlayerStats;
  let sf2A: PlayerStats;
  let sf2B: PlayerStats;
  let sf1Subtitle = '#1 Seed vs #4 Seed';
  let sf2Subtitle = '#2 Seed vs #3 Seed';

  if (allQuartersComplete) {
    sf1A = findStat(quarters[0]);
    sf1B = findStat(quarters[1]);
    sf2A = findStat(quarters[2]);
    sf2B = findStat(quarters[3]);
    sf1Subtitle = 'QF1 Winner vs QF2 Winner';
    sf2Subtitle = 'QF3 Winner vs QF4 Winner';
  } else if (useGroupSeeding) {
    sf1A = groupA[0];
    sf1B = groupB[1];
    sf2A = groupB[0];
    sf2B = groupA[1];
    sf1Subtitle = 'Group A #1 vs Group B #2';
    sf2Subtitle = 'Group B #1 vs Group A #2';
  } else {
    sf1A = standings[0];
    sf1B = standings[3];
    sf2A = standings[1];
    sf2B = standings[2];
  }

  const sf1Winner = semis[0];
  const sf2Winner = semis[1];

  let sf1Loser: number | null = null;
  if (sf1Winner !== undefined) {
    sf1Loser = sf1Winner === sf1A.id ? sf1B.id : sf1A.id;
  }
  let sf2Loser: number | null = null;
  if (sf2Winner !== undefined) {
    sf2Loser = sf2Winner === sf2A.id ? sf2B.id : sf2A.id;
  }

  const renderCompetitorRow = (
    playerStat: PlayerStats,
    seedLabel: string,
    isWinner: boolean
  ) => (
    <div
      className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
        isWinner
          ? 'bg-[#D4AF37]/15 border-[#D4AF37]'
          : 'bg-white dark:bg-[#080808] border-slate-200 dark:border-white/10'
      }`}
    >
      <div
        onClick={() => onOpenPlayerProfile?.(playerStat.id)}
        className="flex items-center gap-2.5 cursor-pointer group min-w-0"
      >
        <span className="text-[10px] font-black text-[#D4AF37] w-6 shrink-0">{seedLabel}</span>
        {playerStat.photo ? (
          <img
            src={playerStat.photo}
            alt={playerStat.name}
            className="w-7 h-7 rounded-lg object-cover border border-[#D4AF37]/60 shadow-sm shrink-0"
          />
        ) : (
          <div
            className="w-7 h-7 rounded-lg text-[#080808] font-black text-xs flex items-center justify-center shrink-0"
            style={{ backgroundColor: playerStat.avatarColor }}
          >
            {getInitials(playerStat.name)}
          </div>
        )}
        <span className="text-sm font-bold text-[#172033] dark:text-white group-hover:text-[#FFD700] transition-colors truncate">
          {playerStat.name}
        </span>
      </div>
      {isWinner && (
        <span className="text-[11px] font-black text-[#22C55E] uppercase tracking-wider shrink-0 pl-2">
          Qualified
        </span>
      )}
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {!allLeagueMatchesDone && (
        <div className="p-4 rounded-2xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#172033] dark:text-slate-200">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <span>
              <strong>Stage in progress:</strong> Playoff seeds reflect live standings. Complete all
              stage fixtures to lock official seeds.
            </span>
          </div>
          <button
            onClick={onNavigateToMatches}
            className="px-3.5 py-1.5 bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] font-extrabold rounded-xl shrink-0 self-start sm:self-auto transition-opacity hover:opacity-90 cursor-pointer"
          >
            Go to Matches
          </button>
        </div>
      )}

      {/* Bracket Header Card */}
      <div className="bg-white dark:bg-[#141414] rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-white/10">
          <div>
            <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight flex items-center gap-2">
              <Trophy className="w-5 h-5 text-[#D4AF37]" />
              <span>Championship Playoff Bracket</span>
            </h2>
            <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
              {useGroupSeeding
                ? 'Cross-Group Semi-Finals (A1 vs B2 · B1 vs A2) leading to Grand Final & Bronze Medal Match.'
                : hasTop8
                ? 'Top-8 Quarter-Finals, Semi-Finals, Grand Final & Bronze Medal Playoff.'
                : 'Semi-Finals (1st vs 4th · 2nd vs 3rd) leading to the Grand Final & Bronze Medal Match.'}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-[#64748B] dark:text-[#A0A0A0]">
            <span className="font-bold text-[#172033] dark:text-[#FFD700]">
              {getTournamentFormatLabel(tournamentFormat)}
            </span>
            <span aria-hidden="true">·</span>
            <span>{getFormatLabel(matchFormat)}</span>
          </div>
        </div>

        {/* Optional Top-8 Quarter-Finals Section */}
        {hasTop8 && onSetQuarterWinner && onUndoQuarter && (
          <div className="mt-6 pb-6 border-b border-slate-100 dark:border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-[#D4AF37]">
                <Zap className="w-4 h-4" />
                <span>Quarter-Finals (Top 8 Bracket)</span>
              </div>
              <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                {allQuartersComplete
                  ? 'Quarter-Final winners seeded into Semi-Finals'
                  : 'Complete all 4 QFs to seed Semi-Finals dynamically'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {qfPairs.map(([pA, pB, seedText], qIdx) => {
                const qWinner = quarters[qIdx];
                const qKey = `qf-${qIdx}`;
                const qScoreStr = formatScore(quarterScores[qIdx]);
                const isEditingQ = editingKey === qKey;
                const d = getDraft(qKey);

                return (
                  <div
                    key={qIdx}
                    className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-white/10 space-y-2.5"
                  >
                    <div className="flex items-center justify-between gap-2 text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0]">
                      <span className="text-[#172033] dark:text-white">QUARTER-FINAL {qIdx + 1}</span>
                      <div className="flex items-center gap-2">
                        <span>{seedText}</span>
                        {renderFormatToggle(qKey)}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {[pA, pB].map((p) => {
                        const won = qWinner === p.id;
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => qWinner === undefined && onSetQuarterWinner(qIdx, p.id)}
                            disabled={qWinner !== undefined}
                            className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all truncate cursor-pointer ${
                              won
                                ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] border-transparent font-black'
                                : 'bg-white dark:bg-[#141414] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white hover:border-[#D4AF37]'
                            }`}
                          >
                            {p.name}
                          </button>
                        );
                      })}
                    </div>

                    {qScoreStr && (
                      <div className="text-[11px] font-mono text-[#D4AF37] font-bold">
                        Games: {qScoreStr}
                      </div>
                    )}

                    {qWinner === undefined && (
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        {onLaunchKnockoutLive && (
                          <button
                            type="button"
                            onClick={() =>
                              onLaunchKnockoutLive({
                                knockoutKey: qKey,
                                label: `Quarter-Final ${qIdx + 1}`,
                                playerAIndex: pA.id,
                                playerBIndex: pB.id,
                              })
                            }
                            className="px-2.5 py-1 rounded-lg bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                          >
                            <Zap className="w-3 h-3" />
                            <span>Score Live</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setEditingKey(isEditingQ ? null : qKey)}
                          className="text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0] hover:text-[#FFD700] flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>{isEditingQ ? 'Cancel' : 'Enter Set Scores'}</span>
                        </button>
                      </div>
                    )}

                    {isEditingQ && qWinner === undefined && (
                      <div className="p-2.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 space-y-2 text-[11px]">
                        <div className="grid grid-cols-3 gap-1.5 text-center">
                          <div>
                            <span className="text-[#A0A0A0] block mb-0.5">Game 1</span>
                            <div className="flex items-center justify-center gap-1">
                              <input type="number" value={d.s1a} onChange={(e) => updateDraftField(qKey, 's1a', e.target.value)} className="w-9 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                              <input type="number" value={d.s1b} onChange={(e) => updateDraftField(qKey, 's1b', e.target.value)} className="w-9 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                            </div>
                          </div>
                          <div>
                            <span className="text-[#A0A0A0] block mb-0.5">Game 2</span>
                            <div className="flex items-center justify-center gap-1">
                              <input type="number" value={d.s2a} onChange={(e) => updateDraftField(qKey, 's2a', e.target.value)} className="w-9 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                              <input type="number" value={d.s2b} onChange={(e) => updateDraftField(qKey, 's2b', e.target.value)} className="w-9 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                            </div>
                          </div>
                          <div>
                            <span className="text-[#A0A0A0] block mb-0.5">Game 3</span>
                            <div className="flex items-center justify-center gap-1">
                              <input type="number" value={d.s3a} placeholder="—" onChange={(e) => updateDraftField(qKey, 's3a', e.target.value)} className="w-9 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                              <input type="number" value={d.s3b} placeholder="—" onChange={(e) => updateDraftField(qKey, 's3b', e.target.value)} className="w-9 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            const { winnerId, score } = resolveScoreAndWinner(qKey, pA.id, pB.id);
                            onSetQuarterWinner(qIdx, winnerId, score);
                            setEditingKey(null);
                          }}
                          className="w-full py-1.5 rounded-lg bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] font-extrabold cursor-pointer"
                        >
                          Save Quarter-Final Score
                        </button>
                      </div>
                    )}

                    {qWinner !== undefined && (
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[#22C55E] font-bold">
                            Winner: {players[qWinner]}
                          </span>
                          {matchMvps[`ko:qf-${qIdx}`] === qWinner && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-600 dark:text-[#FFD700] border border-amber-400/40 text-[10px] font-black uppercase">
                              <Award className="w-3 h-3" />
                              <span>Match MVP</span>
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {onToggleMatchMvp && (
                            <button
                              type="button"
                              onClick={() =>
                                onToggleMatchMvp(
                                  `ko:qf-${qIdx}`,
                                  matchMvps[`ko:qf-${qIdx}`] === qWinner ? null : qWinner
                                )
                              }
                              className={`px-2 py-0.5 rounded-lg border text-[10px] font-extrabold flex items-center gap-1 cursor-pointer ${
                                matchMvps[`ko:qf-${qIdx}`] === qWinner
                                  ? 'bg-amber-400/20 border-amber-400/50 text-amber-600 dark:text-[#FFD700]'
                                  : 'border-slate-300 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0]'
                              }`}
                            >
                              <Award className="w-3 h-3" />
                              <span>{matchMvps[`ko:qf-${qIdx}`] === qWinner ? 'MVP' : 'Award MVP'}</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => onUndoQuarter(qIdx)}
                            className="text-[#64748B] hover:text-white underline cursor-pointer"
                          >
                            Undo
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Semi-Finals Grid */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* SEMI-FINAL 1 */}
          <div className="p-5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808]/90 border border-slate-200 dark:border-white/10 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]">
              <span className="flex items-center gap-1.5 text-[#172033] dark:text-white">
                <Medal className="w-4 h-4 text-[#FFD700]" />
                <span>SEMI-FINAL 1</span>
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[#D4AF37]">{sf1Subtitle}</span>
                {renderFormatToggle('sf-0')}
              </div>
            </div>

            <div className="space-y-2">
              {renderCompetitorRow(sf1A, useGroupSeeding ? 'A1' : '#1', sf1Winner === sf1A.id)}
              {renderCompetitorRow(sf1B, useGroupSeeding ? 'B2' : '#4', sf1Winner === sf1B.id)}
            </div>

            {formatScore(semiScores[0]) && (
              <div className="text-xs font-mono text-[#D4AF37] font-bold">
                Games: {formatScore(semiScores[0])}
              </div>
            )}

            <div className="pt-2 space-y-2">
              {sf1Winner === undefined ? (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onSetSemiWinner(0, sf1A.id)}
                      className="py-2.5 px-3 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] font-extrabold text-xs rounded-xl transition-all truncate cursor-pointer"
                    >
                      {sf1A.name} Wins
                    </button>
                    <button
                      onClick={() => onSetSemiWinner(0, sf1B.id)}
                      className="py-2.5 px-3 bg-[#172B4D] dark:bg-white/15 hover:opacity-95 text-white font-extrabold text-xs rounded-xl transition-all truncate cursor-pointer"
                    >
                      {sf1B.name} Wins
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    {onLaunchKnockoutLive && (
                      <button
                        type="button"
                        onClick={() =>
                          onLaunchKnockoutLive({
                            knockoutKey: 'sf-0',
                            label: 'Semi-Final 1',
                            playerAIndex: sf1A.id,
                            playerBIndex: sf1B.id,
                          })
                        }
                        className="px-3 py-1.5 rounded-xl bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>Score Live on Court</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setEditingKey(editingKey === 'sf-0' ? null : 'sf-0')}
                      className="text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] hover:text-[#FFD700] flex items-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{editingKey === 'sf-0' ? 'Close' : 'Enter Set Scores'}</span>
                    </button>
                  </div>

                  {editingKey === 'sf-0' && (
                    <div className="p-3 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 space-y-2 text-xs">
                      <div className="grid grid-cols-3 gap-2 text-center">
                        {(['1', '2', '3'] as const).map((sn) => {
                          const d = getDraft('sf-0');
                          const fa = `s${sn}a` as 's1a' | 's2a' | 's3a';
                          const fb = `s${sn}b` as 's1b' | 's2b' | 's3b';
                          return (
                            <div key={sn}>
                              <span className="text-[10px] text-[#A0A0A0] block mb-1">Game {sn}</span>
                              <div className="flex items-center justify-center gap-1">
                                <input type="number" value={d[fa]} placeholder="—" onChange={(e) => updateDraftField('sf-0', fa, e.target.value)} className="w-10 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                                <input type="number" value={d[fb]} placeholder="—" onChange={(e) => updateDraftField('sf-0', fb, e.target.value)} className="w-10 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const { winnerId, score } = resolveScoreAndWinner('sf-0', sf1A.id, sf1B.id);
                          onSetSemiWinner(0, winnerId, score);
                          setEditingKey(null);
                        }}
                        className="w-full py-2 rounded-xl bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] font-extrabold cursor-pointer"
                      >
                        Save Semi-Final 1 Score
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                      Advancing:{' '}
                      <strong className="text-[#22C55E]">{players[sf1Winner]}</strong>
                    </span>
                    {matchMvps['ko:sf-0'] === sf1Winner && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-600 dark:text-[#FFD700] border border-amber-400/40 text-[10px] font-black uppercase">
                        <Award className="w-3 h-3" />
                        <span>Match MVP</span>
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    {onToggleMatchMvp && (
                      <button
                        type="button"
                        onClick={() =>
                          onToggleMatchMvp(
                            'ko:sf-0',
                            matchMvps['ko:sf-0'] === sf1Winner ? null : sf1Winner
                          )
                        }
                        className={`px-2.5 py-1.5 rounded-lg border text-xs font-extrabold flex items-center gap-1 cursor-pointer ${
                          matchMvps['ko:sf-0'] === sf1Winner
                            ? 'bg-amber-400/20 border-amber-400/50 text-amber-600 dark:text-[#FFD700]'
                            : 'border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0]'
                        }`}
                      >
                        <Award className="w-3 h-3" />
                        <span>{matchMvps['ko:sf-0'] === sf1Winner ? 'Match MVP' : 'Award MVP'}</span>
                      </button>
                    )}
                    <button
                      onClick={() => onUndoSemi(0)}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 hover:bg-slate-200 dark:hover:bg-white/10 text-xs font-bold text-[#64748B] dark:text-slate-300 flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Undo</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* SEMI-FINAL 2 */}
          <div className="p-5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808]/90 border border-slate-200 dark:border-white/10 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]">
              <span className="flex items-center gap-1.5 text-[#172033] dark:text-white">
                <Medal className="w-4 h-4 text-[#D4AF37]" />
                <span>SEMI-FINAL 2</span>
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[#D4AF37]">{sf2Subtitle}</span>
                {renderFormatToggle('sf-1')}
              </div>
            </div>

            <div className="space-y-2">
              {renderCompetitorRow(sf2A, useGroupSeeding ? 'B1' : '#2', sf2Winner === sf2A.id)}
              {renderCompetitorRow(sf2B, useGroupSeeding ? 'A2' : '#3', sf2Winner === sf2B.id)}
            </div>

            {formatScore(semiScores[1]) && (
              <div className="text-xs font-mono text-[#D4AF37] font-bold">
                Games: {formatScore(semiScores[1])}
              </div>
            )}

            <div className="pt-2 space-y-2">
              {sf2Winner === undefined ? (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onSetSemiWinner(1, sf2A.id)}
                      className="py-2.5 px-3 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] font-extrabold text-xs rounded-xl transition-all truncate cursor-pointer"
                    >
                      {sf2A.name} Wins
                    </button>
                    <button
                      onClick={() => onSetSemiWinner(1, sf2B.id)}
                      className="py-2.5 px-3 bg-[#172B4D] dark:bg-white/15 hover:opacity-95 text-white font-extrabold text-xs rounded-xl transition-all truncate cursor-pointer"
                    >
                      {sf2B.name} Wins
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    {onLaunchKnockoutLive && (
                      <button
                        type="button"
                        onClick={() =>
                          onLaunchKnockoutLive({
                            knockoutKey: 'sf-1',
                            label: 'Semi-Final 2',
                            playerAIndex: sf2A.id,
                            playerBIndex: sf2B.id,
                          })
                        }
                        className="px-3 py-1.5 rounded-xl bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>Score Live on Court</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setEditingKey(editingKey === 'sf-1' ? null : 'sf-1')}
                      className="text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] hover:text-[#FFD700] flex items-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{editingKey === 'sf-1' ? 'Close' : 'Enter Set Scores'}</span>
                    </button>
                  </div>

                  {editingKey === 'sf-1' && (
                    <div className="p-3 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 space-y-2 text-xs">
                      <div className="grid grid-cols-3 gap-2 text-center">
                        {(['1', '2', '3'] as const).map((sn) => {
                          const d = getDraft('sf-1');
                          const fa = `s${sn}a` as 's1a' | 's2a' | 's3a';
                          const fb = `s${sn}b` as 's1b' | 's2b' | 's3b';
                          return (
                            <div key={sn}>
                              <span className="text-[10px] text-[#A0A0A0] block mb-1">Game {sn}</span>
                              <div className="flex items-center justify-center gap-1">
                                <input type="number" value={d[fa]} placeholder="—" onChange={(e) => updateDraftField('sf-1', fa, e.target.value)} className="w-10 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                                <input type="number" value={d[fb]} placeholder="—" onChange={(e) => updateDraftField('sf-1', fb, e.target.value)} className="w-10 p-1 text-center rounded bg-[#F4F7FB] dark:bg-[#080808] border border-slate-300 dark:border-white/15" />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const { winnerId, score } = resolveScoreAndWinner('sf-1', sf2A.id, sf2B.id);
                          onSetSemiWinner(1, winnerId, score);
                          setEditingKey(null);
                        }}
                        className="w-full py-2 rounded-xl bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] font-extrabold cursor-pointer"
                      >
                        Save Semi-Final 2 Score
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                      Advancing:{' '}
                      <strong className="text-[#22C55E]">{players[sf2Winner]}</strong>
                    </span>
                    {matchMvps['ko:sf-1'] === sf2Winner && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-600 dark:text-[#FFD700] border border-amber-400/40 text-[10px] font-black uppercase">
                        <Award className="w-3 h-3" />
                        <span>Match MVP</span>
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    {onToggleMatchMvp && (
                      <button
                        type="button"
                        onClick={() =>
                          onToggleMatchMvp(
                            'ko:sf-1',
                            matchMvps['ko:sf-1'] === sf2Winner ? null : sf2Winner
                          )
                        }
                        className={`px-2.5 py-1.5 rounded-lg border text-xs font-extrabold flex items-center gap-1 cursor-pointer ${
                          matchMvps['ko:sf-1'] === sf2Winner
                            ? 'bg-amber-400/20 border-amber-400/50 text-amber-600 dark:text-[#FFD700]'
                            : 'border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0]'
                        }`}
                      >
                        <Award className="w-3 h-3" />
                        <span>{matchMvps['ko:sf-1'] === sf2Winner ? 'Match MVP' : 'Award MVP'}</span>
                      </button>
                    )}
                    <button
                      onClick={() => onUndoSemi(1)}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 hover:bg-slate-200 dark:hover:bg-white/10 text-xs font-bold text-[#64748B] dark:text-slate-300 flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Undo</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* GRAND FINAL SECTION */}
        <div className="mt-8 pt-8 border-t border-slate-100 dark:border-white/10">
          <div className="p-6 rounded-3xl bg-gradient-to-br from-[#141414] via-[#101010] to-[#080808] border border-[#D4AF37]/45 text-white shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
              <div className="flex items-center gap-2.5">
                <Trophy className="w-6 h-6 text-[#FFD700]" />
                <h3 className="text-lg font-black">Grand Championship Final</h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">
                  Gold &amp; Silver Medal Match
                </span>
                {renderFormatToggle('final')}
              </div>
            </div>

            {sf1Winner !== undefined && sf2Winner !== undefined ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    { idx: sf1Winner, label: 'Winner Semi-Final 1' },
                    { idx: sf2Winner, label: 'Winner Semi-Final 2' },
                  ].map((finalist) => {
                    const isChamp = finalWinner === finalist.idx;
                    return (
                      <div
                        key={finalist.idx}
                        className={`p-4 rounded-2xl border flex items-center justify-between ${
                          isChamp
                            ? 'bg-[#D4AF37]/15 border-[#FFD700]'
                            : 'bg-[#080808]/80 border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-9 h-9 rounded-xl text-[#080808] font-black text-xs flex items-center justify-center shadow shrink-0"
                            style={{ backgroundColor: getPlayerColor(finalist.idx) }}
                          >
                            {getInitials(players[finalist.idx])}
                          </div>
                          <div className="min-w-0">
                            <span className="font-black text-sm text-white block truncate">
                              {players[finalist.idx]}
                            </span>
                            <span className="text-[11px] text-[#A0A0A0]">{finalist.label}</span>
                          </div>
                        </div>
                        {isChamp && (
                          <span className="text-xs font-black text-[#FFD700] shrink-0">
                            🏆 Champion
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {formatScore(finalScore) && (
                  <div className="text-xs font-mono text-[#FFD700] font-bold">
                    Grand Final Score: {formatScore(finalScore)}
                  </div>
                )}

                {finalWinner === null ? (
                  <div className="space-y-3">
                    <div className="pt-2 flex flex-col sm:flex-row gap-3">
                      <button
                        onClick={() => onSetFinalWinner(sf1Winner)}
                        className="flex-1 py-3 px-4 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-sm rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Trophy className="w-4 h-4" />
                        <span>{players[sf1Winner]} Wins Title</span>
                      </button>
                      <button
                        onClick={() => onSetFinalWinner(sf2Winner)}
                        className="flex-1 py-3 px-4 bg-white/15 hover:bg-white/25 text-white border border-[#D4AF37]/40 font-black text-sm rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Trophy className="w-4 h-4 text-[#FFD700]" />
                        <span>{players[sf2Winner]} Wins Title</span>
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2">
                      {onLaunchKnockoutLive && (
                        <button
                          type="button"
                          onClick={() =>
                            onLaunchKnockoutLive({
                              knockoutKey: 'final',
                              label: 'Grand Championship Final',
                              playerAIndex: sf1Winner,
                              playerBIndex: sf2Winner,
                            })
                          }
                          className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-[#D4AF37]/50 text-[#FFD700] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Zap className="w-3.5 h-3.5" />
                          <span>Score Grand Final Live</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setEditingKey(editingKey === 'final' ? null : 'final')}
                        className="text-xs font-bold text-[#A0A0A0] hover:text-[#FFD700] flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>{editingKey === 'final' ? 'Close' : 'Enter Final Set Scores'}</span>
                      </button>
                    </div>

                    {editingKey === 'final' && (
                      <div className="p-3.5 rounded-2xl bg-[#080808] border border-white/15 space-y-2.5 text-xs">
                        <div className="grid grid-cols-3 gap-2 text-center">
                          {(['1', '2', '3'] as const).map((sn) => {
                            const d = getDraft('final');
                            const fa = `s${sn}a` as 's1a' | 's2a' | 's3a';
                            const fb = `s${sn}b` as 's1b' | 's2b' | 's3b';
                            return (
                              <div key={sn}>
                                <span className="text-[10px] text-[#A0A0A0] block mb-1">Game {sn}</span>
                                <div className="flex items-center justify-center gap-1">
                                  <input type="number" value={d[fa]} placeholder="—" onChange={(e) => updateDraftField('final', fa, e.target.value)} className="w-10 p-1 text-center rounded bg-[#141414] border border-white/15 text-white" />
                                  <input type="number" value={d[fb]} placeholder="—" onChange={(e) => updateDraftField('final', fb, e.target.value)} className="w-10 p-1 text-center rounded bg-[#141414] border border-white/15 text-white" />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            const { winnerId, score } = resolveScoreAndWinner('final', sf1Winner, sf2Winner);
                            onSetFinalWinner(winnerId, score);
                            setEditingKey(null);
                          }}
                          className="w-full py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black cursor-pointer"
                        >
                          Save Grand Final Score &amp; Crown Champion
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-[#FFD700]">
                        🏆 Crowned Champion: <strong>{players[finalWinner]}</strong>
                      </span>
                      {matchMvps['ko:final'] === finalWinner && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/20 text-[#FFD700] border border-amber-400/50 text-[10px] font-black uppercase">
                          <Award className="w-3 h-3" />
                          <span>Match MVP</span>
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {onToggleMatchMvp && (
                        <button
                          type="button"
                          onClick={() =>
                            onToggleMatchMvp(
                              'ko:final',
                              matchMvps['ko:final'] === finalWinner ? null : finalWinner
                            )
                          }
                          className={`px-3 py-1.5 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 cursor-pointer ${
                            matchMvps['ko:final'] === finalWinner
                              ? 'bg-[#D4AF37] text-[#080808] border-[#FFD700]'
                              : 'border-white/20 text-white/80 hover:border-[#D4AF37]'
                          }`}
                        >
                          <Award className="w-3.5 h-3.5" />
                          <span>
                            {matchMvps['ko:final'] === finalWinner ? 'Match MVP' : 'Designate MVP'}
                          </span>
                        </button>
                      )}
                      <button
                        onClick={onUndoFinal}
                        className="px-3.5 py-1.5 rounded-xl border border-white/20 hover:bg-white/10 text-xs font-bold text-slate-300 flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Undo Final</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-6 text-xs text-[#A0A0A0]">
                Complete both Semi-Finals above to unlock the Grand Finalists.
              </div>
            )}
          </div>
        </div>

        {/* 3RD PLACE PLAYOFF */}
        {sf1Loser !== null && sf2Loser !== null && (
          <div className="mt-6 p-5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808]/90 border border-slate-200 dark:border-white/10 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1 text-xs text-[#64748B] dark:text-[#A0A0A0]">
              <span className="font-black text-[#172033] dark:text-[#FFD700] flex items-center gap-1.5">
                <Medal className="w-4 h-4" />
                <span>3rd Place Playoff (Bronze Medal)</span>
              </span>
              <div className="flex items-center gap-2">
                <span>
                  {players[sf1Loser]} vs {players[sf2Loser]}
                </span>
                {renderFormatToggle('third')}
              </div>
            </div>

            {formatScore(thirdPlaceScore) && (
              <div className="text-xs font-mono text-[#D4AF37] font-bold">
                Games: {formatScore(thirdPlaceScore)}
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-[#64748B] dark:text-slate-300 flex items-center gap-2 flex-wrap">
                {thirdPlaceWinner !== null ? (
                  <>
                    <span>
                      🥉 Bronze Medalist:{' '}
                      <strong className="text-[#22C55E]">{players[thirdPlaceWinner]}</strong>
                    </span>
                    {matchMvps['ko:third'] === thirdPlaceWinner && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-600 dark:text-[#FFD700] border border-amber-400/40 text-[10px] font-black uppercase">
                        <Award className="w-3 h-3" />
                        <span>Match MVP</span>
                      </span>
                    )}
                  </>
                ) : (
                  <span>Select Bronze Medalist or Score Live:</span>
                )}
              </div>

              {thirdPlaceWinner === null ? (
                <div className="flex flex-wrap gap-2">
                  {onLaunchKnockoutLive && (
                    <button
                      type="button"
                      onClick={() =>
                        onLaunchKnockoutLive({
                          knockoutKey: 'third',
                          label: '3rd Place Bronze Playoff',
                          playerAIndex: sf1Loser!,
                          playerBIndex: sf2Loser!,
                        })
                      }
                      className="px-3 py-1.5 bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] text-xs font-extrabold rounded-xl flex items-center gap-1 cursor-pointer"
                    >
                      <Zap className="w-3 h-3" />
                      <span>Score Live</span>
                    </button>
                  )}
                  <button
                    onClick={() => onSetThirdPlaceWinner(sf1Loser!)}
                    className="px-3 py-1.5 bg-[#172B4D] dark:bg-[#141414] border border-white/15 hover:border-[#D4AF37] text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    {players[sf1Loser]} Wins 3rd
                  </button>
                  <button
                    onClick={() => onSetThirdPlaceWinner(sf2Loser!)}
                    className="px-3 py-1.5 bg-[#172B4D] dark:bg-[#141414] border border-white/15 hover:border-[#D4AF37] text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    {players[sf2Loser]} Wins 3rd
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  {onToggleMatchMvp && (
                    <button
                      type="button"
                      onClick={() =>
                        onToggleMatchMvp(
                          'ko:third',
                          matchMvps['ko:third'] === thirdPlaceWinner ? null : thirdPlaceWinner
                        )
                      }
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-extrabold flex items-center gap-1 cursor-pointer ${
                        matchMvps['ko:third'] === thirdPlaceWinner
                          ? 'bg-amber-400/20 border-amber-400/50 text-amber-600 dark:text-[#FFD700]'
                          : 'border-slate-300 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0]'
                      }`}
                    >
                      <Award className="w-3 h-3" />
                      <span>
                        {matchMvps['ko:third'] === thirdPlaceWinner ? 'Match MVP' : 'Award MVP'}
                      </span>
                    </button>
                  )}
                  <button
                    onClick={onUndoThirdPlace}
                    className="px-2.5 py-1 text-xs text-[#64748B] dark:text-[#A0A0A0] hover:text-white underline cursor-pointer"
                  >
                    Undo 3rd Place
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* CONSOLATION PLATE BRACKET (Lower-Seed / Eliminated Players) */}
        {standings.length >= 6 && onUpdateConsolation && (
          <div className="mt-6 p-5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808]/90 border border-[#D4AF37]/25 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-black text-[#172033] dark:text-[#FFD700] flex items-center gap-1.5">
                  <GitBranch className="w-4 h-4" />
                  <span>Consolation Plate Bracket</span>
                </h3>
                <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  Classification &amp; Plate Draw for non-semifinalists (#5–#{Math.min(8, standings.length)})
                </p>
              </div>
              {consolationBracket.winner !== null && consolationBracket.winner !== undefined && (
                <span className="px-3 py-1 rounded-full bg-[#D4AF37]/20 text-[#FFD700] text-xs font-black">
                  Plate Champion: {players[consolationBracket.winner]}
                </span>
              )}
            </div>

            {(() => {
              const pool = standings.slice(4, 8);
              const cA = pool[0];
              const cB = pool[1];
              const cC = pool[2] || pool[0];
              const cD = pool[3] || pool[1];
              const semi1W = consolationBracket.semis?.[0];
              const semi2W = consolationBracket.semis?.[1];

              return (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10 space-y-2">
                    <div className="font-bold text-[#64748B] dark:text-[#A0A0A0] text-[10px] uppercase">
                      Consolation SF1 (#5 vs #6)
                    </div>
                    {[cA, cB].map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() =>
                          onUpdateConsolation({
                            ...consolationBracket,
                            semis: { ...(consolationBracket.semis || {}), 0: p.id },
                          })
                        }
                        className={`w-full p-2 rounded-lg text-left font-bold cursor-pointer ${
                          semi1W === p.id
                            ? 'bg-[#D4AF37] text-[#080808]'
                            : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>

                  <div className="p-3.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10 space-y-2">
                    <div className="font-bold text-[#64748B] dark:text-[#A0A0A0] text-[10px] uppercase">
                      Consolation SF2 ({standings.length >= 8 ? '#7 vs #8' : 'Play-In'})
                    </div>
                    {[cC, cD].map((p, idx) => (
                      <button
                        key={`${p.id}-${idx}`}
                        type="button"
                        onClick={() =>
                          onUpdateConsolation({
                            ...consolationBracket,
                            semis: { ...(consolationBracket.semis || {}), 1: p.id },
                          })
                        }
                        className={`w-full p-2 rounded-lg text-left font-bold cursor-pointer ${
                          semi2W === p.id
                            ? 'bg-[#D4AF37] text-[#080808]'
                            : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>

                  <div className="p-3.5 rounded-xl bg-white dark:bg-[#141414] border border-[#D4AF37]/30 space-y-2">
                    <div className="font-bold text-[#D4AF37] text-[10px] uppercase">
                      Consolation Plate Final
                    </div>
                    {semi1W !== undefined && semi2W !== undefined ? (
                      <>
                        {[semi1W, semi2W].map((pid) => (
                          <button
                            key={pid}
                            type="button"
                            onClick={() =>
                              onUpdateConsolation({
                                ...consolationBracket,
                                winner: pid,
                              })
                            }
                            className={`w-full p-2 rounded-lg text-left font-black cursor-pointer ${
                              consolationBracket.winner === pid
                                ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808]'
                                : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white'
                            }`}
                          >
                            {players[pid]}
                          </button>
                        ))}
                        {consolationBracket.winner !== undefined &&
                          consolationBracket.winner !== null && (
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateConsolation({
                                  ...consolationBracket,
                                  winner: null,
                                })
                              }
                              className="text-[11px] text-[#64748B] hover:text-white underline cursor-pointer"
                            >
                              Undo Plate Final
                            </button>
                          )}
                      </>
                    ) : (
                      <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] py-3">
                        Pick Consolation SF1 &amp; SF2 winners to decide Plate Champion.
                      </p>
                    )}
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
