import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Shuffle,
  Play,
  Users,
  Check,
  AlertCircle,
  Camera,
  Award,
  Search,
  Minus,
  Sparkles,
  ArrowUp,
  ArrowDown,
  ShieldCheck,
  UserPlus,
} from 'lucide-react';
import {
  MatchFormat,
  TournamentFormatType,
  CompetitionCategory,
  CustomTournamentRules,
  PlayerStats,
  TournamentState,
  DoublesTeam,
  PlayerBio,
} from '../types';
import {
  getPlayerColor,
  getPlayerCode,
  getInitials,
  PRESET_ROSTERS,
  getFormatLabel,
  generateFixtures,
  clampPointsPerSet,
  getSuggestedInterval,
  getSuggestedDeuceCap,
} from '../utils/tournament';
import { evaluatePlayerSeeds } from '../utils/seeding';

interface PlayerSetupProps {
  players: string[];
  setPlayers: (players: string[]) => void;
  playerPhotos?: Record<number, string>;
  standings?: PlayerStats[];
  allTournaments?: TournamentState[];
  doublesTeams?: DoublesTeam[];
  onAddDoublesTeam?: (team: DoublesTeam) => void;
  onRemoveDoublesTeam?: (teamId: string) => void;
  onUpdateBio?: (playerId: number, bio: PlayerBio) => void;
  onApplySmartSeeding?: () => void;
  onSwapPlayers?: (indexA: number, indexB: number) => void;
  matchFormat: MatchFormat;
  setMatchFormat: (format: MatchFormat) => void;
  tournamentFormat?: TournamentFormatType;
  setTournamentFormat?: (fmt: TournamentFormatType) => void;
  category?: CompetitionCategory;
  setCategory?: (cat: CompetitionCategory) => void;
  customRules?: CustomTournamentRules;
  onUpdateCustomRules?: (rules: CustomTournamentRules) => void;
  tournamentStarted: boolean;
  onStartTournament: () => void;
  onResetTournament: () => void;
  onOpenPlayerProfile: (playerId: number) => void;
}

export const PlayerSetup: React.FC<PlayerSetupProps> = ({
  players,
  setPlayers,
  playerPhotos,
  standings = [],
  allTournaments = [],
  doublesTeams = [],
  onAddDoublesTeam,
  onRemoveDoublesTeam,
  onUpdateBio,
  onApplySmartSeeding,
  onSwapPlayers,
  matchFormat,
  setMatchFormat,
  tournamentFormat = 'round_robin',
  setTournamentFormat,
  category = 'singles',
  setCategory,
  customRules,
  onUpdateCustomRules,
  tournamentStarted,
  onStartTournament,
  onResetTournament,
  onOpenPlayerProfile,
}) => {
  const [newPlayerName, setNewPlayerName] = useState('');
  const [showOptionalFields, setShowOptionalFields] = useState(false);
  const [newPlayerAge, setNewPlayerAge] = useState('');
  const [newPlayerContact, setNewPlayerContact] = useState('');
  const [newPlayerCategory, setNewPlayerCategory] = useState<CompetitionCategory>('singles');

  const [searchQuery, setSearchQuery] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showPairGenerator, setShowPairGenerator] = useState(false);
  const [showSeedingPreview, setShowSeedingPreview] = useState(false);
  const [seedingAppliedNotice, setSeedingAppliedNotice] = useState(false);
  const [rawDoublesNames, setRawDoublesNames] = useState(
    'Hassan, Hamza, Ali, Usman, Tariq, Bilal, Zain, Saad'
  );
  const [pairP1, setPairP1] = useState('');
  const [pairP2, setPairP2] = useState('');
  const [pairCustomName, setPairCustomName] = useState('');
  const [pairCategory, setPairCategory] = useState<'doubles' | 'mixed_doubles'>('doubles');
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [bulkInput, setBulkInput] = useState('');

  const duplicateNames = React.useMemo(() => {
    const seen = new Set<string>();
    const dups: string[] = [];
    players.forEach((p) => {
      const k = p.trim().toLowerCase();
      if (k && seen.has(k)) dups.push(p);
      seen.add(k);
    });
    return dups;
  }, [players]);

  const handleBulkImportPlayers = () => {
    const incoming = bulkInput
      .split(/[\n,;]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (incoming.length === 0) return;
    const existingKeys = new Set(players.map((p) => p.trim().toLowerCase()));
    const uniqueNew = incoming.filter((name) => {
      const k = name.toLowerCase();
      if (existingKeys.has(k)) return false;
      existingKeys.add(k);
      return true;
    });
    if (uniqueNew.length > 0) {
      setPlayers([...players, ...uniqueNew]);
    }
    setBulkInput('');
    setShowBulkImport(false);
    setErrorMessage(null);
  };

  const handleCreateCustomDoublesTeam = () => {
    const p1 = pairP1.trim();
    const p2 = pairP2.trim();
    if (!p1 || !p2) {
      setErrorMessage('Enter both Partner 1 and Partner 2 names to create a Doubles team.');
      return;
    }
    const label = pairCustomName.trim() || `${p1} / ${p2}`;
    if (onAddDoublesTeam) {
      onAddDoublesTeam({
        id: `dt-${Date.now()}`,
        name: label,
        player1: p1,
        player2: p2,
        category: pairCategory,
        createdAt: new Date().toISOString(),
      });
    }
    if (!players.some((p) => p.toLowerCase() === label.toLowerCase())) {
      setPlayers([...players, label]);
    }
    if (setCategory && category === 'singles') {
      setCategory(pairCategory);
    }
    setPairP1('');
    setPairP2('');
    setPairCustomName('');
    setErrorMessage(null);
  };

  const handleGenerateDoublesPairs = (randomize: boolean) => {
    const individuals = rawDoublesNames
      .split(/[\n,]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (individuals.length < 4) {
      setErrorMessage('Enter at least 4 individual players to form Doubles pairs.');
      return;
    }
    const pool = randomize ? [...individuals].sort(() => Math.random() - 0.5) : [...individuals];
    const pairs: string[] = [];
    for (let i = 0; i + 1 < pool.length; i += 2) {
      const pairStr = `${pool[i]} / ${pool[i + 1]}`;
      pairs.push(pairStr);
      if (onAddDoublesTeam) {
        onAddDoublesTeam({
          id: `dt-${Date.now()}-${i}`,
          name: pairStr,
          player1: pool[i],
          player2: pool[i + 1],
          category: category === 'mixed_doubles' ? 'mixed_doubles' : 'doubles',
          createdAt: new Date().toISOString(),
        });
      }
    }
    if (pairs.length < 4) {
      setErrorMessage('Need at least 8 individual players (4 pairs) for a tournament bracket.');
      return;
    }
    if (setCategory && category === 'singles') {
      setCategory('doubles');
    }
    setPlayers(pairs);
    setErrorMessage(null);
    setShowPairGenerator(false);
  };

  const currentPoints = clampPointsPerSet(customRules?.pointsPerSet ?? 21);

  const handleSetPointsTarget = (nextRaw: number) => {
    if (!onUpdateCustomRules) return;
    const pts = clampPointsPerSet(nextRaw);
    onUpdateCustomRules({
      pointsPerSet: pts,
      intervalAt: getSuggestedInterval(pts),
      maxDeuceCap: getSuggestedDeuceCap(pts),
      refereeName: customRules?.refereeName ?? 'Hassan',
    });
  };

  const handleAddPlayer = (nameToAdd?: string) => {
    const target = (nameToAdd || newPlayerName).trim();
    if (!target) return;

    if (players.some((p) => p.toLowerCase() === target.toLowerCase())) {
      setErrorMessage(`"${target}" is already in the tournament roster.`);
      return;
    }

    const nextIdx = players.length;
    setPlayers([...players, target]);
    if (onUpdateBio && (newPlayerAge.trim() || newPlayerContact.trim() || showOptionalFields)) {
      const parsedAge = parseInt(newPlayerAge, 10);
      onUpdateBio(nextIdx, {
        playerCode: getPlayerCode(nextIdx),
        age: Number.isFinite(parsedAge) && parsedAge > 0 ? parsedAge : undefined,
        contact: newPlayerContact.trim() || undefined,
        preferredCategory: newPlayerCategory,
      });
    }
    setNewPlayerName('');
    setNewPlayerAge('');
    setNewPlayerContact('');
    setErrorMessage(null);
  };

  const handleRemovePlayer = (index: number) => {
    if (players.length <= 4) {
      setErrorMessage('Tournament requires at least 4 players.');
      return;
    }
    const updated = players.filter((_, i) => i !== index);
    setPlayers(updated);
    setErrorMessage(null);
  };

  const handleUpdatePlayerName = (index: number, newName: string) => {
    const updated = [...players];
    updated[index] = newName;
    setPlayers(updated);
  };

  const handleShuffle = () => {
    const shuffled = [...players].sort(() => Math.random() - 0.5);
    setPlayers(shuffled);
  };

  const handleApplyPreset = (presetPlayers: string[]) => {
    setPlayers([...presetPlayers]);
    setErrorMessage(null);
  };

  const generatedFixtures = generateFixtures(players.length, tournamentFormat);
  const totalMatches = generatedFixtures.length;
  const byeCount = generatedFixtures.filter((f) => f.isBye).length;
  const seedEvaluations = evaluatePlayerSeeds(players, standings, allTournaments);

  const handleSmartSeedingTrigger = () => {
    if (onApplySmartSeeding) {
      onApplySmartSeeding();
      setSeedingAppliedNotice(true);
      setTimeout(() => setSeedingAppliedNotice(false), 2600);
    }
  };

  const handleMoveSeed = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= players.length) return;
    if (onSwapPlayers) {
      onSwapPlayers(index, target);
    } else {
      const updated = [...players];
      [updated[index], updated[target]] = [updated[target], updated[index]];
      setPlayers(updated);
    }
  };

  const filteredIndices = players
    .map((name, idx) => ({ name, idx }))
    .filter(({ name, idx }) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return name.toLowerCase().includes(q) || getPlayerCode(idx).toLowerCase().includes(q);
    });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white dark:bg-[#141414] theme-card rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-white/10">
          <div>
            <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight flex items-center gap-2">
              <Users className="w-5 h-5 text-[#D4AF37]" />
              <span>Players, Doubles Pairing &amp; Format</span>
            </h2>
            <p className="text-xs sm:text-sm text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
              Register players or doubles teams, choose elimination/league format, and adjust target points (11–21).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs text-[#64748B] dark:text-[#A0A0A0]">
            <span className="font-black text-[#172033] dark:text-[#FFD700] tabular-nums text-sm">
              {players.length}
            </span>{' '}
            Registered
            <span aria-hidden="true">·</span>
            <span className="font-black text-[#172033] dark:text-[#D4AF37] tabular-nums text-sm">
              {totalMatches}
            </span>{' '}
            Fixtures
            {byeCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#9A7B1C] dark:text-[#FFD700] font-bold text-[10px]">
                +{byeCount} BYE{byeCount > 1 ? 's' : ''}
              </span>
            )}
          </div>
        </div>

        {/* Category + Stage + Match Format + Points Controls */}
        <div className="mt-5 grid grid-cols-1 lg:grid-cols-3 gap-3">
          {/* Match Sets Format Toggle (Entire Tournament) */}
          <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-white/10 flex flex-col justify-between gap-2.5">
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-extrabold text-[#172033] dark:text-white flex items-center gap-1.5 uppercase tracking-wider">
                  <Award className="w-4 h-4 text-[#D4AF37]" />
                  <span>Match Format</span>
                </span>
                <span className="text-[10px] font-bold text-[#D4AF37]">Entire Tournament</span>
              </div>
              <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
                {getFormatLabel(matchFormat)}
              </p>
            </div>
            <div className="grid grid-cols-3 gap-1 p-1 bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/10 rounded-xl w-full">
              {(
                [
                  { id: 'bo1', label: 'Best of 1' },
                  { id: 'bo3', label: 'Best of 3' },
                  { id: 'bo5', label: 'Best of 5' },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setMatchFormat(opt.id)}
                  className={`px-2 py-2 text-xs font-extrabold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                    matchFormat === opt.id
                      ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-sm'
                      : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Adjustable Points Target (11-21) */}
          {onUpdateCustomRules && (
            <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-white/10 flex flex-col justify-between gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-[#172033] dark:text-white uppercase tracking-wider">
                  Points / Game (11–21)
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleSetPointsTarget(currentPoints - 1)}
                    disabled={currentPoints <= 11}
                    className="w-6 h-6 rounded-md bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-7 text-center font-mono font-black text-sm text-[#172B4D] dark:text-[#FFD700]">
                    {currentPoints}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleSetPointsTarget(currentPoints + 1)}
                    disabled={currentPoints >= 21}
                    className="w-6 h-6 rounded-md bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>
              <input
                type="range"
                min={11}
                max={21}
                step={1}
                value={currentPoints}
                onChange={(e) => handleSetPointsTarget(Number(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
              <div className="flex items-center gap-1">
                {[11, 15, 18, 21].map((pts) => (
                  <button
                    key={pts}
                    type="button"
                    onClick={() => handleSetPointsTarget(pts)}
                    className={`flex-1 py-1 rounded-lg text-[11px] font-extrabold cursor-pointer ${
                      currentPoints === pts
                        ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                        : 'bg-white dark:bg-[#141414] text-[#64748B] dark:text-[#A0A0A0]'
                    }`}
                  >
                    {pts}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Stage Format & Category */}
          <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-white/10 flex flex-wrap items-center justify-between gap-3">
            {setCategory && (
              <div className="flex-1 min-w-[120px]">
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as CompetitionCategory)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white focus:outline-none"
                >
                  <option value="singles">Singles</option>
                  <option value="doubles">Doubles</option>
                  <option value="mixed_doubles">Mixed Doubles</option>
                </select>
              </div>
            )}

            {setTournamentFormat && (
              <div className="flex-1 min-w-[155px]">
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                  Tournament Format
                </label>
                <select
                  value={tournamentFormat}
                  onChange={(e) => setTournamentFormat(e.target.value as TournamentFormatType)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white focus:outline-none"
                >
                  <option value="round_robin">Round-Robin League</option>
                  <option value="double_round_robin">Double Round-Robin (Home/Away)</option>
                  <option value="swiss">Swiss System</option>
                  <option value="league">Points League</option>
                  <option value="group_stage">Group Stage (A &amp; B)</option>
                  <option value="single_elimination">Single Elimination (BYEs)</option>
                  <option value="double_elimination">Double Elimination (WB + LB)</option>
                  <option value="team_championship">Team Championship</option>
                  <option value="knockout">Knockout Elimination</option>
                  <option value="custom">Custom Tournament</option>
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Add Player + Optional Bio Toggle + Search Bar */}
        <div className="mt-5 space-y-2.5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
            <div className="md:col-span-2 flex gap-2">
              <input
                type="text"
                value={newPlayerName}
                onChange={(e) => {
                  setNewPlayerName(e.target.value);
                  if (errorMessage) setErrorMessage(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddPlayer();
                }}
                placeholder={
                  category === 'singles'
                    ? 'Enter player name...'
                    : 'Enter team / pair name (e.g. Hassan / Ali)...'
                }
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
              <button
                type="button"
                onClick={() => setShowOptionalFields((p) => !p)}
                className="px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] hover:text-[#D4AF37] cursor-pointer whitespace-nowrap"
                title="Add optional Age, Contact & Category"
              >
                {showOptionalFields ? 'Less' : '+ Bio'}
              </button>
              <button
                onClick={() => handleAddPlayer()}
                disabled={!newPlayerName.trim()}
                className="px-4 py-2.5 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 disabled:opacity-40 text-white dark:text-[#080808] font-extrabold text-sm rounded-xl transition-all flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add</span>
              </button>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-[#64748B] dark:text-[#A0A0A0] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search roster or #SC-ID..."
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
          </div>

          {showOptionalFields && (
            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <input
                type="number"
                min={5}
                max={99}
                value={newPlayerAge}
                onChange={(e) => setNewPlayerAge(e.target.value)}
                placeholder="Age (optional)"
                className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white focus:outline-none"
              />
              <input
                type="text"
                value={newPlayerContact}
                onChange={(e) => setNewPlayerContact(e.target.value)}
                placeholder="Phone / Email (optional)"
                className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white focus:outline-none"
              />
              <select
                value={newPlayerCategory}
                onChange={(e) => setNewPlayerCategory(e.target.value as CompetitionCategory)}
                className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
              >
                <option value="singles">Singles</option>
                <option value="doubles">Doubles</option>
                <option value="mixed_doubles">Mixed Doubles</option>
              </select>
            </div>
          )}
        </div>

        {errorMessage && (
          <div className="mt-3 flex items-center gap-2 text-xs text-[#EF4444] font-semibold">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {duplicateNames.length > 0 && (
          <div className="mt-3 p-3 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-between gap-2 text-xs text-amber-400 font-bold">
            <span>Duplicate player names detected: {duplicateNames.join(', ')}</span>
            <button
              type="button"
              onClick={() => {
                const seen = new Set<string>();
                const deduped = players.filter((p) => {
                  const k = p.trim().toLowerCase();
                  if (seen.has(k)) return false;
                  seen.add(k);
                  return true;
                });
                if (deduped.length >= 2) setPlayers(deduped);
              }}
              className="px-2.5 py-1 rounded-lg bg-amber-500 text-[#080808] font-black text-[11px] cursor-pointer"
            >
              Remove Duplicates
            </button>
          </div>
        )}

        {/* Quick Presets + Doubles Pair Generator */}
        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-white/10 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]">
              Quick Roster Presets:
            </span>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => setShowBulkImport((p) => !p)}
                className="px-3 py-1 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white border border-slate-200 dark:border-white/15 text-xs font-bold cursor-pointer"
              >
                {showBulkImport ? 'Hide Bulk Paste' : '+ Bulk Import CSV'}
              </button>
              <button
                type="button"
                onClick={() => setShowPairGenerator((p) => !p)}
                className="px-3 py-1 rounded-lg bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] border border-[#D4AF37]/35 text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{showPairGenerator ? 'Hide Doubles Studio' : 'Doubles Pairing & Teams'}</span>
              </button>
            </div>
          </div>

          {showBulkImport && (
            <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/35 space-y-2 text-xs">
              <textarea
                rows={2}
                value={bulkInput}
                onChange={(e) => setBulkInput(e.target.value)}
                placeholder="Paste names separated by commas or new lines (duplicates skipped automatically)..."
                className="w-full p-2.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white"
              />
              <button
                type="button"
                onClick={handleBulkImportPlayers}
                className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black cursor-pointer"
              >
                Import Unique Players
              </button>
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            {PRESET_ROSTERS.map((preset) => (
              <button
                key={preset.name}
                onClick={() => handleApplyPreset(preset.players)}
                className="px-3 py-1 text-xs rounded-lg bg-[#F4F7FB] dark:bg-[#080808] hover:border-[#D4AF37] text-[#172033] dark:text-[#A0A0A0] dark:hover:text-[#FFD700] border border-slate-200 dark:border-white/10 transition-colors cursor-pointer font-semibold"
              >
                {preset.name} ({preset.players.length})
              </button>
            ))}
          </div>

          {showPairGenerator && (
            <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/35 space-y-4">
              {/* Single Pair Creator */}
              <div className="space-y-2">
                <div className="text-xs font-black text-[#172033] dark:text-[#FFD700] flex items-center gap-1.5">
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Create &amp; Save Custom Doubles Pair</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                  <input
                    type="text"
                    value={pairP1}
                    onChange={(e) => setPairP1(e.target.value)}
                    placeholder="Partner 1 name"
                    className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white"
                  />
                  <input
                    type="text"
                    value={pairP2}
                    onChange={(e) => setPairP2(e.target.value)}
                    placeholder="Partner 2 name"
                    className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white"
                  />
                  <input
                    type="text"
                    value={pairCustomName}
                    onChange={(e) => setPairCustomName(e.target.value)}
                    placeholder="Team Name (optional)"
                    className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white"
                  />
                  <div className="flex gap-1.5">
                    <select
                      value={pairCategory}
                      onChange={(e) => setPairCategory(e.target.value as 'doubles' | 'mixed_doubles')}
                      className="px-2 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
                    >
                      <option value="doubles">Doubles</option>
                      <option value="mixed_doubles">Mixed</option>
                    </select>
                    <button
                      type="button"
                      onClick={handleCreateCustomDoublesTeam}
                      className="flex-1 px-3 py-2 rounded-xl bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] font-extrabold cursor-pointer whitespace-nowrap"
                    >
                      Save Pair
                    </button>
                  </div>
                </div>
              </div>

              {doublesTeams.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-white/10">
                  <div className="text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0]">
                    Saved Doubles Teams (Click to add to roster):
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {doublesTeams.map((dt) => (
                      <div
                        key={dt.id}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-[#D4AF37]/25 text-xs"
                      >
                        <button
                          type="button"
                          onClick={() => handleAddPlayer(dt.name)}
                          className="font-bold text-[#172033] dark:text-white hover:text-[#D4AF37] cursor-pointer"
                        >
                          + {dt.name} ({dt.player1} / {dt.player2})
                        </button>
                        {onRemoveDoublesTeam && (
                          <button
                            type="button"
                            onClick={() => onRemoveDoublesTeam(dt.id)}
                            className="text-[#64748B] hover:text-[#EF4444] cursor-pointer"
                            title="Delete saved team"
                          >
                            ×
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Bulk Auto-Pair Generator */}
              <div className="pt-2 border-t border-slate-200 dark:border-white/10 space-y-2">
                <div className="text-xs font-black text-[#172033] dark:text-white">
                  Bulk Doubles Auto-Pair Generator
                </div>
                <textarea
                  rows={2}
                  value={rawDoublesNames}
                  onChange={(e) => setRawDoublesNames(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-semibold text-[#172033] dark:text-white focus:outline-none"
                  placeholder="Player 1, Player 2, Player 3..."
                />
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => handleGenerateDoublesPairs(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] text-xs font-extrabold cursor-pointer"
                  >
                    Generate Random Pairs
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGenerateDoublesPairs(false)}
                    className="px-3.5 py-1.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white text-xs font-bold cursor-pointer"
                  >
                    Pair In Order (1+2, 3+4...)
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Smart Tournament Seeding Toolbar */}
        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-white/10 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="text-xs font-black text-[#172033] dark:text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                <span>Smart Tournament Seeding</span>
              </div>
              <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                Balances Seed #1 &amp; #2 on opposite bracket halves or Groups A &amp; B using player career &amp; rating history.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setShowSeedingPreview((prev) => !prev)}
                className="px-3 py-1.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white text-xs font-bold cursor-pointer"
              >
                {showSeedingPreview ? 'Hide Ratings' : 'View Power Seeds'}
              </button>
              {onApplySmartSeeding && (
                <button
                  type="button"
                  onClick={handleSmartSeedingTrigger}
                  className="px-3.5 py-1.5 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{seedingAppliedNotice ? 'Smart Seeds Applied!' : 'Apply Smart Seeding'}</span>
                </button>
              )}
            </div>
          </div>

          {showSeedingPreview && (
            <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {seedEvaluations.map((ev) => (
                <div
                  key={`${ev.index}-${ev.name}`}
                  className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200/80 dark:border-white/10 flex items-center justify-between gap-2 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-black text-[#172033] dark:text-white truncate">
                      Seed #{ev.seedRank} · {ev.name}
                    </div>
                    <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] font-mono tabular-nums">
                      Rating {ev.rating} · {ev.careerWins}W/{ev.careerMatches}M
                      {ev.titlesWon > 0 ? ` · ${ev.titlesWon}🏆` : ''}
                    </div>
                  </div>
                  <span className="text-[10px] font-black text-[#9A7B1C] dark:text-[#FFD700] shrink-0">
                    Grp {ev.assignedGroup}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Player Cards */}
        <div className="mt-6 space-y-2.5">
          <div className="text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] flex items-center justify-between">
            <span>REGISTERED PLAYERS (Tap avatar or Profile for stats &amp; bio)</span>
            <span>
              {filteredIndices.length} / {players.length}
            </span>
          </div>

          {filteredIndices.map(({ name: player, idx: index }) => {
            const avatarColor = getPlayerColor(index);
            const initials = getInitials(player);
            const photo = playerPhotos?.[index];
            const code = getPlayerCode(index);

            return (
              <div
                key={index}
                className="flex items-center gap-3 p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808]/90 border border-slate-200/80 dark:border-white/10 transition-all hover:border-[#D4AF37]/60"
              >
                <button
                  type="button"
                  onClick={() => onOpenPlayerProfile(index)}
                  className="relative group shrink-0 focus:outline-none cursor-pointer"
                  title="Edit profile picture"
                >
                  {photo ? (
                    <img
                      src={photo}
                      alt={player}
                      className="w-10 h-10 rounded-xl object-cover border-2 border-[#D4AF37] shadow-sm"
                    />
                  ) : (
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-[#080808] font-black text-xs shadow-sm"
                      style={{ backgroundColor: avatarColor }}
                    >
                      {initials}
                    </div>
                  )}
                  <span className="absolute inset-0 bg-black/45 rounded-xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                    <Camera className="w-3.5 h-3.5" />
                  </span>
                </button>

                <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-white dark:bg-[#141414] text-[#9A7B1C] dark:text-[#FFD700] border border-slate-200 dark:border-white/10 shrink-0 tabular-nums">
                  #{index + 1} · {code}
                </span>

                <div className="flex-1 flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 min-w-0">
                  <input
                    type="text"
                    value={player}
                    onChange={(e) => handleUpdatePlayerName(index, e.target.value)}
                    className="flex-1 bg-transparent border-0 text-sm font-bold text-[#172033] dark:text-white focus:outline-none focus:ring-1 focus:ring-[#D4AF37] rounded px-2 py-1 min-w-0"
                    placeholder={`Player ${index + 1}`}
                  />
                  <button
                    type="button"
                    onClick={() => onOpenPlayerProfile(index)}
                    className="text-[11px] text-[#172B4D] dark:text-[#FFD700] font-bold hover:underline self-start sm:self-auto px-2 cursor-pointer shrink-0"
                  >
                    Profile
                  </button>
                </div>

                <div className="flex items-center gap-0.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleMoveSeed(index, -1)}
                    disabled={index === 0}
                    className="p-1.5 text-[#64748B] hover:text-[#FFD700] disabled:opacity-25 rounded-lg transition-colors cursor-pointer"
                    title="Move seed up"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMoveSeed(index, 1)}
                    disabled={index === players.length - 1}
                    className="p-1.5 text-[#64748B] hover:text-[#FFD700] disabled:opacity-25 rounded-lg transition-colors cursor-pointer"
                    title="Move seed down"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleRemovePlayer(index)}
                    disabled={players.length <= 4}
                    className="p-1.5 text-[#64748B] hover:text-[#EF4444] disabled:opacity-20 rounded-lg transition-colors cursor-pointer"
                    title="Remove player"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="mt-6 pt-5 border-t border-slate-100 dark:border-white/10 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={handleShuffle}
            className="px-3.5 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-[#A0A0A0] hover:text-[#FFD700] text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Shuffle Seeds</span>
          </button>

          <div className="flex items-center gap-2">
            {tournamentStarted && (
              <button
                onClick={onResetTournament}
                className="px-4 py-2.5 rounded-xl border border-[#EF4444]/40 text-[#EF4444] hover:bg-[#EF4444]/10 text-xs font-bold transition-colors cursor-pointer"
              >
                Reset Matches
              </button>
            )}

            <button
              onClick={onStartTournament}
              className="px-6 py-2.5 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] font-black text-sm rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              {tournamentStarted ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save &amp; Continue</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Start Tournament</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
