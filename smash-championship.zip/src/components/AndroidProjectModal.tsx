import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  X,
  FolderArchive,
  MapPin,
  ShieldCheck,
  Copy,
  Check,
  ExternalLink,
  Wrench,
  FileJson,
  Sparkles,
} from 'lucide-react';
import {
  DEFAULT_ANDROID_OPTIONS,
  buildAssetLinksJson,
  generateCustomAndroidProjectZip,
} from '../utils/androidZip';

interface AndroidProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidProjectModal: React.FC<AndroidProjectModalProps> = ({ isOpen, onClose }) => {
  const [appName, setAppName] = useState(DEFAULT_ANDROID_OPTIONS.appName);
  const [packageId, setPackageId] = useState(DEFAULT_ANDROID_OPTIONS.packageId);
  const [targetUrl, setTargetUrl] = useState(() =>
    typeof window !== 'undefined' && window.location.origin.startsWith('https')
      ? window.location.origin
      : DEFAULT_ANDROID_OPTIONS.targetUrl
  );
  const [versionName, setVersionName] = useState(DEFAULT_ANDROID_OPTIONS.versionName);
  const [sha256, setSha256] = useState('');
  const [buildingZip, setBuildingZip] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [showCustomForm, setShowCustomForm] = useState(false);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(targetUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      setStatusNotice('Copy the URL manually from the input field.');
    }
  };

  const handleGenerateCustomZip = async () => {
    setBuildingZip(true);
    setStatusNotice(null);
    try {
      const blob = await generateCustomAndroidProjectZip({
        appName,
        packageId,
        targetUrl,
        versionName,
        versionCode: DEFAULT_ANDROID_OPTIONS.versionCode,
        sha256Fingerprint: sha256,
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Smash_Championship_Android_Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setStatusNotice('Custom Android Studio APK project ZIP downloaded!');
    } catch {
      setStatusNotice('Could not generate custom ZIP. Use the pre-built download button above.');
    } finally {
      setBuildingZip(false);
    }
  };

  const handleDownloadAssetLinks = () => {
    const json = buildAssetLinksJson(packageId, sha256);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'assetlinks.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setStatusNotice('Downloaded assetlinks.json for TWA / Play Store verification.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div className="bg-white dark:bg-[#141414] w-full max-w-2xl rounded-3xl border border-slate-200 dark:border-[#D4AF37]/40 shadow-2xl overflow-hidden animate-fade-in">
        {/* Modal Header */}
        <div className="p-6 bg-[#172B4D] dark:bg-[#080808] text-white flex items-center justify-between border-b border-white/10 dark:border-[#D4AF37]/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/20 border border-[#D4AF37]/50 flex items-center justify-center text-[#FFD700]">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black">APK Builder &amp; Android Studio Project</h3>
              <p className="text-xs text-[#A0A0A0]">
                Package:{' '}
                <code className="font-mono bg-[#141414] px-1.5 py-0.5 rounded text-[#FFD700]">
                  {packageId}
                </code>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#A0A0A0] hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Primary Download Card */}
          <div className="p-5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/45 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-sm font-black text-[#172033] dark:text-white">
                <FolderArchive className="w-4 h-4 text-[#D4AF37] dark:text-[#FFD700]" />
                <span>Smash_Championship_Android_Project.zip</span>
              </div>
              <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-1">
                Complete Kotlin + Gradle Android Studio APK source bundle with Black &amp; Gold icons,
                Blob/CSV Download Bridge, File Chooser, WakeLock, Geolocation, and ProGuard rules.
              </p>
            </div>

            <a
              href="/Smash_Championship_Android_Project.zip"
              download="Smash_Championship_Android_Project.zip"
              className="px-4 py-2.5 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Download APK ZIP</span>
            </a>
          </div>

          {/* PWABuilder Instant Packaging Box */}
          <div className="p-4 rounded-2xl bg-[#D4AF37]/10 border border-[#D4AF37]/40 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-[#9A7B1C] dark:text-[#FFD700]">
                <Sparkles className="w-4 h-4" />
                <span>PWABuilder Cloud APK / AAB Ready</span>
              </div>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#22C55E]/20 text-[#22C55E]">
                HTTPS · Manifest · SW · 512px Maskable · Shortcuts
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="url"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs font-mono text-[#172033] dark:text-white focus:outline-none"
              />
              <button
                type="button"
                onClick={() => void handleCopyUrl()}
                className="px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {copiedUrl ? <Check className="w-3.5 h-3.5 text-[#22C55E]" /> : <Copy className="w-3.5 h-3.5 text-[#D4AF37]" />}
                <span>{copiedUrl ? 'Copied' : 'Copy URL'}</span>
              </button>
              <a
                href="https://www.pwabuilder.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-xs font-black flex items-center justify-center gap-1.5 shrink-0"
              >
                <span>Open PWABuilder</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Customize APK Project Builder */}
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-[#172033] dark:text-white">
                <Wrench className="w-4 h-4 text-[#D4AF37]" />
                <span>Customize &amp; Build Custom APK Project ZIP</span>
              </div>
              <button
                type="button"
                onClick={() => setShowCustomForm((prev) => !prev)}
                className="text-xs font-bold text-[#D4AF37] hover:underline cursor-pointer"
              >
                {showCustomForm ? 'Hide Options' : 'Customize ID / SHA-256'}
              </button>
            </div>

            {showCustomForm && (
              <div className="space-y-3 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                      App Name
                    </label>
                    <input
                      type="text"
                      value={appName}
                      onChange={(e) => setAppName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                      Android Package ID
                    </label>
                    <input
                      type="text"
                      value={packageId}
                      onChange={(e) => setPackageId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-mono text-[#172033] dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                      Version
                    </label>
                    <input
                      type="text"
                      value={versionName}
                      onChange={(e) => setVersionName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-mono text-[#172033] dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#64748B] dark:text-[#A0A0A0] mb-1">
                    Signing SHA-256 Fingerprint (Optional for assetlinks.json)
                  </label>
                  <input
                    type="text"
                    value={sha256}
                    onChange={(e) => setSha256(e.target.value)}
                    placeholder="AB:CD:EF:12:34:..."
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-mono text-[#172033] dark:text-white"
                  />
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={buildingZip}
                    onClick={() => void handleGenerateCustomZip()}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{buildingZip ? 'Bundling ZIP...' : 'Build & Download Custom ZIP'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadAssetLinks}
                    className="px-3.5 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileJson className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Export assetlinks.json</span>
                  </button>
                </div>
              </div>
            )}

            {statusNotice && (
              <div className="p-2.5 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/40 text-xs font-bold text-[#22C55E]">
                {statusNotice}
              </div>
            )}
          </div>

          {/* Project Details */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-extrabold text-[#64748B] dark:text-[#A0A0A0] uppercase tracking-wider">
              Included Native &amp; APK Capabilities
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {[
                {
                  name: 'MainActivity.kt + DownloadBridge',
                  desc: 'Saves Blob/JSON/CSV backups & certificates directly to Android Downloads/',
                },
                {
                  name: 'mipmap-* Launcher Icons + Splash',
                  desc: 'Includes Black + Gold adaptive launcher PNGs across hdpi to xxxhdpi',
                },
                {
                  name: 'WakeLock + Geolocation + FileChooser',
                  desc: 'Keeps screen awake on courts, enables GPS Map pins & logo/avatar uploads',
                },
                {
                  name: 'Gradle Wrapper + ProGuard + AssetLinks',
                  desc: 'Ready for Android Studio APK build or PWABuilder Trusted Web Activity',
                },
              ].map((item) => (
                <div
                  key={item.name}
                  className="p-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10"
                >
                  <span className="font-bold text-[#172033] dark:text-[#FFD700] block">
                    {item.name}
                  </span>
                  <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    {item.desc}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/30 flex items-start gap-2.5 text-xs text-[#172033] dark:text-slate-200">
            <MapPin className="w-4 h-4 text-[#FFD700] shrink-0 mt-0.5" />
            <div>
              <strong>Online vs Offline Note:</strong> Scoring, brackets, rankings, players, finances,
              and media exports work 100% offline. World Badminton News and Google Maps Venue search
              automatically activate whenever Wi-Fi or mobile data is available.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#F4F7FB] dark:bg-[#080808] border-t border-slate-200 dark:border-white/10 flex items-center justify-between">
          <span className="text-xs text-[#64748B] dark:text-[#A0A0A0] flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#22C55E]" />
            <span>Hassan Badminton Tournament Manager · APK &amp; PWABuilder Ready</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#172B4D] dark:bg-[#141414] border border-[#D4AF37]/40 text-white font-bold text-xs rounded-xl cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
