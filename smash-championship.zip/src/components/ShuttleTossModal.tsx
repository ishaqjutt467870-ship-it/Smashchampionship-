import React, { useState } from 'react';
import { X, RotateCw, Zap } from 'lucide-react';
import { playShuttleHitSound } from '../utils/audio';

interface ShuttleTossModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerAName: string;
  playerBName: string;
  onApplyTossResult: (firstServer: 'A' | 'B', sideLeft: 'A' | 'B') => void;
}

export const ShuttleTossModal: React.FC<ShuttleTossModalProps> = ({
  isOpen,
  onClose,
  playerAName,
  playerBName,
  onApplyTossResult,
}) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [tossWinner, setTossWinner] = useState<'A' | 'B' | null>(null);
  const [servingChoice, setServingChoice] = useState<'A' | 'B'>('A');
  const [sideChoice, setSideChoice] = useState<'left' | 'right'>('left');

  if (!isOpen) return null;

  const handleSpinShuttle = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setTossWinner(null);
    playShuttleHitSound();

    const winner: 'A' | 'B' = Math.random() > 0.5 ? 'A' : 'B';
    const targetAngle = winner === 'A' ? 0 : 180;
    const extraSpins = (Math.floor(Math.random() * 4) + 5) * 360;
    const finalRot = rotation + extraSpins + (targetAngle - (rotation % 360));

    setRotation(finalRot);

    setTimeout(() => {
      setIsSpinning(false);
      setTossWinner(winner);
      setServingChoice(winner);
      playShuttleHitSound();
    }, 1800);
  };

  const handleConfirm = () => {
    const sideLeft = sideChoice === 'left' ? 'A' : 'B';
    onApplyTossResult(servingChoice, sideLeft);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#07111F]/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-[#111E30] w-full max-w-md rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6 text-center space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏸</span>
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Shuttle Spin / Match Toss
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#64748B] hover:text-[#172033] dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
          Spin the shuttlecock on court to determine the first server and side choice.
        </p>

        {/* Players Indicator */}
        <div className="flex items-center justify-between px-4 text-xs font-bold text-[#172033] dark:text-white">
          <div
            className={`p-2 rounded-xl transition-all ${
              tossWinner === 'A'
                ? 'bg-[#B7F34A] text-[#07111F] font-black ring-2 ring-[#B7F34A]'
                : ''
            }`}
          >
            ▲ {playerAName}
          </div>
          <span className="text-[#38BDF8] text-[10px] font-black">TOSS</span>
          <div
            className={`p-2 rounded-xl transition-all ${
              tossWinner === 'B'
                ? 'bg-[#B7F34A] text-[#07111F] font-black ring-2 ring-[#B7F34A]'
                : ''
            }`}
          >
            ▼ {playerBName}
          </div>
        </div>

        {/* Shuttlecock Spinner */}
        <div className="relative w-44 h-44 mx-auto flex items-center justify-center bg-[#F4F7FB] dark:bg-[#07111F] rounded-full border-2 border-[#B7F34A]/40">
          <div
            className="text-6xl transition-transform duration-[1800ms] ease-out select-none"
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            🏸
          </div>
        </div>

        {/* Result & Choice */}
        {tossWinner && (
          <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-[#B7F34A]/40 text-xs text-[#172033] dark:text-white space-y-2">
            <span className="font-black flex items-center justify-center gap-1 text-[#8BCB35] dark:text-[#B7F34A]">
              <Zap className="w-3.5 h-3.5" />
              <span>{tossWinner === 'A' ? playerAName : playerBName} wins the toss!</span>
            </span>

            <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8] flex items-center justify-around pt-1">
              <div>
                <span className="block">First Server:</span>
                <select
                  value={servingChoice}
                  onChange={(e) => setServingChoice(e.target.value as 'A' | 'B')}
                  className="mt-1 px-2 py-1 bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 rounded font-bold text-xs text-[#172033] dark:text-white"
                >
                  <option value="A">{playerAName}</option>
                  <option value="B">{playerBName}</option>
                </select>
              </div>

              <div>
                <span className="block">Court Side:</span>
                <select
                  value={sideChoice}
                  onChange={(e) => setSideChoice(e.target.value as 'left' | 'right')}
                  className="mt-1 px-2 py-1 bg-white dark:bg-[#111E30] border border-slate-200 dark:border-slate-700 rounded font-bold text-xs text-[#172033] dark:text-white"
                >
                  <option value="left">{playerAName} Left / {playerBName} Right</option>
                  <option value="right">{playerBName} Left / {playerAName} Right</option>
                </select>
              </div>
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <button
            onClick={handleSpinShuttle}
            disabled={isSpinning}
            className="flex-1 py-2.5 bg-[#172B4D] dark:bg-[#B7F34A] hover:opacity-95 disabled:opacity-50 text-white dark:text-[#07111F] font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isSpinning ? 'animate-spin' : ''}`} />
            <span>{isSpinning ? 'Spinning...' : 'Spin Shuttlecock'}</span>
          </button>

          {tossWinner && (
            <button
              onClick={handleConfirm}
              className="py-2.5 px-4 bg-[#38BDF8] text-[#07111F] font-black text-xs rounded-xl transition-all shadow-sm cursor-pointer"
            >
              Confirm
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
