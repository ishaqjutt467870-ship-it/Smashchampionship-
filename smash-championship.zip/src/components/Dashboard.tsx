import React from 'react';
import {
  Trophy,
  Play,
  Users,
  Calendar,
  Zap,
  Award,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ChevronRight,
  Tv,
  FileText,
  Sparkles,
  Flame,
  MapPin,
  Layers,
  History,
  Palette,
  UserCheck,
  UserPlus,
  Megaphone,
  Pin,
  Trash2,
  Medal,
  QrCode,
  Activity,
  Newspaper,
  Wallet,
  Wrench,
  Eye,
} from 'lucide-react';
import {
  TournamentState,
  PlayerStats,
  TournamentMatch,
  AppLanguage,
  UserAccount,
  TournamentAnnouncement,
  CourtRecord,
  CourtMatchHistoryEntry,
} from '../types';
import { AppTab } from './Header';
import {
  getTournamentFormatLabel,
  calculateTournamentAwards,
  getInitials,
  formatScore,
} from '../utils/tournament';
import { t } from '../utils/i18n';
import { DashboardAnalytics } from './DashboardAnalytics';

interface DashboardProps {
  state: TournamentState;
  tournamentsCount: number;
  standings: PlayerStats[];
  fixtures: TournamentMatch[];
  totalMatchesCount: number;
  completedMatchesCount: number;
  courts?: CourtRecord[];
  courtHistory?: CourtMatchHistoryEntry[];
  language?: AppLanguage;
  isDark?: boolean;
  userAccount?: UserAccount | null;
  activeThemeName?: string;
  spectatorMode?: boolean;
  onNavigateTab: (tab: AppTab) => void;
  onLaunchLiveMatch?: (matchId: string) => void;
  onStartTournament: () => void;
  onOpenCertificateModal: () => void;
  onOpenSettingsModal?: () => void;
  onOpenThemeStudio?: (section: 'themes' | 'wallpapers') => void;
  onOpenAuthModal?: () => void;
  onOpenQuickMatch?: () => void;
  onOpenQRModal?: () => void;
  onUpdateAnnouncements?: (announcements: TournamentAnnouncement[]) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  state,
  tournamentsCount,
  standings,
  fixtures,
  totalMatchesCount,
  completedMatchesCount,
  courts = [],
  courtHistory = [],
  language = 'en',
  isDark = true,
  userAccount,
  activeThemeName = 'Black + Gold Elite',
  spectatorMode = false,
  onNavigateTab,
  onLaunchLiveMatch,
  onStartTournament,
  onOpenCertificateModal,
  onOpenSettingsModal,
  onOpenThemeStudio,
  onOpenAuthModal,
  onOpenQuickMatch,
  onOpenQRModal,
  onUpdateAnnouncements,
}) => {
  const [noticeText, setNoticeText] = React.useState('');
  const announcements = state.announcements || [];

  const handleAddAnnouncement = () => {
    if (!onUpdateAnnouncements || !noticeText.trim()) return;
    const item: TournamentAnnouncement = {
      id: `ann-${Date.now()}`,
      text: noticeText.trim(),
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      pinned: announcements.length === 0,
      author: userAccount?.name || 'Organizer',
    };
    onUpdateAnnouncements([item, ...announcements]);
    setNoticeText('');
  };

  const playableFixtures = fixtures.filter((f) => !f.isBye && f.playerBIndex >= 0);
  const pendingMatchesCount = Math.max(0, totalMatchesCount - completedMatchesCount);
  const completionPercentage =
    totalMatchesCount > 0 ? Math.round((completedMatchesCount / totalMatchesCount) * 100) : 0;
  const isPlayoffsReady = totalMatchesCount > 0 && completedMatchesCount === totalMatchesCount;
  const upcomingMatches = playableFixtures.filter((m) => state.results[m.id] === undefined);
  const nextUpMatch = upcomingMatches[0] || playableFixtures[0];
  const awards = calculateTournamentAwards(standings);
  const pointsTarget = state.customRules?.pointsPerSet ?? 21;
  const liveCourtsCount = courts.filter((c) => c.assignedMatchId !== null).length;

  // Compute recent activity exclusively from real saved matches and court history
  const recentActivity = React.useMemo(() => {
    const items: Array<{ id: string; title: string; detail: string; badge: string }> = [];
    courtHistory.slice(0, 4).forEach((entry) => {
      items.push({
        id: `ch-${entry.id}`,
        title: `${entry.winner} won vs ${entry.winner === entry.playerA ? entry.playerB : entry.playerA}`,
        detail: `${entry.courtName} · ${entry.score || 'Completed'}`,
        badge: new Date(entry.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      });
    });

    if (items.length < 4) {
      playableFixtures
        .filter((f) => state.results[f.id] !== undefined)
        .slice(-4)
        .reverse()
        .forEach((f) => {
          if (items.length >= 4) return;
          const winnerIdx = state.results[f.id];
          const winnerName = state.players[winnerIdx] || `Player ${winnerIdx + 1}`;
          const pA = state.players[f.playerAIndex] || `Player ${f.playerAIndex + 1}`;
          const pB = state.players[f.playerBIndex] || `Player ${f.playerBIndex + 1}`;
          const scoreStr = formatScore(state.scores?.[f.id]);
          items.push({
            id: `fix-${f.id}`,
            title: `${winnerName} def. ${winnerIdx === f.playerAIndex ? pB : pA}`,
            detail: `Match #${f.roundNumber || ''} · ${scoreStr || 'Recorded Result'}`,
            badge: state.matchMeta?.[f.id]?.resultType === 'retired'
              ? 'RET'
              : state.matchMeta?.[f.id]?.resultType === 'walkover'
              ? 'W/O'
              : 'DONE',
          });
        });
    }
    return items;
  }, [courtHistory, playableFixtures, state.results, state.players, state.scores, state.matchMeta]);

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in">
      {/* Dynamic Black + Gold Hero Command Center */}
      <div className="relative overflow-hidden rounded-3xl theme-hero p-6 sm:p-9 text-white shadow-2xl border border-[#D4AF37]/30">
        <div
          className="absolute -top-24 right-1/4 w-96 h-96 rounded-full blur-[110px] pointer-events-none opacity-25"
          style={{ backgroundColor: 'var(--accent-primary)' }}
        />
        <div
          className="absolute -bottom-24 -right-16 w-80 h-80 rounded-full blur-[120px] pointer-events-none opacity-20"
          style={{ backgroundColor: 'var(--accent-secondary)' }}
        />

        <div className="relative z-10 max-w-4xl space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-extrabold uppercase tracking-wider text-[11px] text-[#FFD700]">
                Hassan Badminton Tournament Manager
              </span>
              <span className="text-[#A0A0A0]">&middot;</span>
              <span className="text-[#D4AF37] font-bold">Developed By Hassan</span>
              {liveCourtsCount > 0 && (
                <>
                  <span className="text-[#A0A0A0]">&middot;</span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#22C55E]/15 text-[#22C55E] font-bold text-[10px]">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E] animate-pulse" />
                    {liveCourtsCount} Live Court{liveCourtsCount > 1 ? 's' : ''} Active
                  </span>
                </>
              )}
            </div>

            {onOpenAuthModal && (
              <button
                type="button"
                onClick={onOpenAuthModal}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-200 hover:text-[#FFD700] transition-colors cursor-pointer"
              >
                {userAccount?.verified ? (
                  <>
                    <UserCheck className="w-3.5 h-3.5 text-[#22C55E]" />
                    <span className="text-[#22C55E]">Verified: {userAccount.name}</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Sign Up &amp; Verify Account</span>
                  </>
                )}
              </button>
            )}
          </div>

          <div className="flex items-center gap-4 sm:gap-5 pt-1">
            {state.customLogoUrl ? (
              <img
                src={state.customLogoUrl}
                alt={state.tournamentTitle || 'Smash Championship'}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-[#D4AF37] shadow-xl shrink-0 bg-[#080808]"
              />
            ) : (
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] border-2 border-white/40 flex items-center justify-center text-3xl sm:text-4xl text-[#080808] shadow-xl shrink-0">
                🏸
              </div>
            )}
            <div className="min-w-0">
              <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight text-white leading-tight font-sans drop-shadow-md truncate">
                {state.tournamentTitle || 'SMASH CHAMPIONSHIP'}
              </h1>
              <div className="text-xs sm:text-sm text-[#A0A0A0] font-semibold tracking-wide flex flex-wrap items-center gap-x-2.5 gap-y-1 mt-1">
                <span className="text-[#FFD700] font-bold">
                  {getTournamentFormatLabel(state.tournamentFormat)}
                </span>
                <span aria-hidden="true">&middot;</span>
                <span className="uppercase">{(state.category || 'singles').replace('_', ' ')}</span>
                <span aria-hidden="true">&middot;</span>
                <span>{pointsTarget} Pts / Set</span>
                <span aria-hidden="true">&middot;</span>
                <span className="inline-flex items-center gap-1 text-[#D4AF37]">
                  <MapPin className="w-3.5 h-3.5" />
                  {state.venue || 'Center Arena Court'}
                </span>
              </div>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-[#A0A0A0] leading-relaxed max-w-2xl">
            {state.description ||
              'Elite offline badminton tournament platform featuring 5 competition formats, BWF 21-point live scoring, global rankings, QR invites, and Black + Gold championship exports.'}
          </p>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2 pt-2">
            <button
              onClick={() => onNavigateTab('live')}
              className="px-5 py-2.5 theme-accent-btn hover:opacity-95 active:scale-[0.98] font-black text-xs sm:text-sm rounded-xl transition-all shadow-lg flex items-center gap-2 cursor-pointer"
            >
              <Zap className="w-4 h-4 fill-current" />
              <span>{t(language, 'quickStartLive')}</span>
            </button>

            {onOpenQuickMatch && (
              <button
                type="button"
                onClick={onOpenQuickMatch}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white border border-[#D4AF37]/50 font-black text-xs sm:text-sm rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <Zap className="w-4 h-4 text-[#FFD700]" />
                <span>Quick Match 1v1/2v2</span>
              </button>
            )}

            {!state.started ? (
              <button
                onClick={onStartTournament}
                className="px-5 py-2.5 bg-[#FFD700] hover:opacity-95 active:scale-[0.98] text-[#080808] font-black text-xs sm:text-sm rounded-xl transition-all shadow-lg flex items-center gap-2 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{t(language, 'startTournament')}</span>
              </button>
            ) : (
              <button
                onClick={() => onNavigateTab('matches')}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white border border-white/15 text-xs sm:text-sm font-bold rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>View Fixtures</span>
                <ArrowRight className="w-4 h-4 text-[#FFD700]" />
              </button>
            )}

            <button
              onClick={() => onNavigateTab('tournaments')}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Layers className="w-4 h-4 text-[#D4AF37]" />
              <span>Tournaments</span>
            </button>

            <button
              onClick={() => onNavigateTab('rankings')}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Medal className="w-4 h-4 text-[#FFD700]" />
              <span>Rankings</span>
            </button>

            <button
              onClick={() => onNavigateTab('courts')}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Tv className="w-4 h-4 text-[#22C55E]" />
              <span>Courts</span>
            </button>

            {onOpenQRModal && (
              <button
                type="button"
                onClick={onOpenQRModal}
                className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <QrCode className="w-4 h-4 text-[#FFD700]" />
                <span>QR Code</span>
              </button>
            )}

            {onOpenThemeStudio && (
              <button
                onClick={() => onOpenThemeStudio('themes')}
                className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                title={`Active Theme: ${activeThemeName}`}
              >
                <Palette className="w-4 h-4 text-[#D4AF37]" />
                <span>120+ Themes</span>
              </button>
            )}

            <button
              onClick={onOpenCertificateModal}
              className={`px-3.5 py-2.5 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer border ${
                state.finalWinner !== null
                  ? 'bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#FFD700] border-[#D4AF37]/50'
                  : 'bg-white/10 hover:bg-white/15 text-slate-200 border-white/15'
              }`}
            >
              <FileText className="w-4 h-4 text-[#FFD700]" />
              <span>Reports &amp; Posters</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigateTab('venue')}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <MapPin className="w-4 h-4 text-[#FFD700]" />
              <span>{state.venueLocation ? 'Venue GPS Saved' : 'Pin Venue Map'}</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigateTab('news')}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Newspaper className="w-4 h-4 text-[#D4AF37]" />
              <span>World News</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigateTab('studio')}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#FFD700]" />
              <span>Media Studio</span>
            </button>

            {!spectatorMode && (
              <>
                <button
                  type="button"
                  onClick={() => onNavigateTab('finance')}
                  className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Wallet className="w-4 h-4 text-[#22C55E]" />
                  <span>Finance</span>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigateTab('admin')}
                  className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Wrench className="w-4 h-4 text-[#D4AF37]" />
                  <span>Admin Center</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 6 KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <div
          onClick={() => onNavigateTab('tournaments')}
          className="theme-card rounded-3xl p-4 sm:p-5 border shadow-sm flex flex-col justify-between cursor-pointer hover:-translate-y-0.5 transition-all"
        >
          <div className="flex items-center justify-between text-[#64748B] dark:text-[#A0A0A0]">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {t(language, 'totalTournaments')}
            </span>
            <Trophy className="w-4 h-4 text-[#D4AF37] dark:text-[#FFD700]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-[#172033] dark:text-white font-mono tabular-nums">
              {tournamentsCount}
            </div>
            <div className="text-[11px] text-[#9A7B1C] dark:text-[#FFD700] font-bold mt-0.5">
              {state.started ? 'Active League' : 'Ready to Play'}
            </div>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('roster')}
          className="theme-card rounded-3xl p-4 sm:p-5 border shadow-sm flex flex-col justify-between cursor-pointer hover:-translate-y-0.5 transition-all"
        >
          <div className="flex items-center justify-between text-[#64748B] dark:text-[#A0A0A0]">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {t(language, 'totalPlayers')}
            </span>
            <Users className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-[#172033] dark:text-white font-mono tabular-nums">
              {state.players.length}
            </div>
            <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] font-medium mt-0.5">
              Registered Roster
            </div>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('matches')}
          className="theme-card rounded-3xl p-4 sm:p-5 border shadow-sm flex flex-col justify-between cursor-pointer hover:-translate-y-0.5 transition-all"
        >
          <div className="flex items-center justify-between text-[#64748B] dark:text-[#A0A0A0]">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {t(language, 'totalMatches')}
            </span>
            <Calendar className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-[#172033] dark:text-white font-mono tabular-nums">
              {totalMatchesCount}
            </div>
            <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] font-medium mt-0.5 truncate">
              {getTournamentFormatLabel(state.tournamentFormat)}
            </div>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('matches')}
          className="theme-card rounded-3xl p-4 sm:p-5 border shadow-sm flex flex-col justify-between cursor-pointer hover:-translate-y-0.5 transition-all"
        >
          <div className="flex items-center justify-between text-[#64748B] dark:text-[#A0A0A0]">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {t(language, 'completedMatches')}
            </span>
            <CheckCircle2 className="w-4 h-4 text-[#22C55E]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-[#22C55E] font-mono tabular-nums">
              {completedMatchesCount}
            </div>
            <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] font-medium mt-0.5">
              {completionPercentage}% completed
            </div>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('matches')}
          className="theme-card rounded-3xl p-4 sm:p-5 border shadow-sm flex flex-col justify-between cursor-pointer hover:-translate-y-0.5 transition-all"
        >
          <div className="flex items-center justify-between text-[#64748B] dark:text-[#A0A0A0]">
            <span className="text-[11px] font-bold uppercase tracking-wider">Upcoming</span>
            <Clock className="w-4 h-4 text-[#FFD700]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-[#172B4D] dark:text-[#FFD700] font-mono tabular-nums">
              {pendingMatchesCount}
            </div>
            <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] font-medium mt-0.5">
              {liveCourtsCount} courts active
            </div>
          </div>
        </div>

        <div
          onClick={onOpenSettingsModal}
          className="theme-card rounded-3xl p-4 sm:p-5 border shadow-sm flex flex-col justify-between cursor-pointer hover:-translate-y-0.5 transition-all"
        >
          <div className="flex items-center justify-between text-[#64748B] dark:text-[#A0A0A0]">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {t(language, 'matchFormat')}
            </span>
            <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-[#172033] dark:text-white uppercase font-mono">
              {state.matchFormat || 'bo3'}
            </div>
            <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] font-medium mt-0.5">
              {pointsTarget} Pts (Cap {state.customRules?.maxDeuceCap || 30})
            </div>
          </div>
        </div>
      </div>

      {/* Live / Next Up Match Spotlight */}
      {nextUpMatch && (
        <div className="theme-card rounded-3xl p-5 sm:p-6 border border-[#D4AF37]/25 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-12 h-12 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/45 flex items-center justify-center text-[#172B4D] dark:text-[#FFD700] shrink-0">
              <Zap className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-wider text-[#D4AF37]">
                <span>{upcomingMatches.length > 0 ? 'Next Featured Fixture' : 'Spotlight Match'}</span>
                {nextUpMatch.group && (
                  <span className="px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700]">
                    Group {nextUpMatch.group}
                  </span>
                )}
              </div>
              <div className="text-base sm:text-lg font-black text-[#172033] dark:text-white truncate mt-0.5">
                {state.players[nextUpMatch.playerAIndex]} <span className="text-[#FFD700]">VS</span>{' '}
                {state.players[nextUpMatch.playerBIndex]}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full md:w-auto">
            <button
              type="button"
              onClick={() =>
                onLaunchLiveMatch
                  ? onLaunchLiveMatch(nextUpMatch.id)
                  : onNavigateTab('live')
              }
              className="flex-1 md:flex-initial px-5 py-2.5 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-extrabold text-xs shadow hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Open Live Scorer</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('history')}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <History className="w-3.5 h-3.5" />
              <span>History &amp; Guide</span>
            </button>
          </div>
        </div>
      )}

      {/* Recharts Analytics & Smart Match Analytics Section */}
      <DashboardAnalytics
        players={state.players}
        standings={standings}
        fixtures={playableFixtures}
        results={state.results}
        scores={state.scores || {}}
        matchMeta={state.matchMeta}
        isDark={isDark}
        onStartMatch={() =>
          nextUpMatch && onLaunchLiveMatch
            ? onLaunchLiveMatch(nextUpMatch.id)
            : onNavigateTab('live')
        }
        onOpenReportModal={onOpenCertificateModal}
      />

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Standings Preview */}
        <div className="lg:col-span-2 theme-card rounded-3xl p-5 sm:p-6 border shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-[#D4AF37]/15 text-[#172B4D] dark:text-[#FFD700] border border-[#D4AF37]/30">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-black text-[#172033] dark:text-white tracking-tight">
                  Official Leaderboard
                </h2>
                <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                  Top 4 qualify for Semi-Finals &amp; Grand Final playoffs
                </p>
              </div>
            </div>
            <button
              onClick={() => onNavigateTab('table')}
              className="text-xs text-[#172B4D] dark:text-[#FFD700] hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>Full Table</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-white/5">
            {standings.map((player, idx) => {
              const isQualified = idx < 4;
              return (
                <div
                  key={player.id}
                  className="py-3 px-2.5 flex items-center justify-between rounded-2xl transition-colors hover:bg-[#F4F7FB] dark:hover:bg-[#080808]/70"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
                        idx === 0
                          ? 'bg-gradient-to-br from-[#FFD700] to-[#D4AF37] text-[#080808]'
                          : idx === 1
                          ? 'bg-slate-300 text-[#080808]'
                          : idx === 2
                          ? 'bg-amber-700 text-white'
                          : 'bg-slate-100 dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0]'
                      }`}
                    >
                      #{idx + 1}
                    </span>

                    {player.photo ? (
                      <img
                        src={player.photo}
                        alt={player.name}
                        className="w-10 h-10 rounded-2xl object-cover border-2 border-[#D4AF37]/60 shrink-0"
                      />
                    ) : (
                      <div
                        className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-[#080808] text-xs shrink-0"
                        style={{ backgroundColor: player.avatarColor }}
                      >
                        {getInitials(player.name)}
                      </div>
                    )}

                    <div className="min-w-0">
                      <div className="text-sm font-black text-[#172033] dark:text-white flex items-center gap-2 truncate">
                        <span className="truncate">{player.name}</span>
                        {player.group && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] font-bold shrink-0">
                            Grp {player.group}
                          </span>
                        )}
                        {isQualified && (
                          <span className="text-[10px] text-[#22C55E] font-bold uppercase tracking-wider shrink-0">
                            &middot; Seed
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-[#64748B] dark:text-[#A0A0A0] flex items-center gap-2 mt-0.5">
                        <span>
                          {player.won}W - {player.lost}L ({player.played} played)
                        </span>
                        <span aria-hidden="true">&middot;</span>
                        <span>
                          Sets {player.setsWon}-{player.setsLost}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0 pl-3">
                    <div className="text-lg font-black text-[#172B4D] dark:text-[#FFD700] font-mono tabular-nums">
                      {player.points}{' '}
                      <span className="text-xs font-semibold text-[#64748B] dark:text-[#A0A0A0]">
                        pts
                      </span>
                    </div>
                    <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] font-mono">
                      {player.played > 0 ? Math.round((player.won / player.played) * 100) : 0}% win
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Champion / Activity / Playoffs / Notice Board */}
        <div className="space-y-4">
          {state.finalWinner !== null && (
            <div className="rounded-3xl bg-gradient-to-br from-[#141414] to-[#080808] p-6 text-white shadow-xl space-y-3 relative overflow-hidden border border-[#D4AF37]/60">
              <div className="flex items-center gap-2 text-[#FFD700] text-xs font-black uppercase tracking-wider">
                <Sparkles className="w-4 h-4" />
                <span>Reigning Champion</span>
              </div>

              <div className="flex items-center gap-4 pt-1">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center font-black text-2xl shadow-lg">
                  👑
                </div>
                <div className="min-w-0">
                  <h3 className="text-2xl font-black leading-tight truncate">
                    {state.players[state.finalWinner]}
                  </h3>
                  <div className="text-xs text-[#D4AF37] font-bold mt-0.5">
                    {state.tournamentTitle} Winner
                  </div>
                </div>
              </div>

              <button
                onClick={onOpenCertificateModal}
                className="w-full mt-2 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] hover:opacity-95 text-[#080808] font-extrabold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Champion Certificate &amp; Poster</span>
              </button>
            </div>
          )}

          {/* Recent Tournament Activity */}
          <div className="theme-card rounded-3xl p-5 border shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#172033] dark:text-white font-black text-sm">
                <Activity className="w-4 h-4 text-[#FFD700]" />
                <span>Recent Tournament Activity</span>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('history')}
                className="text-[11px] font-bold text-[#D4AF37] hover:underline cursor-pointer"
              >
                History
              </button>
            </div>
            {recentActivity.length === 0 ? (
              <p className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                No completed matches yet. Score a fixture live to populate real-time activity here.
              </p>
            ) : (
              <div className="space-y-2 text-xs">
                {recentActivity.map((act) => (
                  <div
                    key={act.id}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/70 dark:border-white/10 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="font-bold text-[#172033] dark:text-white truncate">
                        {act.title}
                      </div>
                      <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] truncate">
                        {act.detail}
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] font-mono text-[10px] font-bold shrink-0">
                      {act.badge}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* MVP & Statistical Awards Card */}
          {awards.mvp && (
            <div className="theme-card rounded-3xl p-5 border shadow-sm space-y-3">
              <div className="flex items-center gap-2 text-[#172033] dark:text-white font-black text-sm">
                <Trophy className="w-4 h-4 text-[#FFD700]" />
                <span>Tournament Leaders</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between">
                  <span className="text-[#64748B] dark:text-[#A0A0A0] font-semibold">MVP Leader</span>
                  <span className="font-black text-[#172033] dark:text-[#FFD700]">
                    {awards.mvp.name} ({awards.mvp.points} pts)
                  </span>
                </div>
                {awards.topScorer && (
                  <div className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] flex items-center justify-between">
                    <span className="text-[#64748B] dark:text-[#A0A0A0] font-semibold">
                      Top Rally Scorer
                    </span>
                    <span className="font-black text-[#172033] dark:text-[#D4AF37]">
                      {awards.topScorer.name} ({awards.topScorer.pointsFor} pts)
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Playoffs Status Card */}
          <div className="theme-card rounded-3xl p-5 sm:p-6 border shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-[#172033] dark:text-white font-black text-sm">
              <Flame className="w-4 h-4 text-[#FFD700]" />
              <span>Championship Playoffs Status</span>
            </div>

            <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] leading-relaxed">
              {isPlayoffsReady
                ? 'All stage fixtures are complete! Knockout Semi-Finals and Grand Final brackets are unlocked.'
                : `${pendingMatchesCount} match${pendingMatchesCount === 1 ? '' : 'es'} remaining before playoff seeds lock.`}
            </p>

            <div className="w-full bg-slate-100 dark:bg-[#080808] rounded-full h-3 overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#D4AF37] to-[#FFD700] h-3 rounded-full transition-all duration-500"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-[#A0A0A0] font-mono">
              <span>
                {completedMatchesCount} / {totalMatchesCount} matches
              </span>
              <span>{completionPercentage}%</span>
            </div>

            <button
              onClick={() => onNavigateTab('knockout')}
              className={`w-full mt-2 py-2.5 rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isPlayoffsReady
                  ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-md'
                  : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white border border-slate-200 dark:border-white/10 hover:border-[#D4AF37]'
              }`}
            >
              <Trophy className="w-4 h-4 text-[#D4AF37]" />
              <span>View Knockout Brackets</span>
            </button>
          </div>

          {/* Tournament Notice Board & Announcements */}
          {(onUpdateAnnouncements || announcements.length > 0) && (
            <div className="theme-card rounded-3xl p-5 border shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[#172033] dark:text-white font-black text-sm">
                  <Megaphone className="w-4 h-4 text-[#D4AF37]" />
                  <span>Tournament Notice Board</span>
                </div>
                <span className="text-[10px] font-mono text-[#64748B] dark:text-[#A0A0A0] flex items-center gap-1">
                  {spectatorMode && <Eye className="w-3 h-3 text-[#22C55E]" />}
                  {announcements.length} notices
                </span>
              </div>

              {onUpdateAnnouncements && !spectatorMode && (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={noticeText}
                    onChange={(e) => setNoticeText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddAnnouncement()}
                    placeholder="Post announcement (e.g. Final on Court 1)..."
                    className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddAnnouncement}
                    disabled={!noticeText.trim()}
                    className="px-3 py-2 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] disabled:opacity-40 text-white dark:text-[#080808] text-xs font-extrabold cursor-pointer shrink-0"
                  >
                    Post
                  </button>
                </div>
              )}

              {announcements.length === 0 ? (
                <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  No notices posted yet. Pin court schedules or break alerts here.
                </p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {[...announcements]
                    .sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)))
                    .map((ann) => (
                      <div
                        key={ann.id}
                        className={`p-2.5 rounded-xl border text-xs flex items-start justify-between gap-2 ${
                          ann.pinned
                            ? 'bg-[#D4AF37]/10 border-[#D4AF37]/40'
                            : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200 dark:border-white/10'
                        }`}
                      >
                        <div className="min-w-0">
                          <div className="font-bold text-[#172033] dark:text-white break-words">
                            {ann.text}
                          </div>
                          <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
                            {ann.author || 'Organizer'} · {ann.createdAt}
                          </div>
                        </div>
                        {onUpdateAnnouncements && !spectatorMode && (
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateAnnouncements(
                                  announcements.map((a) =>
                                    a.id === ann.id ? { ...a, pinned: !a.pinned } : a
                                  )
                                )
                              }
                              className={`p-1 rounded cursor-pointer ${
                                ann.pinned
                                  ? 'text-[#D4AF37] dark:text-[#FFD700]'
                                  : 'text-[#64748B] hover:text-white'
                              }`}
                              title={ann.pinned ? 'Unpin notice' : 'Pin notice'}
                            >
                              <Pin className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateAnnouncements(announcements.filter((a) => a.id !== ann.id))
                              }
                              className="p-1 rounded text-[#64748B] hover:text-[#EF4444] cursor-pointer"
                              title="Delete notice"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
