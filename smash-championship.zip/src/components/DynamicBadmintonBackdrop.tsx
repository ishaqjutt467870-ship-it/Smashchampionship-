import React from 'react';
import { WallpaperSettings } from '../types';
import { AppTheme } from '../utils/themes';
import { getWallpaperById } from '../utils/wallpapers';

interface DynamicBadmintonBackdropProps {
  theme: AppTheme;
  wallpaper?: WallpaperSettings;
}

export const DynamicBadmintonBackdrop: React.FC<DynamicBadmintonBackdropProps> = ({
  theme,
  wallpaper,
}) => {
  const activeWallpaper = getWallpaperById(wallpaper?.id);
  const customImageUrl =
    wallpaper?.id === 'custom' && wallpaper.customUrl ? wallpaper.customUrl : undefined;
  const imageSrc =
    customImageUrl || (activeWallpaper.type === 'image' ? activeWallpaper.imageUrl : undefined);
  const isGradientWallpaper = activeWallpaper.type === 'gradient';
  const hasWallpaper = Boolean(imageSrc || isGradientWallpaper);

  const opacity = Math.min(100, Math.max(15, wallpaper?.opacity ?? 45)) / 100;
  const blurPx = Math.min(16, Math.max(0, wallpaper?.blur ?? 2));
  const useScrim = wallpaper?.scrim ?? true;

  return (
    <div
      className="fixed inset-0 pointer-events-none -z-10 overflow-hidden transition-colors duration-300"
      style={{ backgroundColor: theme.bgCanvas }}
      aria-hidden="true"
    >
      {/* Selected Image Wallpaper Layer */}
      {imageSrc && (
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-all duration-500 scale-105"
          style={{
            backgroundImage: `url("${imageSrc}")`,
            opacity,
            filter: blurPx > 0 ? `blur(${blurPx}px)` : undefined,
          }}
        />
      )}

      {/* Selected Gradient Mesh Wallpaper Layer */}
      {isGradientWallpaper && activeWallpaper.cssBackground && (
        <div
          className="absolute inset-0 transition-all duration-500"
          style={{
            backgroundImage: activeWallpaper.cssBackground,
            backgroundSize:
              activeWallpaper.id === 'carbon-blueprint' ? '36px 36px, 36px 36px, cover' : 'cover',
            opacity: Math.max(0.55, opacity),
            filter: blurPx > 0 ? `blur(${blurPx}px)` : undefined,
          }}
        />
      )}

      {/* Contrast Readability Scrim when a wallpaper is active */}
      {hasWallpaper && useScrim && (
        <div
          className="absolute inset-0 transition-colors duration-300"
          style={{
            background:
              theme.mode === 'dark'
                ? `linear-gradient(180deg, ${theme.bgCanvas}C8 0%, ${theme.bgCanvas}9E 45%, ${theme.bgCanvas}E0 100%)`
                : `linear-gradient(180deg, ${theme.bgCanvas}D4 0%, ${theme.bgCanvas}AD 45%, ${theme.bgCanvas}DE 100%)`,
          }}
        />
      )}

      {/* Dynamic Theme Arena Spotlights */}
      <div
        className="absolute -top-[15%] left-[18%] w-[65vw] h-[45vw] max-w-[820px] max-h-[600px] rounded-full blur-[140px] transition-colors duration-500"
        style={{ backgroundColor: theme.accentPrimary, opacity: theme.mode === 'dark' ? 0.12 : 0.14 }}
      />
      <div
        className="absolute top-[35%] -right-[10%] w-[50vw] h-[50vw] max-w-[650px] max-h-[650px] rounded-full blur-[130px] transition-colors duration-500"
        style={{ backgroundColor: theme.accentSecondary, opacity: theme.mode === 'dark' ? 0.11 : 0.12 }}
      />
      <div
        className="absolute -bottom-[10%] -left-[10%] w-[55vw] h-[55vw] max-w-[700px] max-h-[700px] rounded-full blur-[150px] transition-colors duration-500"
        style={{ backgroundColor: theme.accentPrimary, opacity: theme.mode === 'dark' ? 0.07 : 0.08 }}
      />

      {/* Subtle Micro Mesh Pattern */}
      <div
        className="absolute inset-0 opacity-[0.03] dark:opacity-[0.045]"
        style={{
          backgroundImage: `radial-gradient(${theme.accentSecondary} 1px, transparent 1px)`,
          backgroundSize: '28px 28px',
        }}
      />

      {/* Architectural Badminton Court Outlines */}
      <div
        className="absolute top-8 left-1/2 -translate-x-1/2 w-[94vw] max-w-6xl h-[480px] rounded-[36px] pointer-events-none border"
        style={{ borderColor: theme.borderColor }}
      />
      <div
        className="absolute top-28 left-1/2 -translate-x-1/2 w-[90vw] max-w-5xl h-[360px] rounded-3xl pointer-events-none border border-dashed"
        style={{ borderColor: theme.borderColor }}
      />
    </div>
  );
};
