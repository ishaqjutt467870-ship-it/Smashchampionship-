import React, { useState } from 'react';
import {
  CheckCircle2,
  RotateCcw,
  Filter,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Trophy,
  Minus,
  Plus,
  Clock,
  Award,
  Edit3,
  Trash2,
  Image as ImageIcon,
} from 'lucide-react';
import {
  TournamentMatch,
  TournamentFormatType,
  MatchScore,
  MatchFormat,
  CustomTournamentRules,
  MatchScheduleInfo,
  MatchMetaInfo,
} from '../types';
import {
  getPlayerColor,
  getInitials,
  formatScore,
  getFormatLabel,
  clampPointsPerSet,
  getSuggestedInterval,
  getSuggestedDeuceCap,
} from '../utils/tournament';
import { downloadMatchResultPoster } from '../utils/exports';

interface LeagueMatchesProps {
  players: string[];
  fixtures: TournamentMatch[];
  manualFixtures?: TournamentMatch[];
  onUpdateManualFixtures?: (fixtures: TournamentMatch[]) => void;
  tournamentFormat?: TournamentFormatType;
  onGenerateNextSwissRound?: () => void;
  onAutoSchedulePending?: () => void;
  onUpdateMatchMeta?: (matchId: string, updater: (prev: MatchMetaInfo) => MatchMetaInfo) => void;
  results: Record<string, number>;
  scores: Record<string, MatchScore>;
  matchMeta?: Record<string, MatchMetaInfo>;
  tournamentTitle?: string;
  matchFormat: MatchFormat;
  setMatchFormat?: (fmt: MatchFormat) => void;
  matchFormats?: Record<string, MatchFormat>;
  onSetMatchItemFormat?: (matchId: string, fmt: MatchFormat) => void;
  matchSchedules?: Record<string, MatchScheduleInfo>;
  onUpdateMatchSchedule?: (matchId: string, info: MatchScheduleInfo) => void;
  referees?: string[];
  customRules?: CustomTournamentRules;
  onUpdateCustomRules?: (rules: CustomTournamentRules) => void;
  playerPhotos?: Record<number, string>;
  onSetResult: (matchId: string, winnerIndex: number, score?: MatchScore) => void;
  onUndoResult: (matchId: string) => void;
  matchMvps?: Record<string, number>;
  onToggleMatchMvp?: (matchId: string, playerIndex: number | null) => void;
  onSimulateAll: () => void;
  onOpenPlayerProfile: (playerId: number) => void;
  onLaunchLiveScorer?: (matchId: string) => void;
}

const generateDefaultQuickScore = (
  winnerIndex: number,
  aIndex: number,
  _bIndex: number,
  format: MatchFormat,
  targetPoints: number
): MatchScore => {
  const isA = winnerIndex === aIndex;
  const low1 = Math.max(5, targetPoints - 5);
  const low2 = Math.max(4, targetPoints - 7);
  const low3 = Math.max(6, targetPoints - 3);

  if (format === 'bo1') {
    return { s1a: isA ? targetPoints : low1, s1b: isA ? low1 : targetPoints };
  }
  if (format === 'bo2') {
    return {
      s1a: isA ? targetPoints : low1,
      s1b: isA ? low1 : targetPoints,
      s2a: isA ? targetPoints : low2,
      s2b: isA ? low2 : targetPoints,
    };
  }
  if (format === 'bo5') {
    return {
      s1a: isA ? targetPoints : low1,
      s1b: isA ? low1 : targetPoints,
      s2a: isA ? targetPoints : low2,
      s2b: isA ? low2 : targetPoints,
      s3a: isA ? targetPoints : low3,
      s3b: isA ? low3 : targetPoints,
    };
  }
  return {
    s1a: isA ? targetPoints : low1,
    s1b: isA ? low1 : targetPoints,
    s2a: isA ? targetPoints : low2,
    s2b: isA ? low2 : targetPoints,
  };
};

export const LeagueMatches: React.FC<LeagueMatchesProps> = ({
  players,
  fixtures,
  manualFixtures = [],
  onUpdateManualFixtures,
  tournamentFormat = 'round_robin',
  onGenerateNextSwissRound,
  onAutoSchedulePending,
  onUpdateMatchMeta,
  results,
  scores,
  matchMeta = {},
  tournamentTitle = 'Smash Championship',
  matchFormat,
  setMatchFormat,
  matchFormats = {},
  onSetMatchItemFormat,
  matchSchedules = {},
  onUpdateMatchSchedule,
  referees = ['Hassan (Chief Referee)', 'Bilal', 'Tariq'],
  customRules,
  onUpdateCustomRules,
  playerPhotos,
  onSetResult,
  onUndoResult,
  matchMvps = {},
  onToggleMatchMvp,
  onSimulateAll,
  onOpenPlayerProfile,
  onLaunchLiveScorer,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'pending' | 'completed'>('all');
  const [groupFilter, setGroupFilter] = useState<'all' | 'A' | 'B'>('all');
  const [selectedPlayerFilter, setSelectedPlayerFilter] = useState<number | 'all'>('all');
  const [expandedScoreMatchId, setExpandedScoreMatchId] = useState<string | null>(null);
  const [editingScheduleId, setEditingScheduleId] = useState<string | null>(null);
  const [tempScores, setTempScores] = useState<Record<string, Record<string, string>>>({});
  const [showFixtureEditor, setShowFixtureEditor] = useState(false);
  const [customAIdx, setCustomAIdx] = useState<number>(0);
  const [customBIdx, setCustomBIdx] = useState<number>(1);
  const [customGroup, setCustomGroup] = useState<'none' | 'A' | 'B'>('none');

  const targetPoints = clampPointsPerSet(customRules?.pointsPerSet ?? 21);
  const defaultLoseScore = Math.max(5, targetPoints - 4);

  const handleAdjustPointsTarget = (nextRaw: number) => {
    if (!onUpdateCustomRules) return;
    const pts = clampPointsPerSet(nextRaw);
    onUpdateCustomRules({
      pointsPerSet: pts,
      intervalAt: getSuggestedInterval(pts),
      maxDeuceCap: getSuggestedDeuceCap(pts),
      refereeName: customRules?.refereeName ?? 'Hassan',
    });
  };

  const playableFixtures = fixtures.filter((m) => !m.isBye && m.playerBIndex >= 0);
  const hasGroups = fixtures.some((m) => m.group === 'A' || m.group === 'B');
  const completedMatches = playableFixtures.filter((m) => results[m.id] !== undefined);
  const totalCount = playableFixtures.length;
  const completedCount = completedMatches.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const filteredMatches = fixtures.filter((match) => {
    const isCompleted = results[match.id] !== undefined || Boolean(match.isBye);
    if (filterMode === 'pending' && isCompleted) return false;
    if (filterMode === 'completed' && !isCompleted) return false;
    if (hasGroups && groupFilter !== 'all' && match.group !== groupFilter) return false;

    if (selectedPlayerFilter !== 'all') {
      if (match.playerAIndex !== selectedPlayerFilter && match.playerBIndex !== selectedPlayerFilter) {
        return false;
      }
    }
    return true;
  });

  const handleScoreChange = (matchId: string, field: string, value: string) => {
    setTempScores((prev) => ({
      ...prev,
      [matchId]: {
        ...(prev[matchId] || {}),
        [field]: value,
      },
    }));
  };

  const handleSaveDetailedScore = (match: TournamentMatch, effectiveFormat: MatchFormat) => {
    const temp = tempScores[match.id] || {};
    const s1a = parseInt(temp.s1a || String(targetPoints), 10);
    const s1b = parseInt(temp.s1b || String(defaultLoseScore), 10);
    const s2a =
      effectiveFormat !== 'bo1'
        ? temp.s2a
          ? parseInt(temp.s2a, 10)
          : targetPoints
        : undefined;
    const s2b =
      effectiveFormat !== 'bo1'
        ? temp.s2b
          ? parseInt(temp.s2b, 10)
          : defaultLoseScore
        : undefined;
    const s3a =
      effectiveFormat !== 'bo1' && effectiveFormat !== 'bo2' && temp.s3a
        ? parseInt(temp.s3a, 10)
        : effectiveFormat === 'bo5'
        ? targetPoints
        : undefined;
    const s3b =
      effectiveFormat !== 'bo1' && effectiveFormat !== 'bo2' && temp.s3b
        ? parseInt(temp.s3b, 10)
        : effectiveFormat === 'bo5'
        ? defaultLoseScore
        : undefined;
    const s4a = effectiveFormat === 'bo5' && temp.s4a ? parseInt(temp.s4a, 10) : undefined;
    const s4b = effectiveFormat === 'bo5' && temp.s4b ? parseInt(temp.s4b, 10) : undefined;
    const s5a = effectiveFormat === 'bo5' && temp.s5a ? parseInt(temp.s5a, 10) : undefined;
    const s5b = effectiveFormat === 'bo5' && temp.s5b ? parseInt(temp.s5b, 10) : undefined;

    let setsWonA = 0;
    let setsWonB = 0;
    let totalPtsA = 0;
    let totalPtsB = 0;
    const setPairs: Array<[number | undefined, number | undefined]> = [
      [s1a, s1b],
      [s2a, s2b],
      [s3a, s3b],
      [s4a, s4b],
      [s5a, s5b],
    ];
    setPairs.forEach(([sa, sb]) => {
      if (sa !== undefined && sb !== undefined && (sa > 0 || sb > 0)) {
        totalPtsA += sa;
        totalPtsB += sb;
        if (sa > sb) setsWonA++;
        else if (sb > sa) setsWonB++;
      }
    });

    let winnerIndex: number;
    if (setsWonA > setsWonB) winnerIndex = match.playerAIndex;
    else if (setsWonB > setsWonA) winnerIndex = match.playerBIndex;
    else winnerIndex = totalPtsA >= totalPtsB ? match.playerAIndex : match.playerBIndex;

    const scoreObj: MatchScore = {
      s1a,
      s1b,
      ...(s2a !== undefined && s2b !== undefined ? { s2a, s2b } : {}),
      ...(s3a !== undefined && s3b !== undefined ? { s3a, s3b } : {}),
      ...(s4a !== undefined && s4b !== undefined ? { s4a, s4b } : {}),
      ...(s5a !== undefined && s5b !== undefined ? { s5a, s5b } : {}),
    };
    onSetResult(match.id, winnerIndex, scoreObj);
    setExpandedScoreMatchId(null);
  };

  const handleAddManualFixture = () => {
    if (!onUpdateManualFixtures || customAIdx === customBIdx) return;
    const base = manualFixtures.length > 0 ? [...manualFixtures] : [...fixtures];
    base.push({
      id: `manual-${Date.now()}`,
      playerAIndex: customAIdx,
      playerBIndex: customBIdx,
      roundNumber: base.length + 1,
      group: customGroup === 'none' ? undefined : customGroup,
      bracketSide: 'manual',
    });
    onUpdateManualFixtures(base);
  };

  const handleDeleteManualFixture = (matchId: string) => {
    if (!onUpdateManualFixtures) return;
    const base = (manualFixtures.length > 0 ? [...manualFixtures] : [...fixtures]).filter(
      (f) => f.id !== matchId
    );
    onUpdateManualFixtures(base);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white dark:bg-[#141414] theme-card rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight">
                Match Fixtures &amp; Results
              </h2>
              <span className="text-xs text-[#64748B] dark:text-[#A0A0A0] font-bold">
                ({completedCount} / {totalCount})
              </span>
            </div>
            <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-1">
              Format:{' '}
              <strong className="text-[#172B4D] dark:text-[#FFD700]">
                {getFormatLabel(matchFormat)}
              </strong>{' '}
              &middot; <strong className="text-[#D4AF37]">{targetPoints} Pts / Game</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onUpdateCustomRules && (
              <div
                className="flex items-center gap-1.5 px-2.5 py-1 bg-[#F4F7FB] dark:bg-[#080808] rounded-xl border border-slate-200 dark:border-white/15 text-xs"
                title="Adjust points target (11–21)"
              >
                <span className="text-[11px] font-bold text-[#64748B] dark:text-[#A0A0A0]">
                  Pts:
                </span>
                <button
                  type="button"
                  onClick={() => handleAdjustPointsTarget(targetPoints - 1)}
                  disabled={targetPoints <= 11}
                  className="w-5 h-5 rounded bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="font-mono font-black text-[#172B4D] dark:text-[#FFD700] w-5 text-center">
                  {targetPoints}
                </span>
                <button
                  type="button"
                  onClick={() => handleAdjustPointsTarget(targetPoints + 1)}
                  disabled={targetPoints >= 21}
                  className="w-5 h-5 rounded bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 flex items-center justify-center disabled:opacity-30 cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            )}

            {setMatchFormat && (
              <div className="flex items-center gap-1 p-1 bg-[#F4F7FB] dark:bg-[#080808] rounded-xl border border-slate-200 dark:border-white/15">
                {(['bo1', 'bo3', 'bo5'] as MatchFormat[]).map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setMatchFormat(fmt)}
                    className={`px-2.5 py-1 text-[11px] font-extrabold rounded-lg uppercase cursor-pointer ${
                      matchFormat === fmt
                        ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                        : 'text-[#64748B] dark:text-[#A0A0A0]'
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            )}

            {onUpdateManualFixtures && (
              <button
                type="button"
                onClick={() => setShowFixtureEditor((p) => !p)}
                className="px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white hover:border-[#D4AF37] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>{showFixtureEditor ? 'Close Editor' : 'Edit Fixtures'}</span>
              </button>
            )}

            {onAutoSchedulePending && completedCount < totalCount && (
              <button
                type="button"
                onClick={onAutoSchedulePending}
                className="px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/35 text-[#9A7B1C] dark:text-[#FFD700] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Auto-Schedule</span>
              </button>
            )}

            {tournamentFormat === 'swiss' && onGenerateNextSwissRound && (
              <button
                type="button"
                onClick={onGenerateNextSwissRound}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Next Swiss Round</span>
              </button>
            )}

            {completedCount < totalCount && (
              <button
                onClick={onSimulateAll}
                className="px-3.5 py-2 rounded-xl bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] border border-[#D4AF37]/35 text-xs font-extrabold transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Simulate Remaining</span>
              </button>
            )}
          </div>
        </div>

        {showFixtureEditor && onUpdateManualFixtures && (
          <div className="mt-4 p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/35 space-y-3 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="font-black text-[#172033] dark:text-[#FFD700]">
                  Manual Fixture Editor
                </div>
                <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  Add custom pairings or remove matches. {manualFixtures.length > 0 ? 'Using custom fixture list.' : 'Auto-generated schedule active.'}
                </p>
              </div>
              {manualFixtures.length > 0 && (
                <button
                  type="button"
                  onClick={() => onUpdateManualFixtures([])}
                  className="px-3 py-1.5 rounded-xl bg-[#EF4444]/15 text-[#EF4444] font-bold cursor-pointer"
                >
                  Restore Auto-Generated
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <select
                value={customAIdx}
                onChange={(e) => setCustomAIdx(Number(e.target.value))}
                className="px-2.5 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
              >
                {players.map((p, i) => (
                  <option key={i} value={i}>
                    {p}
                  </option>
                ))}
              </select>
              <select
                value={customBIdx}
                onChange={(e) => setCustomBIdx(Number(e.target.value))}
                className="px-2.5 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
              >
                {players.map((p, i) => (
                  <option key={i} value={i}>
                    {p}
                  </option>
                ))}
              </select>
              <select
                value={customGroup}
                onChange={(e) => setCustomGroup(e.target.value as 'none' | 'A' | 'B')}
                className="px-2.5 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
              >
                <option value="none">No Group</option>
                <option value="A">Group A</option>
                <option value="B">Group B</option>
              </select>
              <button
                type="button"
                disabled={customAIdx === customBIdx}
                onClick={handleAddManualFixture}
                className="px-3 py-2 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] disabled:opacity-35 text-white dark:text-[#080808] font-black cursor-pointer"
              >
                + Add Custom Match
              </button>
            </div>
          </div>
        )}

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-[#A0A0A0] mb-1.5">
            <span>Stage Completion</span>
            <span className="font-black tabular-nums text-[#172033] dark:text-[#FFD700]">
              {progressPercent}%
            </span>
          </div>
          <div className="w-full h-2.5 bg-[#F4F7FB] dark:bg-[#080808] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#D4AF37] to-[#FFD700] transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Filters */}
        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-white/10 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-[#F4F7FB] dark:bg-[#080808] rounded-xl border border-slate-200 dark:border-white/10">
              {(['all', 'pending', 'completed'] as const).map((fm) => (
                <button
                  key={fm}
                  onClick={() => setFilterMode(fm)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg capitalize cursor-pointer ${
                    filterMode === fm
                      ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  {fm}
                </button>
              ))}
            </div>

            {hasGroups && (
              <div className="flex items-center gap-1 p-1 bg-[#F4F7FB] dark:bg-[#080808] rounded-xl border border-slate-200 dark:border-white/10">
                {(['all', 'A', 'B'] as const).map((g) => (
                  <button
                    key={g}
                    onClick={() => setGroupFilter(g)}
                    className={`px-2.5 py-1.5 text-xs font-bold rounded-lg cursor-pointer ${
                      groupFilter === g
                        ? 'bg-[#D4AF37] text-[#080808]'
                        : 'text-[#64748B] dark:text-[#A0A0A0]'
                    }`}
                  >
                    {g === 'all' ? 'All Groups' : `Group ${g}`}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-[#64748B] dark:text-[#A0A0A0] flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              <span>Player:</span>
            </span>
            <select
              value={selectedPlayerFilter}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedPlayerFilter(val === 'all' ? 'all' : parseInt(val, 10));
              }}
              className="text-xs bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white border border-slate-200 dark:border-white/15 rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="all">All Players</option>
              {players.map((p, i) => (
                <option key={i} value={i}>
                  {p}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Match Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredMatches.length === 0 ? (
          <div className="col-span-full py-12 text-center bg-white dark:bg-[#141414] rounded-3xl border border-slate-200 dark:border-white/10">
            <div className="text-sm font-bold text-[#64748B] dark:text-[#A0A0A0]">
              No matches found matching the selected filter.
            </div>
          </div>
        ) : (
          filteredMatches.map((match, idx) => {
            const playerA = players[match.playerAIndex] || `Player ${match.playerAIndex + 1}`;
            const isByeMatch = Boolean(match.isBye || match.playerBIndex < 0);

            if (isByeMatch) {
              return (
                <div
                  key={match.id}
                  className="bg-white dark:bg-[#141414] rounded-3xl p-4 sm:p-5 border border-[#D4AF37]/30 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider">
                      Match {match.roundNumber || idx + 1} · BYE Allocation
                    </div>
                    <div className="text-sm font-black text-[#172033] dark:text-white mt-1">
                      {playerA}
                    </div>
                    <div className="text-[11px] text-[#22C55E] font-bold mt-0.5">
                      Auto-advances cleanly due to bracket BYE
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-[#D4AF37]/15 text-[#FFD700] border border-[#D4AF37]/40 text-xs font-black">
                    BYE
                  </span>
                </div>
              );
            }

            const playerB = players[match.playerBIndex] || `Player ${match.playerBIndex + 1}`;
            const colorA = getPlayerColor(match.playerAIndex);
            const colorB = getPlayerColor(match.playerBIndex);
            const photoA = playerPhotos?.[match.playerAIndex];
            const photoB = playerPhotos?.[match.playerBIndex];
            const winner = results[match.id];
            const isCompleted = winner !== undefined;
            const formattedScoreStr = formatScore(scores[match.id]);
            const isExpanded = expandedScoreMatchId === match.id;
            const effectiveFormat: MatchFormat = matchFormats[match.id] || matchFormat;
            const meta = matchMeta[match.id];

            return (
              <div
                key={match.id}
                className={`bg-white dark:bg-[#141414] theme-card rounded-3xl p-4 sm:p-5 border transition-all ${
                  isCompleted
                    ? 'border-[#22C55E]/40'
                    : 'border-slate-200 dark:border-white/10 shadow-sm'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#64748B] dark:text-[#A0A0A0] mb-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold tracking-wide">
                      MATCH {match.roundNumber || idx + 1}
                    </span>
                    {match.group && (
                      <span className="px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] font-bold text-[10px]">
                        Group {match.group}
                      </span>
                    )}
                    {meta?.resultType && meta.resultType !== 'normal' && (
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-600 dark:text-[#FFD700] font-black uppercase text-[10px]">
                        {meta.resultType}
                      </span>
                    )}
                    {meta?.status === 'postponed' && (
                      <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-500 font-black uppercase text-[10px]">
                        Postponed{meta.rescheduledTo ? ` · ${meta.rescheduledTo}` : ''}
                      </span>
                    )}
                    {meta?.verifiedBy && (
                      <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-500 font-black text-[10px]">
                        Verified · {meta.verifiedBy}
                      </span>
                    )}
                    {matchSchedules[match.id]?.courtNumber && (
                      <span className="text-[11px] font-bold text-[#172033] dark:text-[#FFD700]">
                        · Court {matchSchedules[match.id]?.courtNumber}
                      </span>
                    )}
                    {matchSchedules[match.id]?.time && (
                      <span className="text-[11px] font-mono text-[#D4AF37]">
                        · {matchSchedules[match.id]?.time}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {showFixtureEditor && onUpdateManualFixtures && !isCompleted && (
                      <button
                        type="button"
                        onClick={() => handleDeleteManualFixture(match.id)}
                        className="p-1 rounded-lg text-[#EF4444] hover:bg-[#EF4444]/10 cursor-pointer"
                        title="Remove match from fixture list"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {onUpdateMatchSchedule && (
                      <button
                        type="button"
                        onClick={() =>
                          setEditingScheduleId(editingScheduleId === match.id ? null : match.id)
                        }
                        className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 text-[#64748B] dark:text-[#A0A0A0] hover:text-[#D4AF37] cursor-pointer"
                        title="Schedule Court, Time & Referee"
                      >
                        <Clock className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {onSetMatchItemFormat ? (
                      <div
                        className="inline-flex items-center gap-0.5 p-0.5 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10"
                        title="Select Best of 1, 3, or 5 sets for this match"
                      >
                        {(['bo1', 'bo3', 'bo5'] as MatchFormat[]).map((fmt) => (
                          <button
                            key={fmt}
                            type="button"
                            onClick={() => onSetMatchItemFormat(match.id, fmt)}
                            className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase cursor-pointer transition-colors ${
                              effectiveFormat === fmt
                                ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                                : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white'
                            }`}
                          >
                            {fmt}
                          </button>
                        ))}
                      </div>
                    ) : (
                      <span className="px-1.5 py-0.5 rounded bg-[#F4F7FB] dark:bg-[#080808] text-[10px] font-black uppercase text-[#D4AF37]">
                        {effectiveFormat}
                      </span>
                    )}

                    {isCompleted ? (
                      <span className="flex items-center gap-1 text-[#22C55E] font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Done</span>
                      </span>
                    ) : (
                      <span>Upcoming</span>
                    )}
                  </div>
                </div>

                {editingScheduleId === match.id && onUpdateMatchSchedule && (
                  <div className="mb-3 p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    <div>
                      <label className="text-[10px] font-bold text-[#64748B] block mb-0.5">
                        Court
                      </label>
                      <select
                        value={matchSchedules[match.id]?.courtNumber || ''}
                        onChange={(e) =>
                          onUpdateMatchSchedule(match.id, {
                            ...(matchSchedules[match.id] || {}),
                            courtNumber: e.target.value ? Number(e.target.value) : undefined,
                          })
                        }
                        className="w-full px-2 py-1 rounded-lg bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white"
                      >
                        <option value="">Any Court</option>
                        <option value="1">Court 1</option>
                        <option value="2">Court 2</option>
                        <option value="3">Court 3</option>
                        <option value="4">Court 4</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-[#64748B] block mb-0.5">
                        Time Slot
                      </label>
                      <input
                        type="text"
                        value={matchSchedules[match.id]?.time || ''}
                        onChange={(e) =>
                          onUpdateMatchSchedule(match.id, {
                            ...(matchSchedules[match.id] || {}),
                            time: e.target.value,
                          })
                        }
                        placeholder="e.g. 5:30 PM"
                        className="w-full px-2 py-1 rounded-lg bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-[#64748B] block mb-0.5">
                        Referee
                      </label>
                      <select
                        value={matchSchedules[match.id]?.referee || ''}
                        onChange={(e) =>
                          onUpdateMatchSchedule(match.id, {
                            ...(matchSchedules[match.id] || {}),
                            referee: e.target.value || undefined,
                          })
                        }
                        className="w-full px-2 py-1 rounded-lg bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-bold text-[#172033] dark:text-white"
                      >
                        <option value="">Unassigned</option>
                        {referees.map((r) => (
                          <option key={r} value={r}>
                            {r}
                          </option>
                        ))}
                      </select>
                    </div>
                    {onUpdateMatchMeta && !isCompleted && (
                      <div className="sm:col-span-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 dark:border-white/10">
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateMatchMeta(match.id, (prev) => ({
                              ...prev,
                              status: prev.status === 'postponed' ? 'scheduled' : 'postponed',
                              postponedReason:
                                prev.status === 'postponed' ? undefined : 'Schedule adjustment',
                            }))
                          }
                          className={`px-3 py-1 rounded-lg font-extrabold text-[11px] cursor-pointer ${
                            meta?.status === 'postponed'
                              ? 'bg-emerald-500/15 text-emerald-500'
                              : 'bg-rose-500/15 text-rose-500'
                          }`}
                        >
                          {meta?.status === 'postponed' ? 'Resume Match' : 'Mark Postponed'}
                        </button>
                        {meta?.status === 'postponed' && (
                          <input
                            type="text"
                            value={meta.rescheduledTo || ''}
                            onChange={(e) =>
                              onUpdateMatchMeta(match.id, (prev) => ({
                                ...prev,
                                rescheduledTo: e.target.value,
                              }))
                            }
                            placeholder="Reschedule date/time..."
                            className="flex-1 min-w-[140px] px-2.5 py-1 rounded-lg bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white"
                          />
                        )}
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-2.5">
                  <div
                    className={`flex items-center justify-between p-2.5 rounded-2xl border ${
                      winner === match.playerAIndex
                        ? 'bg-[#22C55E]/15 border-[#22C55E]/40'
                        : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200/80 dark:border-white/10'
                    }`}
                  >
                    <div
                      onClick={() => onOpenPlayerProfile(match.playerAIndex)}
                      className="flex items-center gap-2.5 cursor-pointer group min-w-0"
                    >
                      {photoA ? (
                        <img
                          src={photoA}
                          alt={playerA}
                          className="w-8 h-8 rounded-xl object-cover shrink-0"
                        />
                      ) : (
                        <div
                          className="w-8 h-8 rounded-xl flex items-center justify-center text-[#080808] font-black text-xs shrink-0"
                          style={{ backgroundColor: colorA }}
                        >
                          {getInitials(playerA)}
                        </div>
                      )}
                      <span className="font-bold text-sm text-[#172033] dark:text-white group-hover:text-[#FFD700] transition-colors truncate">
                        {playerA}
                      </span>
                    </div>

                    {winner === match.playerAIndex && (
                      <div className="flex items-center gap-1.5 shrink-0">
                        {matchMvps[match.id] === match.playerAIndex && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-600 dark:text-[#FFD700] border border-amber-400/40 text-[10px] font-black uppercase tracking-wide">
                            <Award className="w-3 h-3" />
                            <span>Match MVP</span>
                          </span>
                        )}
                        <span className="text-xs font-extrabold text-[#22C55E] flex items-center gap-1">
                          <Trophy className="w-3.5 h-3.5" />
                          <span>Winner</span>
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="text-center text-[10px] font-black text-[#D4AF37] tracking-widest">
                    VS
                  </div>

                  <div
                    className={`flex items-center justify-between p-2.5 rounded-2xl border ${
                      winner === match.playerBIndex
                        ? 'bg-[#22C55E]/15 border-[#22C55E]/40'
                        : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200/80 dark:border-white/10'
                    }`}
                  >
                    <div
                      onClick={() => onOpenPlayerProfile(match.playerBIndex)}
                      className="flex items-center gap-2.5 cursor-pointer group min-w-0"
                    >
                      {photoB ? (
                        <img
                          src={photoB}
                          alt={playerB}
                          className="w-8 h-8 rounded-xl object-cover shrink-0"
                        />
                      ) : (
                        <div
                          className="w-8 h-8 rounded-xl flex items-center justify-center text-[#080808] font-black text-xs shrink-0"
                          style={{ backgroundColor: colorB }}
                        >
                          {getInitials(playerB)}
                        </div>
                      )}
                      <span className="font-bold text-sm text-[#172033] dark:text-white group-hover:text-[#FFD700] transition-colors truncate">
                        {playerB}
                      </span>
                    </div>

                    {winner === match.playerBIndex && (
                      <div className="flex items-center gap-1.5 shrink-0">
                        {matchMvps[match.id] === match.playerBIndex && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-600 dark:text-[#FFD700] border border-amber-400/40 text-[10px] font-black uppercase tracking-wide">
                            <Award className="w-3 h-3" />
                            <span>Match MVP</span>
                          </span>
                        )}
                        <span className="text-xs font-extrabold text-[#22C55E] flex items-center gap-1">
                          <Trophy className="w-3.5 h-3.5" />
                          <span>Winner</span>
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {formattedScoreStr && (
                  <div className="mt-2.5 text-center text-xs text-[#64748B] dark:text-[#A0A0A0] font-mono">
                    Games: <strong className="text-[#172033] dark:text-white">{formattedScoreStr}</strong>
                    {meta?.incidents && meta.incidents.length > 0 && (
                      <span className="ml-2 text-[10px] text-[#D4AF37]">
                        · {meta.incidents.length} Official Event{meta.incidents.length > 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                )}

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-white/10">
                  {!isCompleted ? (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() =>
                            onSetResult(
                              match.id,
                              match.playerAIndex,
                              generateDefaultQuickScore(
                                match.playerAIndex,
                                match.playerAIndex,
                                match.playerBIndex,
                                effectiveFormat,
                                targetPoints
                              )
                            )
                          }
                          className="py-2 px-3 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-xs font-extrabold rounded-xl truncate cursor-pointer"
                        >
                          {playerA} Wins
                        </button>
                        <button
                          onClick={() =>
                            onSetResult(
                              match.id,
                              match.playerBIndex,
                              generateDefaultQuickScore(
                                match.playerBIndex,
                                match.playerAIndex,
                                match.playerBIndex,
                                effectiveFormat,
                                targetPoints
                              )
                            )
                          }
                          className="py-2 px-3 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-xs font-extrabold rounded-xl truncate cursor-pointer"
                        >
                          {playerB} Wins
                        </button>
                      </div>

                      {onLaunchLiveScorer && (
                        <button
                          type="button"
                          onClick={() => onLaunchLiveScorer(match.id)}
                          className="w-full py-2 px-3 bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-[#9A7B1C] dark:text-[#FFD700] border border-[#D4AF37]/35 text-xs font-extrabold rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <span>🏸 Umpire Live Scoreboard</span>
                        </button>
                      )}

                      <button
                        onClick={() => setExpandedScoreMatchId(isExpanded ? null : match.id)}
                        className="w-full text-center py-1 text-[11px] text-[#64748B] dark:text-[#A0A0A0] hover:text-[#FFD700] flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <span>{isExpanded ? 'Hide Score Form' : 'Enter Set Scores Manually'}</span>
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>

                      {isExpanded && (
                        <div className="p-3 bg-[#F4F7FB] dark:bg-[#080808] rounded-2xl border border-slate-200 dark:border-white/10 space-y-2.5 text-xs">
                          <div
                            className={`grid gap-2 text-center ${
                              effectiveFormat === 'bo1'
                                ? 'grid-cols-1 max-w-[160px] mx-auto'
                                : effectiveFormat === 'bo2'
                                ? 'grid-cols-2'
                                : 'grid-cols-3'
                            }`}
                          >
                            <div>
                              <span className="text-[10px] text-[#A0A0A0] block mb-1">Game 1</span>
                              <div className="flex items-center gap-1 justify-center">
                                <input
                                  type="number"
                                  defaultValue={String(targetPoints)}
                                  className="w-10 px-1 py-1 text-center bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 rounded-lg text-xs"
                                  onChange={(e) => handleScoreChange(match.id, 's1a', e.target.value)}
                                />
                                <span>-</span>
                                <input
                                  type="number"
                                  defaultValue={String(defaultLoseScore)}
                                  className="w-10 px-1 py-1 text-center bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 rounded-lg text-xs"
                                  onChange={(e) => handleScoreChange(match.id, 's1b', e.target.value)}
                                />
                              </div>
                            </div>

                            {effectiveFormat !== 'bo1' && (
                              <div>
                                <span className="text-[10px] text-[#A0A0A0] block mb-1">Game 2</span>
                                <div className="flex items-center gap-1 justify-center">
                                  <input
                                    type="number"
                                    defaultValue={String(targetPoints)}
                                    className="w-10 px-1 py-1 text-center bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 rounded-lg text-xs"
                                    onChange={(e) => handleScoreChange(match.id, 's2a', e.target.value)}
                                  />
                                  <span>-</span>
                                  <input
                                    type="number"
                                    defaultValue={String(defaultLoseScore)}
                                    className="w-10 px-1 py-1 text-center bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 rounded-lg text-xs"
                                    onChange={(e) => handleScoreChange(match.id, 's2b', e.target.value)}
                                  />
                                </div>
                              </div>
                            )}

                            {effectiveFormat !== 'bo1' && effectiveFormat !== 'bo2' && (
                              <div>
                                <span className="text-[10px] text-[#A0A0A0] block mb-1">Game 3</span>
                                <div className="flex items-center gap-1 justify-center">
                                  <input
                                    type="number"
                                    defaultValue={effectiveFormat === 'bo5' ? String(targetPoints) : ''}
                                    placeholder="—"
                                    className="w-10 px-1 py-1 text-center bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 rounded-lg text-xs"
                                    onChange={(e) => handleScoreChange(match.id, 's3a', e.target.value)}
                                  />
                                  <span>-</span>
                                  <input
                                    type="number"
                                    defaultValue={effectiveFormat === 'bo5' ? String(defaultLoseScore) : ''}
                                    placeholder="—"
                                    className="w-10 px-1 py-1 text-center bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 rounded-lg text-xs"
                                    onChange={(e) => handleScoreChange(match.id, 's3b', e.target.value)}
                                  />
                                </div>
                              </div>
                            )}
                          </div>

                          <button
                            onClick={() => handleSaveDetailedScore(match, effectiveFormat)}
                            className="w-full py-2 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-extrabold rounded-xl text-xs cursor-pointer"
                          >
                            Save Score &amp; Confirm Winner
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
                        Winner: <strong className="text-[#22C55E]">{players[winner]}</strong>
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            downloadMatchResultPoster({
                              tournamentTitle,
                              stageLabel: `Match #${match.roundNumber || idx + 1}`,
                              playerA,
                              playerB,
                              winnerName: players[winner] || playerA,
                              scoreSummary: formattedScoreStr || 'Victory',
                              isMvp: matchMvps[match.id] === winner,
                            })
                          }
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-white/15 text-[#D4AF37] hover:border-[#FFD700] cursor-pointer"
                          title="Download Black+Gold Match Result Poster PNG"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                        </button>
                        {onToggleMatchMvp && (
                          <button
                            type="button"
                            onClick={() =>
                              onToggleMatchMvp(
                                match.id,
                                matchMvps[match.id] === winner ? null : winner
                              )
                            }
                            className={`px-2.5 py-1.5 rounded-lg border text-xs font-extrabold flex items-center gap-1 cursor-pointer transition-colors ${
                              matchMvps[match.id] === winner
                                ? 'bg-amber-400/20 border-amber-400/50 text-amber-600 dark:text-[#FFD700]'
                                : 'border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0] hover:border-amber-400/60 hover:text-amber-500 dark:hover:text-[#FFD700]'
                            }`}
                          >
                            <Award className="w-3.5 h-3.5" />
                            <span>
                              {matchMvps[match.id] === winner ? 'Match MVP' : 'Designate MVP'}
                            </span>
                          </button>
                        )}
                        <button
                          onClick={() => onUndoResult(match.id)}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Undo</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
