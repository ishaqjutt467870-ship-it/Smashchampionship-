import React, { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  Flame,
  Zap,
  Target,
  Award,
  Play,
  FileText,
  Activity,
} from 'lucide-react';
import { MatchMetaInfo, MatchScore, PlayerStats, TournamentMatch } from '../types';
import { computeSmartMatchAnalytics } from '../utils/reports';

interface DashboardAnalyticsProps {
  players: string[];
  standings: PlayerStats[];
  fixtures: TournamentMatch[];
  results: Record<string, number>;
  scores: Record<string, MatchScore>;
  matchMeta?: Record<string, MatchMetaInfo>;
  isDark?: boolean;
  onStartMatch?: () => void;
  onOpenReportModal?: () => void;
}

export const DashboardAnalytics: React.FC<DashboardAnalyticsProps> = ({
  players,
  standings,
  fixtures,
  results,
  scores,
  matchMeta,
  isDark = true,
  onStartMatch,
  onOpenReportModal,
}) => {
  const [chartView, setChartView] = useState<'both' | 'wins' | 'trends'>('both');

  const insights = useMemo(
    () => computeSmartMatchAnalytics(players, fixtures, results, scores, standings, matchMeta),
    [players, fixtures, results, scores, standings, matchMeta]
  );

  const playerBarData = useMemo(() => {
    return standings.map((p) => {
      const shortName = p.name.length > 12 ? `${p.name.slice(0, 11)}…` : p.name;
      return {
        name: shortName,
        fullName: p.name,
        won: p.won,
        lost: p.lost,
        winRate: p.played > 0 ? Math.round((p.won / p.played) * 100) : 0,
        points: p.points,
      };
    });
  }, [standings]);

  const axisTickColor = isDark ? '#A0A0A0' : '#64748B';
  const gridStroke = isDark ? 'rgba(212, 175, 55, 0.14)' : 'rgba(15, 23, 42, 0.08)';
  const tooltipStyle = {
    backgroundColor: isDark ? '#080808' : '#FFFFFF',
    border: isDark ? '1px solid rgba(212, 175, 55, 0.45)' : '1px solid #E2E8F0',
    borderRadius: '14px',
    color: isDark ? '#FFFFFF' : '#172033',
    fontSize: '12px',
    boxShadow: '0 12px 32px rgba(0,0,0,0.35)',
  };

  return (
    <section
      aria-label="Tournament Analytics"
      className="theme-card rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-[#D4AF37]/25 bg-white dark:bg-[#141414] shadow-sm space-y-6"
    >
      {/* Section Header + Segmented View Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#172B4D] dark:bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#FFD700]">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black text-[#172033] dark:text-white tracking-tight">
              Smart Match Analytics
            </h2>
            <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] tabular-nums">
              {insights.completedCount} completed matches · {insights.totalPointsPlayed} rally points contested
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
            {(
              [
                { id: 'both', label: 'All Charts' },
                { id: 'wins', label: 'Wins Bar' },
                { id: 'trends', label: 'Scoring Trend' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setChartView(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-colors whitespace-nowrap cursor-pointer ${
                  chartView === tab.id
                    ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-sm'
                    : 'text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {onOpenReportModal && (
            <button
              type="button"
              onClick={onOpenReportModal}
              className="px-3.5 py-2 rounded-xl bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 border border-[#D4AF37]/40 text-[#9A7B1C] dark:text-[#FFD700] text-xs font-extrabold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Auto Report</span>
            </button>
          )}
        </div>
      </div>

      {/* Smart Match Analytics KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-[#D4AF37]/20">
          <div className="flex items-center justify-between text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]">
            <span>Avg Rally Pace</span>
            <Zap className="w-4 h-4 text-[#FFD700]" />
          </div>
          <div className="text-2xl font-black text-[#172033] dark:text-white font-mono tabular-nums mt-1.5">
            {insights.avgPointsPerMatch} pts
          </div>
          <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5">
            Per scored fixture
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-[#D4AF37]/20">
          <div className="flex items-center justify-between text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]">
            <span>Straight-Set Rate</span>
            <Target className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="text-2xl font-black text-[#9A7B1C] dark:text-[#FFD700] font-mono tabular-nums mt-1.5">
            {insights.straightSetRate}%
          </div>
          <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5 tabular-nums">
            {insights.straightSetWins} sweeps · {insights.deciderMatches} deciders
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-[#D4AF37]/20">
          <div className="flex items-center justify-between text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]">
            <span>Closest Thriller</span>
            <Flame className="w-4 h-4 text-[#FFD700]" />
          </div>
          {insights.closestMatch ? (
            <>
              <div className="text-sm font-black text-[#172033] dark:text-white truncate mt-1.5">
                {insights.closestMatch.label}
              </div>
              <div className="text-[11px] font-mono text-[#9A7B1C] dark:text-[#D4AF37] mt-0.5 truncate">
                {insights.closestMatch.scoreText} · Δ{insights.closestMatch.margin} pts
              </div>
            </>
          ) : (
            <div className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-2">
              Awaiting scored match
            </div>
          )}
        </div>

        <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-[#D4AF37]/20">
          <div className="flex items-center justify-between text-xs font-bold text-[#64748B] dark:text-[#A0A0A0]">
            <span>Upsets &amp; Comebacks</span>
            <Award className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="text-2xl font-black text-[#172033] dark:text-[#FFD700] font-mono tabular-nums mt-1.5">
            {insights.upsetCount}
          </div>
          <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] mt-0.5 truncate">
            {insights.comebackMatch
              ? `Comeback: ${insights.comebackMatch.label}`
              : 'Seed upsets tracked live'}
          </div>
        </div>
      </div>

      {/* Real Rally & Officiating Telemetry (Strictly from Live Scorer records) */}
      {(insights.hasRallyTelemetry ||
        insights.totalServiceFaults > 0 ||
        insights.totalLets > 0 ||
        insights.totalMedicalTimeouts > 0) && (
        <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/30 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 font-black text-[#9A7B1C] dark:text-[#FFD700]">
            <Activity className="w-4 h-4" />
            <span>Verified Live Court Telemetry ({insights.totalRalliesLogged} rallies)</span>
          </div>
          <div className="flex flex-wrap items-center gap-3 font-mono text-[11px]">
            <span>
              Avg Rally: <strong className="text-[#FFD700]">{insights.avgRallyDurationSec}s</strong>
            </span>
            <span>
              Server Win: <strong className="text-emerald-500">{insights.serviceWinRatePct}%</strong>
            </span>
            <span>
              Lead Changes: <strong className="text-[#D4AF37]">{insights.momentumSwings}</strong>
            </span>
            <span>
              Faults: <strong>{insights.totalServiceFaults}</strong> · Lets: <strong>{insights.totalLets}</strong>
            </span>
          </div>
        </div>
      )}

      {/* Recharts Visualizations or Empty State */}
      {insights.completedCount === 0 ? (
        <div className="rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-dashed border-slate-300 dark:border-[#D4AF37]/30 p-8 text-center space-y-3">
          <TrendingUp className="w-8 h-8 mx-auto text-[#D4AF37]" />
          <div className="space-y-1">
            <h3 className="text-sm font-black text-[#172033] dark:text-white">
              Tournament Analytics Ready
            </h3>
            <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] max-w-md mx-auto">
              Complete your first fixture to populate the player wins bar chart and point-scoring progression curves.
            </p>
          </div>
          {onStartMatch && (
            <button
              type="button"
              onClick={onStartMatch}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-xs font-extrabold cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Score First Match</span>
            </button>
          )}
        </div>
      ) : (
        <div
          className={`grid gap-5 ${
            chartView === 'both' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'
          }`}
        >
          {/* Chart 1: Matches Won vs Lost Bar Chart */}
          {(chartView === 'both' || chartView === 'wins') && (
            <div className="rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-[#D4AF37]/20 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-[#172033] dark:text-white">
                    Matches Won &amp; Lost per Player
                  </h3>
                  <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Real-time league record sorted by ranking
                  </p>
                </div>
                <span className="text-[11px] font-mono font-bold text-[#D4AF37] tabular-nums">
                  {standings.length} Players
                </span>
              </div>

              <div className="w-full h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={playerBarData}
                    margin={{ top: 8, right: 12, left: -16, bottom: 8 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} vertical={false} />
                    <XAxis
                      dataKey="name"
                      tick={{ fill: axisTickColor, fontSize: 11, fontWeight: 600 }}
                      axisLine={{ stroke: gridStroke }}
                      tickLine={false}
                      interval={0}
                      angle={playerBarData.length > 6 ? -20 : 0}
                      textAnchor={playerBarData.length > 6 ? 'end' : 'middle'}
                      height={playerBarData.length > 6 ? 48 : 30}
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fill: axisTickColor, fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={tooltipStyle}
                      cursor={{
                        fill: isDark ? 'rgba(212, 175, 55, 0.08)' : 'rgba(15, 23, 42, 0.04)',
                      }}
                      labelFormatter={(_, payload) => payload?.[0]?.payload?.fullName || ''}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                    <Bar
                      dataKey="won"
                      name="Matches Won"
                      fill="#FFD700"
                      radius={[6, 6, 0, 0]}
                      maxBarSize={36}
                    />
                    <Bar
                      dataKey="lost"
                      name="Matches Lost"
                      fill="#52525B"
                      radius={[6, 6, 0, 0]}
                      maxBarSize={36}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Chart 2: Point-Scoring Trends Throughout the Tournament */}
          {(chartView === 'both' || chartView === 'trends') && (
            <div className="rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-[#D4AF37]/20 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-[#172033] dark:text-white">
                    Point-Scoring Progression Trend
                  </h3>
                  <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Winner vs. opponent points &amp; tournament rally average
                  </p>
                </div>
                <span className="text-[11px] font-mono font-bold text-[#FFD700] tabular-nums">
                  {insights.progressionData.length} Matches
                </span>
              </div>

              <div className="w-full h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={insights.progressionData}
                    margin={{ top: 8, right: 12, left: -12, bottom: 8 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} vertical={false} />
                    <XAxis
                      dataKey="matchLabel"
                      tick={{ fill: axisTickColor, fontSize: 11, fontWeight: 600 }}
                      axisLine={{ stroke: gridStroke }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: axisTickColor, fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={tooltipStyle}
                      labelFormatter={(_, payload) => payload?.[0]?.payload?.matchTitle || ''}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                    <Line
                      type="monotone"
                      dataKey="totalPts"
                      name="Total Match Pts"
                      stroke="#FFD700"
                      strokeWidth={3}
                      dot={{ r: 4, fill: '#FFD700', strokeWidth: 0 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="winnerPts"
                      name="Winner Pts"
                      stroke="#22C55E"
                      strokeWidth={2.2}
                      dot={{ r: 3, fill: '#22C55E', strokeWidth: 0 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="loserPts"
                      name="Opponent Pts"
                      stroke="#A0A0A0"
                      strokeWidth={2}
                      strokeDasharray="4 4"
                      dot={{ r: 2.5, fill: '#A0A0A0', strokeWidth: 0 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
};
