import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Camera,
  User,
  Zap,
  Award,
  Download,
  Trophy,
  Phone,
  Star,
  QrCode,
  Building2,
  ShieldCheck,
  FileBadge,
} from 'lucide-react';
import QRCode from 'qrcode';
import {
  PlayerStats,
  TournamentMatch,
  MatchScore,
  PlayerBio,
  TournamentState,
  RankingConfig,
  CompetitionCategory,
} from '../types';
import {
  getPlayerColor,
  getPlayerCode,
  getInitials,
  formatScore,
  calculateGlobalRankings,
  DEFAULT_RANKING_CONFIG,
} from '../utils/tournament';
import { downloadPlayerAchievementCard } from '../utils/exports';

interface PlayerProfileModalProps {
  player: PlayerStats | null;
  isOpen: boolean;
  onClose: () => void;
  fixtures: TournamentMatch[];
  results: Record<string, number>;
  scores: Record<string, MatchScore>;
  matchMvps?: Record<string, number>;
  allPlayers: string[];
  allTournaments?: TournamentState[];
  rankingConfig?: RankingConfig;
  tournamentCategory?: CompetitionCategory;
  rankPosition?: number;
  onUpdatePhoto: (playerId: number, photoDataUrl: string) => void;
  onRemovePhoto: (playerId: number) => void;
  onUpdateBio: (playerId: number, bio: PlayerBio) => void;
}

export const PlayerProfileModal: React.FC<PlayerProfileModalProps> = ({
  player,
  isOpen,
  onClose,
  fixtures,
  results,
  scores,
  matchMvps = {},
  allPlayers,
  allTournaments = [],
  rankingConfig = DEFAULT_RANKING_CONFIG,
  tournamentCategory = 'singles',
  rankPosition,
  onUpdatePhoto,
  onRemovePhoto,
  onUpdateBio,
}) => {
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [playStyle, setPlayStyle] = useState(player?.bio?.playStyle || 'All-Round Tactician');
  const [hand, setHand] = useState<'Right' | 'Left'>(player?.bio?.hand || 'Right');
  const [notes, setNotes] = useState(player?.bio?.notes || '');
  const [age, setAge] = useState(player?.bio?.age ? String(player.bio.age) : '');
  const [contact, setContact] = useState(player?.bio?.contact || '');
  const [club, setClub] = useState(player?.bio?.club || '');
  const [availability, setAvailability] = useState<NonNullable<PlayerBio['availability']>>(
    player?.bio?.availability || 'Available'
  );
  const [favourite, setFavourite] = useState<boolean>(Boolean(player?.bio?.favourite));
  const [preferredCategory, setPreferredCategory] = useState<CompetitionCategory>(
    player?.bio?.preferredCategory || tournamentCategory
  );
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    if (player) {
      setPlayStyle(player.bio?.playStyle || 'All-Round Tactician');
      setHand(player.bio?.hand || 'Right');
      setNotes(player.bio?.notes || '');
      setAge(player.bio?.age ? String(player.bio.age) : '');
      setContact(player.bio?.contact || '');
      setClub(player.bio?.club || '');
      setAvailability(player.bio?.availability || 'Available');
      setFavourite(Boolean(player.bio?.favourite));
      setPreferredCategory(player.bio?.preferredCategory || tournamentCategory);
      setIsEditingBio(false);

      const code = player.bio?.playerCode || getPlayerCode(player.id);
      const qrPayload = JSON.stringify({
        type: 'smash_player_id',
        code,
        name: player.name,
        club: player.bio?.club || 'Unattached',
        category: player.bio?.preferredCategory || tournamentCategory,
      });
      QRCode.toDataURL(qrPayload, {
        width: 160,
        margin: 1,
        color: { dark: '#FFD700', light: '#080808' },
      })
        .then(setQrDataUrl)
        .catch(() => setQrDataUrl(''));
    }
  }, [player?.id, player?.bio, player?.name, tournamentCategory]);

  if (!isOpen || !player) return null;

  const winRate = player.played > 0 ? Math.round((player.won / player.played) * 100) : 0;
  const pointDiff = player.pointsFor - player.pointsAgainst;
  const playerCode = player.bio?.playerCode || getPlayerCode(player.id);

  const playerMatches = fixtures.filter(
    (m) =>
      !m.isBye &&
      m.playerBIndex >= 0 &&
      (m.playerAIndex === player.id || m.playerBIndex === player.id)
  );
  const mvpAwardsCount = Object.values(matchMvps).filter((pid) => pid === player.id).length;

  // Global career entry if allTournaments provided
  const globalRankings =
    allTournaments.length > 0
      ? calculateGlobalRankings(allTournaments, rankingConfig, 'all')
      : [];
  const globalIdx = globalRankings.findIndex(
    (g) => g.playerName.toLowerCase() === player.name.trim().toLowerCase()
  );
  const globalEntry = globalIdx >= 0 ? globalRankings[globalIdx] : null;
  const resolvedRank = globalIdx >= 0 ? globalIdx + 1 : rankPosition || 1;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_DIM = 256;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > MAX_DIM) {
            height = Math.round((height * MAX_DIM) / width);
            width = MAX_DIM;
          }
        } else {
          if (height > MAX_DIM) {
            width = Math.round((width * MAX_DIM) / height);
            height = MAX_DIM;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          onUpdatePhoto(player.id, dataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const earnedBadges = useMemo(() => {
    const badges: string[] = [];
    const totalWins = globalEntry?.wins ?? player.won;
    const totalTitles = globalEntry?.titles ?? 0;
    const totalMvps = globalEntry?.mvpAwards ?? mvpAwardsCount;
    if (totalTitles > 0) badges.push(`${totalTitles}x Champion`);
    if (totalMvps > 0) badges.push(`${totalMvps}x Match MVP`);
    if (totalWins >= 10) badges.push('10+ Career Wins');
    else if (totalWins >= 5) badges.push('5+ Career Wins');
    if (winRate >= 75 && player.played >= 3) badges.push('Elite 75%+ Win Rate');
    if (globalEntry && globalEntry.bestWinStreak >= 3) {
      badges.push(`${globalEntry.bestWinStreak}-Match Streak`);
    }
    return badges;
  }, [globalEntry, player.won, player.played, winRate, mvpAwardsCount]);

  const handleToggleFavourite = () => {
    const nextFav = !favourite;
    setFavourite(nextFav);
    onUpdateBio(player.id, {
      ...(player.bio || {}),
      playStyle,
      hand,
      notes,
      playerCode,
      club: club.trim() || undefined,
      availability,
      favourite: nextFav,
      preferredCategory,
    });
  };

  const handleSaveBio = () => {
    const parsedAge = parseInt(age, 10);
    onUpdateBio(player.id, {
      ...(player.bio || {}),
      playStyle,
      hand,
      notes,
      playerCode,
      age: Number.isFinite(parsedAge) && parsedAge > 0 ? parsedAge : undefined,
      contact: contact.trim() || undefined,
      club: club.trim() || undefined,
      availability,
      favourite,
      preferredCategory,
    });
    setIsEditingBio(false);
  };

  const handleDownloadCard = () => {
    downloadPlayerAchievementCard({
      playerName: player.name,
      playerCode,
      rank: resolvedRank,
      ratingPoints: globalEntry?.ratingPoints ?? player.points * 50,
      wins: globalEntry?.wins ?? player.won,
      losses: globalEntry?.losses ?? player.lost,
      winRate: globalEntry?.winRate ?? winRate,
      titles: globalEntry?.titles ?? 0,
      mvpCount: globalEntry?.mvpAwards ?? mvpAwardsCount,
      category: preferredCategory,
    });
  };

  const handleDownloadCertificate = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1400;
    canvas.height = 950;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#080808';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#D4AF37';
    ctx.lineWidth = 10;
    ctx.strokeRect(32, 32, canvas.width - 64, canvas.height - 64);
    ctx.strokeStyle = '#FFD700';
    ctx.lineWidth = 2;
    ctx.strokeRect(52, 52, canvas.width - 104, canvas.height - 104);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#D4AF37';
    ctx.font = 'bold 26px sans-serif';
    ctx.fillText('HASSAN BADMINTON TOURNAMENT MANAGER · OFFICIAL CERTIFICATE', canvas.width / 2, 130);

    ctx.fillStyle = '#FFD700';
    ctx.font = 'bold 54px sans-serif';
    ctx.fillText('PLAYER CAREER CREDENTIAL', canvas.width / 2, 220);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 68px sans-serif';
    ctx.fillText(player.name, canvas.width / 2, 350);

    ctx.fillStyle = '#A0A0A0';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText(
      `ID: ${playerCode}  ·  Club: ${club.trim() || 'Independent'}  ·  Global Rank #${resolvedRank}`,
      canvas.width / 2,
      420
    );

    ctx.fillStyle = '#141414';
    ctx.fillRect(140, 490, 1120, 220);
    ctx.strokeStyle = '#D4AF37';
    ctx.strokeRect(140, 490, 1120, 220);

    const metrics = [
      ['MATCHES WON', `${globalEntry?.wins ?? player.won}`],
      ['WIN RATE', `${globalEntry?.winRate ?? winRate}%`],
      ['TITLES', `${globalEntry?.titles ?? 0}`],
      ['RANK POINTS', `${globalEntry?.ratingPoints ?? player.points * 50}`],
    ];
    metrics.forEach(([label, val], i) => {
      const cx = 280 + i * 280;
      ctx.fillStyle = '#FFD700';
      ctx.font = 'bold 52px monospace';
      ctx.fillText(val, cx, 595);
      ctx.fillStyle = '#A0A0A0';
      ctx.font = 'bold 20px sans-serif';
      ctx.fillText(label, cx, 650);
    });

    ctx.fillStyle = '#D4AF37';
    ctx.font = 'bold 24px sans-serif';
    ctx.fillText(
      `Issued ${new Date().toLocaleDateString()} · Smash Championship`,
      canvas.width / 2,
      835
    );

    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `${player.name.replace(/\s+/g, '_')}_Certificate.png`;
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080808]/85 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-[#141414] w-full max-w-xl rounded-3xl border border-slate-200 dark:border-[#D4AF37]/30 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Black + Gold Hero Header */}
        <div className="relative p-6 bg-gradient-to-r from-[#141414] to-[#080808] text-white border-b border-[#D4AF37]/25">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-[#A0A0A0] hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4">
            <div className="relative group">
              {player.photo ? (
                <img
                  src={player.photo}
                  alt={player.name}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-[#D4AF37] shadow-lg"
                />
              ) : (
                <div
                  className="w-20 h-20 rounded-2xl flex items-center justify-center text-[#080808] font-black text-2xl shadow-lg border-2 border-[#FFD700]/40"
                  style={{ backgroundColor: player.avatarColor }}
                >
                  {getInitials(player.name)}
                </div>
              )}

              <label className="absolute inset-0 bg-black/50 rounded-2xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-bold cursor-pointer transition-opacity">
                <Camera className="w-5 h-5 mb-0.5" />
                <span>Photo</span>
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-xl font-black tracking-tight">{player.name}</h3>
                <button
                  type="button"
                  onClick={handleToggleFavourite}
                  className={`p-1 rounded-lg border transition-colors cursor-pointer ${
                    favourite
                      ? 'bg-[#FFD700]/20 border-[#FFD700] text-[#FFD700]'
                      : 'bg-white/5 border-white/15 text-[#A0A0A0] hover:text-[#FFD700]'
                  }`}
                  title={favourite ? 'Remove Favourite Player' : 'Mark as Favourite Player'}
                >
                  <Star className={`w-3.5 h-3.5 ${favourite ? 'fill-current' : ''}`} />
                </button>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#D4AF37]/20 text-[#FFD700] border border-[#D4AF37]/40 font-mono font-bold">
                  {playerCode}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-white/10 text-white font-bold uppercase">
                  Rank #{resolvedRank}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/40 font-bold uppercase">
                  {availability}
                </span>
                {mvpAwardsCount > 0 && (
                  <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-amber-400/20 text-[#FFD700] border border-amber-400/40 font-black uppercase tracking-wider">
                    <Award className="w-3 h-3" />
                    <span>{mvpAwardsCount}x Match MVP</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-[#A0A0A0] mt-1 flex flex-wrap items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>{player.bio?.playStyle || 'All-Round Tactician'}</span>
                <span>·</span>
                <span>{player.bio?.hand || 'Right'}-Handed</span>
                {club && (
                  <>
                    <span>·</span>
                    <span className="text-[#FFD700] font-bold">{club}</span>
                  </>
                )}
                {player.bio?.age && (
                  <>
                    <span>·</span>
                    <span>Age {player.bio.age}</span>
                  </>
                )}
              </p>
              {player.bio?.contact && (
                <p className="text-[11px] text-[#A0A0A0] mt-0.5 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-[#D4AF37]" />
                  <span>{player.bio.contact}</span>
                </p>
              )}
              {player.photo && (
                <button
                  onClick={() => onRemovePhoto(player.id)}
                  className="text-[10px] text-[#EF4444] hover:underline mt-1 cursor-pointer"
                >
                  Remove custom photo
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1 text-xs">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-center">
              <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block">Win Rate</span>
              <span className="text-lg font-black text-[#172033] dark:text-white tabular-nums">
                {winRate}%
              </span>
              <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] block">
                {player.won}W - {player.lost}L
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-center">
              <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block">
                League Points
              </span>
              <span className="text-lg font-black text-[#9A7B1C] dark:text-[#FFD700] tabular-nums">
                {player.points}
              </span>
              <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] block">
                {globalEntry ? `${globalEntry.ratingPoints} Global Pts` : '2 pts / win'}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-center">
              <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block">Games W/L</span>
              <span className="text-lg font-black text-[#172033] dark:text-white tabular-nums">
                {player.setsWon}-{player.setsLost}
              </span>
              <span className="text-[10px] text-[#D4AF37] block font-mono">
                Diff:{' '}
                {player.setsWon - player.setsLost > 0
                  ? `+${player.setsWon - player.setsLost}`
                  : player.setsWon - player.setsLost}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-center">
              <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block">
                Point Diff
              </span>
              <span
                className={`text-lg font-black tabular-nums ${
                  pointDiff > 0
                    ? 'text-[#22C55E]'
                    : pointDiff < 0
                    ? 'text-[#EF4444]'
                    : 'text-[#64748B] dark:text-[#A0A0A0]'
                }`}
              >
                {pointDiff > 0 ? `+${pointDiff}` : pointDiff}
              </span>
              <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] block">
                {player.pointsFor}:{player.pointsAgainst}
              </span>
            </div>
          </div>

          {/* Career Badges + Player QR Identity Pass */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/25 space-y-2">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#D4AF37] flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Earned Career Badges &amp; Honors</span>
              </div>
              {earnedBadges.length === 0 ? (
                <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  Play matches or win MVP awards to unlock automatic career badges.
                </p>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {earnedBadges.map((b) => (
                    <span
                      key={b}
                      className="px-2.5 py-1 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#9A7B1C] dark:text-[#FFD700] text-[10px] font-black uppercase"
                    >
                      {b}
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="p-3 rounded-2xl bg-[#080808] border border-[#D4AF37]/35 flex items-center gap-3">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt={`QR ID ${playerCode}`}
                  className="w-16 h-16 rounded-xl border border-[#D4AF37]/40 shrink-0"
                />
              ) : (
                <div className="w-16 h-16 rounded-xl bg-[#141414] flex items-center justify-center text-[#FFD700]">
                  <QrCode className="w-6 h-6" />
                </div>
              )}
              <div className="min-w-0">
                <div className="text-[10px] font-black uppercase text-[#FFD700]">Player QR ID</div>
                <div className="text-xs font-mono font-bold text-white truncate">{playerCode}</div>
                <div className="text-[10px] text-[#A0A0A0] truncate">
                  {club || 'Official Pass'}
                </div>
              </div>
            </div>
          </div>

          {/* Bio Editor */}
          <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="font-extrabold text-[#172033] dark:text-white text-xs flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Player Profile, Contact &amp; Category</span>
              </span>
              <button
                onClick={() => setIsEditingBio(!isEditingBio)}
                className="text-[11px] text-[#172B4D] dark:text-[#FFD700] font-bold hover:underline cursor-pointer"
              >
                {isEditingBio ? 'Cancel' : 'Edit Profile'}
              </button>
            </div>

            {isEditingBio ? (
              <div className="space-y-3 pt-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Play Style
                    </label>
                    <select
                      value={playStyle}
                      onChange={(e) => setPlayStyle(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#141414] text-[#172033] dark:text-white"
                    >
                      <option value="Jump Smash Attacker">Jump Smash Attacker</option>
                      <option value="All-Round Tactician">All-Round Tactician</option>
                      <option value="Net Play Specialist">Net Play Specialist</option>
                      <option value="Defensive Retriever">Defensive Retriever</option>
                      <option value="Fast-Paced Speedster">Fast-Paced Speedster</option>
                      <option value="Deceptive Drop-Shotter">Deceptive Drop-Shotter</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Playing Category
                    </label>
                    <select
                      value={preferredCategory}
                      onChange={(e) => setPreferredCategory(e.target.value as CompetitionCategory)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#141414] text-[#172033] dark:text-white"
                    >
                      <option value="singles">Singles</option>
                      <option value="doubles">Doubles</option>
                      <option value="mixed_doubles">Mixed Doubles</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Age (optional)
                    </label>
                    <input
                      type="number"
                      min={5}
                      max={99}
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      placeholder="e.g. 24"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#141414] text-[#172033] dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Contact Information (optional)
                    </label>
                    <input
                      type="text"
                      value={contact}
                      onChange={(e) => setContact(e.target.value)}
                      placeholder="Phone or Email"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#141414] text-[#172033] dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Preferred Hand
                  </label>
                  <div className="flex gap-2">
                    {(['Right', 'Left'] as const).map((h) => (
                      <button
                        key={h}
                        type="button"
                        onClick={() => setHand(h)}
                        className={`flex-1 py-1.5 rounded-lg border font-bold cursor-pointer ${
                          hand === h
                            ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] border-transparent'
                            : 'bg-white dark:bg-[#141414] text-[#64748B] dark:text-[#A0A0A0] border-slate-200 dark:border-white/15'
                        }`}
                      >
                        {h}-Handed
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Club Membership (optional)
                    </label>
                    <input
                      type="text"
                      value={club}
                      onChange={(e) => setClub(e.target.value)}
                      placeholder="e.g. Hassan Shuttle Club"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#141414] text-[#172033] dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Court Availability Status
                    </label>
                    <select
                      value={availability}
                      onChange={(e) =>
                        setAvailability(e.target.value as NonNullable<PlayerBio['availability']>)
                      }
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#141414] text-[#172033] dark:text-white"
                    >
                      <option value="Available">Available</option>
                      <option value="On Court">On Court</option>
                      <option value="Resting">Resting</option>
                      <option value="Injured">Injured</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                    Racket / Notes
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g. Yonex Astrox 99 Pro"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 bg-white dark:bg-[#141414] text-[#172033] dark:text-white"
                  />
                </div>

                <button
                  onClick={handleSaveBio}
                  className="w-full py-2 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-extrabold rounded-xl text-xs cursor-pointer"
                >
                  Save Profile
                </button>
              </div>
            ) : (
              <div className="text-[#64748B] dark:text-[#A0A0A0] space-y-1">
                <p>
                  <strong className="text-[#172033] dark:text-white">Category:</strong>{' '}
                  <span className="uppercase font-bold text-[#D4AF37]">
                    {(player.bio?.preferredCategory || tournamentCategory).replace('_', ' ')}
                  </span>
                  {player.bio?.age ? ` · Age ${player.bio.age}` : ''}
                </p>
                <p>
                  <strong className="text-[#172033] dark:text-white">Style:</strong>{' '}
                  {player.bio?.playStyle || 'All-Round Tactician'} ({player.bio?.hand || 'Right'}-Handed)
                </p>
                {club && (
                  <p className="flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-[#D4AF37]" />
                    <strong className="text-[#172033] dark:text-white">Club:</strong> {club}
                  </p>
                )}
                {player.bio?.contact && (
                  <p>
                    <strong className="text-[#172033] dark:text-white">Contact:</strong>{' '}
                    {player.bio.contact}
                  </p>
                )}
                {player.bio?.notes && (
                  <p>
                    <strong className="text-[#172033] dark:text-white">Gear/Notes:</strong>{' '}
                    {player.bio.notes}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Multi-Tournament Participation History */}
          {globalEntry && globalEntry.history.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-extrabold text-[#172033] dark:text-white text-xs flex items-center gap-1.5">
                <Trophy className="w-3.5 h-3.5 text-[#FFD700]" />
                <span>Career Tournament Participation ({globalEntry.history.length})</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {globalEntry.history.map((h, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 flex items-center justify-between"
                  >
                    <div className="min-w-0">
                      <div className="font-bold text-[#172033] dark:text-white truncate">
                        {h.tournamentTitle}
                      </div>
                      <div className="text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                        {h.resultLabel}
                      </div>
                    </div>
                    <span className="font-mono font-black text-[#FFD700] shrink-0 pl-2">
                      +{h.pointsEarned} pts
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Match History */}
          <div className="space-y-2">
            <h4 className="font-extrabold text-[#172033] dark:text-white text-xs">
              Current Tournament Matches ({playerMatches.length})
            </h4>

            <div className="space-y-2">
              {playerMatches.map((m) => {
                const isPlayerA = m.playerAIndex === player.id;
                const oppIndex = isPlayerA ? m.playerBIndex : m.playerAIndex;
                const opponentName = allPlayers[oppIndex] || 'Opponent';
                const winner = results[m.id];
                const hasResult = winner !== undefined;
                const won = winner === player.id;
                const isMatchMvp = won && matchMvps[m.id] === player.id;
                const formattedScoreStr = formatScore(scores[m.id]);

                return (
                  <div
                    key={m.id}
                    className={`p-3 rounded-xl border flex items-center justify-between gap-2 ${
                      hasResult
                        ? won
                          ? 'bg-[#22C55E]/10 border-[#22C55E]/30'
                          : 'bg-[#EF4444]/10 border-[#EF4444]/30'
                        : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200 dark:border-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="w-7 h-7 rounded-lg text-[#080808] font-black text-[10px] flex items-center justify-center shrink-0"
                        style={{ backgroundColor: getPlayerColor(oppIndex) }}
                      >
                        {getInitials(opponentName)}
                      </div>
                      <div className="min-w-0">
                        <span className="font-bold text-[#172033] dark:text-white truncate block">
                          vs {opponentName}
                        </span>
                        {formattedScoreStr && (
                          <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] block">
                            Games: {formattedScoreStr}
                          </span>
                        )}
                      </div>
                    </div>

                    {hasResult ? (
                      <div className="flex items-center gap-1.5 shrink-0">
                        {isMatchMvp && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-600 dark:text-[#FFD700] border border-amber-400/40 font-black text-[10px] uppercase tracking-wide">
                            <Award className="w-3 h-3" />
                            <span>Match MVP</span>
                          </span>
                        )}
                        <span
                          className={`font-black px-2 py-0.5 rounded text-[10px] ${
                            won ? 'bg-[#22C55E] text-[#080808]' : 'bg-[#EF4444] text-white'
                          }`}
                        >
                          {won ? 'WON' : 'LOST'}
                        </span>
                      </div>
                    ) : (
                      <span className="text-[#A0A0A0] text-[11px] shrink-0">Scheduled</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#F4F7FB] dark:bg-[#080808] border-t border-slate-200 dark:border-white/10 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-white/15 text-[#172033] dark:text-white hover:border-[#D4AF37] cursor-pointer font-bold text-xs transition-colors">
              <Camera className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Photo</span>
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>

            <button
              type="button"
              onClick={handleDownloadCard}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[#9A7B1C] dark:text-[#FFD700] font-bold text-xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Achievement Card</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadCertificate}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#D4AF37]/40 bg-[#080808] text-[#FFD700] font-bold text-xs cursor-pointer"
            >
              <FileBadge className="w-3.5 h-3.5" />
              <span>Player Certificate</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-extrabold rounded-xl text-xs cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
