import React, { useEffect, useState, useRef } from 'react';
import { Award, Zap, ShieldCheck, ChevronUp } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
  isDark?: boolean;
  customLogoUrl?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  isDark: propIsDark,
  customLogoUrl,
}) => {
  const [phase, setPhase] = useState<'splash' | 'loading' | 'complete'>('splash');
  const [progress, setProgress] = useState(12);
  const [loadingText, setLoadingText] = useState('Initializing Court Engine...');
  const [isSystemDark, setIsSystemDark] = useState(true);
  const [dragOffsetY, setDragOffsetY] = useState(0);
  const [isExiting, setIsExiting] = useState(false);

  const finishTriggered = useRef(false);
  const touchStartY = useRef<number | null>(null);
  const touchCurrentY = useRef<number | null>(null);
  const isDragging = useRef(false);

  useEffect(() => {
    if (propIsDark !== undefined) {
      setIsSystemDark(propIsDark);
    } else {
      const stored = localStorage.getItem('smash-theme');
      if (stored) {
        setIsSystemDark(stored === 'dark');
      } else {
        setIsSystemDark(window.matchMedia('(prefers-color-scheme: dark)').matches);
      }
    }
  }, [propIsDark]);

  const handleComplete = () => {
    if (finishTriggered.current) return;
    finishTriggered.current = true;
    onFinish();
  };

  const triggerSwipeUpExit = () => {
    if (finishTriggered.current || isExiting) return;
    setIsExiting(true);
    setTimeout(() => {
      handleComplete();
    }, 280);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    touchCurrentY.current = e.touches[0].clientY;
    isDragging.current = true;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging.current || touchStartY.current === null) return;
    touchCurrentY.current = e.touches[0].clientY;
    const deltaY = e.touches[0].clientY - touchStartY.current;
    if (deltaY < 0) {
      setDragOffsetY(Math.max(deltaY, -240));
    }
  };

  const handleTouchEnd = () => {
    if (!isDragging.current) return;
    isDragging.current = false;
    if (touchStartY.current !== null && touchCurrentY.current !== null) {
      const deltaY = touchCurrentY.current - touchStartY.current;
      if (deltaY < -30) {
        triggerSwipeUpExit();
        return;
      }
    }
    setDragOffsetY(0);
    touchStartY.current = null;
    touchCurrentY.current = null;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    touchStartY.current = e.clientY;
    touchCurrentY.current = e.clientY;
    isDragging.current = true;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current || touchStartY.current === null) return;
    touchCurrentY.current = e.clientY;
    const deltaY = e.clientY - touchStartY.current;
    if (deltaY < 0) {
      setDragOffsetY(Math.max(deltaY, -240));
    }
  };

  const handleMouseUp = () => {
    if (!isDragging.current) return;
    isDragging.current = false;
    if (touchStartY.current !== null && touchCurrentY.current !== null) {
      const deltaY = touchCurrentY.current - touchStartY.current;
      if (deltaY < -30) {
        triggerSwipeUpExit();
        return;
      }
    }
    setDragOffsetY(0);
    touchStartY.current = null;
    touchCurrentY.current = null;
  };

  useEffect(() => {
    const phaseTimer = setTimeout(() => setPhase('loading'), 650);
    const t1 = setTimeout(() => {
      setProgress(42);
      setLoadingText('Connecting Offline Local Database...');
    }, 950);
    const t2 = setTimeout(() => {
      try {
        const raw = localStorage.getItem('smash-store-v2') || localStorage.getItem('hbt-state');
        if (raw) JSON.parse(raw);
      } catch (err) {
        console.warn('Recovered safely from local storage check:', err);
      }
      setProgress(74);
      setLoadingText('Verifying Player Rosters & Rankings...');
    }, 1350);
    const t3 = setTimeout(() => {
      setProgress(94);
      setLoadingText('Compiling BWF Fixtures & Courts...');
    }, 1750);
    const t4 = setTimeout(() => {
      setProgress(100);
      setLoadingText('Championship Ready! Swipe up to enter');
      setPhase('complete');
    }, 2150);
    const t5 = setTimeout(() => triggerSwipeUpExit(), 2750);
    const safetyTimeout = setTimeout(() => triggerSwipeUpExit(), 3400);

    return () => {
      clearTimeout(phaseTimer);
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
      clearTimeout(safetyTimeout);
    };
  }, []);

  const strokeWidth = 5;
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Loading Hassan Badminton Tournament Manager"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      style={{
        transform: isExiting
          ? 'translateY(-100%)'
          : dragOffsetY !== 0
          ? `translateY(${dragOffsetY}px)`
          : undefined,
        opacity: isExiting ? 0 : 1,
        transition: isExiting
          ? 'transform 0.32s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.28s ease-out'
          : dragOffsetY !== 0
          ? 'none'
          : 'transform 0.25s ease-out, opacity 0.25s ease-out',
        touchAction: 'pan-y',
      }}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between p-6 sm:p-10 select-none transition-colors duration-500 cursor-grab active:cursor-grabbing ${
        isSystemDark
          ? 'bg-gradient-to-br from-[#080808] via-[#121212] to-[#080808] text-white'
          : 'bg-gradient-to-br from-[#F4F7FB] via-[#EBF1F8] to-[#E2EAF4] text-[#172033]'
      }`}
    >
      {/* Court Ambient Backdrop */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className={`absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] rounded-full blur-3xl ${
            isSystemDark ? 'bg-[#D4AF37]/14' : 'bg-[#D4AF37]/18'
          }`}
        />
        <div
          className={`absolute bottom-1/4 right-1/3 w-[340px] h-[340px] rounded-full blur-2xl ${
            isSystemDark ? 'bg-[#FFD700]/10' : 'bg-[#172B4D]/12'
          }`}
        />

        <div
          className={`absolute inset-8 sm:inset-16 border rounded-3xl pointer-events-none ${
            isSystemDark ? 'border-[#D4AF37]/25' : 'border-[#172B4D]/12'
          }`}
        >
          <div
            className={`absolute inset-x-0 top-1/2 -translate-y-1/2 border-t-2 border-dashed ${
              isSystemDark ? 'border-[#FFD700]/25' : 'border-[#D4AF37]/30'
            }`}
          />
          <div
            className={`absolute inset-y-0 left-1/2 -translate-x-1/2 border-l ${
              isSystemDark ? 'border-[#D4AF37]/20' : 'border-[#172B4D]/12'
            }`}
          />
        </div>
      </div>

      {/* Top Bar */}
      <div className="w-full max-w-md flex items-center justify-between relative z-10">
        <div
          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold border backdrop-blur-md ${
            isSystemDark
              ? 'bg-[#141414]/90 border-[#D4AF37]/45 text-[#FFD700]'
              : 'bg-white/90 border-[#172B4D]/20 text-[#172B4D]'
          }`}
        >
          <span>BLACK + GOLD PRO EDITION</span>
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            triggerSwipeUpExit();
          }}
          className={`text-xs font-bold px-3 py-1 rounded-lg transition-colors cursor-pointer ${
            isSystemDark
              ? 'text-[#A0A0A0] hover:text-white hover:bg-[#141414]'
              : 'text-[#64748B] hover:text-[#172033] hover:bg-white'
          }`}
        >
          Skip &rarr;
        </button>
      </div>

      {/* Center Core */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-sm w-full my-auto py-4">
        <div className="relative mb-5">
          <div
            className={`absolute -inset-2 rounded-3xl blur-md opacity-40 animate-pulse ${
              isSystemDark ? 'bg-[#D4AF37]' : 'bg-[#D4AF37]'
            }`}
          />

          <div
            className={`relative w-24 h-24 sm:w-28 sm:h-28 rounded-3xl p-1 flex items-center justify-center shadow-2xl border overflow-hidden ${
              isSystemDark
                ? 'bg-[#141414] border-[#D4AF37]/70 shadow-black/80'
                : 'bg-[#172B4D] border-white shadow-[#172B4D]/25'
            }`}
          >
            <img
              src={customLogoUrl || '/logo.png'}
              alt="Hassan Badminton Tournament Manager Logo"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-2xl"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/icon.svg';
              }}
            />

            <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] flex items-center justify-center font-black shadow-lg border-2 border-[#080808] z-10">
              <Zap className="w-4 h-4 fill-current" />
            </div>
          </div>
        </div>

        <h1
          className={`text-2xl sm:text-3xl font-black tracking-tight uppercase drop-shadow-sm font-sans ${
            isSystemDark ? 'text-white' : 'text-[#172B4D]'
          }`}
        >
          SMASH CHAMPIONSHIP
        </h1>
        <p className={`text-xs font-bold mt-1 ${isSystemDark ? 'text-[#A0A0A0]' : 'text-[#64748B]'}`}>
          Hassan Badminton Tournament Manager
        </p>

        <div className="mt-2 mb-3 flex items-center justify-center gap-1.5">
          <Award className={`w-4 h-4 ${isSystemDark ? 'text-[#FFD700]' : 'text-[#D4AF37]'}`} />
          <span
            className={`text-sm sm:text-base font-extrabold tracking-tight ${
              isSystemDark ? 'text-[#FFD700]' : 'text-[#172B4D]'
            }`}
          >
            Developed By Hassan
          </span>
        </div>

        <div
          className={`inline-flex items-center px-3.5 py-1 rounded-full text-xs font-black tracking-wider uppercase shadow-sm border mb-6 ${
            isSystemDark
              ? 'bg-[#141414] border-[#D4AF37]/40 text-[#D4AF37]'
              : 'bg-white border-[#172B4D]/20 text-[#172B4D]'
          }`}
        >
          HASSAN DEVELOPERS
        </div>

        {/* Circular Progress */}
        <div className="w-full flex flex-col items-center gap-3">
          <div className="relative w-18 h-18 sm:w-20 sm:h-20 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 80 80">
              <circle
                cx="40"
                cy="40"
                r={radius}
                className={isSystemDark ? 'text-[#141414]' : 'text-slate-200'}
                strokeWidth={strokeWidth}
                stroke="currentColor"
                fill="transparent"
              />
              <circle
                cx="40"
                cy="40"
                r={radius}
                className={
                  isSystemDark
                    ? 'text-[#FFD700] transition-all duration-300 ease-out'
                    : 'text-[#D4AF37] transition-all duration-300 ease-out'
                }
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
              />
            </svg>

            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span
                className={`text-sm font-black font-mono ${
                  isSystemDark ? 'text-white' : 'text-[#172033]'
                }`}
              >
                {progress}%
              </span>
            </div>
          </div>

          <div className="h-6 flex items-center justify-center">
            <p
              className={`text-xs font-bold tracking-wide transition-all ${
                phase === 'complete'
                  ? isSystemDark
                    ? 'text-[#FFD700] font-extrabold animate-pulse'
                    : 'text-[#172B4D] font-extrabold animate-pulse'
                  : isSystemDark
                  ? 'text-[#A0A0A0]'
                  : 'text-[#64748B]'
              }`}
            >
              {loadingText}
            </p>
          </div>
        </div>
      </div>

      {/* Swipe Up Prompt */}
      <div className="w-full max-w-sm flex flex-col items-center relative z-20 my-2">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            triggerSwipeUpExit();
          }}
          className={`w-full py-2.5 px-4 rounded-2xl flex flex-col items-center justify-center gap-1 border backdrop-blur-md transition-all active:scale-95 group shadow-lg cursor-pointer ${
            isSystemDark
              ? 'bg-[#141414]/90 hover:bg-[#1C1C1C] border-[#D4AF37]/50'
              : 'bg-white hover:bg-slate-50 border-[#172B4D]/20'
          }`}
          title="Swipe up or tap to enter Hassan Badminton Tournament Manager"
        >
          <div
            className={`flex items-center gap-1 text-xs font-black tracking-wider uppercase ${
              isSystemDark ? 'text-[#FFD700]' : 'text-[#172B4D]'
            }`}
          >
            <ChevronUp className="w-4 h-4 animate-bounce stroke-[3]" />
            <span>Swipe Up To Enter</span>
            <ChevronUp className="w-4 h-4 animate-bounce stroke-[3]" />
          </div>
          <div
            className={`w-16 h-1 rounded-full transition-colors ${
              isSystemDark ? 'bg-[#D4AF37]/70 group-hover:bg-[#FFD700]' : 'bg-[#D4AF37]'
            }`}
          />
        </button>
      </div>

      {/* Bottom Strip */}
      <div className="w-full max-w-md text-center relative z-10 pt-2 border-t border-slate-500/15">
        <div
          className={`flex items-center justify-center gap-3 text-[10px] font-mono tracking-wider uppercase ${
            isSystemDark ? 'text-[#A0A0A0]' : 'text-[#64748B]'
          }`}
        >
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-[#D4AF37]" />
            Black + Gold Pro
          </span>
          <span>&bull;</span>
          <span>Offline Ready</span>
          <span>&bull;</span>
          <span>Swipe-Up Ready</span>
        </div>
      </div>
    </div>
  );
};
