import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  X,
  QrCode,
  Download,
  Copy,
  Check,
  UserPlus,
  Search,
  AlertCircle,
  Trophy,
  CheckCircle2,
} from 'lucide-react';
import { CompetitionCategory, PlayerBio, TournamentState } from '../types';

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournamentState: TournamentState;
  onRegisterPlayer?: (name: string, bio?: PlayerBio) => void;
  onImportTournamentFromQR?: (payload: Partial<TournamentState>) => void;
}

type QRTab = 'tournament' | 'player' | 'lookup';

export const QRCodeModal: React.FC<QRCodeModalProps> = ({
  isOpen,
  onClose,
  tournamentState,
  onRegisterPlayer,
  onImportTournamentFromQR,
}) => {
  const [activeTab, setActiveTab] = useState<QRTab>('tournament');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  // Player registration QR builder
  const [regName, setRegName] = useState('');
  const [regAge, setRegAge] = useState('');
  const [regContact, setRegContact] = useState('');
  const [regCategory, setRegCategory] = useState<CompetitionCategory>(
    tournamentState.category || 'singles'
  );

  // QR lookup / validation
  const [lookupInput, setLookupInput] = useState('');
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [lookupSuccess, setLookupSuccess] = useState<string | null>(null);
  const [validatedPreview, setValidatedPreview] = useState<
    | { kind: 'tournament'; data: Partial<TournamentState> }
    | { kind: 'player'; name: string; bio: PlayerBio; tournamentId?: string }
    | null
  >(null);

  const tournamentPayload = JSON.stringify({
    type: 'smash-tournament',
    version: 1,
    id: tournamentState.id,
    tournamentTitle: tournamentState.tournamentTitle || 'Smash Championship',
    venue: tournamentState.venue || 'Center Arena Court',
    category: tournamentState.category || 'singles',
    tournamentFormat: tournamentState.tournamentFormat || 'round_robin',
    matchFormat: tournamentState.matchFormat || 'bo3',
    pointsPerSet: tournamentState.customRules?.pointsPerSet ?? 21,
    players: tournamentState.players,
    createdDate: tournamentState.createdDate,
  });

  const playerRegPayload = JSON.stringify({
    type: 'smash-player-reg',
    version: 1,
    tournamentId: tournamentState.id,
    tournamentTitle: tournamentState.tournamentTitle,
    playerName: regName.trim() || 'New Badminton Player',
    age: regAge ? Number(regAge) : undefined,
    contact: regContact.trim() || undefined,
    category: regCategory,
  });

  const activePayload = activeTab === 'player' ? playerRegPayload : tournamentPayload;

  useEffect(() => {
    if (!isOpen || activeTab === 'lookup') return;
    let cancelled = false;
    QRCode.toDataURL(activePayload, {
      width: 340,
      margin: 2,
      color: {
        dark: '#080808',
        light: '#FFD700',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (!cancelled) setQrDataUrl(url);
      })
      .catch(() => {
        if (!cancelled) setQrDataUrl('');
      });
    return () => {
      cancelled = true;
    };
  }, [isOpen, activeTab, activePayload]);

  if (!isOpen) return null;

  const handleCopyPayload = async () => {
    try {
      await navigator.clipboard.writeText(activePayload);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard blocked cleanly
    }
  };

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download =
      activeTab === 'player'
        ? `player-registration-qr-${(regName || 'player').toLowerCase().replace(/\s+/g, '-')}.png`
        : `tournament-qr-${(tournamentState.tournamentTitle || 'smash').toLowerCase().replace(/\s+/g, '-')}.png`;
    a.click();
  };

  const handleValidateQRPayload = () => {
    setLookupError(null);
    setLookupSuccess(null);
    setValidatedPreview(null);

    if (!lookupInput.trim()) {
      setLookupError('Paste a scanned QR JSON token before validating.');
      return;
    }

    try {
      const parsed = JSON.parse(lookupInput.trim()) as Record<string, unknown>;
      if (!parsed || typeof parsed !== 'object') {
        setLookupError('QR payload is not a valid structured object.');
        return;
      }

      if (parsed.type === 'smash-player-reg') {
        const playerName = typeof parsed.playerName === 'string' ? parsed.playerName.trim() : '';
        if (playerName.length < 2) {
          setLookupError('Invalid player registration QR: missing valid playerName.');
          return;
        }
        const alreadyExists = tournamentState.players.some(
          (p) => p.trim().toLowerCase() === playerName.toLowerCase()
        );
        if (alreadyExists) {
          setLookupError(`Player "${playerName}" is already registered in this tournament.`);
          return;
        }
        const bio: PlayerBio = {
          age: typeof parsed.age === 'number' && parsed.age > 0 ? parsed.age : undefined,
          contact: typeof parsed.contact === 'string' ? parsed.contact : undefined,
          preferredCategory:
            parsed.category === 'doubles' || parsed.category === 'mixed_doubles'
              ? parsed.category
              : 'singles',
        };
        setValidatedPreview({
          kind: 'player',
          name: playerName,
          bio,
          tournamentId: typeof parsed.tournamentId === 'string' ? parsed.tournamentId : undefined,
        });
        return;
      }

      if (parsed.type === 'smash-tournament' || Array.isArray(parsed.players)) {
        const players = Array.isArray(parsed.players)
          ? parsed.players.filter((p): p is string => typeof p === 'string' && p.trim().length > 0)
          : [];
        if (players.length < 2) {
          setLookupError('Invalid tournament QR: must include at least 2 valid players.');
          return;
        }
        setValidatedPreview({
          kind: 'tournament',
          data: {
            id: typeof parsed.id === 'string' ? parsed.id : undefined,
            tournamentTitle:
              typeof parsed.tournamentTitle === 'string'
                ? parsed.tournamentTitle
                : 'Imported QR Tournament',
            venue: typeof parsed.venue === 'string' ? parsed.venue : 'Center Arena Court',
            category:
              parsed.category === 'doubles' || parsed.category === 'mixed_doubles'
                ? parsed.category
                : 'singles',
            tournamentFormat:
              parsed.tournamentFormat === 'group_stage' ||
              parsed.tournamentFormat === 'knockout' ||
              parsed.tournamentFormat === 'single_elimination' ||
              parsed.tournamentFormat === 'double_elimination'
                ? parsed.tournamentFormat
                : 'round_robin',
            matchFormat:
              parsed.matchFormat === 'bo1' ||
              parsed.matchFormat === 'bo2' ||
              parsed.matchFormat === 'bo5'
                ? parsed.matchFormat
                : 'bo3',
            players,
          },
        });
        return;
      }

      setLookupError('Unrecognized QR code payload. Expected Smash Tournament or Player Registration token.');
    } catch {
      setLookupError('Malformed QR code text. Could not parse JSON payload.');
    }
  };

  const handleApplyValidated = () => {
    if (!validatedPreview) return;
    if (validatedPreview.kind === 'player' && onRegisterPlayer) {
      onRegisterPlayer(validatedPreview.name, validatedPreview.bio);
      setLookupSuccess(`Registered "${validatedPreview.name}" into ${tournamentState.tournamentTitle}!`);
      setValidatedPreview(null);
      setLookupInput('');
    } else if (validatedPreview.kind === 'tournament' && onImportTournamentFromQR) {
      onImportTournamentFromQR(validatedPreview.data);
      setLookupSuccess(
        `Imported "${validatedPreview.data.tournamentTitle}" (${validatedPreview.data.players?.length || 0} players)!`
      );
      setValidatedPreview(null);
      setLookupInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-lg bg-white dark:bg-[#141414] border border-slate-200 dark:border-[#D4AF37]/35 rounded-3xl shadow-2xl overflow-hidden animate-fade-in my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-[#172B4D] dark:bg-[#080808] border-b border-white/10 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/45 flex items-center justify-center text-[#FFD700]">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black">QR Code Sharing &amp; Lookup</h3>
              <p className="text-[11px] text-[#A0A0A0]">
                Tournament invites, player registration &amp; validated QR import
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-[#A0A0A0] hover:text-white hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5 max-h-[78vh] overflow-y-auto">
          {/* Tabs */}
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-xs">
            {(
              [
                { id: 'tournament', label: 'Tournament QR', icon: <Trophy className="w-3.5 h-3.5" /> },
                { id: 'player', label: 'Player Reg QR', icon: <UserPlus className="w-3.5 h-3.5" /> },
                { id: 'lookup', label: 'QR Lookup', icon: <Search className="w-3.5 h-3.5" /> },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-2 rounded-xl font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  activeTab === tab.id
                    ? 'bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] shadow-sm'
                    : 'text-[#64748B] dark:text-[#A0A0A0]'
                }`}
              >
                {tab.icon}
                <span className="truncate">{tab.label}</span>
              </button>
            ))}
          </div>

          {activeTab !== 'lookup' ? (
            <div className="space-y-4">
              {activeTab === 'player' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10">
                  <div className="sm:col-span-2">
                    <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Player Name
                    </label>
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="e.g. Hamza Tariq"
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Age (Optional)
                    </label>
                    <input
                      type="number"
                      min={6}
                      max={99}
                      value={regAge}
                      onChange={(e) => setRegAge(e.target.value)}
                      placeholder="24"
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Category
                    </label>
                    <select
                      value={regCategory}
                      onChange={(e) => setRegCategory(e.target.value as CompetitionCategory)}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-semibold"
                    >
                      <option value="singles">Singles</option>
                      <option value="doubles">Doubles</option>
                      <option value="mixed_doubles">Mixed Doubles</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                      Contact / Phone (Optional)
                    </label>
                    <input
                      type="text"
                      value={regContact}
                      onChange={(e) => setRegContact(e.target.value)}
                      placeholder="+92 300 0000000"
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white"
                    />
                  </div>
                </div>
              )}

              {/* QR Display */}
              <div className="flex flex-col items-center justify-center p-5 rounded-3xl bg-[#080808] border-2 border-[#D4AF37]/50 shadow-xl space-y-3">
                {qrDataUrl ? (
                  <img
                    src={qrDataUrl}
                    alt="Championship QR Code"
                    className="w-56 h-56 rounded-2xl border-4 border-[#FFD700] shadow-lg bg-[#FFD700]"
                  />
                ) : (
                  <div className="w-56 h-56 rounded-2xl bg-[#141414] flex items-center justify-center text-xs text-[#A0A0A0]">
                    Generating QR Code...
                  </div>
                )}

                <div className="text-center">
                  <div className="text-sm font-black text-white">
                    {activeTab === 'player'
                      ? regName.trim() || 'Player Registration Token'
                      : tournamentState.tournamentTitle}
                  </div>
                  <div className="text-[11px] text-[#D4AF37] font-mono mt-0.5">
                    {activeTab === 'player'
                      ? `Category: ${regCategory.replace('_', ' ').toUpperCase()}`
                      : `${tournamentState.players.length} Players · ${tournamentState.venue || 'Arena Court'}`}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5 text-xs">
                <button
                  type="button"
                  onClick={handleCopyPayload}
                  className="py-2.5 px-3 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4 text-[#22C55E]" /> : <Copy className="w-4 h-4 text-[#D4AF37]" />}
                  <span>{copied ? 'Token Copied!' : 'Copy QR Token'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadQR}
                  disabled={!qrDataUrl}
                  className="py-2.5 px-3 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-black flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40"
                >
                  <Download className="w-4 h-4" />
                  <span>Save QR PNG</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2">
                <label className="font-black text-[#172033] dark:text-white block">
                  Paste Scanned QR Code Data / Token
                </label>
                <p className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  All QR tokens are strictly validated for schema &amp; duplicate detection before modifying tournament records.
                </p>
                <textarea
                  rows={4}
                  value={lookupInput}
                  onChange={(e) => setLookupInput(e.target.value)}
                  placeholder='{"type":"smash-player-reg","playerName":"Ali Raza",...}'
                  className="w-full p-3 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 font-mono text-[11px] text-[#172033] dark:text-white focus:outline-none focus:border-[#D4AF37]"
                />
                <button
                  type="button"
                  onClick={handleValidateQRPayload}
                  className="w-full py-2.5 rounded-xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] font-black cursor-pointer"
                >
                  Validate QR Information
                </button>
              </div>

              {lookupError && (
                <div className="p-3 rounded-2xl bg-[#EF4444]/10 border border-[#EF4444]/40 text-[#EF4444] flex items-center gap-2 font-semibold">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{lookupError}</span>
                </div>
              )}

              {lookupSuccess && (
                <div className="p-3 rounded-2xl bg-[#22C55E]/15 border border-[#22C55E]/40 text-[#22C55E] flex items-center gap-2 font-bold">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{lookupSuccess}</span>
                </div>
              )}

              {validatedPreview && (
                <div className="p-4 rounded-2xl bg-[#D4AF37]/10 border border-[#D4AF37]/50 space-y-3">
                  <div className="flex items-center gap-2 text-[#D4AF37] font-black">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      Verified QR:{' '}
                      {validatedPreview.kind === 'player'
                        ? 'Player Registration'
                        : 'Tournament Info'}
                    </span>
                  </div>
                  {validatedPreview.kind === 'player' ? (
                    <div className="space-y-1 text-[#172033] dark:text-white">
                      <div>
                        Name: <strong>{validatedPreview.name}</strong>
                      </div>
                      <div>
                        Category:{' '}
                        <strong>
                          {(validatedPreview.bio.preferredCategory || 'singles').replace('_', ' ')}
                        </strong>
                      </div>
                      {validatedPreview.bio.age && <div>Age: {validatedPreview.bio.age}</div>}
                    </div>
                  ) : (
                    <div className="space-y-1 text-[#172033] dark:text-white">
                      <div>
                        Title: <strong>{validatedPreview.data.tournamentTitle}</strong>
                      </div>
                      <div>
                        Venue: {validatedPreview.data.venue} ·{' '}
                        {validatedPreview.data.players?.length} Players
                      </div>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={handleApplyValidated}
                    className="w-full py-2.5 rounded-xl bg-[#22C55E] text-[#080808] font-black cursor-pointer"
                  >
                    {validatedPreview.kind === 'player'
                      ? 'Confirm & Register Player'
                      : 'Confirm & Import Tournament'}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
