import React, { useState } from 'react';
import {
  Home,
  Trophy,
  Zap,
  Users,
  Calendar,
  User,
  UserCheck,
  Table2,
  Award,
  Tv,
  Users2,
  History,
  FileText,
  Palette,
  Settings,
  X,
  Moon,
  Sun,
  ShieldCheck,
  Medal,
  MoreHorizontal,
  Database,
  QrCode,
  Info,
  BarChart3,
  Shield,
  MapPin,
  Newspaper,
  Wallet,
  Sparkles,
  Wrench,
  Eye,
  HelpCircle,
} from 'lucide-react';
import { AppTab } from './Header';
import { AppLanguage, UserAccount, UserRoleMode } from '../types';
import { t } from '../utils/i18n';

interface MobileBottomNavProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  tournamentStarted: boolean;
  completedMatchesCount: number;
  totalMatchesCount: number;
  hasChampion: boolean;
  language?: AppLanguage;
  userAccount?: UserAccount | null;
  userRoleMode?: UserRoleMode;
  onToggleRoleMode?: () => void;
  spectatorMode?: boolean;
  onToggleSpectatorMode?: () => void;
  isDark?: boolean;
  onToggleDark?: () => void;
  onOpenAuthModal?: () => void;
  onOpenPDFModal?: () => void;
  onOpenShareModal?: () => void;
  onOpenThemeStudio?: () => void;
  onOpenSettingsModal?: () => void;
  onOpenQRModal?: () => void;
  onOpenAboutModal?: () => void;
  onOpenTutorial?: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  language = 'en',
  userAccount,
  userRoleMode = 'admin',
  onToggleRoleMode,
  spectatorMode = false,
  onToggleSpectatorMode,
  isDark = true,
  onToggleDark,
  onOpenAuthModal,
  onOpenPDFModal,
  onOpenShareModal,
  onOpenThemeStudio,
  onOpenSettingsModal,
  onOpenQRModal,
  onOpenAboutModal,
  onOpenTutorial,
}) => {
  const [showMoreDrawer, setShowMoreDrawer] = useState(false);

  const navigateAndClose = (tab: AppTab) => {
    setActiveTab(tab);
    setShowMoreDrawer(false);
  };

  const sectionItems: Array<{
    id: AppTab;
    label: string;
    icon: React.ReactNode;
  }> = [
    { id: 'rankings', label: t(language, 'rankings'), icon: <Medal className="w-4 h-4" /> },
    { id: 'courts', label: t(language, 'courts'), icon: <Tv className="w-4 h-4" /> },
    { id: 'matches', label: t(language, 'matches'), icon: <Calendar className="w-4 h-4" /> },
    { id: 'knockout', label: t(language, 'playoffs'), icon: <Award className="w-4 h-4" /> },
    { id: 'table', label: t(language, 'standings'), icon: <Table2 className="w-4 h-4" /> },
    { id: 'h2h', label: t(language, 'h2h'), icon: <Users2 className="w-4 h-4" /> },
    { id: 'history', label: t(language, 'history'), icon: <History className="w-4 h-4" /> },
    { id: 'venue', label: t(language, 'venue'), icon: <MapPin className="w-4 h-4" /> },
    { id: 'news', label: t(language, 'news'), icon: <Newspaper className="w-4 h-4" /> },
    { id: 'studio', label: t(language, 'studio'), icon: <Sparkles className="w-4 h-4" /> },
    ...(!spectatorMode
      ? [
          { id: 'finance' as AppTab, label: t(language, 'finance'), icon: <Wallet className="w-4 h-4" /> },
          { id: 'admin' as AppTab, label: t(language, 'adminCenter'), icon: <Wrench className="w-4 h-4" /> },
        ]
      : []),
    { id: 'dashboard', label: t(language, 'analytics'), icon: <BarChart3 className="w-4 h-4" /> },
  ];

  const isMoreSectionActive =
    showMoreDrawer ||
    [
      'rankings',
      'courts',
      'matches',
      'knockout',
      'table',
      'h2h',
      'history',
      'news',
      'venue',
      'finance',
      'studio',
      'admin',
    ].includes(activeTab);

  return (
    <>
      {/* More Drawer: Analytics, Rankings, Courts, Reports, Backup & Restore, Settings, About */}
      {showMoreDrawer && (
        <div
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end md:items-center justify-center p-0 md:p-4 animate-fade-in"
          onClick={() => setShowMoreDrawer(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg bg-white dark:bg-[#141414] rounded-t-3xl md:rounded-3xl border-t md:border border-slate-200 dark:border-[#D4AF37]/30 shadow-2xl p-5 sm:p-6 space-y-5 max-h-[86vh] overflow-y-auto"
          >
            {/* Grab bar */}
            <div className="w-10 h-1.5 bg-slate-300 dark:bg-white/20 rounded-full mx-auto md:hidden" />

            {/* User & Role Header */}
            <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-white/10">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-11 h-11 rounded-2xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] flex items-center justify-center font-black shrink-0">
                  {userAccount?.verified ? (
                    <UserCheck className="w-5 h-5" />
                  ) : (
                    <User className="w-5 h-5" />
                  )}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-black text-[#172033] dark:text-white truncate">
                    {userAccount?.name || 'Tournament Organizer'}
                  </div>
                  <div className="text-xs text-[#64748B] dark:text-[#A0A0A0] truncate">
                    {userAccount?.verified
                      ? `${userAccount.role} · Verified Account`
                      : `Mode: ${userRoleMode.toUpperCase()} · Offline Ready`}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowMoreDrawer(false)}
                className="p-2 rounded-xl text-[#64748B] hover:text-[#172033] dark:hover:text-white cursor-pointer"
                aria-label="Close More Menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Account, Role & Theme Quick Actions */}
            <div className="grid grid-cols-3 gap-2">
              {onOpenAuthModal && (
                <button
                  type="button"
                  onClick={() => {
                    setShowMoreDrawer(false);
                    onOpenAuthModal();
                  }}
                  className="py-2.5 px-2.5 rounded-2xl bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-[11px] font-extrabold flex items-center justify-center gap-1 cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{userAccount?.verified ? 'Account' : 'Sign Up'}</span>
                </button>
              )}

              {onToggleRoleMode && (
                <button
                  type="button"
                  onClick={onToggleRoleMode}
                  className="py-2.5 px-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[#172033] dark:text-white text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5 text-[#FFD700] shrink-0" />
                  <span className="capitalize truncate">{userRoleMode}</span>
                </button>
              )}

              {onToggleDark && (
                <button
                  type="button"
                  onClick={onToggleDark}
                  className="py-2.5 px-2.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[#172033] dark:text-white text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                >
                  {isDark ? (
                    <>
                      <Sun className="w-3.5 h-3.5 text-[#FFD700] shrink-0" />
                      <span>Light</span>
                    </>
                  ) : (
                    <>
                      <Moon className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                      <span>Dark</span>
                    </>
                  )}
                </button>
              )}
            </div>

            {/* Sections Grid */}
            <div className="space-y-2">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#64748B] dark:text-[#A0A0A0]">
                Rankings, Courts, Analytics &amp; Brackets
              </div>
              <div className="grid grid-cols-4 gap-2">
                {sectionItems.map((sec) => {
                  const active = activeTab === sec.id;
                  return (
                    <button
                      key={sec.id}
                      type="button"
                      onClick={() => navigateAndClose(sec.id)}
                      className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center gap-1.5 text-center transition-all cursor-pointer min-h-[64px] ${
                        active
                          ? 'bg-[#D4AF37]/20 border-[#FFD700] text-[#172B4D] dark:text-[#FFD700]'
                          : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200/80 dark:border-white/10 text-[#172033] dark:text-white hover:border-[#D4AF37]'
                      }`}
                    >
                      <span className={active ? 'text-[#FFD700]' : 'text-[#D4AF37]'}>
                        {sec.icon}
                      </span>
                      <span className="text-[10px] font-bold leading-tight">{sec.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Reports, Backup & Restore, QR, Themes, Settings, About */}
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-white/10">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#64748B] dark:text-[#A0A0A0]">
                Reports, Backup &amp; System Tools
              </div>
              <div className="grid grid-cols-3 gap-2">
                {onOpenPDFModal && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreDrawer(false);
                      onOpenPDFModal();
                    }}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[11px] font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-[#FFD700]" />
                    <span>{t(language, 'reports')}</span>
                  </button>
                )}
                {onOpenShareModal && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreDrawer(false);
                      onOpenShareModal();
                    }}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[11px] font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Database className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>{t(language, 'backup')}</span>
                  </button>
                )}
                {onOpenQRModal && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreDrawer(false);
                      onOpenQRModal();
                    }}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[11px] font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <QrCode className="w-3.5 h-3.5 text-[#FFD700]" />
                    <span>{t(language, 'qrCode')}</span>
                  </button>
                )}
                {onOpenThemeStudio && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreDrawer(false);
                      onOpenThemeStudio();
                    }}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[11px] font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Palette className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Themes</span>
                  </button>
                )}
                {onOpenSettingsModal && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreDrawer(false);
                      onOpenSettingsModal();
                    }}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[11px] font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Settings className="w-3.5 h-3.5 text-[#A0A0A0]" />
                    <span>{t(language, 'settings')}</span>
                  </button>
                )}
                {onOpenAboutModal && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreDrawer(false);
                      onOpenAboutModal();
                    }}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[11px] font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Info className="w-3.5 h-3.5 text-[#FFD700]" />
                    <span>{t(language, 'about')}</span>
                  </button>
                )}
                {onToggleSpectatorMode && (
                  <button
                    type="button"
                    onClick={() => {
                      onToggleSpectatorMode();
                      setShowMoreDrawer(false);
                    }}
                    className={`p-2.5 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                      spectatorMode
                        ? 'bg-[#22C55E]/20 border-[#22C55E]/50 text-[#22C55E]'
                        : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200 dark:border-white/10 text-[#172033] dark:text-white'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5 text-[#FFD700]" />
                    <span>{spectatorMode ? 'Exit Public' : 'Spectator'}</span>
                  </button>
                )}
                {onOpenTutorial && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreDrawer(false);
                      onOpenTutorial();
                    }}
                    className="p-2.5 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[11px] font-bold text-[#172033] dark:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <HelpCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Tour Guide</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5-Tab Bottom Navigation Bar: Home, Tournaments, Live Scores, Players, More */}
      <nav
        aria-label="Primary Bottom Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#080808]/95 backdrop-blur-xl border-t border-slate-200 dark:border-[#D4AF37]/25 shadow-[0_-8px_24px_rgba(0,0,0,0.45)] pb-safe"
      >
        <div className="grid grid-cols-5 items-center h-16 max-w-xl mx-auto px-1">
          {/* 1. Home */}
          <button
            type="button"
            onClick={() => navigateAndClose('dashboard')}
            className={`flex flex-col items-center justify-center h-full transition-all duration-150 relative cursor-pointer ${
              activeTab === 'dashboard'
                ? 'text-[#172B4D] dark:text-[#FFD700] font-extrabold'
                : 'text-[#64748B] dark:text-[#A0A0A0]'
            }`}
          >
            {activeTab === 'dashboard' && (
              <span className="absolute top-0 w-7 h-0.5 rounded-full bg-[#D4AF37] dark:bg-[#FFD700]" />
            )}
            <Home className="w-4 h-4" strokeWidth={activeTab === 'dashboard' ? 2.4 : 1.8} />
            <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
              {t(language, 'home')}
            </span>
          </button>

          {/* 2. Tournaments */}
          <button
            type="button"
            onClick={() => navigateAndClose('tournaments')}
            className={`flex flex-col items-center justify-center h-full transition-all duration-150 relative cursor-pointer ${
              activeTab === 'tournaments'
                ? 'text-[#172B4D] dark:text-[#FFD700] font-extrabold'
                : 'text-[#64748B] dark:text-[#A0A0A0]'
            }`}
          >
            {activeTab === 'tournaments' && (
              <span className="absolute top-0 w-7 h-0.5 rounded-full bg-[#D4AF37] dark:bg-[#FFD700]" />
            )}
            <Trophy className="w-4 h-4" strokeWidth={activeTab === 'tournaments' ? 2.4 : 1.8} />
            <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
              {t(language, 'tournaments')}
            </span>
          </button>

          {/* 3. Live Scores Center Action */}
          <button
            type="button"
            onClick={() => navigateAndClose('live')}
            className="flex flex-col items-center justify-center h-full relative cursor-pointer"
          >
            <div
              className={`w-11 h-11 -mt-4 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-150 active:scale-95 ${
                activeTab === 'live'
                  ? 'bg-gradient-to-br from-[#D4AF37] to-[#FFD700] text-[#080808] ring-4 ring-[#FFD700]/30 scale-105'
                  : 'bg-[#172B4D] dark:bg-[#141414] text-[#FFD700] border border-[#D4AF37]/60'
              }`}
            >
              <Zap className="w-4 h-4" strokeWidth={2.5} />
            </div>
            <span
              className={`text-[10px] tracking-tight font-extrabold mt-0.5 whitespace-nowrap ${
                activeTab === 'live'
                  ? 'text-[#172B4D] dark:text-[#FFD700]'
                  : 'text-[#64748B] dark:text-[#A0A0A0]'
              }`}
            >
              {t(language, 'liveScores')}
            </span>
          </button>

          {/* 4. Players */}
          <button
            type="button"
            onClick={() => navigateAndClose('roster')}
            className={`flex flex-col items-center justify-center h-full transition-all duration-150 relative cursor-pointer ${
              activeTab === 'roster'
                ? 'text-[#172B4D] dark:text-[#FFD700] font-extrabold'
                : 'text-[#64748B] dark:text-[#A0A0A0]'
            }`}
          >
            {activeTab === 'roster' && (
              <span className="absolute top-0 w-7 h-0.5 rounded-full bg-[#D4AF37] dark:bg-[#FFD700]" />
            )}
            <Users className="w-4 h-4" strokeWidth={activeTab === 'roster' ? 2.4 : 1.8} />
            <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
              {t(language, 'players')}
            </span>
          </button>

          {/* 5. More */}
          <button
            type="button"
            onClick={() => setShowMoreDrawer((prev) => !prev)}
            className={`flex flex-col items-center justify-center h-full transition-all duration-150 relative cursor-pointer ${
              isMoreSectionActive
                ? 'text-[#172B4D] dark:text-[#FFD700] font-extrabold'
                : 'text-[#64748B] dark:text-[#A0A0A0]'
            }`}
          >
            {isMoreSectionActive && (
              <span className="absolute top-0 w-7 h-0.5 rounded-full bg-[#D4AF37] dark:bg-[#FFD700]" />
            )}
            <MoreHorizontal className="w-4 h-4" strokeWidth={isMoreSectionActive ? 2.4 : 1.8} />
            <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
              {t(language, 'more')}
            </span>
          </button>
        </div>
      </nav>
    </>
  );
};
