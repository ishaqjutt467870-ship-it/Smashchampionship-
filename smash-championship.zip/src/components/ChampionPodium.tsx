import React from 'react';
import { Trophy, Sparkles, Share2, RotateCcw } from 'lucide-react';
import { PlayerStats } from '../types';
import { getPlayerColor, getInitials } from '../utils/tournament';
import { fireConfetti } from '../utils/confetti';

interface ChampionPodiumProps {
  players: string[];
  finalWinner: number;
  runnerUp: number | null;
  thirdPlace: number | null;
  standings: PlayerStats[];
  onResetTournament: () => void;
  onOpenShareModal: () => void;
}

export const ChampionPodium: React.FC<ChampionPodiumProps> = ({
  players,
  finalWinner,
  runnerUp,
  thirdPlace,
  standings,
  onResetTournament,
  onOpenShareModal,
}) => {
  const championName = players[finalWinner];
  const championStats = standings.find((s) => s.id === finalWinner);
  const runnerUpName = runnerUp !== null ? players[runnerUp] : null;
  const thirdPlaceName = thirdPlace !== null ? players[thirdPlace] : null;

  return (
    <div className="bg-gradient-to-br from-[#172B4D] via-[#111E30] to-[#07111F] rounded-3xl p-6 sm:p-8 border border-[#B7F34A]/40 shadow-2xl text-center text-white relative overflow-hidden animate-fade-in">
      <div className="absolute top-2 left-6 text-6xl opacity-10 select-none pointer-events-none">🏸</div>
      <div className="absolute bottom-2 right-6 text-6xl opacity-10 select-none pointer-events-none">🏸</div>

      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#B7F34A]/15 text-[#B7F34A] text-xs font-extrabold border border-[#B7F34A]/40 mb-3">
        <Sparkles className="w-3.5 h-3.5" />
        <span>TOURNAMENT CONCLUDED</span>
      </div>

      <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
        Smash Champion Crowned!
      </h2>
      <p className="text-xs sm:text-sm text-[#94A3B8] max-w-md mx-auto mt-1">
        All tournament rounds and championship playoffs have successfully finished.
      </p>

      {/* Podium Stage */}
      <div className="mt-8 flex items-end justify-center gap-3 sm:gap-6 max-w-xl mx-auto">
        {/* 2nd Place (Silver) */}
        {runnerUpName && runnerUp !== null && (
          <div className="flex-1 flex flex-col items-center">
            <div className="relative mb-2">
              <div
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center text-[#07111F] font-black text-sm sm:text-base shadow-md"
                style={{ backgroundColor: getPlayerColor(runnerUp) }}
              >
                {getInitials(runnerUpName)}
              </div>
              <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-[#38BDF8] text-[#07111F] font-black text-xs flex items-center justify-center shadow">
                2
              </div>
            </div>
            <span className="font-bold text-xs sm:text-sm text-white truncate max-w-[100px] block">
              {runnerUpName}
            </span>
            <span className="text-[11px] text-[#94A3B8] font-medium">Runner-Up</span>
            <div className="w-full h-20 bg-[#07111F] rounded-t-xl mt-2 flex items-center justify-center text-[#38BDF8] font-bold text-xs border-t-2 border-[#38BDF8]">
              🥈 Silver
            </div>
          </div>
        )}

        {/* 1st Place (Electric Lime Champion) */}
        <div className="flex-1 flex flex-col items-center">
          <div className="relative mb-2">
            <div className="text-3xl animate-bounce mb-1">👑</div>
            <div
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl flex items-center justify-center text-[#07111F] font-black text-base sm:text-xl shadow-xl border-4 border-[#B7F34A]"
              style={{ backgroundColor: getPlayerColor(finalWinner) }}
            >
              {getInitials(championName)}
            </div>
            <div className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-[#B7F34A] text-[#07111F] font-black text-xs flex items-center justify-center shadow-lg">
              1
            </div>
          </div>
          <span className="font-black text-sm sm:text-base text-white truncate max-w-[130px] block mt-1">
            {championName}
          </span>
          <span className="text-xs font-black text-[#B7F34A]">CHAMPION</span>
          <div className="w-full h-32 bg-[#B7F34A]/15 rounded-t-2xl mt-2 flex flex-col items-center justify-center text-[#B7F34A] font-black text-xs border-t-4 border-[#B7F34A] shadow-sm p-1">
            <Trophy className="w-6 h-6 mb-1 text-[#B7F34A]" />
            <span>🏆 Gold</span>
          </div>
        </div>

        {/* 3rd Place (Bronze) */}
        {thirdPlaceName && thirdPlace !== null && (
          <div className="flex-1 flex flex-col items-center">
            <div className="relative mb-2">
              <div
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center text-[#07111F] font-black text-sm sm:text-base shadow-md"
                style={{ backgroundColor: getPlayerColor(thirdPlace) }}
              >
                {getInitials(thirdPlaceName)}
              </div>
              <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-slate-400 text-[#07111F] font-black text-xs flex items-center justify-center shadow">
                3
              </div>
            </div>
            <span className="font-bold text-xs sm:text-sm text-white truncate max-w-[100px] block">
              {thirdPlaceName}
            </span>
            <span className="text-[11px] text-[#94A3B8] font-medium">3rd Place</span>
            <div className="w-full h-14 bg-[#07111F] rounded-t-xl mt-2 flex items-center justify-center text-slate-300 font-bold text-xs border-t-2 border-slate-500">
              🥉 Bronze
            </div>
          </div>
        )}
      </div>

      {/* Champion Performance Card */}
      {championStats && (
        <div className="mt-8 max-w-md mx-auto p-4 rounded-2xl bg-[#07111F] border border-slate-800 shadow-sm flex items-center justify-around text-xs">
          <div>
            <span className="text-[#94A3B8] block">League Wins</span>
            <span className="text-base font-black text-white tabular-nums">
              {championStats.won} / {championStats.played}
            </span>
          </div>
          <div className="w-px h-8 bg-slate-800" />
          <div>
            <span className="text-[#94A3B8] block">League Points</span>
            <span className="text-base font-black text-[#B7F34A] tabular-nums">
              {championStats.points} pts
            </span>
          </div>
          <div className="w-px h-8 bg-slate-800" />
          <div>
            <span className="text-[#94A3B8] block">Status</span>
            <span className="text-base font-black text-[#38BDF8]">Gold MVP</span>
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={fireConfetti}
          className="px-4 py-2.5 rounded-xl bg-[#B7F34A] hover:bg-[#c8f86e] text-[#07111F] font-black text-xs transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
        >
          <Sparkles className="w-4 h-4" />
          <span>Fire Confetti Again</span>
        </button>

        <button
          onClick={onOpenShareModal}
          className="px-4 py-2.5 rounded-xl bg-[#38BDF8] hover:bg-[#5ecbfa] text-[#07111F] font-black text-xs transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
        >
          <Share2 className="w-4 h-4" />
          <span>Share Results</span>
        </button>

        <button
          onClick={onResetTournament}
          className="px-4 py-2.5 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Match Scores</span>
        </button>
      </div>
    </div>
  );
};
