import React, { useState, useRef, useEffect } from 'react';
import {
  Smartphone,
  Moon,
  Sun,
  Share2,
  Award,
  Home,
  Tv,
  Settings,
  FileText,
  Trophy,
  History,
  Bell,
  Lock,
  Globe,
  Play,
  Users,
  Calendar,
  Table2,
  Users2,
  Palette,
  UserPlus,
  UserCheck,
  Zap,
  Search,
  Medal,
  QrCode,
  Shield,
  Info,
  Eye,
  EyeOff,
  MapPin,
  Newspaper,
  Wallet,
  Sparkles,
  Wrench,
  ChevronDown,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { AppLanguage, TournamentMatch, UserAccount, UserRoleMode } from '../types';
import { t } from '../utils/i18n';

export type AppTab =
  | 'dashboard'
  | 'tournaments'
  | 'history'
  | 'roster'
  | 'matches'
  | 'table'
  | 'knockout'
  | 'courts'
  | 'h2h'
  | 'rankings'
  | 'news'
  | 'venue'
  | 'finance'
  | 'studio'
  | 'admin'
  | 'live';

interface HeaderProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  tournamentStarted: boolean;
  isDark: boolean;
  setIsDark: (val: boolean) => void;
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  hasPin: boolean;
  onPinAction: () => void;
  userRoleMode?: UserRoleMode;
  onToggleRoleMode?: () => void;
  spectatorMode?: boolean;
  onToggleSpectatorMode?: () => void;
  upcomingMatches?: TournamentMatch[];
  players?: string[];
  onLaunchLiveFromReminder?: (matchId: string) => void;
  onOpenAndroidModal: () => void;
  onOpenShareModal: () => void;
  onOpenPDFModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenThemeStudio: () => void;
  onOpenAuthModal: () => void;
  onOpenQuickMatch?: () => void;
  onOpenGlobalSearch?: () => void;
  onOpenQRModal?: () => void;
  onOpenAboutModal?: () => void;
  userAccount?: UserAccount | null;
  completedMatchesCount: number;
  totalMatchesCount: number;
  customLogoUrl?: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  tournamentStarted,
  isDark,
  setIsDark,
  language,
  setLanguage,
  hasPin,
  onPinAction,
  userRoleMode = 'admin',
  onToggleRoleMode,
  spectatorMode = false,
  onToggleSpectatorMode,
  upcomingMatches = [],
  players = [],
  onLaunchLiveFromReminder,
  onOpenAndroidModal,
  onOpenShareModal,
  onOpenPDFModal,
  onOpenSettingsModal,
  onOpenThemeStudio,
  onOpenAuthModal,
  onOpenQuickMatch,
  onOpenGlobalSearch,
  onOpenQRModal,
  onOpenAboutModal,
  userAccount,
  completedMatchesCount,
  totalMatchesCount,
  customLogoUrl,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showHubsMenu, setShowHubsMenu] = useState(false);
  const bellRef = useRef<HTMLDivElement>(null);
  const hubsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (bellRef.current && !bellRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
      if (hubsRef.current && !hubsRef.current.contains(e.target as Node)) {
        setShowHubsMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems: Array<{ id: AppTab; label: string; icon?: React.ReactNode }> = [
    { id: 'dashboard', label: t(language, 'home'), icon: <Home className="w-3.5 h-3.5" /> },
    { id: 'tournaments', label: t(language, 'tournaments'), icon: <Trophy className="w-3.5 h-3.5" /> },
    { id: 'roster', label: t(language, 'players'), icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'matches', label: t(language, 'matches'), icon: <Calendar className="w-3.5 h-3.5" /> },
    { id: 'table', label: t(language, 'standings'), icon: <Table2 className="w-3.5 h-3.5" /> },
    { id: 'knockout', label: t(language, 'playoffs'), icon: <Award className="w-3.5 h-3.5" /> },
    { id: 'rankings', label: t(language, 'rankings'), icon: <Medal className="w-3.5 h-3.5" /> },
    { id: 'courts', label: t(language, 'courts'), icon: <Tv className="w-3.5 h-3.5" /> },
    { id: 'h2h', label: t(language, 'h2h'), icon: <Users2 className="w-3.5 h-3.5" /> },
    { id: 'history', label: t(language, 'history'), icon: <History className="w-3.5 h-3.5" /> },
  ];

  const hubItems: Array<{ id: AppTab; label: string; icon: React.ReactNode }> = [
    { id: 'venue', label: t(language, 'venue'), icon: <MapPin className="w-3.5 h-3.5 text-[#FFD700]" /> },
    { id: 'news', label: t(language, 'news'), icon: <Newspaper className="w-3.5 h-3.5 text-[#D4AF37]" /> },
    { id: 'studio', label: t(language, 'studio'), icon: <Sparkles className="w-3.5 h-3.5 text-[#FFD700]" /> },
    ...(!spectatorMode
      ? [
          { id: 'finance' as AppTab, label: t(language, 'finance'), icon: <Wallet className="w-3.5 h-3.5 text-[#22C55E]" /> },
          { id: 'admin' as AppTab, label: t(language, 'adminCenter'), icon: <Wrench className="w-3.5 h-3.5 text-[#D4AF37]" /> },
        ]
      : []),
  ];

  const isHubActive = ['venue', 'news', 'studio', 'finance', 'admin'].includes(activeTab);

  const playableUpcoming = upcomingMatches.filter((m) => !m.isBye && m.playerBIndex >= 0);

  return (
    <header className="sticky top-0 z-30 bg-[#172B4D]/95 dark:bg-[#080808]/95 backdrop-blur-xl text-white border-b border-white/10 dark:border-[#D4AF37]/25 shadow-lg transition-colors w-full max-w-full">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Zone 1: Brand lockup */}
        <div className="flex items-center gap-2.5 shrink-0 min-w-0">
          <button
            onClick={onOpenSettingsModal}
            className="w-10 h-10 rounded-2xl bg-[#141414] border border-[#D4AF37]/60 flex items-center justify-center text-[#FFD700] font-bold shadow-inner shrink-0 overflow-hidden hover:border-[#FFD700] hover:scale-105 transition-all cursor-pointer"
            title="Hassan Badminton Tournament Manager — Click for Settings"
            aria-label="Tournament Logo"
          >
            <img
              src={customLogoUrl || '/logo.png'}
              alt="Hassan Badminton Tournament Manager Logo"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-xl"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/icon.svg';
              }}
            />
          </button>
          <div className="flex flex-col min-w-0">
            <span className="font-black text-sm sm:text-base tracking-tight text-white whitespace-nowrap truncate">
              Smash Championship
            </span>
            <div className="text-[10px] sm:text-[11px] whitespace-nowrap flex items-center gap-1.5 -mt-0.5">
              <span className="font-bold text-[#FFD700]">Developed By Hassan</span>
              <span className="text-[#A0A0A0] hidden sm:inline">·</span>
              <span className="text-[10px] text-[#A0A0A0] tracking-tight font-medium hidden sm:inline">
                Hassan Badminton Manager
              </span>
            </div>
          </div>
        </div>

        {/* Zone 2: Desktop Single-Line Nav */}
        <nav className="hidden xl:flex items-center gap-0.5 text-xs font-semibold">
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-2 py-1.5 rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-1 cursor-pointer ${
                  active
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-extrabold shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.id === 'matches' && tournamentStarted && totalMatchesCount > 0 && (
                  <span
                    className={`text-[10px] px-1 rounded font-mono ${
                      active ? 'bg-[#080808]/15 text-[#080808]' : 'bg-white/10 text-[#FFD700]'
                    }`}
                  >
                    {completedMatchesCount}/{totalMatchesCount}
                  </span>
                )}
              </button>
            );
          })}

          {/* Expansion Hubs Dropdown */}
          <div className="relative" ref={hubsRef}>
            <button
              type="button"
              onClick={() => setShowHubsMenu((prev) => !prev)}
              className={`px-2 py-1.5 rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-1 cursor-pointer ${
                isHubActive
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-extrabold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <span>{t(language, 'more')}</span>
              <ChevronDown className="w-3 h-3" />
            </button>

            {showHubsMenu && (
              <div className="absolute right-0 top-10 w-52 bg-[#141414] border border-[#D4AF37]/40 rounded-2xl shadow-2xl p-2 z-50 space-y-1 animate-fade-in">
                {hubItems.map((hub) => {
                  const active = activeTab === hub.id;
                  return (
                    <button
                      key={hub.id}
                      type="button"
                      onClick={() => {
                        setActiveTab(hub.id);
                        setShowHubsMenu(false);
                      }}
                      className={`w-full px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                        active
                          ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black'
                          : 'text-slate-200 hover:bg-white/10'
                      }`}
                    >
                      <span className={active ? 'text-[#080808]' : ''}>{hub.icon}</span>
                      <span>{hub.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <button
            onClick={() => setActiveTab('live')}
            className={`ml-1 px-2.5 py-1.5 rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-1 cursor-pointer ${
              activeTab === 'live'
                ? 'bg-[#FFD700] text-[#080808] font-black shadow-md'
                : 'bg-[#D4AF37]/15 text-[#FFD700] border border-[#D4AF37]/45 hover:bg-[#FFD700] hover:text-[#080808] font-bold'
            }`}
          >
            <span>🏸 {t(language, 'liveScores')}</span>
          </button>
        </nav>

        {/* Zone 3: Quick Actions */}
        <div className="flex items-center gap-1 shrink-0">
          {onOpenGlobalSearch && (
            <button
              type="button"
              onClick={onOpenGlobalSearch}
              className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-slate-200 hover:text-white text-[11px] font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              title="Global Search (Ctrl+K)"
              aria-label="Global Search"
            >
              <Search className="w-3.5 h-3.5 text-[#FFD700]" />
              <span className="hidden lg:inline text-[10px] font-mono text-[#A0A0A0]">⌘K</span>
            </button>
          )}

          {onToggleSpectatorMode && (
            <button
              type="button"
              onClick={onToggleSpectatorMode}
              className={`flex items-center gap-1 px-2 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider border cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                spectatorMode
                  ? 'bg-[#22C55E]/20 border-[#22C55E]/60 text-[#22C55E]'
                  : 'bg-white/10 border-white/15 text-slate-200 hover:border-[#D4AF37]'
              }`}
              title={
                spectatorMode
                  ? 'Public Spectator Mode Active — Click to exit'
                  : 'Switch to Public Spectator View'
              }
            >
              {spectatorMode ? (
                <Eye className="w-3.5 h-3.5" />
              ) : (
                <EyeOff className="w-3.5 h-3.5 text-[#D4AF37]" />
              )}
              <span className="hidden lg:inline">{spectatorMode ? 'Spectator' : 'Public'}</span>
            </button>
          )}

          {onOpenQuickMatch && !spectatorMode && (
            <button
              type="button"
              onClick={onOpenQuickMatch}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-black text-[11px] hover:opacity-95 transition-opacity cursor-pointer whitespace-nowrap shrink-0"
              title="Start an Instant Quick Match (1v1 or 2v2)"
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span className="hidden sm:inline">Quick</span>
            </button>
          )}

          {onToggleRoleMode && !spectatorMode && (
            <button
              type="button"
              onClick={onToggleRoleMode}
              className={`hidden md:flex items-center gap-1 px-2 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider border cursor-pointer transition-colors ${
                userRoleMode === 'admin'
                  ? 'bg-[#D4AF37]/15 border-[#D4AF37]/45 text-[#FFD700]'
                  : 'bg-[#22C55E]/15 border-[#22C55E]/40 text-[#22C55E]'
              }`}
              title={`Current Role: ${userRoleMode.toUpperCase()} — Click to switch`}
            >
              <Shield className="w-3 h-3" />
              <span>{userRoleMode}</span>
            </button>
          )}

          {onOpenQRModal && (
            <button
              type="button"
              onClick={onOpenQRModal}
              className="hidden sm:flex p-2 text-[#FFD700] hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              title="QR Code Sharing & Player Lookup"
              aria-label="QR Code Center"
            >
              <QrCode className="w-4 h-4" />
            </button>
          )}

          <button
            type="button"
            onClick={onOpenThemeStudio}
            className="hidden sm:flex p-2 text-[#D4AF37] hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title="120+ Dynamic Themes & Wallpapers"
            aria-label="Themes and Wallpapers Studio"
          >
            <Palette className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenAuthModal}
            className={`hidden md:flex items-center gap-1 px-2 py-1.5 rounded-xl text-[11px] font-extrabold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              userAccount?.verified
                ? 'bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/40'
                : 'bg-white/10 hover:bg-white/15 text-white border border-white/15'
            }`}
            title={
              userAccount?.verified
                ? `Verified: ${userAccount.name}`
                : 'Sign Up with Name, Email or Mobile Verification'
            }
          >
            {userAccount?.verified ? (
              <UserCheck className="w-3.5 h-3.5" />
            ) : (
              <UserPlus className="w-3.5 h-3.5 text-[#FFD700]" />
            )}
          </button>

          {/* Match Reminders Bell */}
          <div className="relative" ref={bellRef}>
            <button
              type="button"
              onClick={() => setShowNotifications((prev) => !prev)}
              className="relative p-2 text-slate-300 hover:text-[#FFD700] hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              title="Upcoming Match Schedule & Alerts"
              aria-label="Upcoming Match Reminders"
            >
              <Bell className="w-4 h-4" />
              {playableUpcoming.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-[#FFD700] text-[#080808] text-[9px] font-black flex items-center justify-center">
                  {playableUpcoming.length > 9 ? '9+' : playableUpcoming.length}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="fixed sm:absolute right-3 sm:right-0 top-16 sm:top-11 w-72 bg-[#141414] border border-[#D4AF37]/35 rounded-2xl shadow-2xl p-4 z-50 text-left space-y-3 animate-fade-in">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="text-xs font-black text-white uppercase tracking-wider">
                    Upcoming Match Queue
                  </span>
                  <span className="text-[10px] font-mono text-[#FFD700]">
                    {playableUpcoming.length} queued
                  </span>
                </div>
                {playableUpcoming.length === 0 ? (
                  <p className="text-xs text-[#A0A0A0] py-2">
                    All fixtures in this tournament are completed!
                  </p>
                ) : (
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {playableUpcoming.slice(0, 4).map((m, i) => (
                      <div
                        key={m.id}
                        className="p-2.5 rounded-xl bg-[#080808] border border-white/10 flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0">
                          <div className="text-[10px] font-mono text-[#A0A0A0]">
                            Match #{m.roundNumber || i + 1}
                            {m.group ? ` · Group ${m.group}` : ''}
                          </div>
                          <div className="text-xs font-bold text-white truncate">
                            {players[m.playerAIndex]} vs {players[m.playerBIndex]}
                          </div>
                        </div>
                        {onLaunchLiveFromReminder && (
                          <button
                            type="button"
                            onClick={() => {
                              onLaunchLiveFromReminder(m.id);
                              setShowNotifications(false);
                            }}
                            className="p-1.5 rounded-lg bg-[#FFD700] text-[#080808] hover:opacity-90 shrink-0 cursor-pointer"
                            title="Score Live"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Language Toggle */}
          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
            className="hidden sm:flex items-center gap-1 px-2 py-1.5 rounded-xl text-[11px] font-extrabold text-slate-200 hover:text-[#FFD700] hover:bg-white/10 transition-colors cursor-pointer"
            title="Switch Language (English / اردو)"
          >
            <Globe className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{language.toUpperCase()}</span>
          </button>

          {/* PIN Lock Button */}
          <button
            type="button"
            onClick={onPinAction}
            className={`hidden sm:flex p-2 rounded-xl transition-colors cursor-pointer ${
              hasPin
                ? 'text-[#FFD700] hover:bg-white/10'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title={hasPin ? 'Lock App Now' : 'Set Security PIN'}
            aria-label="Security PIN"
          >
            <Lock className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenPDFModal}
            className="hidden md:flex p-2 text-slate-300 hover:text-[#FFD700] hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title="Official Certificate, PDF & Posters"
            aria-label="Certificate & PDF"
          >
            <FileText className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenShareModal}
            className="hidden sm:flex p-2 text-slate-300 hover:text-[#FFD700] hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title="Backup, Restore & Export"
            aria-label="Share tournament"
          >
            <Share2 className="w-4 h-4" />
          </button>

          {onOpenAboutModal && (
            <button
              type="button"
              onClick={onOpenAboutModal}
              className="hidden lg:flex p-2 text-slate-300 hover:text-[#FFD700] hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              title="About Hassan Badminton Tournament Manager"
              aria-label="About App"
            >
              <Info className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={onOpenSettingsModal}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title="Tournament Rules, Security & Settings"
            aria-label="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsDark(!isDark)}
            className="p-2 text-slate-300 hover:text-[#FFD700] hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle Dark Mode"
          >
            {isDark ? <Sun className="w-4 h-4 text-[#FFD700]" /> : <Moon className="w-4 h-4 text-[#D4AF37]" />}
          </button>

          <div className="hidden sm:block">
            <PWAInstallButton />
          </div>

          <button
            onClick={onOpenAndroidModal}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] hover:opacity-95 text-[#080808] text-xs font-extrabold rounded-xl transition-colors shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
            title="Download Android Studio Project ZIP"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Android ZIP</span>
          </button>
        </div>
      </div>

      {/* Tablet / Mobile Secondary Horizontal Navigation Strip */}
      <div className="xl:hidden border-t border-white/10 bg-[#111E30]/95 dark:bg-[#0A0A0A]/95 px-3 py-1.5 overflow-x-auto flex items-center gap-1.5">
        {[...navItems, ...hubItems].map((item) => {
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap shrink-0 flex items-center gap-1 transition-all cursor-pointer ${
                active
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808]'
                  : 'text-[#A0A0A0] hover:text-white bg-white/5'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
