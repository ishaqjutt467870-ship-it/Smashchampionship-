import React, { useState, useEffect, useRef } from 'react';
import {
  Volume2,
  VolumeX,
  RotateCcw,
  RotateCw,
  Sparkles,
  Trophy,
  ArrowRightLeft,
  Timer,
  Play,
  Pause,
  Lock,
  Unlock,
  Tv,
  Activity,
  Camera,
  Clock,
  Minus,
  Plus,
  Zap,
  Mic,
  MicOff,
  Sun,
  Award,
  Flag,
  ShieldCheck,
  CheckCircle2,
  Users,
  X,
  AlertTriangle,
  HeartPulse,
  ClipboardCheck,
  FileWarning,
  ShieldAlert,
} from 'lucide-react';
import {
  TournamentMatch,
  MatchScore,
  MatchFormat,
  CustomTournamentRules,
  CompetitionCategory,
  CourtRecord,
  MatchMetaInfo,
  MatchIncident,
  ScoreAuditEntry,
  UserRoleMode,
} from '../types';
import {
  getPlayerColor,
  getInitials,
  getSetsRequiredToWin,
  getMaxSets,
  getFormatLabel,
  clampPointsPerSet,
  getSuggestedInterval,
  getSuggestedDeuceCap,
  DEFAULT_COURTS,
} from '../utils/tournament';
import {
  playShuttleHitSound,
  playPointChime,
  playAlertTone,
  playIntervalBuzzer,
  playMatchPointSound,
  playGameWonSound,
  playMatchWonFanfare,
  toggleAudioMute,
  getAudioMuted,
  getVoiceUmpireEnabled,
  toggleVoiceUmpire,
  speakUmpireCall,
} from '../utils/audio';
import { fireConfetti } from '../utils/confetti';
import { downloadScoreboardImage } from '../utils/exports';
import { ShuttleTossModal } from './ShuttleTossModal';
import { BigScreenScoreboard } from './BigScreenScoreboard';
import { ConfirmModal } from './ConfirmModal';

export type WinningShotType =
  | 'Smash'
  | 'Drop'
  | 'Net Shot'
  | 'Clear'
  | 'Drive'
  | 'Unforced Error'
  | 'Fault';

interface ScoreSnapshot {
  a: number;
  b: number;
  server: 'A' | 'B';
  partnerIdxA: 0 | 1;
  partnerIdxB: 0 | 1;
  completedSets: Array<{ a: number; b: number }>;
  currentSet: number;
  sideAOnLeft: boolean;
  rallyEntry?: {
    set: number;
    winner: 'A' | 'B';
    server: 'A' | 'B';
    shot: WinningShotType;
    rallySec: number;
    scoreA: number;
    scoreB: number;
  };
}

interface LiveCourtScorerProps {
  players: string[];
  fixtures: TournamentMatch[];
  playerPhotos?: Record<number, string>;
  matchFormat: MatchFormat;
  matchFormats?: Record<string, MatchFormat>;
  onSetMatchItemFormat?: (matchId: string, fmt: MatchFormat) => void;
  tournamentTitle?: string;
  competitionCategory?: CompetitionCategory;
  customRules?: CustomTournamentRules;
  onUpdateCustomRules?: (rules: CustomTournamentRules) => void;
  courts?: CourtRecord[];
  userRoleMode?: UserRoleMode;
  defaultDurationMinutes?: number;
  animationsEnabled?: boolean;
  onOpenQuickMatch?: () => void;
  onSaveMatchResult: (
    matchId: string,
    winnerIndex: number,
    score: MatchScore,
    mvpPlayerIndex?: number,
    meta?: MatchMetaInfo,
    courtNumber?: number
  ) => void;
  initialMatchId?: string;
  initialCourtNumber?: number;
}

function splitPartners(name: string): string[] {
  const parts = name
    .split(/[/&+]| and /i)
    .map((p) => p.trim())
    .filter(Boolean);
  return parts.length >= 2 ? parts.slice(0, 2) : [name];
}

export const LiveCourtScorer: React.FC<LiveCourtScorerProps> = ({
  players,
  fixtures,
  playerPhotos,
  matchFormat,
  matchFormats = {},
  onSetMatchItemFormat,
  tournamentTitle = 'Smash Championship',
  competitionCategory = 'singles',
  customRules,
  onUpdateCustomRules,
  courts = DEFAULT_COURTS,
  userRoleMode = 'admin',
  defaultDurationMinutes = 30,
  animationsEnabled = true,
  onOpenQuickMatch,
  onSaveMatchResult,
  initialMatchId,
  initialCourtNumber = 1,
}) => {
  const playableFixtures = fixtures.filter((f) => !f.isBye && f.playerBIndex >= 0);

  const targetPoints = clampPointsPerSet(customRules?.pointsPerSet ?? 21);
  const maxDeuceCap = customRules?.maxDeuceCap ?? getSuggestedDeuceCap(targetPoints);
  const intervalPoint = customRules?.intervalAt ?? getSuggestedInterval(targetPoints);

  const handleAdjustTargetPoints = (delta: number) => {
    if (!onUpdateCustomRules) return;
    const nextPts = clampPointsPerSet(targetPoints + delta);
    onUpdateCustomRules({
      refereeName: customRules?.refereeName ?? 'Hassan',
      pointsPerSet: nextPts,
      intervalAt: getSuggestedInterval(nextPts),
      maxDeuceCap: getSuggestedDeuceCap(nextPts),
    });
  };

  const [selectedMatchId, setSelectedMatchId] = useState<string>(
    initialMatchId || (playableFixtures.length > 0 ? playableFixtures[0].id : '')
  );
  const [courtNumber, setCourtNumber] = useState<number>(initialCourtNumber);
  const [isBigScreenOpen, setIsBigScreenOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isCompleteConfirmOpen, setIsCompleteConfirmOpen] = useState(false);
  const [isRetireWalkoverOpen, setIsRetireWalkoverOpen] = useState(false);
  const [forcedOutcome, setForcedOutcome] = useState<{
    type: 'retired' | 'walkover';
    winnerSide: 'A' | 'B';
    note: string;
  } | null>(null);
  const [retireModeType, setRetireModeType] = useState<'retired' | 'walkover'>('retired');
  const [retireSide, setRetireSide] = useState<'A' | 'B'>('B');
  const [retireNote, setRetireNote] = useState('');

  const [isUmpireLocked, setIsUmpireLocked] = useState(false);
  const [selectedShotType, setSelectedShotType] = useState<WinningShotType>('Smash');
  const [rallyDuration, setRallyDuration] = useState<number>(8);
  const [rallyLog, setRallyLog] = useState<
    Array<{
      set: number;
      winner: 'A' | 'B';
      server: 'A' | 'B';
      shot: WinningShotType;
      rallySec: number;
      scoreA: number;
      scoreB: number;
    }>
  >([]);

  const [incidents, setIncidents] = useState<MatchIncident[]>([]);
  const [auditTrail, setAuditTrail] = useState<ScoreAuditEntry[]>([]);
  const [intervalCount, setIntervalCount] = useState(0);
  const [endsSwitchedCount, setEndsSwitchedCount] = useState(0);
  const [incidentSide, setIncidentSide] = useState<'A' | 'B' | 'General'>('A');
  const [incidentNoteInput, setIncidentNoteInput] = useState('');
  const [refereeVerified, setRefereeVerified] = useState(false);
  const [verifiedByName, setVerifiedByName] = useState(customRules?.refereeName || 'Hassan');

  const [matchElapsedSec, setMatchElapsedSec] = useState(0);
  const [matchTimerRunning, setMatchTimerRunning] = useState(true);

  const [currentSet, setCurrentSet] = useState(1);
  const [pointsA, setPointsA] = useState(0);
  const [pointsB, setPointsB] = useState(0);
  const [server, setServer] = useState<'A' | 'B'>('A');
  const [partnerIdxA, setPartnerIdxA] = useState<0 | 1>(0);
  const [partnerIdxB, setPartnerIdxB] = useState<0 | 1>(0);
  const [sideAOnLeft, setSideAOnLeft] = useState(true);
  const [history, setHistory] = useState<ScoreSnapshot[]>([]);
  const [redoStack, setRedoStack] = useState<ScoreSnapshot[]>([]);
  const [completedSets, setCompletedSets] = useState<Array<{ a: number; b: number }>>([]);
  const [isMuted, setIsMuted] = useState(getAudioMuted());
  const [voiceEnabled, setVoiceEnabled] = useState(getVoiceUmpireEnabled());
  const [keepAwake, setKeepAwake] = useState(false);
  const wakeLockRef = useRef<{ release: () => Promise<void> } | null>(null);

  const [shuttleType, setShuttleType] = useState<'feather' | 'nylon'>('feather');
  const [shuttleBrand, setShuttleBrand] = useState('Yonex Aerosensa 50');
  const [shuttleSpeed, setShuttleSpeed] = useState<76 | 77 | 78>(77);
  const [shuttlesUsed, setShuttlesUsed] = useState(1);
  const [isTossOpen, setIsTossOpen] = useState(false);

  const [timerSeconds, setTimerSeconds] = useState<number | null>(null);
  const [timerActive, setTimerActive] = useState(false);
  const [intervalTitle, setIntervalTitle] = useState('');
  const [designateMvp, setDesignateMvp] = useState(false);
  const [savedBanner, setSavedBanner] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const syncWakeLock = async () => {
      try {
        if (keepAwake && 'wakeLock' in navigator) {
          const sentinel = await (
            navigator as unknown as {
              wakeLock: { request: (type: 'screen') => Promise<{ release: () => Promise<void> }> };
            }
          ).wakeLock.request('screen');
          if (active) wakeLockRef.current = sentinel;
        } else {
          await wakeLockRef.current?.release().catch(() => {});
          wakeLockRef.current = null;
        }
      } catch {
        // ignore restricted environments
      }
    };
    syncWakeLock();
    return () => {
      active = false;
      wakeLockRef.current?.release().catch(() => {});
      wakeLockRef.current = null;
    };
  }, [keepAwake]);

  useEffect(() => {
    if (initialMatchId && initialMatchId !== selectedMatchId) {
      setSelectedMatchId(initialMatchId);
      setCurrentSet(1);
      setPointsA(0);
      setPointsB(0);
      setPartnerIdxA(0);
      setPartnerIdxB(0);
      setHistory([]);
      setRedoStack([]);
      setCompletedSets([]);
      setRallyLog([]);
      setIncidents([]);
      setAuditTrail([]);
      setIntervalCount(0);
      setEndsSwitchedCount(0);
      setRefereeVerified(false);
      setMatchElapsedSec(0);
      setDesignateMvp(false);
      setForcedOutcome(null);
      setSavedBanner(null);
    }
  }, [initialMatchId]);

  useEffect(() => {
    if (initialCourtNumber) setCourtNumber(initialCourtNumber);
  }, [initialCourtNumber]);

  const activeMatch =
    playableFixtures.find((f) => f.id === selectedMatchId) || playableFixtures[0];
  const activeMatchFormat: MatchFormat =
    (activeMatch && matchFormats[activeMatch.id]) || matchFormat;
  const playerA = activeMatch ? players[activeMatch.playerAIndex] || 'Player 1' : 'Player 1';
  const playerB = activeMatch ? players[activeMatch.playerBIndex] || 'Player 2' : 'Player 2';
  const photoA = activeMatch ? playerPhotos?.[activeMatch.playerAIndex] : undefined;
  const photoB = activeMatch ? playerPhotos?.[activeMatch.playerBIndex] : undefined;
  const colorA = activeMatch ? getPlayerColor(activeMatch.playerAIndex) : '#D4AF37';
  const colorB = activeMatch ? getPlayerColor(activeMatch.playerBIndex) : '#A0A0A0';

  const partnersA = splitPartners(playerA);
  const partnersB = splitPartners(playerB);
  const isDoublesMatch =
    competitionCategory !== 'singles' || partnersA.length > 1 || partnersB.length > 1;
  const activePartnerName =
    server === 'A'
      ? partnersA[partnerIdxA % partnersA.length]
      : partnersB[partnerIdxB % partnersB.length];

  const setsToWin = getSetsRequiredToWin(activeMatchFormat);
  const setsWonA = completedSets.filter((s) => s.a > s.b).length;
  const setsWonB = completedSets.filter((s) => s.b > s.a).length;

  let matchWinner: 'A' | 'B' | null = forcedOutcome ? forcedOutcome.winnerSide : null;
  if (!matchWinner) {
    if (activeMatchFormat === 'bo2') {
      if (setsWonA >= 2) matchWinner = 'A';
      else if (setsWonB >= 2) matchWinner = 'B';
      else if (completedSets.length >= 2) {
        const totalPtsA = completedSets.reduce((sum, s) => sum + s.a, 0);
        const totalPtsB = completedSets.reduce((sum, s) => sum + s.b, 0);
        if (totalPtsA > totalPtsB) matchWinner = 'A';
        else if (totalPtsB > totalPtsA) matchWinner = 'B';
        else matchWinner = completedSets[1].a >= completedSets[1].b ? 'A' : 'B';
      }
    } else {
      matchWinner = setsWonA >= setsToWin ? 'A' : setsWonB >= setsToWin ? 'B' : null;
    }
  }

  // Match clock ticker
  useEffect(() => {
    if (!matchTimerRunning || matchWinner) return;
    const id = setInterval(() => {
      setMatchElapsedSec((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(id);
  }, [matchTimerRunning, matchWinner]);

  // Interval timer tick
  useEffect(() => {
    if (!timerActive || timerSeconds === null || timerSeconds <= 0) return;
    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev === null || prev <= 1) {
          setTimerActive(false);
          playIntervalBuzzer();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [timerActive, timerSeconds]);

  const formatClock = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const serverPoints = server === 'A' ? pointsA : pointsB;
  const serverCourtSide: 'right' | 'left' = serverPoints % 2 === 0 ? 'right' : 'left';

  const isGamePointA =
    (pointsA >= targetPoints - 1 && pointsA - pointsB >= 1) || pointsA === maxDeuceCap - 1;
  const isGamePointB =
    (pointsB >= targetPoints - 1 && pointsB - pointsA >= 1) || pointsB === maxDeuceCap - 1;
  const isMatchPointA = isGamePointA && setsWonA === setsToWin - 1;
  const isMatchPointB = isGamePointB && setsWonB === setsToWin - 1;
  const isDeuce =
    pointsA >= targetPoints - 1 && pointsB >= targetPoints - 1 && pointsA === pointsB;

  const appendAudit = (action: string, previousValue?: string, nextValue?: string) => {
    const entry: ScoreAuditEntry = {
      id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toLocaleTimeString(),
      action,
      actor: verifiedByName || customRules?.refereeName || 'Referee',
      previousValue,
      nextValue,
    };
    setAuditTrail((prev) => [entry, ...prev].slice(0, 60));
  };

  const handleLogIncident = (
    type: MatchIncident['type'],
    sideOverride?: 'A' | 'B' | 'General',
    customNote?: string
  ) => {
    if (!activeMatch) return;
    const targetSide = sideOverride || incidentSide;
    const targetName =
      targetSide === 'A' ? playerA : targetSide === 'B' ? playerB : 'Court / Match';
    const labels: Record<MatchIncident['type'], string> = {
      service_fault: 'Service Fault',
      let: 'Let Called',
      medical_timeout: 'Medical Timeout (2:00)',
      warning: 'Verbal Warning',
      yellow_card: 'Yellow Card (Misconduct)',
      red_card: 'Red Card (Fault Penalty)',
      incident: 'Match Note / Incident',
    };
    const note =
      customNote?.trim() ||
      incidentNoteInput.trim() ||
      `${labels[type]} recorded for ${targetName}`;

    const item: MatchIncident = {
      id: `inc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      time: formatClock(matchElapsedSec),
      type,
      playerSide: targetSide,
      note,
    };
    setIncidents((prev) => [item, ...prev]);
    setIncidentNoteInput('');
    appendAudit(labels[type], `${pointsA}-${pointsB}`, note);

    if (type === 'medical_timeout') {
      playAlertTone();
      setTimerSeconds(120);
      setTimerActive(true);
      setIntervalTitle(`Medical Timeout (120s) · ${targetName}`);
      speakUmpireCall(`Medical timeout called for ${targetName}.`);
    } else if (type === 'let') {
      speakUmpireCall('Play a let.');
    } else if (type === 'service_fault') {
      speakUmpireCall('Service fault.');
    } else if (type === 'yellow_card') {
      playAlertTone();
      speakUmpireCall(`${targetName}, warning for misconduct.`);
    } else if (type === 'red_card') {
      playAlertTone();
      speakUmpireCall(`${targetName}, fault for misconduct.`);
    }
  };

  const handlePointScored = (winner: 'A' | 'B') => {
    if (matchWinner || isUmpireLocked || !activeMatch) return;

    playShuttleHitSound();
    playPointChime();

    const nextA = winner === 'A' ? pointsA + 1 : pointsA;
    const nextB = winner === 'B' ? pointsB + 1 : pointsB;
    const newRallyEntry = {
      set: currentSet,
      winner,
      server,
      shot: selectedShotType,
      rallySec: rallyDuration,
      scoreA: nextA,
      scoreB: nextB,
    };

    setHistory((prev) => [
      ...prev,
      {
        a: pointsA,
        b: pointsB,
        server,
        partnerIdxA,
        partnerIdxB,
        completedSets: [...completedSets],
        currentSet,
        sideAOnLeft,
        rallyEntry: newRallyEntry,
      },
    ]);
    setRedoStack([]);
    appendAudit(
      `Point ${winner === 'A' ? playerA : playerB} (${selectedShotType})`,
      `${pointsA}-${pointsB}`,
      `${nextA}-${nextB}`
    );

    // Rotate doubles partner when service changes hands to the winning team
    if (isDoublesMatch && server !== winner) {
      if (winner === 'A') {
        setPartnerIdxA((nextA % 2 === 0 ? 0 : 1) as 0 | 1);
      } else {
        setPartnerIdxB((nextB % 2 === 0 ? 0 : 1) as 0 | 1);
      }
    }

    setPointsA(nextA);
    setPointsB(nextB);
    setServer(winner);
    setRallyLog((prev) => [...prev, newRallyEntry]);

    if (
      (nextA === intervalPoint && nextB < intervalPoint) ||
      (nextB === intervalPoint && nextA < intervalPoint)
    ) {
      playIntervalBuzzer();
      setIntervalCount((c) => c + 1);
      setTimerSeconds(60);
      setTimerActive(true);
      setIntervalTitle(`${intervalPoint}-Point Mid-Game Interval (60s)`);
    }

    const hasWonSet =
      (nextA >= targetPoints && nextA - nextB >= 2) ||
      (nextB >= targetPoints && nextB - nextA >= 2) ||
      nextA >= maxDeuceCap ||
      nextB >= maxDeuceCap;

    if (hasWonSet) {
      const updatedSets = [...completedSets, { a: nextA, b: nextB }];
      setCompletedSets(updatedSets);

      const nextSetsWonA = updatedSets.filter((s) => s.a > s.b).length;
      const nextSetsWonB = updatedSets.filter((s) => s.b > s.a).length;

      const isMatchConcluded =
        activeMatchFormat === 'bo2'
          ? nextSetsWonA >= 2 || nextSetsWonB >= 2 || updatedSets.length >= 2
          : nextSetsWonA >= setsToWin || nextSetsWonB >= setsToWin;

      if (!isMatchConcluded) {
        playGameWonSound();
        speakUmpireCall(
          `Game, ${winner === 'A' ? playerA : playerB}. ${nextA} to ${nextB}.`
        );
        setCurrentSet((prev) => prev + 1);
        setPointsA(0);
        setPointsB(0);
        setPartnerIdxA(0);
        setPartnerIdxB(0);
        setSideAOnLeft((prev) => !prev);
        setEndsSwitchedCount((c) => c + 1);
        setIntervalCount((c) => c + 1);
        setTimerSeconds(120);
        setTimerActive(true);
        setIntervalTitle('Set Break Interval (120s)');
      } else {
        playMatchWonFanfare();
        if (animationsEnabled) {
          fireConfetti();
        }
        speakUmpireCall(
          `Match won by ${winner === 'A' ? playerA : playerB}!`
        );
      }
    } else {
      const serverPts = winner === 'A' ? nextA : nextB;
      const receiverPts = winner === 'A' ? nextB : nextA;
      const isDeuceNext =
        nextA >= targetPoints - 1 && nextB >= targetPoints - 1 && nextA === nextB;
      const isGpNext =
        (nextA >= targetPoints - 1 && nextA - nextB >= 1) ||
        (nextB >= targetPoints - 1 && nextB - nextA >= 1) ||
        nextA === maxDeuceCap - 1 ||
        nextB === maxDeuceCap - 1;
      const isMpNext =
        isGpNext &&
        ((nextA > nextB && setsWonA === setsToWin - 1) ||
          (nextB > nextA && setsWonB === setsToWin - 1));

      if (
        (nextA === intervalPoint && nextB < intervalPoint) ||
        (nextB === intervalPoint && nextA < intervalPoint)
      ) {
        speakUmpireCall(`Interval. ${serverPts} serving ${receiverPts}.`);
      } else if (isMpNext) {
        playMatchPointSound();
        speakUmpireCall(`Match point. ${serverPts} serving ${receiverPts}.`);
      } else if (isGpNext) {
        playAlertTone();
        speakUmpireCall(`Game point. ${serverPts} serving ${receiverPts}.`);
      } else if (isDeuceNext) {
        speakUmpireCall(`${serverPts} all.`);
      } else if (serverPts === receiverPts) {
        speakUmpireCall(`${serverPts} all.`);
      } else {
        speakUmpireCall(
          `${server !== winner ? 'Service over. ' : ''}${serverPts} serving ${receiverPts}.`
        );
      }
    }
  };

  const handleUndoPoint = () => {
    if (history.length === 0 || isUmpireLocked) return;
    const last = history[history.length - 1];
    const currentSnapshot: ScoreSnapshot = {
      a: pointsA,
      b: pointsB,
      server,
      partnerIdxA,
      partnerIdxB,
      completedSets: [...completedSets],
      currentSet,
      sideAOnLeft,
      rallyEntry: last.rallyEntry,
    };
    setRedoStack((prev) => [...prev, currentSnapshot]);
    setPointsA(last.a);
    setPointsB(last.b);
    setServer(last.server);
    setPartnerIdxA(last.partnerIdxA);
    setPartnerIdxB(last.partnerIdxB);
    setCompletedSets(last.completedSets);
    setCurrentSet(last.currentSet);
    setSideAOnLeft(last.sideAOnLeft);
    setHistory((prev) => prev.slice(0, -1));
    setRallyLog((prev) => prev.slice(0, -1));
    setForcedOutcome(null);
    appendAudit('Undo Point', `${pointsA}-${pointsB}`, `${last.a}-${last.b}`);
  };

  const handleRedoPoint = () => {
    if (redoStack.length === 0 || isUmpireLocked) return;
    const nextSnap = redoStack[redoStack.length - 1];
    setHistory((prev) => [
      ...prev,
      {
        a: pointsA,
        b: pointsB,
        server,
        partnerIdxA,
        partnerIdxB,
        completedSets: [...completedSets],
        currentSet,
        sideAOnLeft,
        rallyEntry: nextSnap.rallyEntry,
      },
    ]);
    setPointsA(nextSnap.a);
    setPointsB(nextSnap.b);
    setServer(nextSnap.server);
    setPartnerIdxA(nextSnap.partnerIdxA);
    setPartnerIdxB(nextSnap.partnerIdxB);
    setCompletedSets(nextSnap.completedSets);
    setCurrentSet(nextSnap.currentSet);
    setSideAOnLeft(nextSnap.sideAOnLeft);
    if (nextSnap.rallyEntry) {
      const restoredEntry = nextSnap.rallyEntry;
      setRallyLog((prev) => [...prev, restoredEntry]);
    }
    setRedoStack((prev) => prev.slice(0, -1));
    appendAudit('Redo Point', `${pointsA}-${pointsB}`, `${nextSnap.a}-${nextSnap.b}`);
  };

  const handleSwitchSides = () => {
    setSideAOnLeft((prev) => !prev);
    setEndsSwitchedCount((c) => c + 1);
    appendAudit('Change of Ends', sideAOnLeft ? 'A Left / B Right' : 'B Left / A Right', sideAOnLeft ? 'B Left / A Right' : 'A Left / B Right');
  };

  const handleApplyTossResult = (firstServer: 'A' | 'B', sideLeft: 'A' | 'B') => {
    setServer(firstServer);
    setSideAOnLeft(sideLeft === 'A');
  };

  const handleConfirmRetiredOrWalkover = () => {
    if (!activeMatch) return;
    const winnerSide: 'A' | 'B' = retireSide === 'A' ? 'B' : 'A';
    // Capture in-progress set if any points were played
    if ((pointsA > 0 || pointsB > 0) && completedSets.length < getMaxSets(activeMatchFormat)) {
      setCompletedSets((prev) => [...prev, { a: pointsA, b: pointsB }]);
    }
    setForcedOutcome({
      type: retireModeType,
      winnerSide,
      note:
        retireNote.trim() ||
        (retireModeType === 'retired'
          ? `${retireSide === 'A' ? playerA : playerB} retired mid-match`
          : `Walkover awarded to ${winnerSide === 'A' ? playerA : playerB}`),
    });
    setIsRetireWalkoverOpen(false);
    setIsCompleteConfirmOpen(true);
  };

  const handleCommitMatchResult = () => {
    if (!activeMatch || !matchWinner) return;
    const scoreObj: MatchScore = {};
    const finalSets =
      completedSets.length > 0
        ? completedSets
        : pointsA > 0 || pointsB > 0
        ? [{ a: pointsA, b: pointsB }]
        : [{ a: matchWinner === 'A' ? targetPoints : 0, b: matchWinner === 'B' ? targetPoints : 0 }];

    finalSets.forEach((s, idx) => {
      if (idx === 0) {
        scoreObj.s1a = s.a;
        scoreObj.s1b = s.b;
      } else if (idx === 1) {
        scoreObj.s2a = s.a;
        scoreObj.s2b = s.b;
      } else if (idx === 2) {
        scoreObj.s3a = s.a;
        scoreObj.s3b = s.b;
      } else if (idx === 3) {
        scoreObj.s4a = s.a;
        scoreObj.s4b = s.b;
      } else if (idx === 4) {
        scoreObj.s5a = s.a;
        scoreObj.s5b = s.b;
      }
    });

    const winningIndex =
      matchWinner === 'A' ? activeMatch.playerAIndex : activeMatch.playerBIndex;
    const losingIndex =
      matchWinner === 'A' ? activeMatch.playerBIndex : activeMatch.playerAIndex;

    const meta: MatchMetaInfo = {
      status: 'completed',
      resultType: forcedOutcome ? forcedOutcome.type : 'normal',
      retiredPlayerIndex: forcedOutcome?.type === 'retired' ? losingIndex : undefined,
      walkoverWinnerIndex: forcedOutcome?.type === 'walkover' ? winningIndex : undefined,
      note: forcedOutcome?.note,
      completedAt: new Date().toISOString(),
      courtNumber,
      durationSeconds: matchElapsedSec,
      intervalCount,
      endsSwitchedCount,
      verifiedBy: refereeVerified ? (verifiedByName.trim() || 'Chief Referee') : undefined,
      verifiedAt: refereeVerified ? new Date().toISOString() : undefined,
      incidents,
      auditTrail: [
        {
          id: `aud-save-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          action: refereeVerified ? 'Verified & Saved Match Result' : 'Saved Match Result',
          actor: verifiedByName.trim() || customRules?.refereeName || 'Referee',
          nextValue: `${matchWinner === 'A' ? playerA : playerB} wins`,
        },
        ...auditTrail,
      ],
      rallyHistory: rallyLog,
    };

    onSaveMatchResult(
      activeMatch.id,
      winningIndex,
      scoreObj,
      designateMvp ? winningIndex : undefined,
      meta,
      courtNumber
    );
    setIsCompleteConfirmOpen(false);
    setSavedBanner(`Saved: ${matchWinner === 'A' ? playerA : playerB} won on Court ${courtNumber}`);
  };

  const executeResetCurrentMatch = () => {
    setCurrentSet(1);
    setPointsA(0);
    setPointsB(0);
    setPartnerIdxA(0);
    setPartnerIdxB(0);
    setHistory([]);
    setRedoStack([]);
    setCompletedSets([]);
    setRallyLog([]);
    setIncidents([]);
    setAuditTrail([]);
    setIntervalCount(0);
    setEndsSwitchedCount(0);
    setRefereeVerified(false);
    setTimerSeconds(null);
    setTimerActive(false);
    setMatchElapsedSec(0);
    setDesignateMvp(false);
    setForcedOutcome(null);
    setSavedBanner(null);
    setIsResetConfirmOpen(false);
  };

  const handleSaveSnapshotImage = () => {
    downloadScoreboardImage({
      tournamentTitle,
      courtNumber,
      currentSet,
      playerA,
      playerB,
      pointsA,
      pointsB,
      setsWonA,
      setsWonB,
      completedSets,
      server,
    });
  };

  const shortcutHandlersRef = useRef({
    scoreA: () => {},
    scoreB: () => {},
    undo: () => {},
    redo: () => {},
    toggleClock: () => {},
    isBlocked: false,
  });

  shortcutHandlersRef.current = {
    scoreA: () => handlePointScored('A'),
    scoreB: () => handlePointScored('B'),
    undo: handleUndoPoint,
    redo: handleRedoPoint,
    toggleClock: () => setMatchTimerRunning((r) => !r),
    isBlocked:
      !activeMatch ||
      isResetConfirmOpen ||
      isCompleteConfirmOpen ||
      isRetireWalkoverOpen ||
      isTossOpen ||
      isBigScreenOpen,
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      ) {
        return;
      }
      const handlers = shortcutHandlersRef.current;
      if (handlers.isBlocked) return;

      const key = e.key.toLowerCase();
      if (key === '1' || key === 'q') {
        e.preventDefault();
        handlers.scoreA();
      } else if (key === '2' || key === 'p') {
        e.preventDefault();
        handlers.scoreB();
      } else if (key === 'z') {
        e.preventDefault();
        handlers.undo();
      } else if (key === 'y') {
        e.preventDefault();
        handlers.redo();
      } else if (e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
        handlers.toggleClock();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const activeCourtObj = courts.find((c) => c.id === courtNumber);
  const leftPlayer = sideAOnLeft
    ? { name: playerA, letter: 'A' as const, points: pointsA }
    : { name: playerB, letter: 'B' as const, points: pointsB };
  const rightPlayer = sideAOnLeft
    ? { name: playerB, letter: 'B' as const, points: pointsB }
    : { name: playerA, letter: 'A' as const, points: pointsA };

  const longestRally = rallyLog.reduce((max, r) => Math.max(max, r.rallySec), 0);
  const smashCount = rallyLog.filter((r) => r.shot === 'Smash').length;
  const dropCount = rallyLog.filter((r) => r.shot === 'Drop').length;
  const netCount = rallyLog.filter((r) => r.shot === 'Net Shot').length;
  const errorCount = rallyLog.filter(
    (r) => r.shot === 'Unforced Error' || r.shot === 'Fault'
  ).length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Umpire Console Header */}
      <div className="theme-card rounded-3xl p-5 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xl">🏸</span>
            <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight">
              Live Court Umpire Scorer
            </h2>
            <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] font-extrabold border border-[#D4AF37]/40">
              {targetPoints}-Pt BWF Rules
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-[#172B4D]/10 dark:bg-white/10 text-[#172033] dark:text-white font-bold border border-slate-200 dark:border-white/15">
              <ShieldCheck className="w-3 h-3 text-[#D4AF37]" />
              <span>{userRoleMode === 'referee' ? 'Referee Interface' : 'Admin + Referee'}</span>
            </span>
            {isDoublesMatch && (
              <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full bg-[#D4AF37]/15 text-[#9A7B1C] dark:text-[#FFD700] font-bold">
                <Users className="w-3 h-3" />
                <span>Doubles Rotation</span>
              </span>
            )}
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/25 text-xs font-mono font-bold text-[#172033] dark:text-[#FFD700]">
              <Clock className="w-3 h-3" />
              <span>{formatClock(matchElapsedSec)}</span>
              <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0]">
                / {defaultDurationMinutes}m
              </span>
              <button
                type="button"
                onClick={() => setMatchTimerRunning(!matchTimerRunning)}
                className="ml-1 text-[#64748B] hover:text-[#D4AF37] cursor-pointer"
                title={matchTimerRunning ? 'Pause Match Clock' : 'Resume Match Clock'}
              >
                {matchTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              </button>
            </div>
            {matchElapsedSec > defaultDurationMinutes * 60 && !matchWinner && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-500 border border-amber-500/30 font-black">
                +{Math.ceil((matchElapsedSec - defaultDurationMinutes * 60) / 60)}m Overtime
              </span>
            )}
          </div>
          <p className="text-xs text-[#64748B] dark:text-[#A0A0A0] mt-1">
            Official BWF console: Service box &amp; doubles rotation, timeouts, cards, incidents, audit trail, and referee verification.
            <span className="hidden lg:inline-flex items-center gap-1.5 ml-2 px-2 py-0.5 rounded-md bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 text-[10px] font-mono text-[#64748B] dark:text-[#D4AF37]">
              Keys: Q/1 (A) · P/2 (B) · Z Undo · Y Redo · Space Clock
            </span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={courtNumber}
            onChange={(e) => setCourtNumber(Number(e.target.value))}
            className="text-xs bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white border border-slate-200 dark:border-white/15 rounded-xl px-2.5 py-2 font-semibold focus:outline-none"
          >
            {courts.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={selectedMatchId}
            onChange={(e) => {
              setSelectedMatchId(e.target.value);
              setCurrentSet(1);
              setPointsA(0);
              setPointsB(0);
              setPartnerIdxA(0);
              setPartnerIdxB(0);
              setHistory([]);
              setRedoStack([]);
              setRallyLog([]);
              setIncidents([]);
              setAuditTrail([]);
              setIntervalCount(0);
              setEndsSwitchedCount(0);
              setRefereeVerified(false);
              setCompletedSets([]);
              setMatchElapsedSec(0);
              setDesignateMvp(false);
              setForcedOutcome(null);
              setSavedBanner(null);
            }}
            className="text-xs bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white border border-slate-200 dark:border-white/15 rounded-xl px-3 py-2 font-semibold focus:outline-none max-w-[220px]"
          >
            {playableFixtures.map((m, i) => (
              <option key={m.id} value={m.id}>
                Match #{m.roundNumber || i + 1}: {players[m.playerAIndex]} vs {players[m.playerBIndex]}
              </option>
            ))}
          </select>

          {onUpdateCustomRules && (
            <div
              className="flex items-center gap-1 px-2 py-1 bg-[#F4F7FB] dark:bg-[#080808] rounded-xl border border-slate-200 dark:border-white/15"
              title="Adjust Target Points per Set (11 to 21)"
            >
              <button
                type="button"
                onClick={() => handleAdjustTargetPoints(-1)}
                disabled={targetPoints <= 11}
                className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-white/10 text-[#64748B] dark:text-[#A0A0A0] disabled:opacity-30 cursor-pointer"
                aria-label="Decrease points per set"
              >
                <Minus className="w-3 h-3" />
              </button>
              <span className="text-[11px] font-black font-mono text-[#172033] dark:text-[#FFD700] px-1">
                {targetPoints}pt
              </span>
              <button
                type="button"
                onClick={() => handleAdjustTargetPoints(1)}
                disabled={targetPoints >= 21}
                className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-white/10 text-[#64748B] dark:text-[#A0A0A0] disabled:opacity-30 cursor-pointer"
                aria-label="Increase points per set"
              >
                <Plus className="w-3 h-3" />
              </button>
            </div>
          )}

          {activeMatch && onSetMatchItemFormat && (
            <div
              className="flex items-center gap-1 p-1 bg-[#F4F7FB] dark:bg-[#080808] rounded-xl border border-slate-200 dark:border-white/15"
              title="Set Best of 1, 3, or 5 for this live match"
            >
              {(['bo1', 'bo3', 'bo5'] as MatchFormat[]).map((fmt) => (
                <button
                  key={fmt}
                  type="button"
                  onClick={() => onSetMatchItemFormat(activeMatch.id, fmt)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-black uppercase cursor-pointer transition-colors ${
                    activeMatchFormat === fmt
                      ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                      : 'text-[#64748B] dark:text-[#A0A0A0]'
                  }`}
                >
                  {fmt}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={() => setIsBigScreenOpen(true)}
            className="px-3 py-2 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] hover:opacity-95 text-white dark:text-[#080808] font-extrabold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Tv className="w-3.5 h-3.5" />
            <span>TV Mode</span>
          </button>

          <button
            type="button"
            onClick={handleSaveSnapshotImage}
            className="px-3 py-2 bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#172033] dark:text-white font-bold text-xs rounded-xl hover:border-[#D4AF37] transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Download Shareable Scoreboard PNG"
          >
            <Camera className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="hidden sm:inline">Share PNG</span>
          </button>

          <button
            type="button"
            onClick={() => setIsUmpireLocked(!isUmpireLocked)}
            className={`px-3 py-2 font-bold text-xs rounded-xl shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer ${
              isUmpireLocked
                ? 'bg-[#EF4444] text-white animate-pulse'
                : 'bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0]'
            }`}
            title="Prevent accidental score taps"
          >
            {isUmpireLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{isUmpireLocked ? 'Locked' : 'Lock'}</span>
          </button>

          {onOpenQuickMatch && (
            <button
              type="button"
              onClick={onOpenQuickMatch}
              className="px-3 py-2 bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/45 text-[#172033] dark:text-[#FFD700] font-extrabold text-xs rounded-xl hover:border-[#FFD700] transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              title="Launch Standalone 1v1 or 2v2 Quick Match"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Quick Match</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsTossOpen(true)}
            className="px-3 py-2 bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] font-extrabold text-xs rounded-xl shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>🏸 Toss</span>
          </button>

          <button
            type="button"
            onClick={() => setKeepAwake(!keepAwake)}
            className={`px-2.5 py-2 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
              keepAwake
                ? 'bg-[#D4AF37]/15 border-[#D4AF37]/45 text-[#9A7B1C] dark:text-[#FFD700]'
                : 'border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0]'
            }`}
            title="Keep screen awake while umpiring"
          >
            <Sun className="w-3.5 h-3.5" />
            <span className="hidden xl:inline">{keepAwake ? 'Awake On' : 'Keep Awake'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const next = toggleVoiceUmpire();
              setVoiceEnabled(next);
              if (next) speakUmpireCall('Voice umpire activated', true);
            }}
            className={`px-2.5 py-2 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
              voiceEnabled
                ? 'bg-[#D4AF37]/15 border-[#D4AF37]/45 text-[#9A7B1C] dark:text-[#FFD700]'
                : 'border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0]'
            }`}
            title="Voice Umpire — Announces live BWF score calls"
          >
            {voiceEnabled ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
            <span className="hidden xl:inline">Voice</span>
          </button>

          <button
            type="button"
            onClick={() => setIsMuted(toggleAudioMute())}
            className="p-2 rounded-xl border border-slate-200 dark:border-white/15 text-[#64748B] dark:text-[#A0A0A0] hover:text-[#172033] dark:hover:text-white cursor-pointer"
            title={isMuted ? 'Unmute Sound Effects' : 'Mute Sound Effects'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-[#D4AF37]" />}
          </button>
        </div>
      </div>

      {savedBanner && (
        <div className="p-3.5 rounded-2xl bg-[#22C55E]/15 border border-[#22C55E]/40 text-[#15803D] dark:text-[#4ADE80] text-xs font-extrabold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{savedBanner}</span>
          </div>
          <button
            type="button"
            onClick={() => setSavedBanner(null)}
            className="p-1 hover:bg-white/10 rounded-lg cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Interval Countdown Banner */}
      {timerSeconds !== null && timerSeconds > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] shadow-md flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2.5">
            <Timer className="w-5 h-5 animate-pulse" />
            <div>
              <strong className="block text-xs uppercase tracking-wider font-black">
                {intervalTitle}
              </strong>
              <span className="text-2xl font-black tabular-nums font-mono">
                {Math.floor(timerSeconds / 60)}:{(timerSeconds % 60).toString().padStart(2, '0')}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setTimerActive(!timerActive)}
              className="px-3 py-1.5 bg-[#080808] text-white font-bold text-xs rounded-xl cursor-pointer"
            >
              {timerActive ? 'Pause' : 'Resume'}
            </button>
            <button
              onClick={() => {
                setTimerSeconds(null);
                setTimerActive(false);
              }}
              className="px-3 py-1.5 bg-white/85 text-[#080808] font-bold text-xs rounded-xl cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Match / Game Point Alert */}
      {(isMatchPointA || isMatchPointB || isGamePointA || isGamePointB || isDeuce) && !matchWinner && (
        <div className="p-3 rounded-2xl bg-gradient-to-r from-[#D4AF37] via-[#FFD700] to-[#D4AF37] text-[#080808] font-black text-xs text-center shadow flex items-center justify-center gap-2 tracking-wide uppercase">
          <Sparkles className="w-4 h-4" />
          <span>
            {isMatchPointA
              ? `CHAMPIONSHIP MATCH POINT: ${playerA} (Game ${currentSet})`
              : isMatchPointB
              ? `CHAMPIONSHIP MATCH POINT: ${playerB} (Game ${currentSet})`
              : isGamePointA
              ? `GAME POINT: ${playerA}`
              : isGamePointB
              ? `GAME POINT: ${playerB}`
              : `DEUCE: ${pointsA}-${pointsB} (2-point lead required, cap ${maxDeuceCap})`}
          </span>
        </div>
      )}

      {/* Main Dual Scoreboard Card */}
      <div className="theme-card rounded-3xl p-5 sm:p-6 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-white/10 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-black text-[#172033] dark:text-white">
              Game {currentSet} in Progress
            </span>
            <span className="text-[#64748B]">·</span>
            <span className="text-[#9A7B1C] dark:text-[#FFD700] font-bold">
              {getFormatLabel(activeMatchFormat)}
            </span>
            {activeCourtObj && (
              <>
                <span className="text-[#64748B]">·</span>
                <span className="text-[#64748B] dark:text-[#A0A0A0] font-semibold">
                  {activeCourtObj.name}
                </span>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {completedSets.map((s, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white font-mono font-bold text-xs border border-slate-200 dark:border-white/15"
              >
                G{idx + 1}: {s.a}-{s.b}
              </span>
            ))}
            <div className="flex items-center gap-1 font-extrabold text-[#64748B] dark:text-[#A0A0A0]">
              <span>Games:</span>
              <span className="text-[#9A7B1C] dark:text-[#FFD700] font-black text-sm">{setsWonA}</span>
              <span>-</span>
              <span className="text-[#172033] dark:text-white font-black text-sm">{setsWonB}</span>
            </div>
          </div>
        </div>

        {/* Side-by-Side Score Cards */}
        <div className="py-5 grid grid-cols-2 gap-3 sm:gap-6 items-stretch text-center">
          {/* Player A */}
          <div
            className={`p-4 sm:p-6 rounded-3xl border-2 transition-all flex flex-col items-center justify-between ${
              server === 'A'
                ? 'border-[#D4AF37] bg-[#D4AF37]/8 shadow-lg ring-2 ring-[#D4AF37]/20'
                : 'border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808]/90'
            }`}
          >
            <div className="flex items-center gap-2.5 mb-2 w-full justify-center sm:justify-start">
              {photoA ? (
                <img
                  src={photoA}
                  alt={playerA}
                  className="w-9 h-9 rounded-xl object-cover shadow-sm shrink-0 border border-[#D4AF37]/60"
                />
              ) : (
                <div
                  className="w-9 h-9 rounded-xl text-[#080808] font-black text-xs flex items-center justify-center shadow-sm shrink-0"
                  style={{ backgroundColor: colorA }}
                >
                  {getInitials(playerA)}
                </div>
              )}
              <div className="text-left min-w-0">
                <span className="font-black text-xs sm:text-base text-[#172033] dark:text-white truncate block max-w-[120px] sm:max-w-[210px]">
                  {playerA}
                </span>
                {server === 'A' ? (
                  <span className="text-[10px] text-[#9A7B1C] dark:text-[#FFD700] font-extrabold flex items-center gap-1 uppercase">
                    🏸 Serving ({serverCourtSide})
                    {isDoublesMatch && ` · ${partnersA[partnerIdxA % partnersA.length]}`}
                  </span>
                ) : (
                  <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] font-semibold uppercase">
                    Receiving
                  </span>
                )}
              </div>
            </div>

            <div
              key={`scoreA-${pointsA}`}
              className={`animate-score-pop text-6xl sm:text-7xl md:text-8xl font-black tabular-nums py-2 my-2 tracking-tight font-mono ${
                server === 'A' ? 'text-[#9A7B1C] dark:text-[#FFD700]' : 'text-[#172033] dark:text-white'
              }`}
            >
              {pointsA}
            </div>

            {!matchWinner && (
              <button
                onClick={() => handlePointScored('A')}
                disabled={isUmpireLocked || !activeMatch}
                className={`w-full py-3.5 sm:py-4 active:scale-[0.97] font-black text-sm sm:text-base rounded-2xl shadow-lg transition-all cursor-pointer disabled:opacity-40 ${
                  server === 'A'
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808]'
                    : 'bg-[#172B4D] dark:bg-white/15 text-white hover:dark:bg-[#D4AF37]/30'
                }`}
              >
                +1 Point
              </button>
            )}
          </div>

          {/* Player B */}
          <div
            className={`p-4 sm:p-6 rounded-3xl border-2 transition-all flex flex-col items-center justify-between ${
              server === 'B'
                ? 'border-[#D4AF37] bg-[#D4AF37]/8 shadow-lg ring-2 ring-[#D4AF37]/20'
                : 'border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808]/90'
            }`}
          >
            <div className="flex items-center gap-2.5 mb-2 w-full justify-center sm:justify-start">
              {photoB ? (
                <img
                  src={photoB}
                  alt={playerB}
                  className="w-9 h-9 rounded-xl object-cover shadow-sm shrink-0 border border-[#D4AF37]/60"
                />
              ) : (
                <div
                  className="w-9 h-9 rounded-xl text-[#080808] font-black text-xs flex items-center justify-center shadow-sm shrink-0"
                  style={{ backgroundColor: colorB }}
                >
                  {getInitials(playerB)}
                </div>
              )}
              <div className="text-left min-w-0">
                <span className="font-black text-xs sm:text-base text-[#172033] dark:text-white truncate block max-w-[120px] sm:max-w-[210px]">
                  {playerB}
                </span>
                {server === 'B' ? (
                  <span className="text-[10px] text-[#9A7B1C] dark:text-[#FFD700] font-extrabold flex items-center gap-1 uppercase">
                    🏸 Serving ({serverCourtSide})
                    {isDoublesMatch && ` · ${partnersB[partnerIdxB % partnersB.length]}`}
                  </span>
                ) : (
                  <span className="text-[10px] text-[#64748B] dark:text-[#A0A0A0] font-semibold uppercase">
                    Receiving
                  </span>
                )}
              </div>
            </div>

            <div
              key={`scoreB-${pointsB}`}
              className={`animate-score-pop text-6xl sm:text-7xl md:text-8xl font-black tabular-nums py-2 my-2 tracking-tight font-mono ${
                server === 'B' ? 'text-[#9A7B1C] dark:text-[#FFD700]' : 'text-[#172033] dark:text-white'
              }`}
            >
              {pointsB}
            </div>

            {!matchWinner && (
              <button
                onClick={() => handlePointScored('B')}
                disabled={isUmpireLocked || !activeMatch}
                className={`w-full py-3.5 sm:py-4 active:scale-[0.97] font-black text-sm sm:text-base rounded-2xl shadow-lg transition-all cursor-pointer disabled:opacity-40 ${
                  server === 'B'
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808]'
                    : 'bg-[#172B4D] dark:bg-white/15 text-white hover:dark:bg-[#D4AF37]/30'
                }`}
              >
                +1 Point
              </button>
            )}
          </div>
        </div>

        {/* Match Concluded Card */}
        {matchWinner && (
          <div className="p-5 rounded-2xl bg-gradient-to-r from-[#D4AF37] via-[#FFD700] to-[#D4AF37] text-[#080808] text-center space-y-3 mt-4 animate-fade-in">
            <h3 className="text-lg font-black flex items-center justify-center gap-2">
              <Trophy className="w-6 h-6" />
              <span>
                MATCH FINISHED: {matchWinner === 'A' ? playerA : playerB} WINS
                {forcedOutcome ? ` (${forcedOutcome.type.toUpperCase()})` : ''}!
              </span>
            </h3>
            <p className="text-xs font-bold">
              Final score:{' '}
              {completedSets.length > 0
                ? completedSets.map((s) => `${s.a}-${s.b}`).join(', ')
                : `${pointsA}-${pointsB}`}
              {forcedOutcome?.note ? ` · ${forcedOutcome.note}` : ''}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setDesignateMvp((prev) => !prev)}
                className={`px-4 py-2.5 font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer border ${
                  designateMvp
                    ? 'bg-[#080808] text-[#FFD700] border-[#080808]'
                    : 'bg-white/90 text-[#080808] border-[#080808]/20 hover:bg-white'
                }`}
              >
                <Award className="w-4 h-4" />
                <span>
                  {designateMvp
                    ? `Match MVP Awarded: ${matchWinner === 'A' ? playerA : playerB}`
                    : `Designate ${matchWinner === 'A' ? playerA : playerB} as Match MVP`}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setIsCompleteConfirmOpen(true)}
                className="px-6 py-2.5 bg-[#080808] text-[#FFD700] font-extrabold text-xs rounded-xl shadow-lg hover:opacity-90 transition-opacity cursor-pointer"
              >
                Confirm &amp; Save Result
              </button>
            </div>
          </div>
        )}

        {/* Controls Footer */}
        <div className="pt-4 border-t border-slate-100 dark:border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleUndoPoint}
              disabled={history.length === 0 || isUmpireLocked}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white disabled:opacity-30 font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Undo</span>
            </button>

            <button
              type="button"
              onClick={handleRedoPoint}
              disabled={redoStack.length === 0 || isUmpireLocked}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white disabled:opacity-30 font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5 text-[#FFD700]" />
              <span>Redo</span>
            </button>

            <button
              type="button"
              onClick={handleSwitchSides}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowRightLeft className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Switch Ends</span>
            </button>

            {!matchWinner && activeMatch && (
              <button
                type="button"
                onClick={() => setIsRetireWalkoverOpen(true)}
                disabled={isUmpireLocked}
                className="px-3.5 py-2 rounded-xl border border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-[#FFD700] disabled:opacity-30 font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Flag className="w-3.5 h-3.5" />
                <span>Retire / Walkover</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={() => setIsResetConfirmOpen(true)}
            className="text-xs font-bold text-[#EF4444] hover:underline cursor-pointer"
          >
            Reset Scoreboard
          </button>
        </div>
      </div>

      {/* Live Court Visualizer */}
      <div className="bg-[#141414] text-white rounded-3xl p-6 shadow-xl border border-[#D4AF37]/25 relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-base font-black text-[#FFD700]">🏸 Live Court Visualizer</span>
            <span className="text-[11px] text-[#A0A0A0]">(BWF Service Zones)</span>
          </div>
          <span className="text-xs text-[#A0A0A0] font-medium">
            Active Server:{' '}
            <strong className="text-[#FFD700]">
              {isDoublesMatch ? activePartnerName : server === 'A' ? playerA : playerB}
            </strong>{' '}
            ({serverCourtSide} box)
          </span>
        </div>

        <div className="relative w-full h-52 sm:h-64 bg-[#0D2B22] border-4 border-white/90 rounded-2xl overflow-hidden shadow-inner flex">
          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-1.5 bg-white z-20 shadow-md">
            <div className="w-4 h-full border-r-2 border-l-2 border-dashed border-[#D4AF37]/60 -ml-1.5" />
          </div>

          {/* Left Court */}
          <div className="flex-1 h-full relative border-r-2 border-white/50">
            <div className="absolute top-0 bottom-0 right-[25%] w-1 bg-white/60" />
            <div className="absolute left-0 right-[25%] top-1/2 -translate-y-1/2 h-1 bg-white/60" />
            <div className="absolute bottom-2 left-3 bg-[#080808]/85 px-2.5 py-1 rounded-lg text-[11px] font-bold text-white z-10 flex items-center gap-1.5 border border-[#D4AF37]/30">
              <span>{leftPlayer.name}</span>
              <span className="text-[#FFD700]">({leftPlayer.points})</span>
            </div>

            <div
              className={`absolute top-0 bottom-1/2 left-0 right-[25%] flex items-center justify-center transition-colors ${
                server === leftPlayer.letter && serverCourtSide === 'left'
                  ? 'bg-[#D4AF37]/25 ring-2 ring-[#FFD700]'
                  : ''
              }`}
            >
              {server === leftPlayer.letter && serverCourtSide === 'left' && (
                <div className="text-2xl animate-bounce">🏸</div>
              )}
            </div>

            <div
              className={`absolute top-1/2 bottom-0 left-0 right-[25%] flex items-center justify-center transition-colors ${
                server === leftPlayer.letter && serverCourtSide === 'right'
                  ? 'bg-[#D4AF37]/25 ring-2 ring-[#FFD700]'
                  : ''
              }`}
            >
              {server === leftPlayer.letter && serverCourtSide === 'right' && (
                <div className="text-2xl animate-bounce">🏸</div>
              )}
            </div>
          </div>

          {/* Right Court */}
          <div className="flex-1 h-full relative border-l-2 border-white/50">
            <div className="absolute top-0 bottom-0 left-[25%] w-1 bg-white/60" />
            <div className="absolute left-[25%] right-0 top-1/2 -translate-y-1/2 h-1 bg-white/60" />
            <div className="absolute bottom-2 right-3 bg-[#080808]/85 px-2.5 py-1 rounded-lg text-[11px] font-bold text-white z-10 flex items-center gap-1.5 border border-[#D4AF37]/30">
              <span>{rightPlayer.name}</span>
              <span className="text-[#FFD700]">({rightPlayer.points})</span>
            </div>

            <div
              className={`absolute top-0 bottom-1/2 left-[25%] right-0 flex items-center justify-center transition-colors ${
                server === rightPlayer.letter && serverCourtSide === 'right'
                  ? 'bg-[#D4AF37]/25 ring-2 ring-[#FFD700]'
                  : ''
              }`}
            >
              {server === rightPlayer.letter && serverCourtSide === 'right' && (
                <div className="text-2xl animate-bounce">🏸</div>
              )}
            </div>

            <div
              className={`absolute top-1/2 bottom-0 left-[25%] right-0 flex items-center justify-center transition-colors ${
                server === rightPlayer.letter && serverCourtSide === 'left'
                  ? 'bg-[#D4AF37]/25 ring-2 ring-[#FFD700]'
                  : ''
              }`}
            >
              {server === rightPlayer.letter && serverCourtSide === 'left' && (
                <div className="text-2xl animate-bounce">🏸</div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Match Performance Summary + Rally Shot Tracker */}
      <div className="theme-card rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-white/10">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Shuttle Rally &amp; Performance Analytics
            </h3>
          </div>
          <span className="text-xs text-[#64748B] dark:text-[#A0A0A0]">
            Tag winning shot before tapping +1 Point
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-center">
          <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/70 dark:border-white/10">
            <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#A0A0A0] block">
              Total Rallies
            </span>
            <span className="text-lg font-black text-[#172033] dark:text-white font-mono">
              {rallyLog.length}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/70 dark:border-white/10">
            <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#A0A0A0] block">
              Smashes
            </span>
            <span className="text-lg font-black text-[#9A7B1C] dark:text-[#FFD700] font-mono">
              {smashCount}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/70 dark:border-white/10">
            <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#A0A0A0] block">
              Drops &amp; Net
            </span>
            <span className="text-lg font-black text-[#D4AF37] font-mono">
              {dropCount + netCount}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/70 dark:border-white/10">
            <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#A0A0A0] block">
              Errors / Faults
            </span>
            <span className="text-lg font-black text-[#EF4444] font-mono">{errorCount}</span>
          </div>
          <div className="col-span-2 sm:col-span-1 p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/70 dark:border-white/10">
            <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#A0A0A0] block">
              Longest Rally
            </span>
            <span className="text-lg font-black text-[#172033] dark:text-white font-mono">
              {longestRally}s
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              { type: 'Smash', icon: '💥' },
              { type: 'Drop', icon: '🎯' },
              { type: 'Net Shot', icon: '🕸️' },
              { type: 'Clear', icon: '🚀' },
              { type: 'Drive', icon: '⚡' },
              { type: 'Unforced Error', icon: '❌' },
              { type: 'Fault', icon: '⚠️' },
            ] as const
          ).map((item) => (
            <button
              key={item.type}
              type="button"
              onClick={() => setSelectedShotType(item.type)}
              className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedShotType === item.type
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] shadow-md scale-105 font-black'
                  : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] border border-slate-200 dark:border-white/10'
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.type}</span>
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="font-bold text-[#64748B] dark:text-[#A0A0A0]">Rally Duration:</span>
          {[4, 8, 15, 25, 45].map((sec) => (
            <button
              key={sec}
              type="button"
              onClick={() => setRallyDuration(sec)}
              className={`px-2.5 py-1 rounded-lg font-mono font-bold cursor-pointer ${
                rallyDuration === sec
                  ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808]'
                  : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0]'
              }`}
            >
              ~{sec}s
            </button>
          ))}
        </div>

        {/* Shuttle Equipment Compact Row */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-100 dark:border-white/10 text-xs">
          <div>
            <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1 font-bold">
              Shuttle Type
            </label>
            <div className="flex gap-1">
              {(['feather', 'nylon'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setShuttleType(t)}
                  className={`flex-1 py-1.5 rounded-lg border font-bold capitalize cursor-pointer ${
                    shuttleType === t
                      ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] border-transparent'
                      : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] border-slate-200 dark:border-white/10'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1 font-bold">
              Brand / Model
            </label>
            <select
              value={shuttleBrand}
              onChange={(e) => setShuttleBrand(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 bg-[#F4F7FB] dark:bg-[#080808] text-[#172033] dark:text-white font-semibold"
            >
              <option value="Yonex Aerosensa 50">Yonex Aerosensa 50</option>
              <option value="Yonex Aerosensa 30">Yonex Aerosensa 30</option>
              <option value="Victor Master No. 1">Victor Master No. 1</option>
              <option value="Li-Ning G900">Li-Ning G900</option>
              <option value="Yonex Mavis 350">Yonex Mavis 350</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1 font-bold">
              Speed
            </label>
            <div className="flex gap-1">
              {[76, 77, 78].map((spd) => (
                <button
                  key={spd}
                  type="button"
                  onClick={() => setShuttleSpeed(spd as 76 | 77 | 78)}
                  className={`flex-1 py-1.5 rounded-lg border font-bold cursor-pointer ${
                    shuttleSpeed === spd
                      ? 'bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] border-transparent'
                      : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] border-slate-200 dark:border-white/10'
                  }`}
                >
                  {spd}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[11px] text-[#64748B] dark:text-[#A0A0A0] block mb-1 font-bold">
              Shuttles Used
            </label>
            <div className="flex items-center gap-2">
              <span className="font-black font-mono text-sm text-[#172033] dark:text-white">
                {shuttlesUsed}
              </span>
              <button
                type="button"
                onClick={() => setShuttlesUsed((p) => p + 1)}
                className="px-2.5 py-1.5 rounded-lg bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 font-bold text-[#172033] dark:text-[#FFD700] cursor-pointer"
              >
                +1 New Shuttle
              </button>
            </div>
          </div>
        </div>

        {/* Live Point-by-Point Lead Momentum Graph + Rally Log */}
        {rallyLog.length > 0 && (
          <div className="pt-3 border-t border-slate-100 dark:border-white/10 space-y-4">
            {(() => {
              const currentSetRallies = rallyLog.filter((r) => r.set === currentSet);
              const series = currentSetRallies.length > 0 ? currentSetRallies : rallyLog;
              const diffs = [0, ...series.map((r) => r.scoreA - r.scoreB)];
              const maxAbs = Math.max(4, ...diffs.map((d) => Math.abs(d)));
              const width = 600;
              const height = 110;
              const midY = height / 2;
              const pointsAttr = diffs
                .map((d, idx) => {
                  const x = diffs.length > 1 ? (idx / (diffs.length - 1)) * width : 0;
                  const y = midY - (d / maxAbs) * (midY - 10);
                  return `${x.toFixed(1)},${y.toFixed(1)}`;
                })
                .join(' ');

              return (
                <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200/80 dark:border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-black uppercase tracking-wider text-[#172033] dark:text-white">
                      Game {currentSet} Point Momentum (Lead Curve)
                    </span>
                    <div className="flex items-center gap-3 font-bold">
                      <span className="text-[#9A7B1C] dark:text-[#FFD700]">{playerA} (+)</span>
                      <span className="text-[#64748B] dark:text-[#A0A0A0]">{playerB} (-)</span>
                    </div>
                  </div>
                  <svg
                    viewBox={`0 0 ${width} ${height}`}
                    className="w-full h-24 overflow-visible"
                    role="img"
                    aria-label="Live score momentum chart"
                  >
                    <line
                      x1="0"
                      y1={midY}
                      x2={width}
                      y2={midY}
                      stroke="currentColor"
                      strokeOpacity="0.2"
                      strokeDasharray="4 4"
                    />
                    <polyline
                      fill="none"
                      stroke="#D4AF37"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      points={pointsAttr}
                    />
                    {diffs.map((d, idx) => {
                      const x = diffs.length > 1 ? (idx / (diffs.length - 1)) * width : 0;
                      const y = midY - (d / maxAbs) * (midY - 10);
                      return (
                        <circle
                          key={idx}
                          cx={x}
                          cy={y}
                          r="3"
                          fill={d >= 0 ? '#FFD700' : '#A0A0A0'}
                        />
                      );
                    })}
                  </svg>
                </div>
              );
            })()}

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-extrabold text-[#172033] dark:text-white uppercase tracking-wider">
                  Rally-By-Rally Log ({rallyLog.length})
                </span>
              </div>

              <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-white/10 text-xs border border-slate-200 dark:border-white/10 rounded-2xl">
                {[...rallyLog].reverse().map((r, idx) => (
                  <div
                    key={idx}
                    className="py-2 px-3 flex items-center justify-between hover:bg-[#F4F7FB] dark:hover:bg-[#080808]/60"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-6 text-[#64748B] dark:text-[#A0A0A0] font-mono text-[11px]">
                        #{rallyLog.length - idx}
                      </span>
                      <span
                        className={`font-bold ${
                          r.winner === 'A'
                            ? 'text-[#9A7B1C] dark:text-[#FFD700]'
                            : 'text-[#172033] dark:text-white'
                        }`}
                      >
                        {r.winner === 'A' ? playerA : playerB}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded-md bg-[#F4F7FB] dark:bg-[#080808] font-semibold text-[#64748B] dark:text-[#A0A0A0]">
                        {r.shot}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-[#64748B] dark:text-[#A0A0A0] font-mono text-[11px]">
                        {r.rallySec}s
                      </span>
                      <span className="font-mono font-black text-[#172033] dark:text-white">
                        {r.scoreA} - {r.scoreB}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Official BWF Incidents, Timeouts, Penalties & Score Audit Trail */}
      <div className="theme-card rounded-3xl p-6 shadow-sm space-y-4 border border-[#D4AF37]/20">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-white/10">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="text-base font-black text-[#172033] dark:text-white">
              Official Referee Calls, Incidents &amp; Audit Trail
            </h3>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono text-[#64748B] dark:text-[#A0A0A0]">
            <span>Intervals: <strong className="text-[#FFD700]">{intervalCount}</strong></span>
            <span>·</span>
            <span>Ends Switched: <strong className="text-[#FFD700]">{endsSwitchedCount}</strong></span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="font-bold text-[#64748B] dark:text-[#A0A0A0]">Target Player:</span>
          {(['A', 'B', 'General'] as const).map((side) => (
            <button
              key={side}
              type="button"
              onClick={() => setIncidentSide(side)}
              className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer border ${
                incidentSide === side
                  ? 'bg-[#D4AF37]/20 border-[#FFD700] text-[#9A7B1C] dark:text-[#FFD700]'
                  : 'bg-[#F4F7FB] dark:bg-[#080808] border-slate-200 dark:border-white/10 text-[#64748B] dark:text-[#A0A0A0]'
              }`}
            >
              {side === 'A' ? playerA : side === 'B' ? playerB : 'General'}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            type="button"
            onClick={() => handleLogIncident('service_fault')}
            disabled={!activeMatch}
            className="px-3 py-2 rounded-xl bg-amber-500/15 border border-amber-500/35 text-amber-600 dark:text-amber-300 font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Service Fault</span>
          </button>
          <button
            type="button"
            onClick={() => handleLogIncident('let')}
            disabled={!activeMatch}
            className="px-3 py-2 rounded-xl bg-sky-500/15 border border-sky-500/35 text-sky-600 dark:text-sky-300 font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Call Let</span>
          </button>
          <button
            type="button"
            onClick={() => handleLogIncident('medical_timeout')}
            disabled={!activeMatch}
            className="px-3 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-600 dark:text-emerald-300 font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <HeartPulse className="w-3.5 h-3.5" />
            <span>Medical Timeout (2:00)</span>
          </button>
          <button
            type="button"
            onClick={() => handleLogIncident('yellow_card')}
            disabled={!activeMatch}
            className="px-3 py-2 rounded-xl bg-yellow-500/20 border border-yellow-500/45 text-yellow-700 dark:text-[#FFD700] font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <FileWarning className="w-3.5 h-3.5" />
            <span>Yellow Card</span>
          </button>
          <button
            type="button"
            onClick={() => handleLogIncident('red_card')}
            disabled={!activeMatch}
            className="px-3 py-2 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-500 font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Red Card</span>
          </button>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            value={incidentNoteInput}
            onChange={(e) => setIncidentNoteInput(e.target.value)}
            placeholder="Custom referee note or match incident..."
            className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white"
          />
          <button
            type="button"
            onClick={() => handleLogIncident('incident', 'General')}
            disabled={!incidentNoteInput.trim() || !activeMatch}
            className="px-4 py-2 rounded-xl bg-[#172B4D] dark:bg-[#D4AF37] text-white dark:text-[#080808] font-black text-xs disabled:opacity-40 cursor-pointer"
          >
            Add Note
          </button>
        </div>

        {(incidents.length > 0 || auditTrail.length > 0) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2 max-h-40 overflow-y-auto">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#D4AF37]">
                Official Incident &amp; Card Log ({incidents.length})
              </div>
              {incidents.length === 0 ? (
                <div className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  Clean match — no incidents logged.
                </div>
              ) : (
                incidents.map((inc) => (
                  <div key={inc.id} className="text-[11px] flex items-start justify-between gap-2 border-b border-slate-200/50 dark:border-white/5 pb-1">
                    <span className="text-[#172033] dark:text-white font-semibold">{inc.note}</span>
                    <span className="font-mono text-[#A0A0A0] shrink-0">{inc.time}</span>
                  </div>
                ))
              )}
            </div>

            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 space-y-2 max-h-40 overflow-y-auto">
              <div className="text-[11px] font-black uppercase tracking-wider text-[#FFD700]">
                Score Audit Trail ({auditTrail.length})
              </div>
              {auditTrail.slice(0, 12).map((a) => (
                <div key={a.id} className="text-[11px] flex items-center justify-between gap-2 border-b border-slate-200/50 dark:border-white/5 pb-1">
                  <span className="text-[#172033] dark:text-white truncate">
                    {a.action} {a.nextValue ? `(${a.nextValue})` : ''}
                  </span>
                  <span className="font-mono text-[10px] text-[#A0A0A0] shrink-0">
                    {a.timestamp}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Retirement / Walkover Modal */}
      {isRetireWalkoverOpen && activeMatch && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-[#141414] border border-slate-200 dark:border-[#D4AF37]/30 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-[#172033] dark:text-white flex items-center gap-2">
                <Flag className="w-4 h-4 text-[#D4AF37]" />
                <span>Match Retirement / Walkover</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsRetireWalkoverOpen(false)}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-white/10 text-[#64748B] dark:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {(['retired', 'walkover'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setRetireModeType(t)}
                  className={`py-2.5 rounded-xl text-xs font-black uppercase border cursor-pointer ${
                    retireModeType === t
                      ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] border-transparent'
                      : 'bg-[#F4F7FB] dark:bg-[#080808] text-[#64748B] dark:text-[#A0A0A0] border-slate-200 dark:border-white/15'
                  }`}
                >
                  {t === 'retired' ? 'Player Retired' : 'Walkover (W/O)'}
                </button>
              ))}
            </div>

            <div>
              <label className="text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1.5">
                {retireModeType === 'retired' ? 'Which player/team retired?' : 'Which player/team forfeited (absent)?'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRetireSide('A')}
                  className={`p-3 rounded-xl border text-xs font-bold cursor-pointer ${
                    retireSide === 'A'
                      ? 'border-[#EF4444] bg-[#EF4444]/10 text-[#EF4444]'
                      : 'border-slate-200 dark:border-white/15 text-[#172033] dark:text-white'
                  }`}
                >
                  {playerA}
                </button>
                <button
                  type="button"
                  onClick={() => setRetireSide('B')}
                  className={`p-3 rounded-xl border text-xs font-bold cursor-pointer ${
                    retireSide === 'B'
                      ? 'border-[#EF4444] bg-[#EF4444]/10 text-[#EF4444]'
                      : 'border-slate-200 dark:border-white/15 text-[#172033] dark:text-white'
                  }`}
                >
                  {playerB}
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] block mb-1">
                Referee Note (optional)
              </label>
              <input
                type="text"
                value={retireNote}
                onChange={(e) => setRetireNote(e.target.value)}
                placeholder="e.g. Ankle strain in Game 2"
                className="w-full px-3 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/15 text-xs text-[#172033] dark:text-white focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsRetireWalkoverOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRetiredOrWalkover}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-xs font-black cursor-pointer"
              >
                Award Match &amp; Review
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Match Completion Confirmation Modal */}
      {isCompleteConfirmOpen && activeMatch && matchWinner && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-[#141414] border border-slate-200 dark:border-[#D4AF37]/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-[#172033] dark:text-white flex items-center gap-2">
                <Trophy className="w-5 h-5 text-[#FFD700]" />
                <span>Confirm Match Completion</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsCompleteConfirmOpen(false)}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-white/10 text-[#64748B] dark:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-[#D4AF37]/25 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-[#64748B] dark:text-[#A0A0A0]">Winner</span>
                <span className="font-black text-[#9A7B1C] dark:text-[#FFD700]">
                  {matchWinner === 'A' ? playerA : playerB}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748B] dark:text-[#A0A0A0]">Final Games</span>
                <span className="font-mono font-black text-[#172033] dark:text-white">
                  {completedSets.length > 0
                    ? completedSets.map((s) => `${s.a}-${s.b}`).join(', ')
                    : `${pointsA}-${pointsB}`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748B] dark:text-[#A0A0A0]">Result Type</span>
                <span className="font-bold uppercase text-[#172033] dark:text-white">
                  {forcedOutcome ? forcedOutcome.type : 'Official Score'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748B] dark:text-[#A0A0A0]">Court</span>
                <span className="font-bold text-[#172033] dark:text-white">
                  {activeCourtObj?.name || `Court ${courtNumber}`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748B] dark:text-[#A0A0A0]">Match MVP</span>
                <span className="font-bold text-[#9A7B1C] dark:text-[#FFD700]">
                  {designateMvp ? (matchWinner === 'A' ? playerA : playerB) : 'Not Assigned'}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-[#F4F7FB] dark:bg-[#080808] border border-[#D4AF37]/30 space-y-2.5 text-xs">
              <label className="flex items-center justify-between gap-2 cursor-pointer">
                <span className="font-bold text-[#172033] dark:text-white flex items-center gap-1.5">
                  <ClipboardCheck className="w-4 h-4 text-[#22C55E]" />
                  <span>Referee Score Verification Sign-Off</span>
                </span>
                <input
                  type="checkbox"
                  checked={refereeVerified}
                  onChange={(e) => setRefereeVerified(e.target.checked)}
                  className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
                />
              </label>
              <input
                type="text"
                value={verifiedByName}
                onChange={(e) => setVerifiedByName(e.target.value)}
                placeholder="Verifying Referee Name"
                className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-[#141414] border border-slate-200 dark:border-white/15 text-xs font-semibold text-[#172033] dark:text-white"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsCompleteConfirmOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold text-[#64748B] dark:text-[#A0A0A0] cursor-pointer"
              >
                Back to Board
              </button>
              <button
                type="button"
                onClick={handleCommitMatchResult}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFD700] text-[#080808] text-xs font-black cursor-pointer shadow-lg"
              >
                Save Official Result
              </button>
            </div>
          </div>
        </div>
      )}

      <ShuttleTossModal
        isOpen={isTossOpen}
        onClose={() => setIsTossOpen(false)}
        playerAName={playerA}
        playerBName={playerB}
        onApplyTossResult={handleApplyTossResult}
      />

      {isBigScreenOpen && activeMatch && (
        <BigScreenScoreboard
          matchState={{
            matchId: selectedMatchId,
            playerAIndex: activeMatch.playerAIndex,
            playerBIndex: activeMatch.playerBIndex,
            currentSet,
            setScores: completedSets,
            currentPointsA: pointsA,
            currentPointsB: pointsB,
            server,
            servingSide: serverCourtSide,
            sideAOnLeft,
            history: [],
            courtNumber,
            equipment: {
              type: shuttleType,
              brand: shuttleBrand,
              speed: shuttleSpeed,
              shuttlesUsed,
            },
            status: timerActive ? 'interval' : 'in_progress',
          }}
          tournamentTitle={tournamentTitle}
          courtLabel={activeCourtObj?.name}
          playerAName={playerA}
          playerBName={playerB}
          playerAPhoto={photoA}
          playerBPhoto={photoB}
          servingPartnerLabel={isDoublesMatch ? activePartnerName : undefined}
          targetPoints={targetPoints}
          maxDeuceCap={maxDeuceCap}
          maxSets={getMaxSets(activeMatchFormat)}
          setsRequiredToWin={setsToWin}
          canUndo={history.length > 0 && !isUmpireLocked}
          canRedo={redoStack.length > 0 && !isUmpireLocked}
          onClose={() => setIsBigScreenOpen(false)}
          onAddPointA={() => handlePointScored('A')}
          onAddPointB={() => handlePointScored('B')}
          onUndo={handleUndoPoint}
          onRedo={handleRedoPoint}
        />
      )}

      <ConfirmModal
        isOpen={isResetConfirmOpen}
        title="Reset Match Scoreboard?"
        message="This will clear all current points, completed sets, and rally history for this live match."
        confirmText="Reset Scoreboard"
        cancelText="Keep Scoring"
        type="warning"
        onConfirm={executeResetCurrentMatch}
        onCancel={() => setIsResetConfirmOpen(false)}
      />
    </div>
  );
};
