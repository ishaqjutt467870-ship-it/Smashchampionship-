import React, { useState } from 'react';
import {
  Share2,
  Copy,
  Check,
  Download,
  Upload,
  X,
  Trash2,
  Printer,
  AlertCircle,
  FileSpreadsheet,
  Database,
  FileJson,
  FileArchive,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import { TournamentState, TournamentStore, PlayerStats, TournamentMatch } from '../types';
import { validateBackupPayload, BackupValidationResult } from '../utils/tournament';
import { ConfirmModal } from './ConfirmModal';
import {
  downloadStandingsCSV,
  downloadMatchesCSV,
  downloadTournamentAnalyticsCSV,
  downloadTournamentAnalyticsJSON,
  downloadTournamentZip,
} from '../utils/exports';

interface TournamentShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournamentState: TournamentState;
  fullStore?: TournamentStore;
  standings: PlayerStats[];
  fixtures?: TournamentMatch[];
  onImportState: (imported: TournamentState) => void;
  onImportFullStore?: (importedStore: TournamentStore) => void;
  onResetAll: () => void;
}

export const TournamentShareModal: React.FC<TournamentShareModalProps> = ({
  isOpen,
  onClose,
  tournamentState,
  fullStore,
  standings,
  fixtures = [],
  onImportState,
  onImportFullStore,
  onResetAll,
}) => {
  const [copied, setCopied] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);
  const [pendingImport, setPendingImport] = useState<{
    parsed: unknown;
    validation: BackupValidationResult;
  } | null>(null);

  if (!isOpen) return null;

  const championName =
    tournamentState.finalWinner !== null
      ? tournamentState.players[tournamentState.finalWinner]
      : 'In Progress';

  const standingsLines = standings
    .map(
      (s, i) =>
        `${i + 1}. ${s.name} — ${s.points} pts (W: ${s.won}, L: ${s.lost})`
    )
    .join('\n');

  const shareText = `🏸 *${tournamentState.tournamentTitle}*
📍 Venue: ${tournamentState.venue || 'Center Arena Court'}
🏆 Champion: ${championName}

📊 *Official Standings:*
${standingsLines}

Generated via Hassan Badminton Tournament Manager · Smash Championship.`;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadBackup = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(tournamentState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `smash-championship-${new Date().toISOString().slice(0, 10)}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleDownloadFullStoreBackup = () => {
    if (!fullStore) return;
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(fullStore, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `hassan-badminton-full-backup-${new Date().toISOString().slice(0, 10)}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportError(null);
    setPendingImport(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const validation = validateBackupPayload(
          parsed,
          fullStore?.tournaments || [tournamentState]
        );
        if (!validation.valid) {
          setImportError(validation.error || validation.summary);
          return;
        }
        setPendingImport({ parsed, validation });
      } catch {
        setImportError('Could not parse backup JSON file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleConfirmRestore = () => {
    if (!pendingImport) return;
    const { parsed, validation } = pendingImport;
    if (validation.kind === 'full_store' && onImportFullStore) {
      onImportFullStore(parsed as TournamentStore);
    } else if (validation.kind === 'single_tournament') {
      onImportState(parsed as TournamentState);
    }
    setPendingImport(null);
    onClose();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-white dark:bg-[#141414] w-full max-w-xl rounded-3xl border border-slate-200 dark:border-[#D4AF37]/30 shadow-2xl overflow-hidden animate-fade-in">
        <div className="p-6 bg-[#172B4D] dark:bg-[#080808] text-white flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/45 flex items-center justify-center text-[#FFD700]">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black">Backup, Restore &amp; Export</h3>
              <p className="text-xs text-[#A0A0A0]">
                Validated JSON restore, CSV spreadsheets &amp; ZIP archive
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#A0A0A0] hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* WhatsApp / Text Summary */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-[#172033] dark:text-[#A0A0A0] uppercase tracking-wider">
                Text / WhatsApp Summary
              </span>
              <button
                onClick={handleCopy}
                className="px-3 py-1 bg-[#172B4D] dark:bg-gradient-to-r dark:from-[#D4AF37] dark:to-[#FFD700] text-white dark:text-[#080808] text-xs font-black rounded-lg flex items-center gap-1.5 transition-opacity hover:opacity-90 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
              </button>
            </div>
            <textarea
              readOnly
              value={shareText}
              rows={5}
              className="w-full p-3 bg-[#F4F7FB] dark:bg-[#080808] border border-slate-200 dark:border-white/10 rounded-xl text-xs font-mono text-[#172033] dark:text-slate-200 focus:outline-none resize-none"
            />
          </div>

          {importError && (
            <div className="p-3 bg-[#EF4444]/10 border border-[#EF4444]/30 rounded-xl flex items-center justify-between text-xs text-[#EF4444]">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{importError}</span>
              </div>
              <button
                type="button"
                onClick={() => setImportError(null)}
                className="p-1 hover:bg-[#EF4444]/15 rounded"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Validated Backup Restore Confirmation Preview */}
          {pendingImport && (
            <div className="p-4 rounded-2xl border-2 border-[#D4AF37] bg-[#D4AF37]/10 space-y-3 text-xs animate-fade-in">
              <div className="flex items-center gap-2 text-[#9A7B1C] dark:text-[#FFD700] font-black">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>Backup Validated — Confirm Before Restoring</span>
              </div>
              <div className="text-[#172033] dark:text-white font-semibold">
                {pendingImport.validation.summary}
              </div>

              {(pendingImport.validation.duplicateIds.length > 0 ||
                pendingImport.validation.duplicateTitles.length > 0) && (
                <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-700 dark:text-amber-300 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block">Duplicate Data Detected:</strong>
                    <span>
                      Matches existing tournament(s):{' '}
                      {pendingImport.validation.duplicateTitles.join(', ') ||
                        pendingImport.validation.duplicateIds.join(', ')}
                      . Restoring will overwrite matching records.
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPendingImport(null)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-white/15 font-bold text-[#64748B] dark:text-[#A0A0A0] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmRestore}
                  className="px-4 py-1.5 rounded-xl bg-[#22C55E] text-[#080808] font-black cursor-pointer"
                >
                  Confirm Overwrite &amp; Restore
                </button>
              </div>
            </div>
          )}

          {/* CSV & JSON External Analysis Grid */}
          <div className="space-y-2.5">
            <span className="text-xs font-extrabold text-[#172033] dark:text-[#A0A0A0] uppercase tracking-wider block">
              External Analysis Exports (Standings &amp; Match History)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => downloadTournamentAnalyticsJSON(tournamentState, standings, fixtures)}
                className="p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 hover:bg-[#D4AF37]/15 text-left transition-colors flex items-start gap-3 cursor-pointer"
              >
                <FileJson className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <span className="font-black text-xs text-[#172033] dark:text-white block">
                    Export Standings &amp; History JSON
                  </span>
                  <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Structured rankings, set scores &amp; MVPs
                  </span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => downloadTournamentAnalyticsCSV(tournamentState, standings, fixtures)}
                className="p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 hover:bg-[#D4AF37]/15 text-left transition-colors flex items-start gap-3 cursor-pointer"
              >
                <FileSpreadsheet className="w-5 h-5 text-[#FFD700] shrink-0 mt-0.5" />
                <div>
                  <span className="font-black text-xs text-[#172033] dark:text-white block">
                    Export Combined CSV Report
                  </span>
                  <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Standings + full match history in one file
                  </span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => downloadStandingsCSV(tournamentState, standings)}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] hover:border-[#D4AF37] text-left transition-colors flex items-start gap-3 cursor-pointer"
              >
                <FileSpreadsheet className="w-5 h-5 text-[#22C55E] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-xs text-[#172033] dark:text-white block">
                    Export Standings CSV Only
                  </span>
                  <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Rankings, win %, sets &amp; points diff
                  </span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => downloadMatchesCSV(tournamentState, fixtures, standings)}
                className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#F4F7FB] dark:bg-[#080808] hover:border-[#D4AF37] text-left transition-colors flex items-start gap-3 cursor-pointer"
              >
                <FileSpreadsheet className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-xs text-[#172033] dark:text-white block">
                    Export Match History CSV Only
                  </span>
                  <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    League + playoff results, MVPs &amp; scores
                  </span>
                </div>
              </button>
            </div>

            <button
              type="button"
              onClick={() =>
                void downloadTournamentZip(tournamentState, standings, fixtures, fullStore)
              }
              className="w-full p-3.5 rounded-2xl border border-[#FFD700]/50 bg-[#FFD700]/10 hover:bg-[#FFD700]/15 text-left transition-colors flex items-center justify-between gap-3 cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <FileArchive className="w-5 h-5 text-[#FFD700] shrink-0 mt-0.5" />
                <div>
                  <span className="font-black text-xs text-[#172033] dark:text-white block">
                    Download Complete Export Bundle (.ZIP)
                  </span>
                  <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Includes Analytics JSON, all CSVs, Official Report (.md), &amp; JSON Backups
                  </span>
                </div>
              </div>
              <Download className="w-4 h-4 text-[#FFD700] shrink-0" />
            </button>
          </div>

          {/* JSON Backup & Restore Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={handleDownloadBackup}
              className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 hover:border-[#22C55E] text-left transition-colors flex items-start gap-3 cursor-pointer"
            >
              <Download className="w-5 h-5 text-[#22C55E] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-xs text-[#172033] dark:text-white block">
                  Export Active Tournament JSON
                </span>
                <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  Save current tournament fixtures &amp; bios
                </span>
              </div>
            </button>

            <label className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 hover:border-[#D4AF37] text-left transition-colors flex items-start gap-3 cursor-pointer">
              <Upload className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-xs text-[#172033] dark:text-white block">
                  Restore Backup (Validated)
                </span>
                <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                  Validates schema &amp; checks duplicates first
                </span>
              </div>
              <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          {fullStore && (
            <button
              type="button"
              onClick={handleDownloadFullStoreBackup}
              className="w-full p-3.5 rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 hover:bg-[#D4AF37]/15 text-left transition-colors flex items-center justify-between gap-3 cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <Database className="w-5 h-5 text-[#FFD700] shrink-0 mt-0.5" />
                <div>
                  <span className="font-black text-xs text-[#172033] dark:text-white block">
                    Export Complete App Backup ({fullStore.tournaments.length} Tournaments)
                  </span>
                  <span className="text-[11px] text-[#64748B] dark:text-[#A0A0A0]">
                    Includes rankings formula, courts, teams, themes, wallpapers &amp; settings
                  </span>
                </div>
              </div>
              <Download className="w-4 h-4 text-[#FFD700] shrink-0" />
            </button>
          )}

          {/* Quick Print & Danger Actions */}
          <div className="pt-4 border-t border-slate-100 dark:border-white/10 flex items-center justify-between">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 rounded-xl bg-[#F4F7FB] dark:bg-[#080808] hover:opacity-90 text-[#172033] dark:text-slate-300 border border-slate-200 dark:border-white/10 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Scoresheet</span>
            </button>

            <button
              onClick={() => setConfirmResetOpen(true)}
              className="px-3.5 py-2 rounded-xl border border-[#EF4444]/40 text-[#EF4444] hover:bg-[#EF4444]/10 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Factory Reset</span>
            </button>
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={confirmResetOpen}
        title="Reset Active Tournament?"
        message="This will reset matches, scores, players, and recorded results for this tournament back to defaults. Are you sure?"
        confirmText="Reset Tournament"
        cancelText="Cancel"
        type="danger"
        onConfirm={() => {
          setConfirmResetOpen(false);
          onResetAll();
          onClose();
        }}
        onCancel={() => setConfirmResetOpen(false)}
      />
    </div>
  );
};
