import React from 'react';
import { Award, ArrowRight, ShieldCheck, Flame, Trophy, Download, FileJson, FileArchive } from 'lucide-react';
import { PlayerStats, TournamentFormatType, TournamentMatch, TournamentState } from '../types';
import { getInitials, calculateTournamentAwards } from '../utils/tournament';
import {
  downloadTournamentAnalyticsCSV,
  downloadTournamentAnalyticsJSON,
  downloadTournamentZip,
} from '../utils/exports';
import { PerformanceCharts } from './PerformanceCharts';

interface StandingsTableProps {
  standings: PlayerStats[];
  tournamentState?: TournamentState;
  fixtures?: TournamentMatch[];
  tournamentFormat?: TournamentFormatType;
  onNavigateToKnockout: () => void;
  allMatchesDone: boolean;
  onOpenPlayerProfile?: (playerId: number) => void;
}

export const StandingsTable: React.FC<StandingsTableProps> = ({
  standings,
  tournamentState,
  fixtures,
  tournamentFormat = 'round_robin',
  onNavigateToKnockout,
  allMatchesDone,
  onOpenPlayerProfile,
}) => {
  const isGroupStage = tournamentFormat === 'group_stage';
  const groupA = standings.filter((p) => p.group === 'A');
  const groupB = standings.filter((p) => p.group === 'B');
  const awards = calculateTournamentAwards(standings);

  const renderTableRows = (rows: PlayerStats[], qualifyCutoff: number) => (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead className="bg-[#F4F7FB] dark:bg-[#07111F] text-[#64748B] dark:text-[#94A3B8] text-xs font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
          <tr>
            <th scope="col" className="py-3.5 pl-4 sm:pl-6 pr-2 w-12 text-center">
              Pos
            </th>
            <th scope="col" className="py-3.5 px-3">
              Player
            </th>
            <th scope="col" className="py-3.5 px-3 text-center">
              MP
            </th>
            <th scope="col" className="py-3.5 px-3 text-center text-[#22C55E] font-bold">
              W
            </th>
            <th scope="col" className="py-3.5 px-3 text-center text-[#EF4444]">
              L
            </th>
            <th scope="col" className="py-3.5 px-3 text-center hidden md:table-cell">
              Sets
            </th>
            <th scope="col" className="py-3.5 px-3 text-center hidden sm:table-cell">
              Diff
            </th>
            <th
              scope="col"
              className="py-3.5 px-3 text-center text-[#172033] dark:text-[#B7F34A] font-black"
            >
              Pts
            </th>
            <th scope="col" className="py-3.5 pl-3 pr-4 sm:pr-6 text-center hidden lg:table-cell">
              Form
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
          {rows.map((player, index) => {
            const isQualified = index < qualifyCutoff;
            const isCutoff = index === qualifyCutoff - 1;
            const pointDiff = player.pointsFor - player.pointsAgainst;

            return (
              <React.Fragment key={player.id}>
                <tr
                  className={`transition-colors ${
                    isQualified
                      ? 'bg-[#8BCB35]/5 dark:bg-[#B7F34A]/5 hover:bg-[#8BCB35]/10'
                      : 'hover:bg-[#F4F7FB] dark:hover:bg-[#07111F]/60'
                  }`}
                >
                  <td className="py-3.5 pl-4 sm:pl-6 pr-2 text-center">
                    <div className="flex items-center justify-center">
                      <span
                        className={`w-6 h-6 rounded-full font-black text-xs flex items-center justify-center ${
                          index === 0
                            ? 'bg-[#B7F34A] text-[#07111F]'
                            : index === 1
                            ? 'bg-[#38BDF8] text-[#07111F]'
                            : index < qualifyCutoff
                            ? 'bg-[#172B4D] dark:bg-slate-700 text-white'
                            : 'text-[#64748B] dark:text-[#94A3B8]'
                        }`}
                      >
                        {index + 1}
                      </span>
                    </div>
                  </td>

                  <td className="py-3.5 px-3">
                    <div
                      onClick={() => onOpenPlayerProfile?.(player.id)}
                      className="flex items-center gap-2.5 cursor-pointer group"
                    >
                      {player.photo ? (
                        <img
                          src={player.photo}
                          alt={player.name}
                          className="w-8 h-8 rounded-xl object-cover border border-[#B7F34A]/50 shrink-0"
                        />
                      ) : (
                        <div
                          className="w-8 h-8 rounded-xl flex items-center justify-center text-[#07111F] font-black text-[11px] shrink-0"
                          style={{ backgroundColor: player.avatarColor }}
                        >
                          {getInitials(player.name)}
                        </div>
                      )}
                      <div>
                        <span className="font-bold text-[#172033] dark:text-white group-hover:text-[#B7F34A] transition-colors block leading-tight">
                          {player.name}
                        </span>
                        <span className="text-[10px] text-[#64748B] dark:text-[#94A3B8] block">
                          {player.bio?.playStyle || 'Competitor'}
                        </span>
                      </div>
                    </div>
                  </td>

                  <td className="py-3.5 px-3 text-center text-xs font-semibold text-[#64748B] dark:text-[#94A3B8] tabular-nums">
                    {player.played}
                  </td>
                  <td className="py-3.5 px-3 text-center text-xs font-black text-[#22C55E] tabular-nums">
                    {player.won}
                  </td>
                  <td className="py-3.5 px-3 text-center text-xs font-bold text-[#EF4444] tabular-nums">
                    {player.lost}
                  </td>
                  <td className="py-3.5 px-3 text-center text-xs text-[#64748B] dark:text-[#94A3B8] tabular-nums hidden md:table-cell">
                    {player.setsWon > 0 || player.setsLost > 0
                      ? `${player.setsWon} - ${player.setsLost}`
                      : '—'}
                  </td>
                  <td className="py-3.5 px-3 text-center text-xs tabular-nums hidden sm:table-cell">
                    <span
                      className={`font-bold ${
                        pointDiff > 0
                          ? 'text-[#22C55E]'
                          : pointDiff < 0
                          ? 'text-[#EF4444]'
                          : 'text-[#64748B]'
                      }`}
                    >
                      {pointDiff > 0 ? `+${pointDiff}` : pointDiff}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 text-center">
                    <span className="inline-block px-2.5 py-1 rounded-lg bg-[#8BCB35]/15 dark:bg-[#B7F34A]/15 text-[#172B4D] dark:text-[#B7F34A] font-black text-sm tabular-nums">
                      {player.points}
                    </span>
                  </td>
                  <td className="py-3.5 pl-3 pr-4 sm:pr-6 text-center hidden lg:table-cell">
                    <div className="flex items-center justify-center gap-1">
                      {player.form.length === 0 ? (
                        <span className="text-[11px] text-[#64748B]">—</span>
                      ) : (
                        player.form.slice(-5).map((res, fIdx) => (
                          <span
                            key={fIdx}
                            className={`w-4 h-4 rounded text-[9px] font-black flex items-center justify-center ${
                              res === 'W'
                                ? 'bg-[#22C55E] text-[#07111F]'
                                : 'bg-slate-400 dark:bg-slate-700 text-white'
                            }`}
                          >
                            {res}
                          </span>
                        ))
                      )}
                    </div>
                  </td>
                </tr>

                {isCutoff && rows.length > qualifyCutoff && (
                  <tr className="bg-[#38BDF8]/10">
                    <td
                      colSpan={9}
                      className="py-1 px-4 text-center text-[10px] font-extrabold tracking-wider text-[#0284C7] dark:text-[#38BDF8] uppercase border-y border-[#38BDF8]/30"
                    >
                      ▲ Top {qualifyCutoff} Qualify for Knockout Stage ▲
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white dark:bg-[#111E30] rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-[#172033] dark:text-white tracking-tight">
                {isGroupStage ? 'Group Stage Standings (A & B)' : 'Official League Standings'}
              </h2>
              {allMatchesDone && (
                <span className="text-xs font-extrabold text-[#22C55E] bg-[#22C55E]/15 px-2.5 py-0.5 rounded-full border border-[#22C55E]/30 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Finalized</span>
                </span>
              )}
            </div>
            <p className="text-xs text-[#64748B] dark:text-[#94A3B8] mt-0.5">
              {isGroupStage
                ? 'Top 2 from Group A and Top 2 from Group B qualify for Semi-Finals.'
                : 'Top 4 players advance to Semi-Finals. Tap any player for career stats.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto shrink-0">
            {tournamentState && (
              <>
                <button
                  type="button"
                  onClick={() =>
                    downloadTournamentAnalyticsCSV(tournamentState, standings, fixtures)
                  }
                  className="px-3 py-2 bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 hover:border-[#38BDF8] text-[#172033] dark:text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Export Standings & Match History as CSV"
                >
                  <Download className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Export CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    downloadTournamentAnalyticsJSON(tournamentState, standings, fixtures)
                  }
                  className="px-3 py-2 bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 hover:border-[#B7F34A] text-[#172033] dark:text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Export Standings & Match History as JSON for analysis"
                >
                  <FileJson className="w-3.5 h-3.5 text-[#8BCB35] dark:text-[#B7F34A]" />
                  <span>Export JSON</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    void downloadTournamentZip(tournamentState, standings, fixtures)
                  }
                  className="px-3 py-2 bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200 dark:border-slate-700 hover:border-amber-400 text-[#172033] dark:text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                  title="Download complete ZIP bundle (JSON, CSVs, Report, Backup)"
                >
                  <FileArchive className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                  <span>Export ZIP</span>
                </button>
              </>
            )}

            <button
              onClick={onNavigateToKnockout}
              className="px-4 py-2 bg-[#172B4D] dark:bg-[#B7F34A] text-white dark:text-[#07111F] font-extrabold text-xs rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <Award className="w-4 h-4" />
              <span>Playoff Bracket</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {isGroupStage ? (
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            <div>
              <div className="px-5 py-2.5 bg-[#B7F34A]/15 text-xs font-black uppercase tracking-wider text-[#172B4D] dark:text-[#B7F34A]">
                Group A Standings
              </div>
              {renderTableRows(groupA, 2)}
            </div>
            <div>
              <div className="px-5 py-2.5 bg-[#38BDF8]/15 text-xs font-black uppercase tracking-wider text-[#0284C7] dark:text-[#38BDF8]">
                Group B Standings
              </div>
              {renderTableRows(groupB, 2)}
            </div>
          </div>
        ) : (
          renderTableRows(standings, 4)
        )}

        <div className="p-4 bg-[#F4F7FB] dark:bg-[#07111F] border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-[#64748B] dark:text-[#94A3B8] gap-2">
          <div>
            <strong>Scoring:</strong> Win = 2 pts · Loss = 0 pts. Tie-breaker: Wins → Set Diff → Point Diff.
          </div>
          <div className="flex items-center gap-2">
            <Flame className="w-3.5 h-3.5 text-[#8BCB35] dark:text-[#B7F34A]" />
            <span>
              {isGroupStage ? 'Semi-Finals: A1 vs B2 · B1 vs A2' : 'Semi-Finals: 1st vs 4th · 2nd vs 3rd'}
            </span>
          </div>
        </div>
      </div>

      {/* Tournament Awards Showcase */}
      {awards.mvp && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-[#111E30] rounded-3xl p-4 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#B7F34A]/20 text-[#172B4D] dark:text-[#B7F34A] flex items-center justify-center">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#94A3B8]">
                Tournament MVP
              </span>
              <div className="text-sm font-black text-[#172033] dark:text-white">
                {awards.mvp.name}
              </div>
              <div className="text-[11px] font-mono text-[#22C55E]">
                {awards.mvp.points} League Pts
              </div>
            </div>
          </div>

          {awards.topScorer && (
            <div className="bg-white dark:bg-[#111E30] rounded-3xl p-4 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#38BDF8]/20 text-[#0284C7] dark:text-[#38BDF8] flex items-center justify-center font-black">
                ⚡
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#94A3B8]">
                  Top Rally Scorer
                </span>
                <div className="text-sm font-black text-[#172033] dark:text-white">
                  {awards.topScorer.name}
                </div>
                <div className="text-[11px] font-mono text-[#38BDF8]">
                  {awards.topScorer.pointsFor} Points Won
                </div>
              </div>
            </div>
          )}

          {awards.bestWinRate && (
            <div className="bg-white dark:bg-[#111E30] rounded-3xl p-4 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#22C55E]/20 text-[#22C55E] flex items-center justify-center font-black">
                %
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#94A3B8]">
                  Best Win Percentage
                </span>
                <div className="text-sm font-black text-[#172033] dark:text-white">
                  {awards.bestWinRate.name}
                </div>
                <div className="text-[11px] font-mono text-[#22C55E]">
                  {Math.round((awards.bestWinRate.won / awards.bestWinRate.played) * 100)}% Win Rate
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Performance Graphs & Visual Analytics */}
      <PerformanceCharts
        standings={standings}
        onOpenPlayerProfile={onOpenPlayerProfile}
      />
    </div>
  );
};
