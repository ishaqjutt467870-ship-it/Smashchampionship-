import React from 'react';
import { BarChart3, Shield, TrendingUp } from 'lucide-react';
import { PlayerStats } from '../types';
import { getInitials } from '../utils/tournament';

interface PerformanceChartsProps {
  standings: PlayerStats[];
  onOpenPlayerProfile?: (playerId: number) => void;
}

export const PerformanceCharts: React.FC<PerformanceChartsProps> = ({
  standings,
  onOpenPlayerProfile,
}) => {
  const active = standings.filter((p) => p.played > 0);
  if (active.length === 0) return null;

  const maxPointsScale = Math.max(
    1,
    ...active.map((p) => Math.max(p.pointsFor, p.pointsAgainst))
  );

  const byWinRate = [...active].sort((a, b) => {
    const ra = a.won / a.played;
    const rb = b.won / b.played;
    if (rb !== ra) return rb - ra;
    return b.won - a.won;
  });

  const bestDefense = [...active].sort(
    (a, b) => a.pointsAgainst / a.played - b.pointsAgainst / b.played
  )[0];

  const highestDiff = [...active].sort(
    (a, b) => b.pointsFor - b.pointsAgainst - (a.pointsFor - a.pointsAgainst)
  )[0];

  return (
    <div className="bg-white dark:bg-[#111E30] theme-card rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-[#8BCB35] dark:text-[#B7F34A]" />
          <div>
            <h3 className="text-base sm:text-lg font-black text-[#172033] dark:text-white tracking-tight">
              Tournament Performance Graphs &amp; Analytics
            </h3>
            <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">
              Win percentage leaders, rally points scored vs conceded, and net differential
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-[11px] text-[#64748B] dark:text-[#94A3B8]">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#8BCB35] dark:bg-[#B7F34A]" />
            <span>Points Scored</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#38BDF8]" />
            <span>Conceded</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Win Percentage Leaderboard */}
        <div className="space-y-3">
          <div className="text-xs font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8] flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-[#22C55E]" />
            <span>Win Percentage Ranking</span>
          </div>

          <div className="space-y-2.5">
            {byWinRate.slice(0, 8).map((p) => {
              const pct = Math.round((p.won / p.played) * 100);
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onOpenPlayerProfile?.(p.id)}
                  className="w-full text-left group cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-5 h-5 rounded-md flex items-center justify-center text-[9px] font-black text-[#07111F] shrink-0"
                        style={{ backgroundColor: p.avatarColor }}
                      >
                        {getInitials(p.name)}
                      </span>
                      <span className="font-bold text-[#172033] dark:text-white group-hover:text-[#B7F34A] transition-colors truncate">
                        {p.name}
                      </span>
                    </div>
                    <span className="font-mono font-black text-[#172033] dark:text-[#B7F34A] tabular-nums shrink-0 pl-2">
                      {pct}% ({p.won}/{p.played})
                    </span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-[#F4F7FB] dark:bg-[#07111F] overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[#8BCB35] to-[#38BDF8] dark:from-[#B7F34A] dark:to-[#38BDF8] transition-all duration-500"
                      style={{ width: `${Math.max(4, pct)}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Chart 2: Points Scored vs Conceded Dual Bar Chart */}
        <div className="space-y-3">
          <div className="text-xs font-black uppercase tracking-wider text-[#64748B] dark:text-[#94A3B8]">
            Points Scored vs Points Conceded
          </div>

          <div className="space-y-3">
            {active.slice(0, 8).map((p) => {
              const forW = Math.round((p.pointsFor / maxPointsScale) * 100);
              const againstW = Math.round((p.pointsAgainst / maxPointsScale) * 100);
              const diff = p.pointsFor - p.pointsAgainst;
              return (
                <div key={p.id} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[#172033] dark:text-white truncate max-w-[55%]">
                      {p.name}
                    </span>
                    <div className="flex items-center gap-2 font-mono text-[11px] tabular-nums">
                      <span className="text-[#8BCB35] dark:text-[#B7F34A] font-bold">
                        +{p.pointsFor}
                      </span>
                      <span className="text-[#38BDF8] font-bold">-{p.pointsAgainst}</span>
                      <span
                        className={`font-black ${
                          diff > 0
                            ? 'text-[#22C55E]'
                            : diff < 0
                            ? 'text-[#EF4444]'
                            : 'text-[#64748B]'
                        }`}
                      >
                        ({diff > 0 ? `+${diff}` : diff})
                      </span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="w-full h-2 rounded-full bg-[#F4F7FB] dark:bg-[#07111F] overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#8BCB35] dark:bg-[#B7F34A] transition-all duration-500"
                        style={{ width: `${Math.max(3, forW)}%` }}
                      />
                    </div>
                    <div className="w-full h-2 rounded-full bg-[#F4F7FB] dark:bg-[#07111F] overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#38BDF8] transition-all duration-500"
                        style={{ width: `${Math.max(3, againstW)}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Extra Defensive & Differential Insights */}
      {(bestDefense || highestDiff) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
          {bestDefense && (
            <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#38BDF8]/15 text-[#0284C7] dark:text-[#38BDF8] flex items-center justify-center shrink-0">
                <Shield className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#94A3B8]">
                  Iron Wall Defense (Avg Conceded / Match)
                </div>
                <div className="font-black text-[#172033] dark:text-white truncate">
                  {bestDefense.name} · {(bestDefense.pointsAgainst / bestDefense.played).toFixed(1)} pts/match
                </div>
              </div>
            </div>
          )}

          {highestDiff && (
            <div className="p-3.5 rounded-2xl bg-[#F4F7FB] dark:bg-[#07111F] border border-slate-200/80 dark:border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#B7F34A]/20 text-[#172B4D] dark:text-[#B7F34A] flex items-center justify-center shrink-0 font-black">
                +/-
              </div>
              <div className="min-w-0">
                <div className="text-[10px] font-bold uppercase text-[#64748B] dark:text-[#94A3B8]">
                  Highest Net Point Differential
                </div>
                <div className="font-black text-[#172033] dark:text-white truncate">
                  {highestDiff.name} ·{' '}
                  {highestDiff.pointsFor - highestDiff.pointsAgainst >= 0
                    ? `+${highestDiff.pointsFor - highestDiff.pointsAgainst}`
                    : highestDiff.pointsFor - highestDiff.pointsAgainst}{' '}
                  pts
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
